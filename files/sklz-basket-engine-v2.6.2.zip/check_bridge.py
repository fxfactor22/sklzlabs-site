"""SKLZ — check the ClusterDelta bridge.

Run this on the VPS from the folder where learn_main.py lives:

    python check_bridge.py

It answers one question: is real ClusterDelta delta reaching the bot, or is
it falling back to tick inference? No guessing from log lines.
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _suggest_buffers(status: str) -> None:
    """Read the EA's buffer scan and work out which index holds what.

    Ask and bid volume are positive counts; delta should equal ask minus bid.
    That arithmetic identifies them without guessing.
    """
    import re
    vals = {}
    for line in status.split("\n"):
        m = re.match(r"\s*(\d+):\s*(.+)", line)
        if not m:
            continue
        idx = int(m.group(1))
        body = m.group(2).strip()
        if body.lower().startswith("none"):
            continue
        try:
            nums = [float(x) for x in body.split()]
        except ValueError:
            continue
        if nums:
            vals[idx] = nums

    live = {i: v for i, v in vals.items() if any(abs(x) > 0 for x in v)}
    if not live:
        print("  Every buffer read as zero or empty. Either the indicator has")
        print("  not calculated yet (give it a minute on a fresh chart), or it")
        print("  needs its DLL — Tools > Options > Expert Advisors >")
        print("  Allow DLL imports.")
        return

    print(f"  buffers with data: {sorted(live)}")

    # Identify ask / bid / delta by arithmetic: delta = ask - bid.
    # Several triples can satisfy that, so prefer the one where ask + bid
    # also equals another buffer (the total volume) — that disambiguates.
    idxs = sorted(live)
    candidates = []
    for a in idxs:
        for b in idxs:
            if a == b:
                continue
            for d in idxs:
                if d in (a, b):
                    continue
                n = min(len(live[a]), len(live[b]), len(live[d]))
                if n == 0:
                    continue
                if not all(abs((live[a][k] - live[b][k]) - live[d][k]) < 1.0
                           for k in range(n)):
                    continue
                if not (all(x >= 0 for x in live[a][:n])
                        and all(x >= 0 for x in live[b][:n])):
                    continue
                # does some buffer hold ask + bid? that is total volume, and
                # its presence tells us we have the right pair
                total_idx = None
                for t in idxs:
                    if t in (a, b, d):
                        continue
                    m = min(n, len(live[t]))
                    if m and all(abs((live[a][k] + live[b][k]) - live[t][k]) < 1.0
                                 for k in range(m)):
                        total_idx = t
                        break
                candidates.append((a, b, d, total_idx))

    if not candidates:
        print("  Could not identify ask/bid/delta automatically.")
        print("  Compare the numbers above with what the indicator shows on")
        print("  the chart, or check DemoVolumes.mq5.")
        return

    # a candidate corroborated by a total-volume buffer is the confident one
    confirmed = [c for c in candidates if c[3] is not None]
    pick = confirmed[0] if confirmed else candidates[0]
    a, b, d, t = pick

    print(f"  LIKELY: ask={a}  bid={b}  delta={d}"
          + (f"  (total volume in buffer {t})" if t is not None else ""))
    print(f"          buffer {a} minus buffer {b} equals buffer {d}"
          + (f", and {a}+{b} equals {t}" if t is not None else ""))
    print(f"  Set InpBufAsk={a}, InpBufBid={b}, InpBufDelta={d}, "
          f"InpBufCumDelta=-1")

    if len(candidates) > 1 and not confirmed:
        print()
        print(f"  NOTE: {len(candidates)} buffer combinations fit the same")
        print("  arithmetic, so this is a best guess rather than certain.")
        for a2, b2, d2, _ in candidates[:4]:
            print(f"    ask={a2} bid={b2} delta={d2}")
        print("  Check DemoVolumes.mq5 to confirm which is correct.")


def main() -> None:
    print("SKLZ bridge check")
    print("=" * 58)

    # 1. can we find the terminal's Files folder?
    try:
        import MetaTrader5 as mt5
    except ImportError:
        print("FAIL  MetaTrader5 package not installed in this Python.")
        return

    if not mt5.initialize():
        print("FAIL  Could not connect to MT5. Is the terminal running?")
        return

    info = mt5.terminal_info()
    files_dir = os.path.join(getattr(info, "data_path", ""), "MQL5", "Files")
    print(f"terminal files: {files_dir}")
    if not os.path.isdir(files_dir):
        print("FAIL  That folder does not exist. Check the terminal is the")
        print("      one the bot is attached to.")
        mt5.shutdown()
        return

    # 2. which bridge files exist?
    found = [f for f in os.listdir(files_dir)
             if f.startswith("sklz_delta_") and f.endswith(".csv")]

    # the EA writes a status file when it cannot read the buffers — read it
    # rather than making the user go hunting through MT5's tabs
    status_path = os.path.join(files_dir, "sklz_bridge_status.txt")
    if os.path.exists(status_path):
        try:
            with open(status_path, encoding="ascii", errors="ignore") as f:
                status = f.read()
        except Exception:
            status = ""
        if status:
            print("EA status report:")
            print("-" * 58)
            print(status.strip())
            print("-" * 58)
            _suggest_buffers(status)
            print()

    if not found:
        print("FAIL  No sklz_delta_*.csv files.")
        if os.path.exists(status_path):
            print("      The EA is running but could not read the buffers —")
            print("      see the report above for which indices actually hold data.")
        else:
            print("      The EA is not writing anything at all. Check that it is")
            print("      attached to a chart and that Algo Trading is enabled.")
        mt5.shutdown()
        return

    print(f"bridge files:   {len(found)}")
    print()

    # 3. is each one fresh, and does it contain real numbers?
    import csv
    ok_count = 0
    for name in sorted(found):
        path = os.path.join(files_dir, name)
        age = time.time() - os.path.getmtime(path)
        symbol = name[len("sklz_delta_"):-4]

        try:
            with open(path, newline="", encoding="ascii", errors="ignore") as f:
                rows = list(csv.DictReader(f))
        except Exception as exc:
            print(f"  {symbol:14} FAIL  cannot read: {exc}")
            continue

        if not rows:
            print(f"  {symbol:14} FAIL  file is empty")
            continue

        nonzero = 0
        buy = sell = 0.0
        for r in rows:
            try:
                a = float(r.get("ask_volume") or 0)
                b = float(r.get("bid_volume") or 0)
            except (TypeError, ValueError):
                continue
            if a or b:
                nonzero += 1
                buy += a
                sell += b

        if age > 180:
            print(f"  {symbol:14} STALE {age/60:.0f} min old — EA stopped?")
            continue
        if nonzero == 0:
            print(f"  {symbol:14} FAIL  {len(rows)} rows but every volume is 0")
            print(f"  {'':14}       -> the buffer indices in the EA are wrong.")
            print(f"  {'':14}       Open DemoVolumes.mq5 and check which")
            print(f"  {'':14}       CopyBuffer index holds ask / bid volume.")
            continue

        delta = buy - sell
        print(f"  {symbol:14} OK    {nonzero} bars, {age:.0f}s old")
        print(f"  {'':14}       ask {buy:,.0f}  bid {sell:,.0f}  "
              f"delta {delta:+,.0f}")
        ok_count += 1

    print()

    # 4. does the bot's own reader agree?
    try:
        from basket_engine.mt5io import BasketIO
        from basket_engine.learn import orderflow as OF
        io = BasketIO.__new__(BasketIO)
        io.mt5 = mt5
        io._sym_cache = {}
        io._sym_fill = {}
        for name in sorted(found)[:3]:
            symbol = name[len("sklz_delta_"):-4]
            r = OF.read_bridge(symbol, io)
            verdict = "MEASURED" if r.quality == "measured" else "not used"
            print(f"bot reader: {symbol:14} {verdict}  — {r.note}")
    except Exception as exc:
        print(f"bot reader: could not run ({type(exc).__name__}: {exc})")

    print()
    print("=" * 58)
    if ok_count:
        print(f"{ok_count} symbol(s) supplying real ClusterDelta volumes.")
        print("Those will score on MEASURED delta. Everything else in your")
        print("scan list still uses tick inference, which is fine but less")
        print("precise — attach the EA to more charts to widen coverage.")
    else:
        print("No symbol is supplying usable data yet. The bot will keep")
        print("working on tick-inferred delta; it just will not benefit")
        print("from ClusterDelta until the above is resolved.")

    mt5.shutdown()


if __name__ == "__main__":
    main()
