//+------------------------------------------------------------------+
//|                                            SKLZ_DeltaBridge.mq5  |
//|  Reads ClusterDelta's #Volume_AskBid_Delta buffers and writes    |
//|  them to a CSV the SKLZ Python runner reads.                     |
//|                                                                  |
//|  WHY THIS EXISTS                                                 |
//|  MT5 custom indicators keep their values in buffers inside the   |
//|  terminal. The MetaTrader5 Python package has no way to read     |
//|  them - there is no copy_buffer(). iCustom() can, but only from  |
//|  MQL. So this EA sits in the middle: it reads the buffers and    |
//|  writes them somewhere Python can see.                           |
//|                                                                  |
//|  SETUP                                                           |
//|  1. Put ClusterDelta's indicators in MQL5/Indicators/ as their   |
//|     installer instructs.                                         |
//|  2. Open DemoVolumes.mq5 and check the BUFFER INDICES below      |
//|     match what it uses. They differ between versions.            |
//|  3. Attach this EA to ONE chart per symbol you want delta for.   |
//|  4. Allow DLL imports (ClusterDelta needs them) and AutoTrading. |
//+------------------------------------------------------------------+
#property copyright "SKLZ Labs"
#property version   "1.00"
#property strict

//--- ClusterDelta indicator to read
//--- leave blank to auto-discover; set explicitly to override
input string   InpIndicator     = "";
input int      InpTimeframeMin  = 15;      // bar timeframe to export
input int      InpBars          = 200;     // how much history to write

//--- BUFFER INDICES - verify these against DemoVolumes.mq5.
//--- If the numbers are wrong you will get zeros or nonsense, not an error,
//--- so check rather than assume.
input int      InpBufAsk        = 0;       // ask (buy) volume
input int      InpBufBid        = 1;       // bid (sell) volume
input int      InpBufDelta      = 2;       // delta
input int      InpBufCumDelta   = 3;       // cumulative delta (-1 if absent)

//--- output
input int      InpRefreshSec    = 5;       // how often to rewrite the file
input bool     InpDumpBuffers   = false;   // true = print all buffers once,
                                           // to identify which is which
input bool     InpVerbose       = true;

int      hIndicator = INVALID_HANDLE;
string   loadedName = "";
string   CRLF       = "\r\n";
datetime lastWrite  = 0;
string   fileName   = "";

//+------------------------------------------------------------------+
int OnInit()
  {
   fileName = StringFormat("sklz_delta_%s.csv", _Symbol);

   ENUM_TIMEFRAMES tf = MinutesToTimeframe(InpTimeframeMin);
   string used = "";

   if(StringLen(InpIndicator) > 0)
     {
      hIndicator = iCustom(_Symbol, tf, InpIndicator);
      used = InpIndicator;
     }
   else
     {
      // ClusterDelta installs under different names depending on version and
      // whether the developer archive was used. Try the known variants rather
      // than making the user guess.
      string candidates[] =
        {
         "#Volume_AskBid_Delta",
         "ClusterDelta_#Volume_AskBid_Delta",
         "ClusterDelta\\#Volume_AskBid_Delta",
         "ClusterDelta/#Volume_AskBid_Delta",
         "#Footprint_for_EA",
         "ClusterDelta_#Footprint_for_EA",
         "ClusterDelta\\#Footprint_for_EA",
         "ClusterDelta_#Volumes",
         "ClusterDelta_#Delta",
         "ClusterDelta_#AskBid"
        };
      for(int i = 0; i < ArraySize(candidates); i++)
        {
         int h = iCustom(_Symbol, tf, candidates[i]);
         if(h != INVALID_HANDLE)
           {
            hIndicator = h;
            used = candidates[i];
            break;
           }
        }
     }

   if(hIndicator == INVALID_HANDLE)
     {
      Print("SKLZ bridge: could not load any ClusterDelta indicator.");
      Print("  Tried the common names and none loaded.");
      Print("  Look in Navigator > Indicators for the exact name, then set");
      Print("  it in the EA's Inputs tab as InpIndicator.");
      Print("  If it sits in a subfolder, use  Subfolder\\IndicatorName");
      Print("  Also check Tools > Options > Expert Advisors > Allow DLL imports,");
      Print("  which ClusterDelta requires.");
      Print("  Without this the Python bot uses tick-inferred delta instead —");
      Print("  it still works, just less precisely.");
      return(INIT_FAILED);
     }

   loadedName = used;
   Print("SKLZ bridge: loaded indicator '", used, "'");

   if(InpVerbose)
     {
      Print("SKLZ bridge running.");
      Print("  indicator: ", used);
      Print("  writing:   MQL5/Files/", fileName);
      Print("  buffers:   ask=", InpBufAsk, " bid=", InpBufBid,
            " delta=", InpBufDelta, " cum=", InpBufCumDelta);
      Print("  If values look wrong, the buffer indices are wrong - check");
      Print("  DemoVolumes.mq5 for the correct ones.");
     }
   if(InpDumpBuffers)
      DumpBuffers();

   EventSetTimer(InpRefreshSec);
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   EventKillTimer();
   if(hIndicator != INVALID_HANDLE)
      IndicatorRelease(hIndicator);
  }

//+------------------------------------------------------------------+
//| Print the last few values of every buffer, so the correct indices |
//| can be read off rather than guessed.                              |
//+------------------------------------------------------------------+
void DumpBuffers()
  {
   Print("--- BUFFER DUMP: identify ask / bid / delta from these ---");
   ENUM_TIMEFRAMES tf = MinutesToTimeframe(InpTimeframeMin);
   for(int b = 0; b < 12; b++)
     {
      double v[];
      ArraySetAsSeries(v, true);
      int got = CopyBuffer(hIndicator, b, 0, 4, v);
      if(got <= 0)
        {
         Print("  buffer ", b, ": (none)");
         continue;
        }
      string line = "";
      for(int i = 0; i < got; i++)
         line += StringFormat("%.1f  ", v[i]);
      Print("  buffer ", b, ": ", line);
     }
   Print("--- ask volume is a positive count; bid volume likewise;");
   Print("    delta should equal ask minus bid. Match them up, then set");
   Print("    InpBufAsk / InpBufBid / InpBufDelta in the Inputs tab. ---");
  }

//+------------------------------------------------------------------+
void OnTimer()
  {
   WriteDelta();
  }

//+------------------------------------------------------------------+
void WriteDelta()
  {
   if(hIndicator == INVALID_HANDLE)
      return;

   int n = InpBars;
   double ask[], bid[], delta[], cum[];
   ArraySetAsSeries(ask,   true);
   ArraySetAsSeries(bid,   true);
   ArraySetAsSeries(delta, true);
   ArraySetAsSeries(cum,   true);

   int gotA = CopyBuffer(hIndicator, InpBufAsk,   0, n, ask);
   int gotB = CopyBuffer(hIndicator, InpBufBid,   0, n, bid);
   int gotD = CopyBuffer(hIndicator, InpBufDelta, 0, n, delta);
   int gotC = 0;
   if(InpBufCumDelta >= 0)
      gotC = CopyBuffer(hIndicator, InpBufCumDelta, 0, n, cum);

   if(gotA <= 0 || gotB <= 0)
     {
      // Wrong buffer index, or the indicator has not calculated yet. Write a
      // status file with a full buffer scan so the Python diagnostic can say
      // exactly what is wrong.
      WriteStatus(StringFormat("buffer read failed: ask idx %d gave %d bars, "
                               "bid idx %d gave %d bars",
                               InpBufAsk, gotA, InpBufBid, gotB));
      static datetime lastWarn = 0;
      if(TimeCurrent() - lastWarn > 60)
        {
         Print("SKLZ bridge: no data from buffers (ask=", gotA,
               " bid=", gotB, ") - see sklz_bridge_status.txt");
         lastWarn = TimeCurrent();
        }
      return;
     }

   int count = MathMin(gotA, MathMin(gotB, MathMax(gotD, 1)));

   datetime times[];
   ArraySetAsSeries(times, true);
   if(CopyTime(_Symbol, MinutesToTimeframe(InpTimeframeMin), 0, count, times) <= 0)
      return;

   int fh = FileOpen(fileName, FILE_WRITE | FILE_CSV | FILE_ANSI, ',');
   if(fh == INVALID_HANDLE)
     {
      Print("SKLZ bridge: cannot write ", fileName, " (err ", GetLastError(), ")");
      return;
     }

   // header, so the Python side can validate rather than guess
   FileWrite(fh, "time", "ask_volume", "bid_volume", "delta", "cum_delta");
   for(int i = count - 1; i >= 0; i--)   // oldest first
     {
      double d = (gotD > i) ? delta[i] : (ask[i] - bid[i]);
      double c = (gotC > i) ? cum[i] : 0.0;
      FileWrite(fh, (long)times[i], ask[i], bid[i], d, c);
     }
   FileClose(fh);
   lastWrite = TimeCurrent();
  }

//+------------------------------------------------------------------+
//| Write a machine-readable status the Python side can read, so the |
//| user does not have to hunt through MT5 tabs.                     |
//+------------------------------------------------------------------+
void WriteStatus(string problem)
  {
   int fh = FileOpen("sklz_bridge_status.txt", FILE_WRITE|FILE_TXT|FILE_ANSI);
   if(fh == INVALID_HANDLE)
      return;
   FileWriteString(fh, "symbol=" + _Symbol + CRLF);
   FileWriteString(fh, "indicator=" + loadedName + CRLF);
   FileWriteString(fh, "problem=" + problem + CRLF);
   FileWriteString(fh, "buffers:" + CRLF);
   for(int b = 0; b < 12; b++)
     {
      double v[];
      ArraySetAsSeries(v, true);
      int got = CopyBuffer(hIndicator, b, 0, 3, v);
      if(got <= 0)
        {
         FileWriteString(fh, StringFormat("  %d: none", b) + CRLF);
         continue;
        }
      string line = "";
      for(int i = 0; i < got; i++)
         line += StringFormat("%.1f ", v[i]);
      FileWriteString(fh, StringFormat("  %d: %s", b, line) + CRLF);
     }
   FileClose(fh);
  }

//+------------------------------------------------------------------+
ENUM_TIMEFRAMES MinutesToTimeframe(int m)
  {
   switch(m)
     {
      case 1:    return PERIOD_M1;
      case 5:    return PERIOD_M5;
      case 15:   return PERIOD_M15;
      case 30:   return PERIOD_M30;
      case 60:   return PERIOD_H1;
      case 240:  return PERIOD_H4;
      case 1440: return PERIOD_D1;
     }
   return PERIOD_M15;
  }
//+------------------------------------------------------------------+
