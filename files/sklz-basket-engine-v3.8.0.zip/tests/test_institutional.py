"""Institutional confirmation: the cases that must never pass."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from basket_engine.learn import institutional as INST
from basket_engine.learn import orderflow as OF


def _bars(n, start, drift, vol=0.0004, v=100):
    out, p = [], start
    for i in range(n):
        o = p
        p += drift
        out.append({"time": 1700000000 + i * 900, "open": o,
                    "high": max(o, p) + vol * 0.3, "low": min(o, p) - vol * 0.3,
                    "close": p, "volume": v, "real_volume": 0})
    return out


def test_absent_inputs_are_not_scored_as_zero():
    """Missing DOM must not silently cap the score — it is normalised out."""
    m15, h1, d1 = _bars(120, 1.14, 0.0001), _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001)
    a = INST.assess(1, "EURUSD", 0.0001, m15, h1, d1)
    assert "dom" in a.inputs_missing
    assert "dom" not in a.inputs_used
    assert a.score > 0


def _swing_bar(t, o, h, l, c, v=100):
    return {"time": t, "open": o, "high": h, "low": l, "close": c,
            "volume": v, "real_volume": 0}


def _double_top(level=1.1450):
    """Price rallies to `level` twice and rejects — stops rest above it."""
    bars, t = [], 1700000000
    p = 1.1400
    for _ in range(30):                       # rally toward the level
        bars.append(_swing_bar(t, p, p + 0.0004, p - 0.0002, p + 0.0003))
        p += 0.0003
        t += 900
    bars.append(_swing_bar(t, p, level, p - 0.0003, level - 0.0010))   # peak 1
    t += 900
    p = level - 0.0010
    for _ in range(12):                       # pull back
        bars.append(_swing_bar(t, p, p + 0.0002, p - 0.0005, p - 0.0004))
        p -= 0.0004
        t += 900
    for _ in range(12):                       # rally back
        bars.append(_swing_bar(t, p, p + 0.0005, p - 0.0002, p + 0.0004))
        p += 0.0004
        t += 900
    bars.append(_swing_bar(t, p, level, p - 0.0003, level - 0.0012))   # peak 2
    t += 900
    p = level - 0.0012
    for _ in range(10):                       # drift back up, staying BELOW
        bars.append(_swing_bar(t, p, p + 0.0002, p - 0.0002, p + 0.0001))
        p += 0.0001
        t += 900
    assert p < level, "fixture must approach the pool from below"
    return bars, t, level


def test_liquidity_sweep_is_rejected():
    """Price wicks above a double top and closes back inside — a stop hunt."""
    bars, t, level = _double_top()
    bars.append(_swing_bar(t, level - 0.0004, level + 0.0015,
                           level - 0.0006, level - 0.0005, 320))
    a = INST.assess(1, "EURUSD", 0.0001, bars,
                    _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001))
    assert not a.passed, f"a sweep must never pass (scored {a.score})"
    assert any("SWEEP" in f for f in a.flags), f"flags were {a.flags}"


def test_acceptance_beyond_the_level_is_not_a_sweep():
    """Same level, but price closes decisively beyond it."""
    bars, t, level = _double_top()
    bars.append(_swing_bar(t, level - 0.0004, level + 0.0020,
                           level - 0.0005, level + 0.0018, 320))
    a = INST.assess(1, "EURUSD", 0.0001, bars,
                    _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001))
    assert not any("SWEEP" in f for f in a.flags), f"flags were {a.flags}"


def test_absorption_blocks_entry():
    d = OF.DeltaResult(buy_volume=800, sell_volume=200, delta=600,
                       cumulative=[1] * 50, quality="inferred")
    r = OF.absorption(d, price_move_pips=1)
    assert r["absorbed"] is True
    assert r["side"] == "seller"


def test_absorption_clears_when_price_moves():
    d = OF.DeltaResult(buy_volume=800, sell_volume=200, delta=600,
                       cumulative=[1] * 50, quality="inferred")
    assert OF.absorption(d, price_move_pips=30)["absorbed"] is False


def test_wick_breakout_is_not_acceptance():
    bar = {"open": 1.1400, "high": 1.1430, "low": 1.1398, "close": 1.1404}
    assert INST.candle_acceptance(1, bar)["accepted"] is False


def test_strong_body_is_acceptance():
    bar = {"open": 1.1400, "high": 1.1422, "low": 1.1399, "close": 1.1420}
    assert INST.candle_acceptance(1, bar)["accepted"] is True


def test_delta_divergence_detected():
    closes = [1.14 + i * 0.0001 for i in range(24)]
    cum = [100 - i * 3 for i in range(24)]
    assert OF.delta_divergence(closes, cum, 1)["divergent"] is True


def test_no_book_reports_unavailable_not_bearish():
    r = OF.read_depth([], 1)
    assert r["available"] is False
    assert "no order book" in r["reason"]


def test_basket_disagreement_penalises():
    m15, h1, d1 = _bars(120, 1.14, 0.0001), _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001)
    agree = INST.assess(1, "EURUSD", 0.0001, m15, h1, d1,
                        peer_moves={"EURJPY": 0.3, "EURGBP": 0.2, "GBPUSD": 0.2})
    disagree = INST.assess(1, "EURUSD", 0.0001, m15, h1, d1,
                           peer_moves={"EURJPY": -0.3, "EURGBP": -0.2, "GBPUSD": -0.2})
    assert disagree.score < agree.score


def test_session_scores_overlap_highest():
    from datetime import datetime, timezone
    overlap = INST.session_quality(datetime(2026, 7, 30, 13, tzinfo=timezone.utc))
    asian = INST.session_quality(datetime(2026, 7, 30, 3, tzinfo=timezone.utc))
    assert overlap["score"] > asian["score"]


def test_jpy_gets_credit_in_asian_session():
    from datetime import datetime, timezone
    t = datetime(2026, 7, 30, 3, tzinfo=timezone.utc)
    assert (INST.session_quality(t, "USDJPY")["score"]
            > INST.session_quality(t, "EURUSD")["score"])


def test_runner_actually_has_the_institutional_method():
    """The scan loop calls self._institutional. If the method is missing the
    call raises AttributeError, gets swallowed by the fallback, and the whole
    layer silently does nothing — which is exactly what happened once.
    Compiling is not the same as being wired up."""
    from basket_engine.learn.runner import LearningRunner
    assert hasattr(LearningRunner, "_institutional"), \
        "LearningRunner._institutional is missing — the scan loop calls it"
    import inspect
    src = inspect.getsource(LearningRunner)
    assert "self._institutional(" in src, "nothing calls it"


def test_every_method_the_runner_calls_on_itself_exists():
    """Catch any other self._foo() that was never defined."""
    import inspect, re
    from basket_engine.learn.runner import LearningRunner
    src = inspect.getsource(LearningRunner)
    called = set(re.findall(r"self\.(_[a-z_]+)\(", src))
    defined = {n for n in dir(LearningRunner) if n.startswith("_")}
    missing = {c for c in called if c not in defined}
    assert not missing, f"called but never defined: {sorted(missing)}"


def test_published_signal_carries_the_traded_levels():
    """A signal whose stop differs from the one the bot is trading tells
    subscribers a level nobody is using. If the caller supplies real levels,
    they must appear in the payload rather than being recomputed."""
    import inspect
    from basket_engine.learn import signal_publish
    src = inspect.getsource(signal_publish.publish)
    assert "actual_sl" in src, "publish() must accept the executed stop"
    assert 'payload["sl"]' in src, "the real stop must reach the payload"


def test_entry_record_stores_the_placed_levels():
    from basket_engine.learn.capture import EntryRecord
    r = EntryRecord(ts="", source="auto", strategy="x", symbol="AUDUSD",
                    side=1, lots=0.03, entry_price=0.70333,
                    sl_price=0.70133, tp_price=0.70606)
    assert r.sl_price == 0.70133 and r.tp_price == 0.70606


def test_bridge_rejects_stale_data():
    """Old flow scored against a fresh breakout is worse than no flow."""
    import os, tempfile, time
    from basket_engine.learn import orderflow as OF
    d = tempfile.mkdtemp()
    os.environ["SKLZ_MT5_FILES_DIR"] = d
    p = os.path.join(d, "sklz_delta_EURUSD.csv")
    with open(p, "w") as f:
        f.write("time,ask_volume,bid_volume,delta,cum_delta\n")
        f.write("1700000000,100,50,50,50\n")
    os.utime(p, (time.time() - 4000, time.time() - 4000))
    assert OF.read_bridge("EURUSD").quality == "none"
    os.environ.pop("SKLZ_MT5_FILES_DIR", None)


def test_bridge_flags_wrong_buffer_indices():
    """All-zero volumes mean the EA is reading the wrong buffers. Say so
    rather than reporting a confident delta of zero."""
    import os, tempfile
    from basket_engine.learn import orderflow as OF
    d = tempfile.mkdtemp()
    os.environ["SKLZ_MT5_FILES_DIR"] = d
    with open(os.path.join(d, "sklz_delta_EURUSD.csv"), "w") as f:
        f.write("time,ask_volume,bid_volume,delta,cum_delta\n")
        f.write("1700000000,0,0,0,0\n")
    r = OF.read_bridge("EURUSD")
    assert r.quality == "none"
    assert "buffer indices" in r.note
    os.environ.pop("SKLZ_MT5_FILES_DIR", None)


def test_measured_delta_overrides_tick_inference():
    from basket_engine.learn import orderflow as OF
    measured = OF.DeltaResult(buy_volume=900, sell_volume=300, delta=600,
                              cumulative=[10] * 40, quality="measured")
    m15 = _bars(120, 1.14, 0.0001)
    a = INST.assess(1, "EURUSD", 0.0001, m15, _bars(200, 1.135, 0.0002),
                    _bars(20, 1.12, 0.001), delta_override=measured)
    assert "cluster_delta" in a.inputs_used


def test_correlated_positions_are_one_bet():
    """Four dollar-short positions are not diversification."""
    from basket_engine.learn import exposure as EXP
    pos = [{"symbol": "EURUSD", "side": 1, "lots": 0.01},
           {"symbol": "USDCHF", "side": -1, "lots": 0.01},
           {"symbol": "XAUUSD", "side": 1, "lots": 0.01},
           {"symbol": "USDJPY", "side": -1, "lots": 0.01}]
    net = EXP.exposure_map(pos)
    assert net["USD"] < 0, "all four are short USD"
    assert abs(net["USD"]) == 0.04, "exposure should compound, not offset"
    r = EXP.would_breach(pos, "GBPUSD", 1, 0.01)
    assert r["ok"] is False, "a fifth dollar-short trade must be refused"


def test_reducing_exposure_is_never_blocked():
    from basket_engine.learn import exposure as EXP
    pos = [{"symbol": "EURUSD", "side": 1, "lots": 0.01}] * 4
    assert EXP.would_breach(pos, "EURUSD", -1, 0.01)["ok"] is True


def test_retest_distinguishes_hold_from_fail():
    from basket_engine.learn.institutional import retest_held
    def bar(h, l, c):
        return {"open": c, "high": h, "low": l, "close": c, "volume": 100}
    held = retest_held(1, [bar(1.147, 1.144, 1.1465), bar(1.1468, 1.1448, 1.1452),
                           bar(1.1475, 1.1451, 1.147)], 1.145, 0.0001)
    assert held["tested"] and held["held"]
    failed = retest_held(1, [bar(1.147, 1.144, 1.1465), bar(1.1466, 1.1435, 1.1442),
                             bar(1.1448, 1.143, 1.1438)], 1.145, 0.0001)
    assert failed["tested"] and not failed["held"]


def test_unknown_pnl_is_not_recorded_as_breakeven():
    """A trade whose result the broker never reported is not a flat trade.

    Recording it as 0.00 made nine consecutive trades look like a quiet day
    when the P/L simply had not landed in deal history yet. That silently
    corrupts every statistic built on top of it.
    """
    import json
    import tempfile
    from basket_engine.learn.capture import Journal

    with tempfile.TemporaryDirectory() as d:
        j = Journal.__new__(Journal)
        j.path = f"{d}/j.jsonl"
        j.record_exit(1, 0.0, None)
        j.record_exit(2, 0.0, 0.0)
        j.record_exit(3, 0.0, -4.2)

        rows = [json.loads(x) for x in open(j.path)]
        assert rows[0]["outcome"] == "unknown", "missing P/L must not be flat"
        assert rows[1]["outcome"] == "flat", "a real zero is flat"
        assert rows[2]["outcome"] == "loss"


def test_trailing_is_per_instrument():
    """30 pips is $3 on gold and most of a day's range on EURUSD."""
    from basket_engine.learn.trailing import trail_for
    g_t, g_l = trail_for("XAUUSD..")
    f_t, f_l = trail_for("EURUSD..")
    assert (g_t, g_l) == (30, 15), "gold: $3 trigger, $1.50 lock"
    assert f_t < g_t, "FX must trail tighter in pips than gold"


def test_global_override_still_wins():
    import os
    from basket_engine.learn.trailing import trail_for
    os.environ["SKLZ_TRAIL_TRIGGER_PIPS"] = "45"
    try:
        assert trail_for("XAUUSD..")[0] == 45
    finally:
        os.environ.pop("SKLZ_TRAIL_TRIGGER_PIPS", None)


def _bar(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c, "volume": 100}


def test_rsi_reads_the_pullback_not_just_the_entry_bar():
    """The bar that confirms a retest is upward, which lifts RSI(2) at once.

    Reading only the current bar means the condition is never true at the
    moment you actually want to enter.
    """
    from basket_engine.learn.models import rsi_confirms
    # deep pullback, then one bar turning up
    closes = [100 + i * 0.4 for i in range(40)] + \
             [115.6 - i * 0.9 for i in range(6)] + [111.8]
    r = rsi_confirms(1, closes)
    assert r["ok"], r["reason"]

    # still falling on the entry bar — the pullback was deep but has not
    # turned, so this must NOT fire
    falling = closes[:-1] + [110.2]
    assert not rsi_confirms(1, falling)["ok"]


def test_model_a_needs_the_level_to_hold():
    from basket_engine.learn.models import model_a
    prices = [1.0975, 1.0982, 1.0990, 1.1000, 1.0992, 1.0985, 1.0978, 1.0986,
              1.0994, 1.1000, 1.0993, 1.0986, 1.0980, 1.0988, 1.0996, 1.1002,
              1.1012, 1.1020]
    m15 = [_bar(p - 0.0004, p + 0.0004, p - 0.0006, p) for p in prices]
    pad = [_bar(1.1018, 1.1022, 1.1014, 1.1020) for _ in range(30)]
    held = [_bar(p + 0.0002, p + 0.0003, p - 0.0003, p) for p in
            (1.1020, 1.1016, 1.1010, 1.1006, 1.1003, 1.1005, 1.1009)]
    assert model_a(m15, pad + held, 0.0001).ok

    # same retest but it closes back below the level — must not fire
    failed = [_bar(p + 0.0002, p + 0.0003, p - 0.0003, p) for p in
              (1.1020, 1.1016, 1.1010, 1.1004, 1.0998, 1.0996, 1.0994)]
    assert not model_a(m15, pad + failed, 0.0001).ok


def test_order_block_finds_the_candle_before_the_break():
    from basket_engine.learn.models import order_block
    htf = [_bar(100, 101, 99, 99.5) for _ in range(5)] + \
          [_bar(100, 100.5, 98, 98.2), _bar(98.3, 103, 98.2, 102.5)]
    blk = order_block(htf, 1)
    assert blk and abs(blk["mid"] - 99.25) < 0.01


def test_models_outscore_plain_scanner_hits():
    """A structured model requires a sequence; a scanner requires a condition.

    The weighting is a prior from the owner's own trading, not a measured
    finding — which is why outcomes are recorded per source, so it can be
    revised rather than defended.
    """
    import os
    from basket_engine.learn import quality

    class IO:
        def bars(self, *a, **k):
            return [{"open": 1.1, "high": 1.11, "low": 1.09, "close": 1.105,
                     "tick_volume": 100} for _ in range(60)]
        def spec(self, s):
            return {"digits": 5}
        def price(self, s, side=1):
            return 1.105

    os.environ["SKLZ_MODEL_BONUS"] = "22"
    try:
        plain = quality.score_setup(IO(), "EURUSD", 15,
                                    [("structure_break", 1, "x")])
        withm = quality.score_setup(IO(), "EURUSD", 15,
                                    [("model_a", 1, "x")])
        assert withm["score"] > plain["score"], \
            "a model hit must outscore a lone scanner hit"
        assert withm["score"] - plain["score"] >= 20
    finally:
        os.environ.pop("SKLZ_MODEL_BONUS", None)


def test_price_on_a_high_volume_node_is_a_veto():
    """Selling from inside an HVN is where breaks get absorbed.

    The original check only looked at what was AHEAD, so a trade entered
    directly on a node scored normally — a real NZDUSD sell reached 89/100
    while sitting on one.
    """
    from basket_engine.learn.institutional import profile_check
    vp = {"available": True, "hvn": [0.58540], "lvn": [], "poc": 0.58540}
    r = profile_check(-1, 0.58537, vp, 0.0001)
    assert r["favourable"] is False
    assert r.get("at_node") is True


def test_delta_against_the_trade_blocks_a_high_score():
    """A 0.15 component score was outvoted by seven other components.

    Order flow running the other way is not 'worth fewer points' — it means
    the trade is the wrong way round.
    """
    from basket_engine.learn.institutional import Assessment
    a = Assessment(side=-1, score=89.0)
    a.flags = ["DELTA AGAINST — order flow is +34% buy-side while this is a SELL"]
    passed = (a.score >= 60 and not a.veto and not any(
        f.startswith(("LIQUIDITY SWEEP", "ABSORPTION", "DELTA AGAINST",
                      "price is sitting ON")) for f in a.flags))
    assert passed is False


def test_fair_value_gap_detection():
    from basket_engine.learn.models import fair_value_gap
    bars = [_bar(1.10, 1.101, 1.099, 1.1005),
            _bar(1.1005, 1.104, 1.1004, 1.1038),   # the fast candle
            _bar(1.1038, 1.105, 1.1020, 1.1045)]   # low 1.1020 > first high 1.101
    g = fair_value_gap(bars, 1)
    assert g and abs(g["bottom"] - 1.101) < 1e-9 and abs(g["top"] - 1.1020) < 1e-9

    # no gap when candles overlap
    flat = [_bar(1.10, 1.102, 1.099, 1.101)] * 3
    assert fair_value_gap(flat, 1) is None


def test_model_c_requires_the_trap():
    """Without price trading the far side of the 4H open there is no setup —
    the counter-move IS the pattern, not a failure of it."""
    from basket_engine.learn.models import model_c
    h4 = [_bar(1.10, 1.106, 1.098, 1.105), _bar(1.105, 1.111, 1.103, 1.110),
          _bar(1.110, 1.116, 1.108, 1.115), _bar(1.115, 1.118, 1.112, 1.117),
          _bar(1.1170, 1.118, 1.116, 1.117)]
    # price stays above the 4H open the whole time
    m5 = [_bar(1.1175, 1.1178, 1.1172, 1.1176) for _ in range(30)]
    s = model_c(h4, m5, 0.0001)
    assert not s.ok
    assert any("far side" in b for b in s.blockers)


def test_broker_index_aliases_get_point_pips():
    """USTEC fell through to digits-based 0.1, making the 25-pip index
    trigger 2.5 points on a 29,700 index — armed on noise, stopped in
    seconds, +$2.52 on 1.2 lots."""
    from basket_engine.learn.trailing import pip_size
    for sym in ("USTEC", "US500", "DE40"):
        assert pip_size(sym) == 1.0, f"{sym} must be 1 point per pip"


def test_model_d_needs_choch_not_just_the_sweep():
    """Sweeping the inducement alone is not an entry — without the change of
    character the 'sweep' may simply be the start of a real breakdown."""
    from basket_engine.learn.models import model_d
    path = [1.0990, 1.0975, 1.0960, 1.0950, 1.0962, 1.0978, 1.0995, 1.1010,
            1.1002, 1.0992, 1.0980, 1.0988, 1.0998, 1.1006, 1.1000, 1.0994,
            1.0990, 1.0996, 1.1002, 1.1008, 1.1004]
    m15 = [_bar(p + 0.0002, p + 0.0008, p - 0.0008, p) for p in path]
    pad = [_bar(1.0996, 1.0999, 1.0993, 1.0995) for _ in range(30)]
    # sweep happens but price stays down — no change of character
    stuck = pad + [_bar(1.0994, 1.0995, 1.0985, 1.0987),
                   _bar(1.0987, 1.0988, 1.0972, 1.0975),
                   _bar(1.0975, 1.0978, 1.0970, 1.0973)]
    s = model_d(m15, stuck, 0.0001)
    assert not s.ok
    assert any("change of character" in b for b in s.blockers)
