"""SKLZ — trailing stop and break-even protection.

Applies to every open position the runner can see, whether it was opened by
a scanner, from the dashboard, or typed into the console.

The rule, using the gold example:

    entry 4024, SL 4016 (buy)
    price reaches 4028   -> +40 pips, trigger fires
    SL jumps to 4026     -> +20 pips locked in, trade can no longer lose
    price keeps rising   -> SL trails 20 pips behind, never moving backwards

Expressed generically: trigger at TRIGGER_PIPS, secure at TRAIL_PIPS profit,
then keep the stop TRAIL_PIPS behind the current price. Pip size differs per
instrument, so the same rule gives sensible distances on FX, metals, indices
and crypto.

Two properties that matter:
  - the stop only ever moves in the trader's favour, never wider
  - it is set on the BROKER, so protection survives the runner going offline
"""
from __future__ import annotations

import os

# pip size per instrument family. Gold: 0.1, so 40 pips = $4.00 — matching
# the convention most brokers and traders use for XAUUSD.
PIP_SIZE = {
    # metals
    "XAUUSD": 0.1, "GOLD": 0.1, "XAGUSD": 0.01, "SILVER": 0.01,
    # FX majors / crosses (JPY pairs use 0.01)
    "USDJPY": 0.01, "EURJPY": 0.01, "GBPJPY": 0.01, "AUDJPY": 0.01,
    "CADJPY": 0.01, "CHFJPY": 0.01, "NZDJPY": 0.01,
    # indices — 1 point. Broker aliases matter here: IC Markets calls the
    # Nasdaq USTEC and the S&P US500 — an unlisted alias fell through to
    # digits=1 -> pip 0.1, which made the 25-pip index trigger 2.5 POINTS on
    # a 29,700 index. The trail armed on noise and stopped out in seconds.
    "US30": 1.0, "NAS100": 1.0, "USTEC": 1.0, "USTECH": 1.0,
    "SPX500": 1.0, "US500": 1.0, "GER40": 1.0, "DE40": 1.0, "DE30": 1.0,
    "UK100": 1.0, "JP225": 1.0, "AUS200": 1.0, "HK50": 1.0, "STOXX50": 1.0,
    # energy
    "USOIL": 0.01, "UKOIL": 0.01, "WTI": 0.01,
    "USOUSD": 0.01, "UKOUSD": 0.01, "BRENT": 0.01,
    # crypto — 1 unit
    "BTCUSD": 1.0, "ETHUSD": 0.1, "XRPUSD": 0.0001, "LTCUSD": 0.01,
}
DEFAULT_PIP = 0.0001            # standard FX


def pip_size(symbol: str, digits: int | None = None) -> float:
    """Pip size for an instrument, falling back to broker digits."""
    s = (symbol or "").upper()
    for key, size in PIP_SIZE.items():
        if s.startswith(key):
            return size
    if digits is not None:
        if digits in (3, 5):
            return 10 ** -(digits - 1)      # 5-digit FX -> 0.0001
        if digits in (2, 4):
            return 10 ** -(digits - 1)
        if digits == 1:
            return 0.1
        if digits == 0:
            return 1.0
    return DEFAULT_PIP


def _cfg(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


# Trailing thresholds per instrument class.
#
# A single pip number cannot serve gold and EURUSD: 30 pips is $3 on gold and
# most of a day's range on EURUSD. These are what each class actually needs to
# clear its own noise, with env overrides for testing.
TRAIL_BANDS = {
    "gold":    (30, 15),      # $3.00 move -> lock $1.50
    "silver":  (20, 10),      # silver pip is 10x smaller than gold's
    "fx":      (12, 6),
    "jpy":     (12, 6),
    "index":   (25, 12),
    "crypto":  (60, 30),
    "energy":  (20, 10),
}


def _trail_class(symbol: str) -> str:
    s = (symbol or "").upper()
    for suf in ("..", ".", "m", "c", "r", "_", "#"):
        if s.endswith(suf):
            s = s[: -len(suf)]
    s = s.strip(".")
    if s.startswith(("XAU", "GOLD")):
        return "gold"
    if s.startswith(("XAG", "SILVER")):
        return "silver"
    if s.startswith(("BTC", "ETH", "XRP", "SOL", "LTC", "ADA", "DOGE")):
        return "crypto"
    if s.startswith(("US30", "US500", "NAS", "SPX", "DE40", "UK100", "JP225",
                     "GER", "USTEC", "AUS200")):
        return "index"
    if s.startswith(("USO", "UKO", "WTI", "BRENT", "OIL", "NGAS")):
        return "energy"
    if "JPY" in s:
        return "jpy"
    return "fx"


def trail_for(symbol: str) -> tuple[float, float]:
    """(trigger, lock) in pips for this instrument.

    An explicit env override wins, so a single global number can still be
    forced for testing — but the per-class defaults mean nothing has to be set
    for the behaviour to be sensible.
    """
    import os as _os
    k = _trail_class(symbol)
    trig, lock = TRAIL_BANDS.get(k, TRAIL_BANDS["fx"])

    # class-specific override, e.g. SKLZ_TRAIL_GOLD=30/15
    raw = _os.environ.get(f"SKLZ_TRAIL_{k.upper()}", "").strip()
    if raw and "/" in raw:
        try:
            a, b = raw.split("/", 1)
            trig, lock = float(a), float(b)
        except ValueError:
            pass

    # global override still wins over everything, for a single-number test
    g_t = _os.environ.get("SKLZ_TRAIL_TRIGGER_PIPS", "").strip()
    g_l = _os.environ.get("SKLZ_TRAIL_DISTANCE_PIPS", "").strip()
    if g_t:
        try:
            trig = float(g_t)
        except ValueError:
            pass
    if g_l:
        try:
            lock = float(g_l)
        except ValueError:
            pass
    return trig, lock


# ── R-based trailing (default) ───────────────────────────────────────────
#
# The pip bands above are the same size whatever the trade's stop is. On the
# record (170 trades, 68% win rate, net flat) that was the leak: a gold entry
# with a 100-pip stop had its break-even armed at +30 pips and trailed 15
# behind — winners were cut at 0.2R while losers ran the full 1R. Two wins
# out of three could not pay for one full-size loss.
#
# R-mode measures everything against the trade's OWN initial stop distance:
#     trigger at  SKLZ_TRAIL_TRIGGER_R  (default 1.0R)  -> stop moves to
#     entry + (trigger - dist) = +0.4R, then trails SKLZ_TRAIL_DIST_R (0.6R)
#     behind price. The model's TP stays in place.
# Set SKLZ_TRAIL_MODE=pips to go back to the fixed bands.

def trail_mode() -> str:
    return os.environ.get("SKLZ_TRAIL_MODE", "r").strip().lower() or "r"


# v3.33 — trades the trailer must leave alone: Model O's fixed 3:1 straddle
# and anything whose order-comment code is listed in SKLZ_TRAIL_SKIP_CODES.
_FIXED: set[int] = set()


def mark_fixed(ticket: int) -> None:
    if ticket:
        _FIXED.add(int(ticket))


def skip_position(ticket: int, comment: str = "") -> bool:
    if int(ticket or 0) in _FIXED:
        return True
    codes = {c.strip().upper() for c in
             os.environ.get("SKLZ_TRAIL_SKIP_CODES", "O").split(",") if c.strip()}
    if not codes or not comment:
        return False
    # comments look like "sklz-a SB+SE+C" — the part after the space
    parts = str(comment).split(" ", 1)
    tags = {t.strip().upper() for t in parts[1].split("+")} if len(parts) > 1 else set()
    return bool(tags & codes)


def structure_stop(bars: list[dict], side: int, entry: float, current_sl: float,
                   pip: float, k: int = 2) -> float | None:
    """SKLZ_TRAIL_MODE=structure: once the R-trigger has been reached the
    stop sits just beyond the LAST COMPLETED swing in the trade's favour
    (k-bar pivot on the bars given, M5 by default) instead of a fixed
    distance behind price. Returns the new stop or None when no swing
    improves on the current one."""
    if len(bars) < 2 * k + 3:
        return None
    done = bars[:-1]
    piv = []
    for i in range(k, len(done) - k):
        if side > 0 and done[i]["low"] <= min(b["low"] for b in done[i - k:i + k + 1]):
            piv.append(done[i]["low"])
        if side < 0 and done[i]["high"] >= max(b["high"] for b in done[i - k:i + k + 1]):
            piv.append(done[i]["high"])
    if not piv:
        return None
    cand = (piv[-1] - 2 * pip) if side > 0 else (piv[-1] + 2 * pip)
    # never below break-even once trailing, never backwards
    if side > 0:
        if cand <= entry or (current_sl and cand <= current_sl + 0.5 * pip):
            return None
    else:
        if cand >= entry or (current_sl and cand >= current_sl - 0.5 * pip):
            return None
    return cand


def trigger_r() -> float:
    return _cfg("SKLZ_TRAIL_TRIGGER_R", 1.0)


def dist_r() -> float:
    return _cfg("SKLZ_TRAIL_DIST_R", 0.6)


# initial stop distance per ticket, captured the first time a position is seen
# with its stop still on the losing side (i.e. the broker-set original stop)
_INITIAL_RISK: dict[int, float] = {}


def remember_risk(ticket: int, risk: float) -> None:
    if ticket and risk and risk > 0:
        _INITIAL_RISK[int(ticket)] = float(risk)


def initial_risk(ticket: int, side: int, entry: float, current_sl: float,
                 lookup=None) -> float | None:
    """Best available estimate of the trade's original stop distance."""
    r = _INITIAL_RISK.get(int(ticket or 0))
    if r:
        return r
    if current_sl and ((side > 0 and current_sl < entry) or (side < 0 and current_sl > entry)):
        r = abs(entry - current_sl)
        remember_risk(ticket, r)
        return r
    if lookup is not None:
        try:
            v = lookup(ticket)
            if v and float(v) > 0:
                remember_risk(ticket, float(v))
                return float(v)
        except Exception:
            pass
    return None


def trigger_pips() -> float:
    """Profit at which break-even protection kicks in."""
    return _cfg("SKLZ_TRAIL_TRIGGER_PIPS", 20)


def trail_pips() -> float:
    """Distance the stop keeps behind price once trailing."""
    return _cfg("SKLZ_TRAIL_DISTANCE_PIPS", 10)


def enabled() -> bool:
    return os.environ.get("SKLZ_TRAILING", "1") != "0"


def desired_stop(side: int, entry: float, current: float, current_sl: float,
                 pip: float, symbol: str = "",
                 risk: float | None = None) -> tuple[float | None, str]:
    """Work out where the stop should be. Returns (new_sl, reason) or (None, why not).

    Pure function — no broker calls — so the rule is unit-testable.
    `risk` is the trade's initial stop distance in price; when given and
    SKLZ_TRAIL_MODE is "r" (default) the trigger and trail are R-multiples of
    it. Without it the per-instrument pip bands apply.
    """
    if risk and risk > 0 and trail_mode() in ("r", "structure"):
        trig = trigger_r() * risk
        dist = dist_r() * risk
    else:
        if symbol:
            t_p, d_p = trail_for(symbol)
        else:
            t_p, d_p = trigger_pips(), trail_pips()
        trig = t_p * pip
        dist = d_p * pip

    profit = (current - entry) if side > 0 else (entry - current)
    if profit < trig:
        return None, "not yet at trigger"

    if side > 0:
        target = current - dist
        secured = entry + dist
        target = max(target, secured)          # never below the secure level
        if current_sl and target <= current_sl + (pip * 0.5):
            return None, "stop already at or beyond target"
        moved_to_be = current_sl < entry or not current_sl
        return target, ("secured at break-even + profit" if moved_to_be
                        else "trailing stop up")
    else:
        target = current + dist
        secured = entry - dist
        target = min(target, secured)
        if current_sl and target >= current_sl - (pip * 0.5):
            return None, "stop already at or beyond target"
        moved_to_be = current_sl > entry or not current_sl
        return target, ("secured at break-even + profit" if moved_to_be
                        else "trailing stop down")


_PARTIAL_DONE: set[int] = set()
_TARGET1: dict[int, float] = {}          # v3.35: first M15 S/R per ticket
_EXTENDED: set[int] = set()              # v3.35: tickets whose TP was dropped for the runner


def remember_target1(ticket: int, price: float) -> None:
    if ticket and price:
        _TARGET1[int(ticket)] = float(price)


def partial_at() -> str:
    return os.environ.get("SKLZ_PARTIAL_AT", "r").strip().lower() or "r"


def _take_partial(io, p, side, entry, current, risk, pip, log, on_update) -> None:
    try:
        at_r = float(os.environ.get("SKLZ_PARTIAL_R", "0"))
        pct = float(os.environ.get("SKLZ_PARTIAL_PCT", "50"))
    except ValueError:
        return
    tk = int(p.get("ticket") or 0)
    if at_r <= 0 or not risk or tk in _PARTIAL_DONE or pct <= 0:
        return
    profit = (current - entry) if side > 0 else (entry - current)
    # v3.35 SKLZ_PARTIAL_AT=target1: half off at the first M15 S/R level the
    # entry recorded (ORB-15 clip) instead of a fixed +R; falls back to the
    # R rule when no level was recorded for this ticket
    t1 = _TARGET1.get(tk)
    if partial_at() == "target1" and t1:
        reached = (current >= t1) if side > 0 else (current <= t1)
        if not reached:
            return
    elif profit < at_r * risk:
        return
    lots = float(p.get("lots") or 0)
    try:
        spec = io.spec(p["symbol"])
        step = float(spec.get("lot_step") or 0.01)
        lot_min = float(spec.get("lot_min") or 0.01)
    except Exception:  # noqa: BLE001
        step, lot_min = 0.01, 0.01
    part = round(int((lots * pct / 100) / step) * step, 2)
    if part < lot_min or lots - part < lot_min:
        _PARTIAL_DONE.add(tk)            # too small to split — nothing to do, ever
        return
    ok = io.close({"symbol": p["symbol"], "side": side, "lots": part, "ticket": tk})
    if not ok:
        return
    _PARTIAL_DONE.add(tk)
    be = entry + side * 0.5 * pip
    try:
        io.modify_sl(tk, be)
    except Exception:  # noqa: BLE001
        pass
    log(f"[partial] {p['symbol']} {'BUY' if side > 0 else 'SELL'} — closed {part} of {lots} lots "
        f"at {profit / risk:.1f}R, stop to break-even; {lots - part:g} lots run")
    if on_update:
        try:
            on_update({"ticket": tk, "symbol": p["symbol"], "side": "buy" if side > 0 else "sell",
                       "entry": entry, "price": current, "old_sl": p.get("sl"), "new_sl": be,
                       "locked_pips": 0.0, "reason": f"partial {part} lots secured at {profit / risk:.1f}R",
                       "partial": part, "remaining": round(lots - part, 2), "r": round(profit / risk, 2)})
        except Exception:
            pass


def manage(io, log=print, on_update=None, risk_lookup=None) -> list[dict]:
    """Check every open position and move stops where the rule says to.

    `on_update(event)` is called for each change so the caller can broadcast it.
    Returns the list of updates made.
    """
    if not enabled():
        return []
    updates = []
    try:
        positions = io.my_positions()
    except Exception as exc:  # noqa: BLE001
        log(f"[trail] could not read positions: {exc}")
        return []

    for p in positions:
        symbol = p.get("symbol", "")
        side = p.get("side", 0)
        entry = float(p.get("open_price") or 0)
        cur_sl = float(p.get("sl") or 0)
        if not symbol or not side or not entry:
            continue
        # sanity: an entry price that is zero, or wildly far from the market,
        # means the broker did not report the fill properly. Acting on it
        # produced instant closes, so skip and say so.
        try:
            mkt = io.price(symbol, -side)
        except Exception:
            continue
        if entry <= 0 or mkt <= 0 or abs(entry - mkt) / mkt > 0.25:
            log(f"[trail] {symbol} skipped — entry price {entry} looks wrong "
                f"against market {mkt}; not moving the stop")
            continue
        try:
            digits = io.spec(symbol).get("digits")
        except Exception:
            digits = None
        pip = pip_size(symbol, digits)
        current = mkt                              # exit side price, already read

        if skip_position(p.get("ticket"), p.get("comment", "")):
            continue                               # fixed-TP trade (Model O etc.)
        risk = initial_risk(p.get("ticket"), side, entry, cur_sl, risk_lookup)
        # v3.34 partial profit: close SKLZ_PARTIAL_PCT of the position at
        # SKLZ_PARTIAL_R and move the stop to break-even — the CallistoFX
        # "partials, then risk free" management. Once per ticket.
        try:
            _take_partial(io, p, side, entry, current, risk, pip, log, on_update)
        except Exception as exc:  # noqa: BLE001
            log(f"[partial] {symbol}: {type(exc).__name__}: {exc}")
        new_sl, reason = desired_stop(side, entry, current, cur_sl, pip,
                                      symbol=symbol, risk=risk)
        if new_sl is None:
            continue
        if trail_mode() == "structure" and risk:
            # first lock still comes from the R rule; after that the stop
            # follows structure (last completed M5 swing) rather than a band
            in_profit_sl = cur_sl and ((cur_sl > entry) if side > 0 else (cur_sl < entry))
            if in_profit_sl:
                try:
                    raw = io.bars(symbol, int(os.environ.get("SKLZ_TRAIL_STRUCT_TF", "5")), 60) or []
                    bars = [{"high": r["high"], "low": r["low"]} for r in raw]
                except Exception:  # noqa: BLE001
                    bars = []
                st_sl = structure_stop(bars, side, entry, cur_sl, pip)
                if st_sl is None:
                    continue                       # no new swing yet — give it room
                new_sl = st_sl
                reason = "trailing behind the last swing (structure mode)"
        if risk:
            reason += f" ({(((current - entry) if side > 0 else (entry - current)) / risk):.1f}R reached)"

        # v3.35 SKLZ_RUNNER_EXTEND: when the last SKLZ_RUNNER_BARS (6) closed
        # M5 bars all close in the trade's direction while a TP is still on,
        # drop the fixed TP and let structure trailing manage the runner
        try:
            if os.environ.get("SKLZ_RUNNER_EXTEND", "1") != "0" and float(p.get("tp") or 0) \
                    and int(p.get("ticket") or 0) not in _EXTENDED:
                nb = max(3, int(os.environ.get("SKLZ_RUNNER_BARS", "6")))
                raw5 = io.bars(symbol, 5, nb + 2) or []
                done5 = raw5[:-1][-nb:]
                if len(done5) == nb and all(((b["close"] > b["open"]) if side > 0 else (b["close"] < b["open"])) for b in done5):
                    if io.modify_sl(p["ticket"], new_sl, 0.0):
                        _EXTENDED.add(int(p["ticket"]))
                        log(f"[runner] {symbol} {'BUY' if side > 0 else 'SELL'} — {nb} straight M5 closes in direction; "
                            f"TP {float(p.get('tp')):.5f} dropped, structure trailing takes the runner")
                        ok = True
                        locked = ((new_sl - entry) if side > 0 else (entry - new_sl)) / pip
                        ev = {"ticket": p["ticket"], "symbol": symbol, "side": "buy" if side > 0 else "sell",
                              "entry": entry, "price": current, "old_sl": cur_sl, "new_sl": round(new_sl, 6),
                              "locked_pips": round(locked, 1), "reason": reason + " · TP dropped for the runner",
                              "tp_dropped": True}
                        updates.append(ev)
                        if on_update:
                            try:
                                on_update(ev)
                            except Exception:
                                pass
                        continue
        except Exception as exc:  # noqa: BLE001
            log(f"[runner] {symbol}: {type(exc).__name__}: {exc}")

        ok = False
        try:
            ok = io.modify_sl(p["ticket"], new_sl)
        except Exception as exc:  # noqa: BLE001
            log(f"[trail] modify failed on {symbol}: {exc}")
        if not ok:
            continue

        locked = ((new_sl - entry) if side > 0 else (entry - new_sl)) / pip
        ev = {
            "ticket": p["ticket"], "symbol": symbol,
            "side": "buy" if side > 0 else "sell",
            "entry": entry, "price": current,
            "old_sl": cur_sl, "new_sl": round(new_sl, 6),
            "locked_pips": round(locked, 1),
            "reason": reason,
        }
        updates.append(ev)
        log(f"[trail] {symbol} {ev['side'].upper()} — {reason}: "
            f"SL {cur_sl or 'none'} -> {new_sl:.5f} "
            f"({locked:+.0f} pips locked)")
        if on_update:
            try:
                on_update(ev)
            except Exception:
                pass
    return updates
