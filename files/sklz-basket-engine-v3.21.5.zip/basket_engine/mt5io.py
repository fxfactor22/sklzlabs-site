"""Thin MT5 wrapper — every call the basket engine needs, nothing more.

MetaTrader5 import is guarded so the whole engine is testable on any OS;
tests inject a fake through BasketIO(client=fake).
"""
from __future__ import annotations

import time

try:
    import MetaTrader5 as _mt5
except ImportError:          # tests / macOS
    _mt5 = None


RETCODES = {
    10004: "requote — price moved",
    10006: "request rejected by the broker",
    10013: "invalid request",
    10014: "invalid volume (lot size)",
    10015: "invalid price",
    10016: "invalid stops — check your SL/TP distance",
    10018: "market is closed",
    10019: "not enough money",
    10027: "AutoTrading is DISABLED in MT5 — turn on the Algo Trading button",
    10030: "unsupported filling mode",
    10031: "no connection to the trade server",
}


class BasketIO:
    def __init__(self, magic: int, client=None) -> None:
        self.log = print
        self.mt5 = client or _mt5
        self.magic = magic
        if self.mt5 is None:
            raise RuntimeError("MetaTrader5 package not available")

    # ---- lifecycle ----
    def connect(self) -> dict:
        if not self.mt5.initialize():
            raise RuntimeError(f"MT5 initialize failed: {self.mt5.last_error()}")
        acct = self.mt5.account_info()
        if acct is None:
            raise RuntimeError("MT5: no account — open & log in the terminal first")
        return {"login": acct.login, "server": acct.server,
                "balance": acct.balance, "equity": acct.equity,
                "currency": acct.currency, "demo": acct.trade_mode == 0}

    def account(self) -> dict:
        a = self.mt5.account_info()
        return {"balance": a.balance, "equity": a.equity} if a else {}

    # ---- data ----
    def _tf(self, minutes: int):
        """Map minutes to an MT5 timeframe constant."""
        m = {1: "TIMEFRAME_M1", 5: "TIMEFRAME_M5", 15: "TIMEFRAME_M15",
             30: "TIMEFRAME_M30", 60: "TIMEFRAME_H1", 240: "TIMEFRAME_H4",
             1440: "TIMEFRAME_D1", 10080: "TIMEFRAME_W1"}
        name = m.get(int(minutes), "TIMEFRAME_M15")
        return getattr(self.mt5, name)

    def closes(self, symbol: str, timeframe_min: int, count: int) -> list[float]:
        symbol = self.resolve_symbol(symbol) or symbol
        tf = self._tf(timeframe_min)
        rates = self.mt5.copy_rates_from_pos(symbol, tf, 0, count)
        return [r["close"] for r in rates] if rates is not None else []

    # brokers name the same instrument differently: XAUUSD, XAUUSD.., XAUUSDm,
    # GOLD, XAU/USD. Resolve once, cache, and let the rest of the engine use
    # the plain name everywhere.
    _sym_cache: dict = {}
    _sym_fill: dict = {}

    # common aliases per instrument family
    _ALIASES = {
        "XAUUSD": ("GOLD", "XAU/USD", "GOLDUSD"),
        "XAGUSD": ("SILVER", "XAG/USD"),
        "US30": ("DJ30", "DOW", "US30Cash", "WS30"),
        "NAS100": ("USTEC", "NDX", "NAS100Cash", "US100"),
        "SPX500": ("US500", "SP500", "SPX", "US500Cash"),
        "GER40": ("DE40", "DAX", "GER30", "DE30"),
        "UK100": ("FTSE", "UK100Cash"),
        "USOIL": ("USOUSD", "WTI", "WTIUSD", "CRUDE", "OIL", "XTIUSD",
                  "CL", "OILUSD", "USOIL.spot", "Crude_Oil"),
        "UKOIL": ("UKOUSD", "BRENT", "BRENTUSD", "XBRUSD", "UKOIL.spot"),
        "BTCUSD": ("BTCUSDT", "BITCOIN", "BTC/USD"),
        "ETHUSD": ("ETHUSDT", "ETHEREUM", "ETH/USD"),
    }

    def resolve_symbol(self, symbol: str) -> str | None:
        """Find what this broker actually calls an instrument.

        Tries the exact name, then common suffixes and aliases, then falls
        back to scanning every symbol the broker offers. Returns the broker's
        name, or None if the instrument is genuinely unavailable.
        """
        if not symbol:
            return None
        key = symbol.upper().strip()
        if key in self._sym_cache:
            return self._sym_cache[key]

        def _usable(name: str) -> bool:
            info = self.mt5.symbol_info(name)
            if info is None:
                return False
            if not info.visible:
                self.mt5.symbol_select(name, True)
                info = self.mt5.symbol_info(name)
            return info is not None

        # 1) exactly as given
        if _usable(symbol):
            self._sym_cache[key] = symbol
            return symbol

        # 2) common broker suffixes
        suffixes = ("", ".", "..", "...", "m", "c", "z", "#", "_i", ".r",
                    ".raw", ".pro", ".ecn", "-ECN", ".sml", "micro", ".a")
        for suf in suffixes:
            cand = symbol + suf
            if cand != symbol and _usable(cand):
                self._sym_cache[key] = cand
                return cand

        # 3) known aliases, each also tried with the suffixes
        for alias in self._ALIASES.get(key, ()):
            for suf in suffixes:
                cand = alias + suf
                if _usable(cand):
                    self._sym_cache[key] = cand
                    return cand

        # 4) last resort: scan everything the broker lists and match loosely
        try:
            wanted = key.replace("/", "").replace("-", "")
            best = None
            for s in (self.mt5.symbols_get() or []):
                name = s.name
                flat = name.upper().replace("/", "").replace("-", "")
                if flat == wanted or flat.startswith(wanted):
                    # prefer the shortest match, which is usually the main one
                    if best is None or len(name) < len(best):
                        best = name
            if best and _usable(best):
                self._sym_cache[key] = best
                return best
        except Exception:
            pass

        self._sym_cache[key] = None
        return None

    def resolution_report(self, symbols: list[str]) -> dict:
        """What each requested symbol resolved to on this broker."""
        out = {}
        for s in symbols:
            out[s] = self.resolve_symbol(s)
        return out

    def has_symbol(self, symbol: str) -> bool:
        return self.resolve_symbol(symbol) is not None

    def bars(self, symbol: str, timeframe_min: int, count: int) -> list[dict]:
        """Full OHLCV bars. tick_volume is the number of price changes, NOT
        traded contracts — forex has no central exchange, so real volume is
        almost always zero. Treat it as activity, not size."""
        symbol = self.resolve_symbol(symbol) or symbol
        tf = self._tf(timeframe_min)
        rates = self.mt5.copy_rates_from_pos(symbol, tf, 0, count)
        if rates is None:
            return []
        out = []
        for r in rates:
            out.append({"time": int(r["time"]), "open": float(r["open"]),
                        "high": float(r["high"]), "low": float(r["low"]),
                        "close": float(r["close"]),
                        "volume": float(r["tick_volume"]),
                        "real_volume": float(r["real_volume"])
                        if "real_volume" in r.dtype.names else 0.0})
        return out

    def ticks(self, symbol: str, minutes: int = 15, limit: int = 20000) -> list[dict]:
        """Raw ticks, for inferring delta. Each tick is classified later by
        whether it printed at the ask (buyer-aggressed) or bid (seller)."""
        symbol = self.resolve_symbol(symbol) or symbol
        try:
            from datetime import datetime, timedelta
            frm = datetime.now() - timedelta(minutes=minutes)
            t = self.mt5.copy_ticks_range(frm, datetime.now(),
                                          self.mt5.COPY_TICKS_ALL)
            if t is None:
                return []
            rows = []
            for x in t[-limit:]:
                rows.append({"time": int(x["time"]), "bid": float(x["bid"]),
                             "ask": float(x["ask"]),
                             "last": float(x["last"]) if "last" in x.dtype.names else 0.0,
                             "volume": float(x["volume"]) if "volume" in x.dtype.names else 0.0})
            return rows
        except Exception:
            return []

    def depth(self, symbol: str) -> list[dict]:
        """Level II book, if the broker publishes one. Most retail FX brokers
        do not — an empty list means no depth, not an error."""
        symbol = self.resolve_symbol(symbol) or symbol
        try:
            if not self.mt5.market_book_add(symbol):
                return []
            book = self.mt5.market_book_get(symbol)
            self.mt5.market_book_release(symbol)
            if not book:
                return []
            return [{"type": int(b.type), "price": float(b.price),
                     "volume": float(b.volume)} for b in book]
        except Exception:
            return []

    def capabilities(self, symbol: str) -> dict:
        """What data is genuinely available for this instrument, so the
        confidence score can weight only what it can actually see."""
        caps = {"bars": False, "ticks": False, "depth": False,
                "real_volume": False}
        try:
            caps["bars"] = len(self.bars(symbol, 15, 5)) > 0
        except Exception:
            pass
        try:
            t = self.ticks(symbol, minutes=5, limit=50)
            caps["ticks"] = len(t) > 0
        except Exception:
            pass
        try:
            caps["depth"] = len(self.depth(symbol)) > 0
        except Exception:
            pass
        try:
            b = self.bars(symbol, 15, 20)
            caps["real_volume"] = any(x.get("real_volume", 0) > 0 for x in b)
        except Exception:
            pass
        return caps

    def margin_required(self, symbol: str, lots: float, side: int = 1) -> float:
        """What the broker will lock up to hold this position.

        Asked of the broker rather than estimated: contract sizes and leverage
        differ per instrument and per account, and a guess is exactly the kind
        of thing that looks right until an index order is rejected for margin.
        Returns 0.0 when it cannot be determined, so callers can decide whether
        to proceed rather than being handed a confident wrong number.
        """
        symbol = self.resolve_symbol(symbol) or symbol
        try:
            order_type = (self.mt5.ORDER_TYPE_BUY if side > 0
                          else self.mt5.ORDER_TYPE_SELL)
            price = self.price(symbol, side)
            m = self.mt5.order_calc_margin(order_type, symbol, lots, price)
            return float(m or 0.0)
        except Exception:
            return 0.0

    def spec(self, symbol: str) -> dict:
        symbol = self.resolve_symbol(symbol) or symbol

        s = self.mt5.symbol_info(symbol)
        return {"point": s.point, "tick_value": s.trade_tick_value,
                "tick_size": s.trade_tick_size, "lot_min": s.volume_min,
                "lot_step": s.volume_step, "lot_max": s.volume_max,
                "digits": s.digits}

    def price(self, symbol: str, side: int) -> float:
        """Live ask/bid. Returns 0.0 when there is no tick.

        A closed market returns None from symbol_info_tick — crashing on
        .ask turned "the market is shut" into a stack trace on a forced
        weekend order. No price is an answer, not an error.
        """
        symbol = self.resolve_symbol(symbol) or symbol
        t = self.mt5.symbol_info_tick(symbol)
        if t is None:
            return 0.0
        px = t.ask if side > 0 else t.bid
        return float(px or 0.0)

    # ---- positions ----
    def my_positions(self) -> list[dict]:
        out = []
        for p in (self.mt5.positions_get() or []):
            if p.magic != self.magic:
                continue
            out.append({"ticket": p.ticket, "symbol": p.symbol,
                        "side": 1 if p.type == 0 else -1, "lots": p.volume,
                        "open_price": p.price_open, "profit": p.profit,
                        "sl": getattr(p, "sl", 0.0) or 0.0,
                        "tp": getattr(p, "tp", 0.0) or 0.0,
                        "comment": p.comment})
        return out

    def basket_profit(self) -> float:
        return sum(p["profit"] for p in self.my_positions())

    # ---- orders ----
    def _filling_mode(self, symbol: str):
        """Pick a filling mode this symbol accepts.

        Brokers differ: some allow FOK, some IOC, some only RETURN. The
        symbol exposes a bitmask of what it supports, so read it rather
        than guessing — guessing is what produces retcode 10030.
        """
        if symbol in self._sym_fill:
            return self._sym_fill[symbol]
        try:
            info = self.mt5.symbol_info(symbol)
            mask = getattr(info, "filling_mode", 0) or 0
            # bit 1 = FOK, bit 2 = IOC (MT5 SYMBOL_FILLING_* flags)
            if mask & 2:
                return self.mt5.ORDER_FILLING_IOC
            if mask & 1:
                return self.mt5.ORDER_FILLING_FOK
        except Exception:
            pass
        return self.mt5.ORDER_FILLING_RETURN

    def _fill_price(self, ticket: int, symbol: str, side: int) -> float:
        """The price a just-opened order actually filled at.

        Checked in order: the open position, then recent deal history, then
        the current market price as a last resort. Never returns 0 if the
        broker knows the answer.
        """
        try:
            for p in (self.mt5.positions_get(symbol=symbol) or []):
                if p.ticket == ticket and p.price_open:
                    return float(p.price_open)
        except Exception:
            pass
        try:
            from datetime import datetime, timedelta
            deals = self.mt5.history_deals_get(
                datetime.now() - timedelta(minutes=5),
                datetime.now() + timedelta(minutes=1))
            for d in (deals or []):
                if getattr(d, "order", None) == ticket and d.price:
                    return float(d.price)
        except Exception:
            pass
        try:
            return float(self.price(symbol, side))
        except Exception:
            return 0.0

    def market(self, symbol: str, side: int, lots: float, sl: float,
               comment: str, tp: float = 0.0) -> dict:
        symbol = self.resolve_symbol(symbol) or symbol
        req = {
            "action": self.mt5.TRADE_ACTION_DEAL, "symbol": symbol,
            "volume": lots,
            "type": self.mt5.ORDER_TYPE_BUY if side > 0 else self.mt5.ORDER_TYPE_SELL,
            "price": self.price(symbol, side), "sl": sl, "tp": tp or 0.0,
            "magic": self.magic, "comment": comment[:26],
            "deviation": 30,
            "type_time": self.mt5.ORDER_TIME_GTC,
            "type_filling": self._filling_mode(symbol),
        }
        # filling modes to try, preferred first. Brokers sometimes reject the
        # mode their own symbol mask advertises, so fall through the others
        # rather than failing the order outright (retcode 10030).
        modes = [req["type_filling"]]
        for m in (self.mt5.ORDER_FILLING_IOC, self.mt5.ORDER_FILLING_FOK,
                  self.mt5.ORDER_FILLING_RETURN):
            if m not in modes:
                modes.append(m)

        res = None
        for mode in modes:
            req["type_filling"] = mode
            for attempt in range(3):
                res = self.mt5.order_send(req)
                if res is not None and res.retcode == self.mt5.TRADE_RETCODE_DONE:
                    if mode != modes[0]:
                        self._sym_fill[symbol] = mode   # remember what worked
                    # some brokers return price 0 on the order result even
                    # though the deal filled — read the real price from the
                    # position rather than trusting it, otherwise every level
                    # derived from the entry is nonsense.
                    fill = float(getattr(res, "price", 0) or 0)
                    if fill <= 0:
                        fill = self._fill_price(res.order, symbol, side)
                    return {"ok": True, "ticket": res.order, "price": fill}
                rc = getattr(res, "retcode", None) if res is not None else None
                # the broker's comment string is its confession — a week of
                # 10030 archaeology would have been one log line with this
                _cm = getattr(res, "comment", "") if res is not None else \
                    str(self.mt5.last_error())
                self.log(f"[fill] {symbol} vol {lots} mode={mode} -> "
                         f"rc={rc} '{_cm}'")
                if rc == 10030:
                    break                    # wrong filling mode — try the next
                if rc in (10018, 10019, 10014, 10016, 10027):
                    # market closed / no money / bad volume / bad stops /
                    # autotrading off — retrying will not help
                    return {"ok": False, "retcode": rc}
                time.sleep(0.6)
                req["price"] = self.price(symbol, side)
        rc = getattr(res, "retcode", "n/a") if res is not None else "none"

        # Every filling mode refused with 10030: some market-execution
        # backends reject any open that CARRIES sl/tp — stops must be set
        # after the fill. Try once, naked, then attach the stops in the
        # same breath. If the stops will not attach, CLOSE IMMEDIATELY:
        # a stopless position on real money is worse than no position.
        if rc == 10030 and (sl or tp):
            naked = dict(req)
            naked["sl"], naked["tp"] = 0.0, 0.0
            for mode in modes:
                naked["type_filling"] = mode
                naked["price"] = self.price(symbol, side)
                res = self.mt5.order_send(naked)
                _rc = getattr(res, "retcode", None) if res is not None else None
                _cm = getattr(res, "comment", "") if res is not None else \
                    str(self.mt5.last_error())
                self.log(f"[fill] {symbol} NAKED mode={mode} -> "
                         f"rc={_rc} '{_cm}'")
                if res is not None and res.retcode == self.mt5.TRADE_RETCODE_DONE:
                    self._sym_fill[symbol] = mode
                    ok_sl = self.modify_sl(res.order, sl, tp or None)
                    if not ok_sl:
                        time.sleep(0.4)
                        ok_sl = self.modify_sl(res.order, sl, tp or None)
                    if not ok_sl:
                        try:
                            self.close({"symbol": symbol, "side": side,
                                        "lots": lots, "ticket": res.order})
                        finally:
                            pass
                        return {"ok": False, "retcode": "naked-fill but "
                                "stops refused — position closed for safety"}
                    fill = float(getattr(res, "price", 0) or 0)
                    if fill <= 0:
                        fill = self._fill_price(res.order, symbol, side)
                    return {"ok": True, "ticket": res.order, "price": fill,
                            "note": "exec-mode quirk: opened naked, stops "
                                    "attached post-fill"}
        return {"ok": False, "retcode": rc}

    def modify_sl(self, ticket: int, new_sl: float,
                  new_tp: float | None = None) -> bool:
        """Move the stop on an open position. Returns True if the broker accepted."""
        try:
            pos = None
            for p in (self.mt5.positions_get() or []):
                if p.ticket == ticket:
                    pos = p
                    break
            if pos is None:
                return False
            digits = self.mt5.symbol_info(pos.symbol).digits
            req = {
                "action": self.mt5.TRADE_ACTION_SLTP,
                "position": ticket,
                "symbol": pos.symbol,
                "sl": round(float(new_sl), digits),
                "tp": round(float(new_tp if new_tp is not None else pos.tp), digits),
            }
            res = self.mt5.order_send(req)
            return bool(res and res.retcode == self.mt5.TRADE_RETCODE_DONE)
        except Exception:
            return False

    def close(self, pos: dict) -> bool:
        side = -pos["side"]
        req = {
            "action": self.mt5.TRADE_ACTION_DEAL, "symbol": pos["symbol"],
            "volume": pos["lots"], "position": pos["ticket"],
            "type": self.mt5.ORDER_TYPE_BUY if side > 0 else self.mt5.ORDER_TYPE_SELL,
            "price": self.price(pos["symbol"], side),
            "magic": self.magic, "comment": "basket-close",
            "type_time": self.mt5.ORDER_TIME_GTC,
            "type_filling": self._filling_mode(pos["symbol"]),
        }
        res = self.mt5.order_send(req)
        return res is not None and res.retcode == self.mt5.TRADE_RETCODE_DONE

    def close_all(self) -> int:
        n = 0
        for p in self.my_positions():
            if self.close(p):
                n += 1
        return n


    def closed_trades_since(self, minutes: int = 1440) -> list[dict]:
        """ALL closed round-trip trades on the account in the last N minutes —
        includes trades opened manually in MT5, not just bot trades.
        Groups deals by position_id; a position is 'closed' when its net
        volume returns to zero (an out deal exists)."""
        try:
            from datetime import datetime, timedelta
            frm = datetime.now() - timedelta(minutes=minutes)
            deals = self.mt5.history_deals_get(frm, datetime.now() + timedelta(hours=2))
            if not deals:
                return []
            by_pos: dict = {}
            for d in deals:
                if d.type not in (0, 1):        # 0=buy,1=sell trade deals only
                    continue
                by_pos.setdefault(d.position_id, []).append(d)
            out = []
            for pid, ds in by_pos.items():
                ds.sort(key=lambda x: x.time)
                has_in = any(getattr(x, "entry", 0) == 0 for x in ds)   # DEAL_ENTRY_IN
                has_out = any(getattr(x, "entry", 0) == 1 for x in ds)  # DEAL_ENTRY_OUT
                if not (has_in and has_out):
                    continue                    # still open or partial
                first = ds[0]
                pnl = round(sum(x.profit + x.swap + x.commission for x in ds), 2)
                out.append({
                    "position_id": pid,
                    "symbol": first.symbol,
                    "side": 1 if first.type == 0 else -1,
                    "lots": round(sum(x.volume for x in ds if getattr(x, "entry", 0) == 0), 2),
                    "entry_price": first.price,
                    "exit_price": ds[-1].price,
                    "pnl": pnl,
                    "opened_at": datetime.fromtimestamp(first.time).isoformat(),
                    "closed_at": datetime.fromtimestamp(ds[-1].time).isoformat(),
                    "comment": (getattr(first, "comment", "") or ""),
                })
            return out
        except Exception:
            return []

    def realized_pnl(self, ticket: int) -> float | None:
        """Exact realized P/L for a closed position, from deal history.

        Queried BY POSITION, without a date window. The previous version passed
        datetime.now() bounds — but those are the VPS clock while deal stamps
        are the broker's server clock, and MEX Atlantic runs hours ahead. A
        deal outside the window is simply not returned, so the P/L never
        arrived however many times we retried, and every trade was eventually
        recorded as unknown.

        history_deals_get(position=...) needs no dates and cannot miss for
        this reason.
        """
        try:
            deals = self.mt5.history_deals_get(position=ticket)

            # some builds want the history range selected first
            if not deals:
                from datetime import datetime, timedelta
                try:
                    self.mt5.history_select(
                        datetime.now() - timedelta(days=30),
                        datetime.now() + timedelta(days=2))
                except Exception:
                    pass
                deals = self.mt5.history_deals_get(position=ticket)

            if not deals:
                return None
            # only trade deals on THIS position — never balance/deposit rows
            deals = [d for d in deals
                     if getattr(d, "position_id", ticket) == ticket
                     and d.type in (0, 1)]
            if not deals:
                return None
            return round(sum(d.profit + d.swap + d.commission for d in deals), 2)
        except Exception:
            return None

    def market_live(self, symbol: str, max_age_sec: int = 120) -> bool:
        """True only if this symbol has a tick within max_age_sec — i.e. the
        market is actually open. Prevents scanners acting on frozen weekend data."""
        try:
            import time as _t
            t = self.mt5.symbol_info_tick(symbol)
            if t is None or not t.time:
                return False
            # broker server clocks run offset from the VPS (this one is
            # UTC+3): a tick "from the future" is FRESH, not stale
            age = _t.time() - t.time
            if age < 0:
                age = 0
            return age <= max_age_sec
        except Exception:
            return False
