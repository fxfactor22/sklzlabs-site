"""SKLZ — two structured entry models.

MODEL A — M15 break and retest
    A level breaks on M15, price returns to it, and the level holds as
    support/resistance. Entry on the hold, not the break.

MODEL B — HTF order block, fib 50 entry
    Price rejects from the 50% level of a 4H or 1H order block. A 5M engulfing
    candle confirms the rejection. A fib is drawn from that rejection line to
    the extreme reached, and entry is at the 50% retracement.

BOTH confirmed by RSI(2) with a 21-period SMA on M5.

WHY THE RSI TIMING MATTERS
==========================
RSI(2) is fast and mean-reverting. At the moment a level breaks it will be
deep overbought on a bullish break — so a rule of "buy only below 30" would
block every entry if it were read at the break.

It is read at the RETEST, which is a pullback, and that is exactly when RSI(2)
falls. The rule and the model agree only because of when the measurement is
taken. Read it at the wrong moment and the model never fires.

The 21-SMA of RSI is the slower reference: RSI below its own average says the
pullback is real rather than a single noisy print.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


# ── indicators ──────────────────────────────────────────────────────
def rsi(closes: list[float], period: int = 2) -> list[float]:
    """Wilder's RSI. Returns a list aligned to the input, padded at the front.

    Period 2 is deliberately short — it is a pullback detector, not a trend
    filter, and at that length it swings the full range within a few bars.
    """
    if len(closes) < period + 1:
        return [50.0] * len(closes)

    out = [50.0] * period
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0.0)
        losses += max(-d, 0.0)
    ag, al = gains / period, losses / period
    out.append(100.0 if al == 0 else 100 - 100 / (1 + ag / al))

    for i in range(period + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        ag = (ag * (period - 1) + max(d, 0.0)) / period
        al = (al * (period - 1) + max(-d, 0.0)) / period
        out.append(100.0 if al == 0 else 100 - 100 / (1 + ag / al))
    return out


def sma(values: list[float], period: int) -> list[float]:
    out, run = [], 0.0
    for i, v in enumerate(values):
        run += v
        if i >= period:
            run -= values[i - period]
        out.append(run / min(i + 1, period))
    return out


# ── shared confirmation ─────────────────────────────────────────────
def rsi_confirms(side: int, m5_closes: list[float],
                 period: int = 2, smooth: int = 21) -> dict:
    """RSI(2) against its 21-SMA, read at the entry bar.

    Buy wants RSI oversold (the pullback is deep enough to be worth entering).
    Sell wants overbought. The SMA comparison guards against a single spike:
    RSI can print 12 on one noisy bar and mean nothing.
    """
    if len(m5_closes) < smooth + period + 2:
        return {"ok": False, "reason": "not enough M5 bars for RSI"}

    r = rsi(m5_closes, period)
    rs = sma(r, smooth)
    cur, avg = r[-1], rs[-1]

    try:
        lo = float(os.environ.get("SKLZ_RSI_BUY_BELOW", "30"))
        hi = float(os.environ.get("SKLZ_RSI_SELL_ABOVE", "70"))
    except ValueError:
        lo, hi = 30.0, 70.0

    # Look back a few bars, not only at the current one.
    #
    # The "hold" that confirms a retest is itself upward movement, and RSI(2)
    # is fast enough to leave oversold on that single bar. Demanding RSI < 30
    # AT the entry bar means the condition is almost never true at the moment
    # you actually want to enter.
    #
    # The real signal is: it REACHED oversold during the pullback, and is now
    # turning back up. That is the classic short-RSI entry and it is what the
    # rule was reaching for.
    try:
        window = int(os.environ.get("SKLZ_RSI_LOOKBACK", "4"))
    except ValueError:
        window = 4
    recent = r[-window:]

    if side > 0:
        reached = min(recent) < lo
        turning = cur > recent[-2] if len(recent) > 1 else True
        ok = reached and turning
        why = (f"RSI(2) reached {min(recent):.0f} in the pullback (under "
               f"{lo:.0f}) and is turning up at {cur:.0f}"
               if ok else
               (f"RSI(2) got to {min(recent):.0f} but is not turning up yet"
                if reached else
                f"RSI(2) low was {min(recent):.0f} over the last {window} bars; "
                f"a buy wants it under {lo:.0f}. The pullback is not deep "
                f"enough."))
    else:
        reached = max(recent) > hi
        turning = cur < recent[-2] if len(recent) > 1 else True
        ok = reached and turning
        why = (f"RSI(2) reached {max(recent):.0f} (over {hi:.0f}) and is "
               f"turning down at {cur:.0f}"
               if ok else
               (f"RSI(2) got to {max(recent):.0f} but is not turning down yet"
                if reached else
                f"RSI(2) high was {max(recent):.0f} over the last {window} "
                f"bars; a sell wants it over {hi:.0f}."))

    return {"ok": ok, "rsi": round(cur, 1), "rsi_avg": round(avg, 1),
            "reason": why}


def engulfing(bars: list[dict], side: int) -> dict:
    """A 5M engulfing candle in the intended direction."""
    if len(bars) < 2:
        return {"ok": False, "reason": "not enough bars"}
    p, c = bars[-2], bars[-1]
    if side > 0:
        ok = (p["close"] < p["open"] and c["close"] > c["open"]
              and c["close"] > p["open"] and c["open"] <= p["close"])
    else:
        ok = (p["close"] > p["open"] and c["close"] < c["open"]
              and c["close"] < p["open"] and c["open"] >= p["close"])
    return {"ok": ok,
            "reason": ("5M engulfing candle in our direction" if ok
                       else "no 5M engulfing candle at this level")}


# ── Model A: M15 break and retest ───────────────────────────────────
@dataclass
class Setup:
    ok: bool
    model: str
    side: int = 0
    entry: float = 0.0
    level: float = 0.0
    stop: float = 0.0
    reasons: list = field(default_factory=list)
    blockers: list = field(default_factory=list)


def find_m15_level(m15: list[dict], lookback: int = 40,
                   touches: int = 2, tol_frac: float = 0.0008) -> list[dict]:
    """Levels worth breaking: prices touched more than once.

    A level nobody traded twice is not a level, it is a coordinate.
    """
    if len(m15) < 12:
        return []
    window = m15[-lookback:]
    pts = []
    for i in range(2, len(window) - 2):
        h, l = window[i]["high"], window[i]["low"]
        if h >= max(window[i - 2]["high"], window[i - 1]["high"],
                    window[i + 1]["high"], window[i + 2]["high"]):
            pts.append(("high", h))
        if l <= min(window[i - 2]["low"], window[i - 1]["low"],
                    window[i + 1]["low"], window[i + 2]["low"]):
            pts.append(("low", l))

    levels = []
    for kind, price in pts:
        hit = [p for k, p in pts if k == kind
               and abs(p - price) <= price * tol_frac]
        if len(hit) >= touches:
            if not any(abs(l["price"] - price) <= price * tol_frac
                       for l in levels):
                levels.append({"kind": kind, "price": sum(hit) / len(hit),
                               "touches": len(hit)})
    return levels


def model_a(m15: list[dict], m5: list[dict], pip: float) -> Setup:
    """M15 break, then retest, then enter on the hold."""
    s = Setup(ok=False, model="A: M15 break-retest")

    levels = find_m15_level(m15)
    if not levels:
        s.blockers.append("no M15 level with two or more touches")
        return s
    if len(m15) < 6:
        s.blockers.append("not enough M15 history")
        return s

    for lv in levels:
        price, kind = lv["price"], lv["kind"]
        side = 1 if kind == "high" else -1

        # did a recent M15 bar close beyond it?
        broke_at = None
        for i in range(len(m15) - 6, len(m15)):
            if i < 1:
                continue
            b = m15[i]
            if side > 0 and b["close"] > price and m15[i - 1]["close"] <= price:
                broke_at = i
            if side < 0 and b["close"] < price and m15[i - 1]["close"] >= price:
                broke_at = i
        if broke_at is None:
            continue

        # has price come back to it and held? measured on M5 for precision
        tol = 6 * pip
        came_back = any(
            (side > 0 and b["low"] <= price + tol) or
            (side < 0 and b["high"] >= price - tol)
            for b in m5[-8:])
        if not came_back:
            s.blockers.append(f"broke {price:.5f} but has not retested it yet")
            continue

        last = m5[-1]
        held = last["close"] > price if side > 0 else last["close"] < price
        if not held:
            s.blockers.append(f"retested {price:.5f} and failed to hold")
            continue

        rsi_c = rsi_confirms(side, [b["close"] for b in m5])
        if not rsi_c["ok"]:
            s.blockers.append(rsi_c["reason"])
            continue

        s.ok = True
        s.side = side
        s.level = price
        s.entry = last["close"]
        s.stop = (min(b["low"] for b in m5[-6:]) - 2 * pip if side > 0
                  else max(b["high"] for b in m5[-6:]) + 2 * pip)
        s.reasons = [
            f"M15 level {price:.5f} touched {lv['touches']}x, then broken",
            "price returned and the level held",
            rsi_c["reason"],
        ]
        return s

    return s


# ── Model B: HTF order block, fib 50 entry ──────────────────────────
def order_block(htf: list[dict], side: int, lookback: int = 30) -> dict | None:
    """The last opposing candle before the move that broke structure.

    That candle is where the position was built — the 50% of its range is the
    level worth watching, not its extreme.
    """
    if len(htf) < 6:
        return None
    window = htf[-lookback:]
    # start at len-2 so the candle immediately before the break is reachable —
    # that is usually THE order block, and len-3 skipped it entirely
    for i in range(len(window) - 2, 0, -1):
        c = window[i]
        nxt = window[i + 1] if i + 1 < len(window) else None
        if nxt is None:
            continue
        if side > 0 and c["close"] < c["open"] and nxt["close"] > c["high"]:
            return {"high": c["high"], "low": c["low"],
                    "mid": (c["high"] + c["low"]) / 2, "index": i}
        if side < 0 and c["close"] > c["open"] and nxt["close"] < c["low"]:
            return {"high": c["high"], "low": c["low"],
                    "mid": (c["high"] + c["low"]) / 2, "index": i}
    return None


def model_b(h4: list[dict], h1: list[dict], m5: list[dict],
            pip: float) -> Setup:
    """Rejection from the 50% of an HTF order block, entered at fib 50."""
    s = Setup(ok=False, model="B: HTF block, fib 50")

    for side in (1, -1):
        blk = order_block(h4, side) or order_block(h1, side)
        if not blk:
            continue

        mid = blk["mid"]

        # has price rejected from the block's 50%?
        touched = any(
            (side > 0 and b["low"] <= mid + 4 * pip) or
            (side < 0 and b["high"] >= mid - 4 * pip)
            for b in m5[-30:])
        if not touched:
            continue

        # the extreme reached since that rejection — and it must be a REAL
        # run. A fib of a 2-pip move has levels 1 pip apart, which is spread.
        min_run = _min_pips("SKLZ_B_MIN_RUN_PIPS", 8.0) * pip
        if side > 0:
            extreme = max(b["high"] for b in m5[-30:])
            if extreme <= mid or (extreme - mid) < min_run:
                continue
            fib50 = mid + (extreme - mid) * 0.5
            at_fib = m5[-1]["low"] <= fib50 + 4 * pip
        else:
            extreme = min(b["low"] for b in m5[-30:])
            if extreme >= mid or (mid - extreme) < min_run:
                continue
            fib50 = mid - (mid - extreme) * 0.5
            at_fib = m5[-1]["high"] >= fib50 - 4 * pip

        if not at_fib:
            s.blockers.append(
                f"rejected from the block at {mid:.5f} but price is not back "
                f"at the 50% fib ({fib50:.5f}) yet")
            continue

        eng = engulfing(m5, side)
        if not eng["ok"]:
            s.blockers.append(eng["reason"])
            continue

        rsi_c = rsi_confirms(side, [b["close"] for b in m5])
        if not rsi_c["ok"]:
            s.blockers.append(rsi_c["reason"])
            continue

        s.ok = True
        s.side = side
        s.level = mid
        s.entry = m5[-1]["close"]
        s.stop = (blk["low"] - 2 * pip if side > 0 else blk["high"] + 2 * pip)
        s.reasons = [
            f"HTF order block {blk['low']:.5f}-{blk['high']:.5f}, "
            f"50% at {mid:.5f}",
            f"price rejected from it and ran to {extreme:.5f}",
            f"returned to the 50% fib at {fib50:.5f}",
            eng["reason"],
            rsi_c["reason"],
        ]
        return s

    return s




# ── Model C: 4H candle open + fair value gap ────────────────────────
def _min_pips(env: str, default: float) -> float:
    try:
        return float(os.environ.get(env, str(default)))
    except ValueError:
        return default


def fair_value_gap(bars: list[dict], side: int, lookback: int = 20,
                   min_height: float = 0.0) -> dict | None:
    """A three-candle gap: the middle candle moved so fast that the first and
    third don't overlap. That unfilled space is where the market skipped
    price levels, and it tends to get revisited.

    Bullish FVG: bar[i-2].high < bar[i].low  (gap below, price jumped up)
    Bearish FVG: bar[i-2].low  > bar[i].high (gap above, price fell through)
    """
    if len(bars) < 3:
        return None
    start = max(2, len(bars) - lookback)
    for i in range(len(bars) - 1, start - 1, -1):
        a, b = bars[i - 2], bars[i]
        if side > 0 and a["high"] < b["low"]:
            if (b["low"] - a["high"]) < min_height:
                continue                    # a gap smaller than noise is noise
            return {"top": b["low"], "bottom": a["high"],
                    "mid": (b["low"] + a["high"]) / 2, "index": i}
        if side < 0 and a["low"] > b["high"]:
            if (a["low"] - b["high"]) < min_height:
                continue
            return {"top": a["low"], "bottom": b["high"],
                    "mid": (a["low"] + b["high"]) / 2, "index": i}
    return None


def model_c(h4: list[dict], m5: list[dict], pip: float) -> Setup:
    """4H open + FVG: the drop below a bullish 4H open is the trap, the fair
    value gap left on the way back is the entry.

    Mechanics, stripped of the video's "millions" framing:
      1. HTF bias from 4H structure (three closed candles)
      2. Price must have traded the WRONG side of the current 4H open —
         below it for longs. That counter-move is the setup, not a failure.
      3. The reversal back through leaves an FVG on M5.
      4. Enter on the retracement INTO that gap, stop beyond the
         counter-move's extreme.
    """
    s = Setup(ok=False, model="C: 4H open + FVG")
    if len(h4) < 5 or len(m5) < 20:
        s.blockers.append("not enough history for the 4H model")
        return s

    # bias from closed 4H candles — the forming one's colour isn't known yet
    closed = h4[:-1]
    ups = sum(1 for b in closed[-3:] if b["close"] > b["open"])
    if ups >= 2:
        side = 1
    elif ups <= 1 and sum(1 for b in closed[-3:]
                          if b["close"] < b["open"]) >= 2:
        side = -1
    else:
        s.blockers.append("4H candles are mixed — no bias")
        return s

    h4_open = h4[-1]["open"]

    # the counter-move: price must have traded the wrong side of the open
    recent = m5[-24:]
    if side > 0:
        dipped = min(b["low"] for b in recent) < h4_open
        extreme = min(b["low"] for b in recent)
    else:
        dipped = max(b["high"] for b in recent) > h4_open
        extreme = max(b["high"] for b in recent)
    if not dipped:
        s.blockers.append(
            f"price has not traded the far side of the 4H open "
            f"({h4_open:.5f}) — no trap, no setup")
        return s

    # A GBPUSD sell fired with a 0.5-pip "trap" and a 0.2-pip "FVG" — every
    # condition technically true, all of it inside the spread. Structure
    # smaller than noise is noise: the trap must be a real excursion and the
    # gap must be wider than the ordinary cost of crossing it.
    trap_depth = abs(h4_open - extreme)
    min_trap = _min_pips("SKLZ_C_MIN_TRAP_PIPS", 5.0) * pip
    if trap_depth < min_trap:
        s.blockers.append(
            f"trap beyond the 4H open is only {trap_depth / pip:.1f} pips — "
            f"price is hovering AT the open, not trapped beyond it "
            f"(needs {min_trap / pip:.0f})")
        return s

    min_gap = _min_pips("SKLZ_MIN_FVG_PIPS", 3.0) * pip
    fvg = fair_value_gap(m5, side, min_height=min_gap)
    if not fvg:
        s.blockers.append(
            f"no fair value gap of at least {min_gap / pip:.0f} pips on the "
            f"reversal yet")
        return s

    # entry: price retracing INTO the gap
    last = m5[-1]
    if side > 0:
        in_gap = last["low"] <= fvg["top"] and last["close"] >= fvg["bottom"]
    else:
        in_gap = last["high"] >= fvg["bottom"] and last["close"] <= fvg["top"]
    if not in_gap:
        s.blockers.append(
            f"FVG at {fvg['bottom']:.5f}-{fvg['top']:.5f} exists but price "
            f"has not retraced into it")
        return s

    rsi_c = rsi_confirms(side, [b["close"] for b in m5])
    if not rsi_c["ok"]:
        s.blockers.append(rsi_c["reason"])
        return s

    s.ok = True
    s.side = side
    s.level = fvg["mid"]
    s.entry = last["close"]
    s.stop = extreme - 2 * pip if side > 0 else extreme + 2 * pip
    s.reasons = [
        f"4H bias {'bullish' if side > 0 else 'bearish'} from closed candles",
        f"price trapped the far side of the 4H open ({h4_open:.5f})",
        f"FVG {fvg['bottom']:.5f}-{fvg['top']:.5f} on the reversal, "
        f"price retraced into it",
        rsi_c["reason"],
    ]
    return s



# ── Model D: inducement sweep + change of character ─────────────────
def swing_points(bars: list[dict], k: int = 2) -> tuple[list, list]:
    """(lows, highs) as (index, price), using k-bar pivots."""
    lows, highs = [], []
    for i in range(k, len(bars) - k):
        if bars[i]["low"] <= min(b["low"] for b in bars[i-k:i+k+1]):
            lows.append((i, bars[i]["low"]))
        if bars[i]["high"] >= max(b["high"] for b in bars[i-k:i+k+1]):
            highs.append((i, bars[i]["high"]))
    return lows, highs


def model_d(m15: list[dict], m5: list[dict], pip: float) -> Setup:
    """Inducement sweep: the minor higher-low is the bait, not the target.

    Sequence (long side; mirrored for shorts):
      1. An obvious low L0, then a rally.
      2. A pullback forms a HIGHER low L1 — the inducement. Retail reads it
         as support and rests stops just beneath it.
      3. Price sweeps below L1 — collecting those stops — while holding
         above L0. The obvious low never trades.
      4. The sweep reverses with a change of character: price closes back
         above the minor high formed after L1.
      5. Entry on that close. Stop below the sweep low (the real risk point).
         If price instead takes L0 too, the read was wrong — which is exactly
         what the stop placement admits.
    """
    s = Setup(ok=False, model="D: inducement sweep")
    if len(m15) < 20 or len(m5) < 20:
        s.blockers.append("not enough history for the inducement model")
        return s

    lows, highs = swing_points(m15[-40:])
    if len(lows) < 2 or not highs:
        s.blockers.append("no clear swing structure on M15")
        return s

    for side in (1, -1):
        if side > 0:
            pts = lows
            # L0 then a HIGHER L1 after it, with a rally high between them
            for a in range(len(pts) - 1):
                i0, l0 = pts[a]
                for b in range(a + 1, len(pts)):
                    i1, l1 = pts[b]
                    if l1 <= l0:
                        continue
                    between = [h for hi, h in highs if i0 < hi < i1]
                    if not between:
                        continue
                    rally_high = max(between)
                    if (rally_high - l0) < 10 * pip:
                        continue

                    # the sweep, on M5: below L1, holding above L0
                    recent = m5[-16:]
                    swept = min(bb["low"] for bb in recent)
                    if not (swept < l1 and swept > l0 + 1 * pip):
                        continue

                    # change of character: closed back above the minor high
                    # formed after the inducement low
                    post = [h for hi, h in highs if hi > i1]
                    choch_ref = min(post) if post else l1 + 8 * pip
                    last = m5[-1]
                    if last["close"] <= choch_ref:
                        s.blockers.append(
                            f"swept the inducement at {l1:.5f} but no change "
                            f"of character yet (needs a close above "
                            f"{choch_ref:.5f})")
                        continue

                    rsi_c = rsi_confirms(side, [bb["close"] for bb in m5])
                    if not rsi_c["ok"]:
                        s.blockers.append(rsi_c["reason"])
                        continue

                    s.ok = True
                    s.side = 1
                    s.level = l1
                    s.entry = last["close"]
                    s.stop = swept - 2 * pip
                    s.reasons = [
                        f"inducement: higher-low {l1:.5f} above the real low "
                        f"{l0:.5f} — retail support with stops beneath",
                        f"swept to {swept:.5f}, collecting those stops while "
                        f"holding above {l0:.5f}",
                        f"change of character — closed back above "
                        f"{choch_ref:.5f}",
                        rsi_c["reason"],
                    ]
                    return s
        else:
            pts = highs
            for a in range(len(pts) - 1):
                i0, h0 = pts[a]
                for b in range(a + 1, len(pts)):
                    i1, h1 = pts[b]
                    if h1 >= h0:
                        continue
                    between = [l for li, l in lows if i0 < li < i1]
                    if not between:
                        continue
                    drop_low = min(between)
                    if (h0 - drop_low) < 10 * pip:
                        continue
                    recent = m5[-16:]
                    swept = max(bb["high"] for bb in recent)
                    if not (swept > h1 and swept < h0 - 1 * pip):
                        continue
                    post = [l for li, l in lows if li > i1]
                    choch_ref = max(post) if post else h1 - 8 * pip
                    last = m5[-1]
                    if last["close"] >= choch_ref:
                        s.blockers.append(
                            f"swept the inducement at {h1:.5f} but no change "
                            f"of character yet (needs a close below "
                            f"{choch_ref:.5f})")
                        continue
                    rsi_c = rsi_confirms(side, [bb["close"] for bb in m5])
                    if not rsi_c["ok"]:
                        s.blockers.append(rsi_c["reason"])
                        continue
                    s.ok = True
                    s.side = -1
                    s.level = h1
                    s.entry = last["close"]
                    s.stop = swept + 2 * pip
                    s.reasons = [
                        f"inducement: lower-high {h1:.5f} below the real high "
                        f"{h0:.5f}",
                        f"swept to {swept:.5f} while holding below {h0:.5f}",
                        f"change of character — closed back below "
                        f"{choch_ref:.5f}",
                        rsi_c["reason"],
                    ]
                    return s
    return s

def evaluate(m15: list[dict], m5: list[dict], h1: list[dict],
             h4: list[dict], pip: float) -> Setup:
    """Try both models; A first because it needs less to be true."""
    a = model_a(m15, m5, pip)
    if a.ok:
        return a
    b = model_b(h4, h1, m5, pip)
    if b.ok:
        return b
    cm = model_c(h4, m5, pip)
    if cm.ok:
        return cm
    d = model_d(m15, m5, pip)
    if d.ok:
        return d
    # none fired — return whichever got furthest, so the log says why
    return min((a, b, cm, d), key=lambda s: len(s.blockers))


# ── break-entry confirmation for scanner-led entries ────────────────
def break_entry_confirmed(m5: list[dict], level: float, side: int,
                          pip: float) -> tuple[bool, str]:
    """A confirmed break ENTRY needs more than a confirmed break.

    The candle closing beyond the level says the break is real. It does not
    say the entry is: the profitable version waits for price to come BACK to
    the broken level, hold it, and print a 5M engulfing in the break's
    direction. Without that, half of "breakouts" are entered at the far end
    of the move — maximum chase, minimum information — and the sweep that
    closes back through collects the stop.

    Sequence, from the owner's own losing-trade review:
      break (already confirmed upstream) -> retest of the line ->
      hold -> 5M engulfing in direction -> enter.
    """
    if len(m5) < 6:
        return False, "not enough M5 bars to confirm the retest"

    tol = 6 * pip
    recent = m5[-10:]
    if side > 0:
        came_back = any(b["low"] <= level + tol for b in recent)
    else:
        came_back = any(b["high"] >= level - tol for b in recent)
    if not came_back:
        return False, (f"broke {level:.5f} but has not retested it — "
                       f"entering here is chasing the far end of the move")

    last = m5[-1]
    held = last["close"] > level if side > 0 else last["close"] < level
    if not held:
        return False, (f"retested {level:.5f} and is not holding the break "
                       f"side — this is how sweeps look")

    eng = engulfing(m5, side)
    if not eng["ok"]:
        return False, (f"retest holding at {level:.5f}, waiting for a 5M "
                       f"engulfing candle to confirm direction")

    return True, (f"break of {level:.5f} retested, held, and confirmed by a "
                  f"5M engulfing — continuation, not a sweep")
