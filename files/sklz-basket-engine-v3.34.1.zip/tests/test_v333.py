"""v3.33.0 — level sources, confirmation stack, Models O/P, M boxes,
E variants, trailing skip/structure, playbook prefix rules, gold/DXY."""
import os
from datetime import datetime, timezone, timedelta

import pytest

from basket_engine.learn import levels as LV
from basket_engine.learn import models as MD
from basket_engine.learn import trailing as TR
from basket_engine.learn import xmarket as XM
from basket_engine.learn.playbook import Playbook


def _bar(o, h, l, c, t=None, v=10):
    return {"open": o, "high": h, "low": l, "close": c, "time": t, "volume": v}


def _day_bars(day0, lo, hi, n=24, vol_center=None):
    """n hourly bars inside [lo, hi]; volume piles up around vol_center."""
    out = []
    for i in range(n):
        f = i / max(1, n - 1)
        mid = lo + (hi - lo) * (0.5 + 0.3 * ((-1) ** i) * f)
        v = 10
        if vol_center is not None and abs(mid - vol_center) < (hi - lo) * 0.15:
            v = 60
        out.append(_bar(mid - 0.2, mid + 0.6, mid - 0.6, mid + 0.2, day0 + i * 3600, v))
    return out


# ── levels ──────────────────────────────────────────────────────────
def test_value_area_brackets_the_poc_and_holds_70pct():
    bars = _day_bars(0, 100.0, 110.0, vol_center=104.0)
    va = LV.value_area(bars, source="volume")
    assert va["val"] <= va["poc"] <= va["vah"]
    assert 102.0 <= va["poc"] <= 106.0
    inside = sum(b for i, b in enumerate(va["buckets"])
                 if va["val"] <= va["lo"] + (i + 0.5) * va["step"] <= va["vah"])
    assert inside / sum(va["buckets"]) >= 0.69


def test_tpo_value_area_ignores_volume():
    bars = _day_bars(0, 100.0, 110.0, vol_center=108.5)
    va_v = LV.value_area(bars, source="volume")
    va_t = LV.value_area(bars, source="tpo")
    assert va_v["poc"] != va_t["poc"] or va_v["vah"] != va_t["vah"]


def test_prev_day_range_and_composite_merge():
    now = datetime(2026, 10, 7, 12, tzinfo=timezone.utc)
    d0 = int(now.timestamp()) // 86400 * 86400
    bars = []
    for k in range(4, 0, -1):               # 4 completed days, overlapping ranges
        bars += _day_bars(d0 - k * 86400, 100.0 + 0.2 * k, 110.0 + 0.2 * k)
    bars += _day_bars(d0, 101.0, 109.0, n=12)           # today, partial
    pd = LV.prev_day_range(bars, now)
    assert pd and pd["bars"] == 24 and pd["high"] > pd["low"]
    cva = LV.composite_va(bars, now_utc=now, source="tpo")
    assert cva and cva["days"] >= 3
    # a day far away breaks the merge
    far = _day_bars(d0 - 5 * 86400, 150.0, 160.0)
    cva2 = LV.composite_va(far + bars, now_utc=now, source="tpo")
    assert cva2["days"] == 4


def test_value_migration_direction():
    now = datetime(2026, 10, 7, 12, tzinfo=timezone.utc)
    d0 = int(now.timestamp()) // 86400 * 86400
    up = []
    for k in range(3, 0, -1):
        up += _day_bars(d0 - k * 86400, 100.0 + 2 * (3 - k), 106.0 + 2 * (3 - k))
    up += _day_bars(d0, 105, 110, n=6)
    assert LV.value_migration(up, now_utc=now, source="tpo")["bias"] == 1
    dn = []
    for k in range(3, 0, -1):
        dn += _day_bars(d0 - k * 86400, 110.0 - 2 * (3 - k), 116.0 - 2 * (3 - k))
    dn += _day_bars(d0, 105, 110, n=6)
    assert LV.value_migration(dn, now_utc=now, source="tpo")["bias"] == -1


def test_session_vwap_uses_only_today():
    now = datetime(2026, 10, 7, 12, tzinfo=timezone.utc)
    d0 = int(now.timestamp()) // 86400 * 86400
    bars = _day_bars(d0 - 86400, 200, 210) + _day_bars(d0, 100, 110, n=12)
    v = LV.session_vwap(bars, now_utc=now)
    assert 100 < v < 110


def test_structural_target_needs_min_rr():
    bars = [_bar(100, 100.5, 99.5, 100.2)] * 5
    bars += [_bar(100, 101.0, 99.8, 100.9), _bar(100.9, 103.0, 100.8, 102.5),
             _bar(102.5, 102.6, 101.0, 101.2), _bar(101.2, 101.3, 100.5, 100.8),
             _bar(100.8, 101.0, 100.4, 100.6)]
    bars += [_bar(100.6, 100.9, 100.3, 100.7)] * 4
    tgt, why = LV.structural_target(bars, 1, entry=100.7, stop=100.2, min_rr=1.5)
    assert tgt == pytest.approx(103.0)
    tgt2, _ = LV.structural_target(bars, 1, entry=100.7, stop=99.0, min_rr=1.5)
    assert tgt2 is None


# ── confirmation stack ───────────────────────────────────────────────
def _sweep_series():
    # down-close run into a low sweep at index 4, then a reversal that
    # closes through the opens and through the gap
    b = [_bar(105, 105.5, 104.5, 104.8), _bar(104.8, 105.0, 104.0, 104.2),
         _bar(104.2, 104.3, 103.0, 103.2), _bar(103.2, 103.3, 101.5, 101.8),
         _bar(101.8, 101.9, 100.0, 100.4),                       # sweep bar (4)
         _bar(100.4, 101.2, 100.2, 101.1), _bar(101.1, 102.4, 101.0, 102.3),
         _bar(102.3, 103.6, 102.2, 103.5), _bar(103.5, 105.4, 103.4, 105.2)]
    return b


def test_cisd_requires_close_through_the_series_opens():
    b = _sweep_series()
    ok, lvl, why = MD.cisd(b, 4, 1)
    assert ok and lvl == pytest.approx(105.0) and "CISD" in why
    ok2, _, _ = MD.cisd(b[:7], 4, 1)
    assert not ok2


def test_inverse_fvg_detects_the_failed_gap():
    b = _sweep_series()
    ok, why = MD.inverse_fvg(b, 4, 1)
    assert ok and "inverse FVG" in why


def test_confirm_entry_price_poc_mode(monkeypatch):
    b = _sweep_series()
    monkeypatch.setenv("SKLZ_CONFIRM_ENTRY", "poc")
    px = MD.confirm_entry_price(b, 4, 1)
    assert 100.0 <= px <= 105.5
    monkeypatch.setenv("SKLZ_CONFIRM_ENTRY", "close")
    assert MD.confirm_entry_price(b, 4, 1) == b[-1]["close"]


# ── Model O plan ─────────────────────────────────────────────────────
def test_model_o_plan_marks_pivots_and_invalidates_on_929_break():
    m1 = []
    px = 100.0
    for i in range(40):
        step = 0.3 if (i // 5) % 2 == 0 else -0.3
        px += step
        m1.append(_bar(px - 0.1, px + 0.2, px - 0.2, px + 0.1))
    m1.append(_bar(px, px + 0.1, px - 0.1, px))              # forming 09:29 bar, inside
    plan = MD.model_o_plan(m1, pip=0.1, spread=0.05)
    assert plan["ok"] and plan["high"] > plan["low"]
    assert plan["sl_dist"] == pytest.approx(1.0)              # 10 pts x 0.1
    assert plan["tp_dist"] == pytest.approx(3.0)
    broken = m1[:-1] + [_bar(px, plan["high"] + 1, px - 0.1, px)]
    assert not MD.model_o_plan(broken, pip=0.1)["ok"]


def test_model_o_sl_floor_is_three_spreads():
    m1 = [_bar(100 + (i % 7) * 0.2, 100.3 + (i % 7) * 0.2, 99.8 + (i % 7) * 0.2, 100.1 + (i % 7) * 0.2)
          for i in range(40)] + [_bar(100.5, 100.6, 100.4, 100.5)]
    plan = MD.model_o_plan(m1, pip=0.1, spread=2.0)
    assert plan["ok"] and plan["sl_dist"] == pytest.approx(6.0)


# ── Model M orb / london ─────────────────────────────────────────────
def _orb_day(now):
    from zoneinfo import ZoneInfo
    ny = now.astimezone(ZoneInfo("America/New_York"))
    t_open = int(ny.replace(hour=9, minute=30, second=0, microsecond=0).timestamp())
    bars = []
    t = t_open - 60 * 300
    px = 100.0
    while t < t_open:
        bars.append(_bar(px, px + 0.3, px - 0.3, px, t)); t += 300
    for i in range(3):                                   # the 15-min box
        bars.append(_bar(100, 100.8, 99.2, 100.1, t)); t += 300
    # break up with an FVG through the box high, then a retrace into it
    bars.append(_bar(100.1, 100.9, 100.0, 100.8, t)); t += 300
    bars.append(_bar(100.8, 102.6, 100.8, 102.5, t)); t += 300          # displacement
    bars.append(_bar(102.5, 102.9, 102.3, 102.7, t)); t += 300          # gap 100.9..102.3
    bars.append(_bar(102.7, 102.8, 101.8, 102.0, t)); t += 300          # into the gap
    return bars, t


def test_model_m_orb_enters_on_fvg_retrace(monkeypatch):
    now = datetime(2026, 10, 7, 14, 10, tzinfo=timezone.utc)      # 10:10 NY (EDT)
    bars, t = _orb_day(now)
    # bar times are UTC epochs here, so the server offset is ~0; align `now`
    now = datetime.fromtimestamp(t, tz=timezone.utc)
    monkeypatch.setenv("SKLZ_M_BOX", "orb")
    monkeypatch.setenv("SKLZ_M_PULLBACK", "fvg")
    monkeypatch.setenv("SKLZ_MIN_STOP_PIPS", "2")
    s = MD.model_m([], [], 0.1, {"m5": bars, "now": now})
    assert s.ok, s.blockers
    assert s.side == 1 and s.tag == "m_orb" and s.target > s.entry > s.stop


def test_model_m_orb_waits_without_fvg(monkeypatch):
    now = datetime(2026, 10, 7, 14, 10, tzinfo=timezone.utc)
    bars, t = _orb_day(now)
    # replace the displacement with a slow grind (no gap)
    bars[-3] = _bar(100.8, 101.3, 100.7, 101.2, bars[-3]["time"])
    bars[-2] = _bar(101.2, 101.6, 101.1, 101.5, bars[-2]["time"])
    bars[-1] = _bar(101.5, 101.7, 101.3, 101.6, bars[-1]["time"])
    now = datetime.fromtimestamp(t, tz=timezone.utc)
    monkeypatch.setenv("SKLZ_M_BOX", "orb")
    s = MD.model_m([], [], 0.1, {"m5": bars, "now": now})
    assert not s.ok and any("FVG" in b for b in s.blockers)


# ── Model E variants ─────────────────────────────────────────────────
def test_model_e_prev_day_variant_tags_and_targets(monkeypatch):
    now = datetime(2026, 10, 7, 9, tzinfo=timezone.utc)
    d0 = int(now.timestamp()) // 86400 * 86400
    h1 = _day_bars(d0 - 2 * 86400, 100, 110) + _day_bars(d0 - 86400, 100, 110)
    pdl = min(b["low"] for b in h1[-24:])
    # today: 8 bars, the last ones sweep the PDL
    for i in range(7):
        h1.append(_bar(102, 102.5, 101.5, 102, d0 + i * 3600))
    h1.append(_bar(101.5, 101.6, pdl - 0.8, pdl + 0.3, d0 + 7 * 3600))
    # M15: a lower-high then a close above it (structure shift)
    m15 = [_bar(102, 102.4, 101.6, 101.8)] * 10 + [_bar(101.8, 102.0, 101.0, 101.2),
          _bar(101.2, 101.4, 100.2, 100.4), _bar(100.4, 100.6, pdl - 0.8, pdl + 0.3),
          _bar(pdl + 0.3, 102.6, pdl + 0.2, 102.5)]
    # M5: a bullish FVG and price back in it
    m5 = [_bar(100.4, 100.6, 100.2, 100.5)] * 8 + [_bar(100.5, 100.7, 100.3, 100.6),
          _bar(100.6, 101.9, 100.6, 101.8), _bar(101.8, 102.3, 101.7, 102.2),
          _bar(102.2, 102.2, 101.0, 101.3)]
    monkeypatch.setenv("SKLZ_E_LEVELS", "prev_day")
    monkeypatch.setenv("SKLZ_MIN_STOP_PIPS", "2")
    s = MD.model_e(h1, m5, 0.1, {"m15": m15, "now": now})
    assert s.ok, s.blockers
    assert s.tag == "e_pd" and s.side == 1
    assert s.target == pytest.approx(max(b["high"] for b in h1[-32:-8]))


def test_model_e_default_behaviour_unchanged(monkeypatch):
    monkeypatch.delenv("SKLZ_E_LEVELS", raising=False)
    h1 = [_bar(100, 101, 99, 100.5)] * 48
    m5 = [_bar(100, 100.2, 99.8, 100.1)] * 20
    s = MD.model_e(h1, m5, 0.1)
    assert not s.ok and s.tag == ""


# ── trailing ─────────────────────────────────────────────────────────
def test_trailing_skips_fixed_tp_and_code_O(monkeypatch):
    TR.mark_fixed(777)
    assert TR.skip_position(777)
    assert TR.skip_position(1, "sklz-a O")
    assert not TR.skip_position(2, "sklz-a SB+C")
    monkeypatch.setenv("SKLZ_TRAIL_SKIP_CODES", "O,K")
    assert TR.skip_position(3, "sklz-a SE+K")


def test_structure_stop_follows_last_swing_low():
    bars = [{"high": 101, "low": 100.6}, {"high": 101.5, "low": 100.5},
            {"high": 101.2, "low": 100.2}, {"high": 102, "low": 101},
            {"high": 102.5, "low": 101.5}, {"high": 103, "low": 102.2},
            {"high": 103.5, "low": 102.8}, {"high": 104, "low": 103}]
    sl = TR.structure_stop(bars, 1, entry=99.5, current_sl=99.8, pip=0.1)
    assert sl == pytest.approx(100.2 - 0.2)
    assert TR.structure_stop(bars, 1, entry=99.5, current_sl=100.5, pip=0.1) is None


# ── playbook prefix matching ─────────────────────────────────────────
def test_playbook_rule_on_model_e_also_blocks_variants(tmp_path):
    import json
    pth = tmp_path / "pb.json"
    pth.write_text(json.dumps({"block": [{"signals": ["model_e"], "sessions": ["Asian"], "why": "x"}]}))
    pb = Playbook(path=str(pth), log=lambda *a: None)
    assert pb.check(["model_e_va"], "XAUUSD", session="Asian")[0] is False
    assert pb.check(["model_e_pd"], "XAUUSD", session="London")[0] is True
    assert pb.check(["model_x"], "XAUUSD", session="Asian")[0] is True


# ── gold / DXY ───────────────────────────────────────────────────────
def test_xmarket_neutral_when_not_negatively_correlated(monkeypatch):
    gold = [100 + i * 0.1 for i in range(60)]
    dxy = [100 + i * 0.1 for i in range(60)]               # same direction: corr +1
    out = XM.judge(gold, dxy, [], 1)
    assert out["ok"] is None and out["score"] == 0


def test_xmarket_synthetic_basket_moves_against_eurusd():
    eur = [1.10 - i * 0.001 for i in range(30)]
    jpy = [150 + i * 0.1 for i in range(30)]
    dxy = XM.synthetic_dxy({"EURUSD": eur, "USDJPY": jpy})
    assert dxy and dxy[-1] > dxy[0]
