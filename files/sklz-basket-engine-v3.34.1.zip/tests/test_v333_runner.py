"""Model O straddle wiring: arm -> fill -> journal -> OCO cancel, on a fake IO."""
import os, time
from datetime import datetime, timezone

from basket_engine.learn.runner import LearningRunner


class StraddleIO:
    def __init__(self):
        self.orders, self.positions, self.cancelled = {}, {}, []
        self.next = 500
        px = 100.0
        self.m1 = []
        for i in range(45):
            px += 0.3 if (i // 5) % 2 == 0 else -0.3
            self.m1.append({"open": px - 0.1, "high": px + 0.2, "low": px - 0.2,
                            "close": px + 0.1, "volume": 5, "time": 1_700_000_000 + i * 60})
        self.px = px
    # -- surface the runner / entries touch --
    def account(self): return {"equity": 50000.0, "balance": 50000.0}
    def closes(self, s, tf, n): return [b["close"] for b in self.m1][-n:]
    def bars(self, s, tf, n): return self.m1[-n:]
    def has_symbol(self, s): return True
    def resolve_symbol(self, s): return s
    def spec(self, s): return {"point": 0.1, "tick_value": 1.0, "tick_size": 0.1,
                               "lot_min": 0.01, "lot_step": 0.01, "lot_max": 100.0, "digits": 1,
                               "contract_size": 1.0, "margin_initial": 0.0}
    def price(self, s, side): return self.px + (0.05 if side > 0 else -0.05)
    def spread(self, s): return 0.1
    def my_positions(self): return list(self.positions.values())
    def basket_profit(self): return 0.0
    def margin_required(self, s, lots, side=1): return 10.0
    def market_live(self, s, max_age_sec=120): return True
    def pending(self, symbol, side, lots, price, sl, tp, comment, expire_epoch=None):
        t = self.next; self.next += 1
        self.orders[t] = {"symbol": symbol, "side": side, "lots": lots, "price": price,
                          "sl": sl, "tp": tp, "comment": comment}
        return {"ok": True, "ticket": t, "retcode": 10009, "comment": "done"}
    def cancel_order(self, t):
        self.cancelled.append(t); self.orders.pop(t, None); return True
    def order_alive(self, t): return t in self.orders
    def position_for_order(self, t): return self.positions.get(t)
    def fill(self, t):
        o = self.orders.pop(t)
        self.positions[t] = {"ticket": t, "symbol": o["symbol"], "side": o["side"],
                             "lots": o["lots"], "open_price": o["price"], "profit": 0.0,
                             "sl": o["sl"], "tp": o["tp"], "comment": o["comment"]}


def test_straddle_arms_fills_and_cancels_sibling(tmp_path, monkeypatch):
    monkeypatch.setenv("SKLZ_MODELS_ENABLED", "o")
    monkeypatch.setenv("SKLZ_O_SYMBOLS", "US30")
    monkeypatch.setenv("SKLZ_MAX_RISK_PCT", "0.5")
    monkeypatch.setenv("SKLZ_SL_STRUCTURE", "0")
    monkeypatch.setenv("SKLZ_PUBLISH_SIGNALS", "0")
    monkeypatch.chdir(tmp_path)
    io = StraddleIO()
    logs = []
    r = LearningRunner(io, log=logs.append, auto=True, symbols=["US30"])
    r._pending = []
    r._arm_straddle("US30", int(time.time()) + 60)
    assert len(r._pending) == 2, logs
    buy = [p for p in r._pending if p["side"] > 0][0]
    sell = [p for p in r._pending if p["side"] < 0][0]
    assert buy["price"] > sell["price"]
    assert abs(buy["price"] - buy["sl"]) * 3 == __import__("pytest").approx(abs(buy["tp"] - buy["price"]))
    io.fill(buy["ticket"])
    r._tend_pending(window_closed=False)
    assert sell["ticket"] in io.cancelled
    assert r._pending == []
    rows = r.journal.load_day() if hasattr(r.journal, "load_day") else []
    entries = [x for x in rows if x.get("type") == "entry"]
    assert entries and entries[-1]["ticket"] == buy["ticket"]
    from basket_engine.learn import trailing as TR
    assert TR.skip_position(buy["ticket"])


def test_unfilled_straddle_is_cancelled_when_window_closes(tmp_path, monkeypatch):
    monkeypatch.setenv("SKLZ_MODELS_ENABLED", "o")
    monkeypatch.setenv("SKLZ_SL_STRUCTURE", "0")
    monkeypatch.setenv("SKLZ_PUBLISH_SIGNALS", "0")
    monkeypatch.chdir(tmp_path)
    io = StraddleIO()
    r = LearningRunner(io, log=lambda *a: None, auto=True, symbols=["US30"])
    r._pending = []
    r._arm_straddle("US30", int(time.time()) + 60)
    assert len(r._pending) == 2
    r._tend_pending(window_closed=True)
    assert len(io.cancelled) == 2 and r._pending == []
