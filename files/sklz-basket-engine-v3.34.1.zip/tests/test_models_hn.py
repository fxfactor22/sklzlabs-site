"""Models H, J, K, L, M, N (and the optional E wick rule). Each fixture is
the rule set of its video, drawn as candles; a failing case names the rule."""
import os, sys
from datetime import datetime, timezone
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest
from basket_engine.learn import models as MD

PIP = 0.01


@pytest.fixture(autouse=True)
def _env(monkeypatch):
    monkeypatch.setenv("SKLZ_MIN_STOP_PIPS", "0")
    for v in ("SKLZ_H_WINDOW", "SKLZ_M_WINDOW", "SKLZ_L_SYMBOLS", "SKLZ_N_SYMBOLS",
              "SKLZ_E_WICK", "SKLZ_H_MIN_RR", "SKLZ_J_MIN_RR", "SKLZ_K_MIN_RR",
              "SKLZ_N_MIN_RR", "SKLZ_L_TF"):
        monkeypatch.delenv(v, raising=False)


def bar(o, h, l, c, t=None):
    d = {"open": o, "high": h, "low": l, "close": c, "volume": 100}
    if t is not None:
        d["time"] = t
    return d


def trend(n, start, step, w=0.3, t0=None, dt=60):
    """n bars stepping `step` per bar (negative = down)."""
    out, px = [], start
    for i in range(n):
        o, c = px, px + step
        out.append(bar(o, max(o, c) + w, min(o, c) - w, c,
                       None if t0 is None else t0 + i * dt))
        px = c
    return out


def flat(n, px, w=0.2, t0=None, dt=60):
    return [bar(px, px + w, px - w, px, None if t0 is None else t0 + i * dt) for i in range(n)]


NOW_LDN = datetime(2026, 9, 28, 8, 0, tzinfo=timezone.utc)      # inside 07-10
NOW_US = datetime(2026, 9, 28, 14, 0, tzinfo=timezone.utc)      # inside 13:30-15:30


# ── H: Heikin Ashi flip ──────────────────────────────────────────────
def h_fixture(wick_against=False, flip=True):
    m = trend(70, 100, 0.4)                       # rising ribbon, EMA20 > EMA50
    px = m[-1]["close"]
    m += [bar(px, px + 0.2, px - 1.2, px - 1.0), bar(px - 1.0, px - 0.8, px - 2.0, px - 1.8),
          bar(px - 1.8, px - 1.6, px - 2.6, px - 2.4)]                # red run (pullback)
    lo = px - 2.4
    if flip:
        # strong green: opens at the HA open region and closes well above, no lower wick
        m += [bar(lo + 0.7, lo + 3.3, lo + (0.0 if wick_against else 0.65), lo + 3.2)]
    else:
        m += [bar(lo, lo + 0.1, lo - 0.6, lo - 0.5)]
    m += [bar(m[-1]["close"], m[-1]["close"] + 0.4, m[-1]["close"] - 0.05, m[-1]["close"] + 0.3)]  # live bar, still green
    # a prior swing high far above so the target pays
    m[60] = bar(m[60]["open"], m[60]["open"] + 15.0, m[60]["low"], m[60]["close"])
    return m


def test_h_fires_on_a_clean_flip_in_london():
    s = MD.model_h(h_fixture(), PIP, {"now": NOW_LDN})
    assert s.ok and s.side == 1, s.blockers
    assert "no wick against it" in " ".join(s.reasons) and "R" in s.reasons[-1]


def test_h_rejects_a_flip_with_a_wick_and_outside_london():
    s = MD.model_h(h_fixture(wick_against=True), PIP, {"now": NOW_LDN})
    assert not s.ok and any("wick against" in b for b in s.blockers)
    s = MD.model_h(h_fixture(), PIP, {"now": NOW_US})
    assert not s.ok and any("London window" in b for b in s.blockers)
    s = MD.model_h(h_fixture(flip=False), PIP, {"now": NOW_LDN})
    assert not s.ok and any("no HA colour flip" in b for b in s.blockers)


# ── K: 4H sweep-engulf ──────────────────────────────────────────────
def k_fixture(engulf=True, late=False):
    h4 = flat(10, 100, 1.0, t0=1_000_000, dt=14400)
    h4[3] = bar(100, 111.0, 99.0, 110.0, h4[3]["time"])          # a prior swing high to target
    prev = bar(102.0, 102.8, 100.0, 100.5, h4[-3]["time"])       # bearish previous candle
    sweep = bar(100.5, 102.9, 99.2, 102.6 if engulf else 101.5, h4[-2]["time"])   # sweeps 100.0, closes above 102.0 body top
    h4[-3], h4[-2] = prev, sweep
    h4[-1] = bar(102.6, 102.8, 102.4, 102.7, h4[-1]["time"])
    m5 = flat(5, 102.6, 0.1, t0=h4[-1]["time"] + (3600 if late else 300), dt=300)
    return h4, m5


def test_k_fires_at_the_close_of_a_sweep_engulf_candle():
    h4, m5 = k_fixture()
    s = MD.model_k(h4, m5, PIP)
    assert s.ok and s.side == 1, s.blockers
    assert s.stop < 99.2 and "engulf" in " ".join(s.reasons)


def test_k_needs_the_engulf_and_the_first_30_minutes():
    h4, m5 = k_fixture(engulf=False)
    assert any("no engulf" in b for b in MD.model_k(h4, m5, PIP).blockers)
    h4, m5 = k_fixture(late=True)
    assert any("30 minutes" in b for b in MD.model_k(h4, m5, PIP).blockers)


# ── L: accumulation candle sweep + breaker ──────────────────────────
def l_fixture(retest=True):
    h1 = flat(30, 100, 0.5)
    h1[-5] = bar(99.0, 103.2, 98.8, 103.0)                     # big body, small wicks: the accumulation candle
    e = flat(60, 102.0, 0.2)
    # leg up into a sweep of H=103.2, then break of the leg's start, then retest of the breaker
    e += [bar(102.0, 102.5, 101.9, 102.4), bar(102.4, 102.9, 102.3, 102.8),
          bar(102.8, 103.5, 102.7, 103.3),                     # last bullish candle before the sweep high -> breaker 102.8–103.3
          bar(103.3, 103.9, 103.1, 103.4)]                     # sweep high 103.9 > 103.2, still bullish
    # NOTE: the breaker is the last bullish candle in the leg = the sweep bar itself here; make sweep bar bearish
    e[-1] = bar(103.3, 103.9, 102.9, 103.0)                    # sweep bar closes down -> breaker is the 102.8–103.3 candle
    e += [bar(103.0, 103.1, 102.2, 102.3), bar(102.3, 102.4, 101.5, 101.6)]   # break below the leg start (101.9)
    if retest:
        e += [bar(101.6, 103.0, 101.5, 102.9)]                 # back into the breaker 102.8–103.3
    else:
        e += [bar(101.6, 101.9, 101.2, 101.4)]
    return h1, e


def test_l_sells_the_breaker_retest_after_the_high_sweep():
    h1, e = l_fixture()
    s = MD.model_l(h1, e, PIP, {"symbol": "XAUUSD.c"})
    assert s.ok and s.side == -1, s.blockers
    assert s.stop > 103.3 and "breaker" in " ".join(s.reasons)


def test_l_waits_for_the_retest_and_respects_the_symbol_list():
    h1, e = l_fixture(retest=False)
    assert any("retest of the breaker" in b for b in MD.model_l(h1, e, PIP, {"symbol": "XAUUSD"}).blockers)
    s = MD.model_l(*l_fixture(), PIP, {"symbol": "EURUSD"})
    assert not s.ok and "SKLZ_L_SYMBOLS" in s.blockers[0]


# ── M: day-box breakout, 1B pullback ────────────────────────────────
def m_fixture(now=NOW_US, pierce=True, broke=True):
    t_now = int(now.timestamp())
    day0 = t_now // 86400 * 86400
    m10 = []
    t = day0
    while t < day0 + int(13.5 * 3600):
        m10.append(bar(100, 100.6, 99.4, 100, t)); t += 600          # box 99.4–100.6, EU high 100.6
    if broke:
        m10.append(bar(100, 100.1, 98.9, 99.0, t)); t += 600         # M10 close below the box
    m10.append(bar(99.0, 99.2, 98.8, 99.1, t))                       # forming
    tb = m10[-2]["time"]
    m2 = [bar(99.0, 99.05, 98.95, 99.0, tb + 120 * i) for i in range(30)]
    if pierce:
        for k, o in zip(range(-4, 0), (99.0, 99.1, 99.2, 99.3)):
            m2[k] = bar(o, o + 0.05, o - 0.05, o + 0.02, m2[k]["time"])
        m2[-1] = bar(99.3, 99.75, 99.25, 99.35, m2[-1]["time"])         # high pierces the upper 1B
    return m10, m2


def test_m_shorts_the_1b_pullback_after_a_downside_box_break():
    m10, m2 = m_fixture()
    s = MD.model_m(m10, m2, PIP, {"now": NOW_US})
    assert s.ok and s.side == -1, s.blockers
    assert s.stop > 100.6 and "European-session high" in s.reasons[-1]


def test_m_needs_a_close_outside_the_box_a_pierce_and_the_window():
    m10, m2 = m_fixture(broke=False)
    assert any("no M10 close outside" in b for b in MD.model_m(m10, m2, PIP, {"now": NOW_US}).blockers)
    m10, m2 = m_fixture(pierce=False)
    assert any("pierce the 1B" in b for b in MD.model_m(m10, m2, PIP, {"now": NOW_US}).blockers)
    m10, m2 = m_fixture()
    assert any("US-open window" in b for b in MD.model_m(m10, m2, PIP, {"now": NOW_LDN}).blockers)


# ── N: MA ladder ────────────────────────────────────────────────────
def n_fixture(kind="retest"):
    # a long slow decline stacks the three SMAs above price: SMA200 < SMA400 < SMA600
    c = trend(640, 200, -0.05, w=0.1)
    def line(idx_p):
        return MD._sma_series([b["close"] for b in c], idx_p)
    if kind == "retest":
        px = c[-1]["close"]
        target = line(200)[-1] + 1.0
        c += trend(8, px, (target - px) / 8, w=0.1)               # break above the SMA200
        top = c[-1]["close"]
        c += [bar(top, top + 0.1, top - 0.5, top - 0.2)]           # placeholder retest bar, patched below
        ln = line(200)[-1]
        c[-1] = bar(top, top + 0.1, ln - 0.05, ln + 0.4)            # low touches the line, close above it
    else:
        px = c[-1]["close"]
        mid_target = (line(200)[-1] + line(400)[-1]) / 2
        c += trend(8, px, (mid_target - px) / 8, w=0.1)           # rally to between SMA200 and SMA400
        c += flat(3, c[-1]["close"], 0.2)
        base = c[-1]["close"]
        c += [bar(base, base, base, base) for _ in range(4)]       # placeholders, patched below
        l4 = line(400)
        n = len(c)
        # touch 1 and touch 2 of the SMA400 from below, rejected; then a close under the last test bar
        c[n - 4] = bar(base, l4[n - 4] + 0.02, base - 0.3, l4[n - 4] - 0.4)
        c[n - 3] = bar(l4[n - 4] - 0.4, l4[n - 3] - 0.3, l4[n - 3] - 0.9, l4[n - 3] - 0.6)
        c[n - 2] = bar(l4[n - 3] - 0.6, l4[n - 2] + 0.02, l4[n - 2] - 0.8, l4[n - 2] - 0.5)
        c[n - 1] = bar(l4[n - 2] - 0.5, l4[n - 1] - 0.4, l4[n - 1] - 1.4, l4[n - 1] - 1.3)
    return c


def test_n_buys_the_retest_of_a_broken_ma_toward_the_next_line():
    s = MD.model_n(n_fixture(), PIP, {"symbol": "XAUUSD"})
    assert s.ok and s.side == 1, s.blockers
    assert "never the break" in " ".join(s.reasons) and "next MA" in s.reasons[-1]


def test_n_sells_a_twice_failed_approach():
    s = MD.model_n(n_fixture("fail"), PIP, {"symbol": "XAUUSD"})
    assert s.ok and s.side == -1, s.blockers
    assert "twice" in s.reasons[0]


def test_n_symbol_gate_and_history():
    s = MD.model_n(n_fixture(), PIP, {"symbol": "EURUSD"})
    assert not s.ok and "SKLZ_N_SYMBOLS" in s.blockers[0]
    assert "M5 bars" in MD.model_n(flat(50, 100), PIP, {"symbol": "XAUUSD"}).blockers[0]


# ── J: nested demand ────────────────────────────────────────────────
def j_fixture(back=True):
    # zigzag uptrend: 15 up (+0.5), 5 down (-0.6) x7 -> HH/HL over a rising EMA100
    h1, px = [], 100.0
    tops = []
    for _ in range(7):
        h1 += trend(15, px, 0.5, w=0.3); px = h1[-1]["close"]; tops.append(len(h1) - 1)
        h1 += trend(5, px, -0.6, w=0.3); px = h1[-1]["close"]
    zone = h1[tops[-1]]["high"]                       # the last swing high ...
    h1 += trend(10, px, 0.5, w=0.3); px = h1[-1]["close"]   # ... broken by the current leg
    h1 += trend(3, px, -(px - zone) / 3.2, w=0.3)     # pull back toward it
    last = h1[-1]
    h1[-1] = bar(last["open"], last["open"] + 0.2, zone - 0.05, zone + 0.15)   # into the zone
    m5 = flat(40, zone + 0.3, 0.1)
    d = bar(zone + 0.3, zone + 0.4, zone - 0.1, zone + 0.05)              # the red candle before the push
    imp = [bar(zone + 0.05, zone + 0.9, zone + 0.0, zone + 0.8), bar(zone + 0.8, zone + 1.6, zone + 0.7, zone + 1.5),
           bar(zone + 1.5, zone + 2.4, zone + 1.4, zone + 2.3)]           # 3 green candles >> 1.5 ATR(m5)
    m5 += [d] + imp
    m5 += [bar(zone + 2.3, zone + 2.4, zone + 1.6, zone + 1.7), bar(zone + 1.7, zone + 1.8, zone + 0.9, zone + 1.0)]
    if back:
        m5 += [bar(zone + 1.0, zone + 1.1, zone + 0.2, zone + 0.35)]        # back into the demand block
    else:
        m5 += [bar(zone + 1.0, zone + 1.3, zone + 0.9, zone + 1.2)]
    return h1, m5


def test_j_buys_the_return_into_the_nested_demand_block():
    h1, m5 = j_fixture()
    s = MD.model_j(h1, m5, PIP)
    assert s.ok and s.side == 1, s.blockers
    assert "demand block" in " ".join(s.reasons) and s.stop < s.entry


def test_j_waits_for_the_return_and_needs_a_trend():
    h1, m5 = j_fixture(back=False)
    assert any("return into the demand block" in b for b in MD.model_j(h1, m5, PIP).blockers)
    h1d = trend(150, 200, -0.3, w=0.4)
    s = MD.model_j(h1d, m5, PIP)
    assert not s.ok and any("no long trend" in b for b in s.blockers)


# ── E wick refinement (optional) ────────────────────────────────────
def test_e_wick_rule_is_off_by_default_and_gates_when_on(monkeypatch):
    prev = flat(24, 100, 1.0)                       # prior session 99–101
    cur = flat(20, 100.5, 0.3)
    cur += [bar(100.2, 100.3, 98.4, 100.1)]         # sweep of 99.0 with a long wick, close inside
    cur += flat(3, 100.4, 0.2)
    h1 = prev + cur
    m5 = flat(12, 100.4, 0.1)
    assert MD.model_e(h1, m5, PIP).ok
    monkeypatch.setenv("SKLZ_E_WICK", "1")
    assert MD.model_e(h1, m5, PIP).ok               # a real wick rejection still passes
    cur2 = flat(20, 100.5, 0.3) + [bar(100.2, 100.3, 98.4, 98.6)] + [bar(98.6, 100.5, 98.5, 100.4)] + flat(2, 100.4, 0.2)
    s = MD.model_e(prev + cur2, m5, PIP)            # sweep bar CLOSED below, reclaimed later: not a wick candle
    assert not s.ok and any("SKLZ_E_WICK" in b for b in s.blockers)


# ── wiring ──────────────────────────────────────────────────────────
def test_new_models_are_wired(monkeypatch):
    for t in "hjklmn":
        assert t in MD.ALL_MODELS
    monkeypatch.setenv("SKLZ_MODELS_ENABLED", "k")
    h4, m5 = k_fixture()
    assert MD.evaluate(flat(40, 100), m5, flat(50, 100), h4, PIP, {"symbol": "XAUUSD"}).ok
    assert MD.call_model("k", None, m5, None, h4, PIP).ok
    monkeypatch.setenv("SKLZ_MODELS_ENABLED", "n")
    r = MD.evaluate(flat(40, 100), flat(50, 100), flat(50, 100), flat(30, 100), PIP,
                    {"symbol": "XAUUSD", "m5_long": n_fixture()})
    assert r.ok and r.model.startswith("N")
