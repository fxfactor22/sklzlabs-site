"""Institutional confirmation: the cases that must never pass."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from basket_engine.learn import institutional as INST
from basket_engine.learn import orderflow as OF


def _bars(n, start, drift, vol=0.0004, v=100):
    out, p = [], start
    for i in range(n):
        o = p
        p += drift
        out.append({"time": 1700000000 + i * 900, "open": o,
                    "high": max(o, p) + vol * 0.3, "low": min(o, p) - vol * 0.3,
                    "close": p, "volume": v, "real_volume": 0})
    return out


def test_absent_inputs_are_not_scored_as_zero():
    """Missing DOM must not silently cap the score — it is normalised out."""
    m15, h1, d1 = _bars(120, 1.14, 0.0001), _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001)
    a = INST.assess(1, "EURUSD", 0.0001, m15, h1, d1)
    assert "dom" in a.inputs_missing
    assert "dom" not in a.inputs_used
    assert a.score > 0


def _swing_bar(t, o, h, l, c, v=100):
    return {"time": t, "open": o, "high": h, "low": l, "close": c,
            "volume": v, "real_volume": 0}


def _double_top(level=1.1450):
    """Price rallies to `level` twice and rejects — stops rest above it."""
    bars, t = [], 1700000000
    p = 1.1400
    for _ in range(30):                       # rally toward the level
        bars.append(_swing_bar(t, p, p + 0.0004, p - 0.0002, p + 0.0003))
        p += 0.0003
        t += 900
    bars.append(_swing_bar(t, p, level, p - 0.0003, level - 0.0010))   # peak 1
    t += 900
    p = level - 0.0010
    for _ in range(12):                       # pull back
        bars.append(_swing_bar(t, p, p + 0.0002, p - 0.0005, p - 0.0004))
        p -= 0.0004
        t += 900
    for _ in range(12):                       # rally back
        bars.append(_swing_bar(t, p, p + 0.0005, p - 0.0002, p + 0.0004))
        p += 0.0004
        t += 900
    bars.append(_swing_bar(t, p, level, p - 0.0003, level - 0.0012))   # peak 2
    t += 900
    p = level - 0.0012
    for _ in range(10):                       # drift back up, staying BELOW
        bars.append(_swing_bar(t, p, p + 0.0002, p - 0.0002, p + 0.0001))
        p += 0.0001
        t += 900
    assert p < level, "fixture must approach the pool from below"
    return bars, t, level


def test_liquidity_sweep_is_rejected():
    """Price wicks above a double top and closes back inside — a stop hunt."""
    bars, t, level = _double_top()
    bars.append(_swing_bar(t, level - 0.0004, level + 0.0015,
                           level - 0.0006, level - 0.0005, 320))
    a = INST.assess(1, "EURUSD", 0.0001, bars,
                    _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001))
    assert not a.passed, f"a sweep must never pass (scored {a.score})"
    assert any("SWEEP" in f for f in a.flags), f"flags were {a.flags}"


def test_acceptance_beyond_the_level_is_not_a_sweep():
    """Same level, but price closes decisively beyond it."""
    bars, t, level = _double_top()
    bars.append(_swing_bar(t, level - 0.0004, level + 0.0020,
                           level - 0.0005, level + 0.0018, 320))
    a = INST.assess(1, "EURUSD", 0.0001, bars,
                    _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001))
    assert not any("SWEEP" in f for f in a.flags), f"flags were {a.flags}"


def test_absorption_blocks_entry():
    d = OF.DeltaResult(buy_volume=800, sell_volume=200, delta=600,
                       cumulative=[1] * 50, quality="inferred")
    r = OF.absorption(d, price_move_pips=1)
    assert r["absorbed"] is True
    assert r["side"] == "seller"


def test_absorption_clears_when_price_moves():
    d = OF.DeltaResult(buy_volume=800, sell_volume=200, delta=600,
                       cumulative=[1] * 50, quality="inferred")
    assert OF.absorption(d, price_move_pips=30)["absorbed"] is False


def test_wick_breakout_is_not_acceptance():
    bar = {"open": 1.1400, "high": 1.1430, "low": 1.1398, "close": 1.1404}
    assert INST.candle_acceptance(1, bar)["accepted"] is False


def test_strong_body_is_acceptance():
    bar = {"open": 1.1400, "high": 1.1422, "low": 1.1399, "close": 1.1420}
    assert INST.candle_acceptance(1, bar)["accepted"] is True


def test_delta_divergence_detected():
    closes = [1.14 + i * 0.0001 for i in range(24)]
    cum = [100 - i * 3 for i in range(24)]
    assert OF.delta_divergence(closes, cum, 1)["divergent"] is True


def test_no_book_reports_unavailable_not_bearish():
    r = OF.read_depth([], 1)
    assert r["available"] is False
    assert "no order book" in r["reason"]


def test_basket_disagreement_penalises():
    m15, h1, d1 = _bars(120, 1.14, 0.0001), _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001)
    agree = INST.assess(1, "EURUSD", 0.0001, m15, h1, d1,
                        peer_moves={"EURJPY": 0.3, "EURGBP": 0.2, "GBPUSD": 0.2})
    disagree = INST.assess(1, "EURUSD", 0.0001, m15, h1, d1,
                           peer_moves={"EURJPY": -0.3, "EURGBP": -0.2, "GBPUSD": -0.2})
    assert disagree.score < agree.score


def test_session_scores_overlap_highest():
    from datetime import datetime, timezone
    overlap = INST.session_quality(datetime(2026, 7, 30, 13, tzinfo=timezone.utc))
    asian = INST.session_quality(datetime(2026, 7, 30, 3, tzinfo=timezone.utc))
    assert overlap["score"] > asian["score"]


def test_jpy_gets_credit_in_asian_session():
    from datetime import datetime, timezone
    t = datetime(2026, 7, 30, 3, tzinfo=timezone.utc)
    assert (INST.session_quality(t, "USDJPY")["score"]
            > INST.session_quality(t, "EURUSD")["score"])


def test_runner_actually_has_the_institutional_method():
    """The scan loop calls self._institutional. If the method is missing the
    call raises AttributeError, gets swallowed by the fallback, and the whole
    layer silently does nothing — which is exactly what happened once.
    Compiling is not the same as being wired up."""
    from basket_engine.learn.runner import LearningRunner
    assert hasattr(LearningRunner, "_institutional"), \
        "LearningRunner._institutional is missing — the scan loop calls it"
    import inspect
    src = inspect.getsource(LearningRunner)
    assert "self._institutional(" in src, "nothing calls it"


def test_every_method_the_runner_calls_on_itself_exists():
    """Catch any other self._foo() that was never defined."""
    import inspect, re
    from basket_engine.learn.runner import LearningRunner
    src = inspect.getsource(LearningRunner)
    called = set(re.findall(r"self\.(_[a-z_]+)\(", src))
    defined = {n for n in dir(LearningRunner) if n.startswith("_")}
    missing = {c for c in called if c not in defined}
    assert not missing, f"called but never defined: {sorted(missing)}"


def test_published_signal_carries_the_traded_levels():
    """A signal whose stop differs from the one the bot is trading tells
    subscribers a level nobody is using. If the caller supplies real levels,
    they must appear in the payload rather than being recomputed."""
    import inspect
    from basket_engine.learn import signal_publish
    src = inspect.getsource(signal_publish.publish)
    assert "actual_sl" in src, "publish() must accept the executed stop"
    assert 'payload["sl"]' in src, "the real stop must reach the payload"


def test_entry_record_stores_the_placed_levels():
    from basket_engine.learn.capture import EntryRecord
    r = EntryRecord(ts="", source="auto", strategy="x", symbol="AUDUSD",
                    side=1, lots=0.03, entry_price=0.70333,
                    sl_price=0.70133, tp_price=0.70606)
    assert r.sl_price == 0.70133 and r.tp_price == 0.70606


def test_bridge_rejects_stale_data():
    """Old flow scored against a fresh breakout is worse than no flow."""
    import os, tempfile, time
    from basket_engine.learn import orderflow as OF
    d = tempfile.mkdtemp()
    os.environ["SKLZ_MT5_FILES_DIR"] = d
    p = os.path.join(d, "sklz_delta_EURUSD.csv")
    with open(p, "w") as f:
        f.write("time,ask_volume,bid_volume,delta,cum_delta\n")
        f.write("1700000000,100,50,50,50\n")
    os.utime(p, (time.time() - 4000, time.time() - 4000))
    assert OF.read_bridge("EURUSD").quality == "none"
    os.environ.pop("SKLZ_MT5_FILES_DIR", None)


def test_bridge_flags_wrong_buffer_indices():
    """All-zero volumes mean the EA is reading the wrong buffers. Say so
    rather than reporting a confident delta of zero."""
    import os, tempfile
    from basket_engine.learn import orderflow as OF
    d = tempfile.mkdtemp()
    os.environ["SKLZ_MT5_FILES_DIR"] = d
    with open(os.path.join(d, "sklz_delta_EURUSD.csv"), "w") as f:
        f.write("time,ask_volume,bid_volume,delta,cum_delta\n")
        f.write("1700000000,0,0,0,0\n")
    r = OF.read_bridge("EURUSD")
    assert r.quality == "none"
    assert "buffer indices" in r.note
    os.environ.pop("SKLZ_MT5_FILES_DIR", None)


def test_measured_delta_overrides_tick_inference():
    from basket_engine.learn import orderflow as OF
    measured = OF.DeltaResult(buy_volume=900, sell_volume=300, delta=600,
                              cumulative=[10] * 40, quality="measured")
    m15 = _bars(120, 1.14, 0.0001)
    a = INST.assess(1, "EURUSD", 0.0001, m15, _bars(200, 1.135, 0.0002),
                    _bars(20, 1.12, 0.001), delta_override=measured)
    assert "cluster_delta" in a.inputs_used


def test_correlated_positions_are_one_bet():
    """Four dollar-short positions are not diversification."""
    from basket_engine.learn import exposure as EXP
    pos = [{"symbol": "EURUSD", "side": 1, "lots": 0.01},
           {"symbol": "USDCHF", "side": -1, "lots": 0.01},
           {"symbol": "XAUUSD", "side": 1, "lots": 0.01},
           {"symbol": "USDJPY", "side": -1, "lots": 0.01}]
    net = EXP.exposure_map(pos)
    assert net["USD"] < 0, "all four are short USD"
    assert abs(net["USD"]) == 0.04, "exposure should compound, not offset"
    r = EXP.would_breach(pos, "GBPUSD", 1, 0.01)
    assert r["ok"] is False, "a fifth dollar-short trade must be refused"


def test_reducing_exposure_is_never_blocked():
    from basket_engine.learn import exposure as EXP
    pos = [{"symbol": "EURUSD", "side": 1, "lots": 0.01}] * 4
    assert EXP.would_breach(pos, "EURUSD", -1, 0.01)["ok"] is True


def test_retest_distinguishes_hold_from_fail():
    from basket_engine.learn.institutional import retest_held
    def bar(h, l, c):
        return {"open": c, "high": h, "low": l, "close": c, "volume": 100}
    held = retest_held(1, [bar(1.147, 1.144, 1.1465), bar(1.1468, 1.1448, 1.1452),
                           bar(1.1475, 1.1451, 1.147)], 1.145, 0.0001)
    assert held["tested"] and held["held"]
    failed = retest_held(1, [bar(1.147, 1.144, 1.1465), bar(1.1466, 1.1435, 1.1442),
                             bar(1.1448, 1.143, 1.1438)], 1.145, 0.0001)
    assert failed["tested"] and not failed["held"]


def test_unknown_pnl_is_not_recorded_as_breakeven():
    """A trade whose result the broker never reported is not a flat trade.

    Recording it as 0.00 made nine consecutive trades look like a quiet day
    when the P/L simply had not landed in deal history yet. That silently
    corrupts every statistic built on top of it.
    """
    import json
    import tempfile
    from basket_engine.learn.capture import Journal

    with tempfile.TemporaryDirectory() as d:
        j = Journal.__new__(Journal)
        j.path = f"{d}/j.jsonl"
        j.record_exit(1, 0.0, None)
        j.record_exit(2, 0.0, 0.0)
        j.record_exit(3, 0.0, -4.2)

        rows = [json.loads(x) for x in open(j.path)]
        assert rows[0]["outcome"] == "unknown", "missing P/L must not be flat"
        assert rows[1]["outcome"] == "flat", "a real zero is flat"
        assert rows[2]["outcome"] == "loss"


def test_trailing_is_per_instrument():
    """30 pips is $3 on gold and most of a day's range on EURUSD."""
    from basket_engine.learn.trailing import trail_for
    g_t, g_l = trail_for("XAUUSD..")
    f_t, f_l = trail_for("EURUSD..")
    assert (g_t, g_l) == (30, 15), "gold: $3 trigger, $1.50 lock"
    assert f_t < g_t, "FX must trail tighter in pips than gold"


def test_global_override_still_wins():
    import os
    from basket_engine.learn.trailing import trail_for
    os.environ["SKLZ_TRAIL_TRIGGER_PIPS"] = "45"
    try:
        assert trail_for("XAUUSD..")[0] == 45
    finally:
        os.environ.pop("SKLZ_TRAIL_TRIGGER_PIPS", None)


def _bar(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c, "volume": 100}


def test_rsi_reads_the_pullback_not_just_the_entry_bar():
    """The bar that confirms a retest is upward, which lifts RSI(2) at once.

    Reading only the current bar means the condition is never true at the
    moment you actually want to enter.
    """
    from basket_engine.learn.models import rsi_confirms
    # deep pullback, then one bar turning up
    closes = [100 + i * 0.4 for i in range(40)] + \
             [115.6 - i * 0.9 for i in range(6)] + [111.8]
    r = rsi_confirms(1, closes)
    assert r["ok"], r["reason"]

    # still falling on the entry bar — the pullback was deep but has not
    # turned, so this must NOT fire
    falling = closes[:-1] + [110.2]
    assert not rsi_confirms(1, falling)["ok"]


def test_model_a_needs_the_level_to_hold():
    from basket_engine.learn.models import model_a
    prices = [1.0975, 1.0982, 1.0990, 1.1000, 1.0992, 1.0985, 1.0978, 1.0986,
              1.0994, 1.1000, 1.0993, 1.0986, 1.0980, 1.0988, 1.0996, 1.1002,
              1.1012, 1.1020]
    m15 = [_bar(p - 0.0004, p + 0.0004, p - 0.0006, p) for p in prices]
    pad = [_bar(1.1018, 1.1022, 1.1014, 1.1020) for _ in range(30)]
    held = [_bar(p + 0.0002, p + 0.0003, p - 0.0003, p) for p in
            (1.1020, 1.1016, 1.1010, 1.1006, 1.1003, 1.1005, 1.1009)]
    assert model_a(m15, pad + held, 0.0001).ok

    # same retest but it closes back below the level — must not fire
    failed = [_bar(p + 0.0002, p + 0.0003, p - 0.0003, p) for p in
              (1.1020, 1.1016, 1.1010, 1.1004, 1.0998, 1.0996, 1.0994)]
    assert not model_a(m15, pad + failed, 0.0001).ok


def test_order_block_finds_the_candle_before_the_break():
    from basket_engine.learn.models import order_block
    htf = [_bar(100, 101, 99, 99.5) for _ in range(5)] + \
          [_bar(100, 100.5, 98, 98.2), _bar(98.3, 103, 98.2, 102.5)]
    blk = order_block(htf, 1)
    assert blk and abs(blk["mid"] - 99.25) < 0.01


def test_models_outscore_plain_scanner_hits():
    """A structured model requires a sequence; a scanner requires a condition.

    The weighting is a prior from the owner's own trading, not a measured
    finding — which is why outcomes are recorded per source, so it can be
    revised rather than defended.
    """
    import os
    from basket_engine.learn import quality

    class IO:
        def bars(self, *a, **k):
            return [{"open": 1.1, "high": 1.11, "low": 1.09, "close": 1.105,
                     "tick_volume": 100} for _ in range(60)]
        def spec(self, s):
            return {"digits": 5}
        def price(self, s, side=1):
            return 1.105

    os.environ["SKLZ_MODEL_BONUS"] = "22"
    try:
        plain = quality.score_setup(IO(), "EURUSD", 15,
                                    [("structure_break", 1, "x")])
        withm = quality.score_setup(IO(), "EURUSD", 15,
                                    [("model_a", 1, "x")])
        assert withm["score"] > plain["score"], \
            "a model hit must outscore a lone scanner hit"
        assert withm["score"] - plain["score"] >= 20
    finally:
        os.environ.pop("SKLZ_MODEL_BONUS", None)


def test_price_on_a_high_volume_node_is_a_veto():
    """Selling from inside an HVN is where breaks get absorbed.

    The original check only looked at what was AHEAD, so a trade entered
    directly on a node scored normally — a real NZDUSD sell reached 89/100
    while sitting on one.
    """
    from basket_engine.learn.institutional import profile_check
    vp = {"available": True, "hvn": [0.58540], "lvn": [], "poc": 0.58540}
    r = profile_check(-1, 0.58537, vp, 0.0001)
    assert r["favourable"] is False
    assert r.get("at_node") is True


def test_delta_against_the_trade_blocks_a_high_score():
    """A 0.15 component score was outvoted by seven other components.

    Order flow running the other way is not 'worth fewer points' — it means
    the trade is the wrong way round.
    """
    from basket_engine.learn.institutional import Assessment
    a = Assessment(side=-1, score=89.0)
    a.flags = ["DELTA AGAINST — order flow is +34% buy-side while this is a SELL"]
    passed = (a.score >= 60 and not a.veto and not any(
        f.startswith(("LIQUIDITY SWEEP", "ABSORPTION", "DELTA AGAINST",
                      "price is sitting ON")) for f in a.flags))
    assert passed is False


def test_fair_value_gap_detection():
    from basket_engine.learn.models import fair_value_gap
    bars = [_bar(1.10, 1.101, 1.099, 1.1005),
            _bar(1.1005, 1.104, 1.1004, 1.1038),   # the fast candle
            _bar(1.1038, 1.105, 1.1020, 1.1045)]   # low 1.1020 > first high 1.101
    g = fair_value_gap(bars, 1)
    assert g and abs(g["bottom"] - 1.101) < 1e-9 and abs(g["top"] - 1.1020) < 1e-9

    # no gap when candles overlap
    flat = [_bar(1.10, 1.102, 1.099, 1.101)] * 3
    assert fair_value_gap(flat, 1) is None


def test_model_c_requires_the_trap():
    """Without price trading the far side of the 4H open there is no setup —
    the counter-move IS the pattern, not a failure of it."""
    from basket_engine.learn.models import model_c
    h4 = [_bar(1.10, 1.106, 1.098, 1.105), _bar(1.105, 1.111, 1.103, 1.110),
          _bar(1.110, 1.116, 1.108, 1.115), _bar(1.115, 1.118, 1.112, 1.117),
          _bar(1.1170, 1.118, 1.116, 1.117)]
    # price stays above the 4H open the whole time
    m5 = [_bar(1.1175, 1.1178, 1.1172, 1.1176) for _ in range(30)]
    s = model_c(h4, m5, 0.0001)
    assert not s.ok
    assert any("far side" in b for b in s.blockers)


def test_broker_index_aliases_get_point_pips():
    """USTEC fell through to digits-based 0.1, making the 25-pip index
    trigger 2.5 points on a 29,700 index — armed on noise, stopped in
    seconds, +$2.52 on 1.2 lots."""
    from basket_engine.learn.trailing import pip_size
    for sym in ("USTEC", "US500", "DE40"):
        assert pip_size(sym) == 1.0, f"{sym} must be 1 point per pip"


def test_model_d_needs_choch_not_just_the_sweep():
    """Sweeping the inducement alone is not an entry — without the change of
    character the 'sweep' may simply be the start of a real breakdown."""
    from basket_engine.learn.models import model_d
    path = [1.0990, 1.0975, 1.0960, 1.0950, 1.0962, 1.0978, 1.0995, 1.1010,
            1.1002, 1.0992, 1.0980, 1.0988, 1.0998, 1.1006, 1.1000, 1.0994,
            1.0990, 1.0996, 1.1002, 1.1008, 1.1004]
    m15 = [_bar(p + 0.0002, p + 0.0008, p - 0.0008, p) for p in path]
    pad = [_bar(1.0996, 1.0999, 1.0993, 1.0995) for _ in range(30)]
    # sweep happens but price stays down — no change of character
    stuck = pad + [_bar(1.0994, 1.0995, 1.0985, 1.0987),
                   _bar(1.0987, 1.0988, 1.0972, 1.0975),
                   _bar(1.0975, 1.0978, 1.0970, 1.0973)]
    s = model_d(m15, stuck, 0.0001)
    assert not s.ok
    assert any("change of character" in b for b in s.blockers)


class _WickIO:
    """A sweep in progress: price wicks below the range low RIGHT NOW, but no
    completed candle has closed below it."""
    def bars(self, sym, tf, n):
        out = [_bar(1.10, 1.1010, 1.0990, 1.1000) for _ in range(n - 1)]
        out.append(_bar(1.1000, 1.1002, 1.0940, 1.0945))   # forming: deep wick
        return out
    def closes(self, sym, tf, n):
        return [b["close"] for b in self.bars(sym, tf, n)]


def test_structure_break_ignores_the_forming_bar():
    """A wick through a level is a sweep until the candle CLOSES beyond it.

    The old scanner read the live bar's price as a close and sold the bottom
    of an NZDUSD trap — entering in the direction of the sweep."""
    from basket_engine.learn.scanners import structure_break
    assert structure_break(_WickIO(), "NZDUSD", 15, 20) is None


class _ClosedBreakIO:
    """The same shape, but the breaking candle has COMPLETED below the low."""
    def bars(self, sym, tf, n):
        out = [_bar(1.10, 1.1010, 1.0990, 1.1000) for _ in range(n - 2)]
        out.append(_bar(1.1000, 1.1001, 1.0930, 1.0935))   # completed break
        out.append(_bar(1.0935, 1.0940, 1.0925, 1.0930))   # forming
        return out


def test_structure_break_fires_on_a_completed_body_close():
    from basket_engine.learn.scanners import structure_break
    r = structure_break(_ClosedBreakIO(), "NZDUSD", 15, 20)
    assert r is not None and r[0] == -1
    assert "closed below" in r[1]


def test_news_blackout_window_and_currency_matching():
    """USD news blocks EURUSD, gold and US indices — not EURGBP."""
    import time as _t
    from basket_engine.learn import news
    news._cache["at"] = _t.time()          # stop it fetching
    news._cache["events"] = [{"ts": 1000.0, "ccy": "USD", "title": "NFP"}]

    for sym in ("EURUSD", "XAUUSD..", "USTEC"):
        blocked, why = news.blackout(sym, now_ts=1060.0)   # T+1min
        assert blocked, sym
        assert "NFP" in why
    blocked, _ = news.blackout("EURGBP", now_ts=1060.0)
    assert not blocked, "EURGBP has no USD leg"

    # outside the window: 6 minutes after, with a 5-minute block
    blocked, _ = news.blackout("EURUSD", now_ts=1000.0 + 6 * 60)
    assert not blocked
    # and just before
    blocked, _ = news.blackout("EURUSD", now_ts=1000.0 - 60)
    assert blocked, "2 minutes before the release is inside the window"


def test_news_filter_fails_open():
    """A dead calendar must never become a hidden kill switch."""
    import time as _t
    from basket_engine.learn import news
    news._cache["at"] = _t.time()
    news._cache["events"] = []             # feed returned nothing
    blocked, _ = news.blackout("EURUSD", now_ts=_t.time())
    assert not blocked


def test_break_entry_needs_retest_hold_and_engulfing():
    """The candle close confirms the BREAK; only the retest + hold + 5M
    engulfing confirms the ENTRY. Straight-after-break entries were the
    journal's losing pattern."""
    from basket_engine.learn.models import break_entry_confirmed
    lvl = 1.1000

    # 1: broke up but never came back — chasing
    away = [_bar(1.1010, 1.1030, 1.1008, 1.1025)] * 8
    ok, why = break_entry_confirmed(away, lvl, 1, 0.0001)
    assert not ok and "not retested" in why

    # 2: came back and is holding, but no engulfing yet — still waiting
    hold = [_bar(1.1025, 1.1027, 1.1002, 1.1006),
            _bar(1.1006, 1.1009, 1.1001, 1.1004),
            _bar(1.1004, 1.1007, 1.1000, 1.1005)]
    ok, why = break_entry_confirmed(away[:4] + hold, lvl, 1, 0.0001)
    assert not ok and "engulfing" in why

    # 3: retest held AND a bullish engulfing — enter
    eng = [_bar(1.1005, 1.1006, 1.0999, 1.1001),      # small down candle
           _bar(1.1000, 1.1015, 1.0999, 1.1013)]      # engulfs it, up
    ok, why = break_entry_confirmed(away[:3] + hold + eng, lvl, 1, 0.0001)
    assert ok, why

    # 4: retested and closed back through — the sweep shape must refuse
    fail = [_bar(1.1006, 1.1008, 1.0988, 1.0992)]
    ok, why = break_entry_confirmed(away[:4] + hold + fail, lvl, 1, 0.0001)
    assert not ok and "sweep" in why


def test_selling_into_an_opposing_htf_block_is_vetoed():
    """EURJPY: a strong down move hit a 1H demand block and strength_extreme
    sold exactly AT the block, on a wick. Momentum into the other side's
    resting positions gets absorbed, not extended."""
    from basket_engine.learn.institutional import Assessment
    a = Assessment(side=-1, score=88.0)
    a.flags = ["INTO HTF BLOCK — price is inside an opposing 1H order block"]
    passed = (a.score >= 60 and not a.veto and not any(
        f.startswith(("LIQUIDITY SWEEP", "ABSORPTION", "DELTA AGAINST",
                      "price is sitting ON", "INTO HTF BLOCK"))
        for f in a.flags))
    assert passed is False


def test_strength_uses_completed_bars_only():
    """A live wick spike must not inflate the strength differential."""
    from basket_engine.learn.scanners import strength_extreme

    class IO:
        def has_symbol(self, s):
            return True
        def closes(self, s, tf, n):
            flat = [1.0] * (n - 1)
            # the forming bar spikes hard on every pair — pure wick
            return flat + [1.05 if s.startswith("EUR") else 0.95]

    r = strength_extreme(IO(), "EURJPY", 15, 20)
    assert r is None, "a forming-bar spike alone must not fire the scanner"


def test_model_c_rejects_microscopic_structure():
    """The GBPUSD degenerate case: price hovering AT the 4H open, a 0.5-pip
    'trap' and a 0.2-pip 'FVG'. Every condition technically true, all of it
    inside the spread. Must not fire."""
    from basket_engine.learn.models import model_c
    h4 = [_bar(1.3655, 1.3665, 1.3645, 1.3650),
          _bar(1.3650, 1.3660, 1.3640, 1.3645),
          _bar(1.3645, 1.3650, 1.3635, 1.3638),
          _bar(1.3638, 1.3642, 1.3630, 1.3634),
          _bar(1.36327, 1.3634, 1.3630, 1.3633)]      # forming, open 1.36327
    # M5 oscillates within a pip of the open; tiny gap
    m5 = [_bar(1.36330, 1.36338, 1.36325, 1.36332) for _ in range(30)]
    m5 += [_bar(1.36332, 1.36333, 1.36322, 1.36325),   # "trap": 0.5 pip
           _bar(1.36325, 1.36340, 1.36324, 1.36338),
           _bar(1.36338, 1.36341, 1.36334, 1.36336)]
    s = model_c(h4, m5, 0.0001)
    assert not s.ok
    assert any("hovering AT the open" in b or "pips" in b for b in s.blockers)


def test_fvg_smaller_than_minimum_is_ignored():
    from basket_engine.learn.models import fair_value_gap
    bars = [_bar(1.1000, 1.10010, 1.0999, 1.1000),
            _bar(1.1000, 1.10030, 1.0999, 1.10028),
            _bar(1.10028, 1.10040, 1.10012, 1.10035)]  # 0.2-pip gap
    assert fair_value_gap(bars, 1, min_height=0.0003) is None
    assert fair_value_gap(bars, 1) is not None          # without the floor


def test_models_enabled_switch():
    """SKLZ_MODELS_ENABLED=a,b,d must silence Model C without touching the
    rest — the V1 backtest's owner-decision switch."""
    import os
    from basket_engine.learn.models import _enabled
    os.environ["SKLZ_MODELS_ENABLED"] = "a,b,d"
    try:
        en = _enabled()
        assert en == {"a", "b", "d"}
        assert "c" not in en
    finally:
        os.environ.pop("SKLZ_MODELS_ENABLED", None)
    assert _enabled() == {"a", "b", "c", "d"}, "default runs everything"


def test_regime_classifier_basics():
    from basket_engine.learn.regime import classify, efficiency_ratio
    # a clean trend: high efficiency
    trend = [_bar(100 + i*0.1 - 0.02, 100 + i*0.1 + 0.05,
                  100 + i*0.1 - 0.05, 100 + i*0.1) for i in range(130)]
    r = classify(trend, now_utc=1755600000)   # 11:20 UTC -> london
    assert r["trend"] == "trending", r
    assert r["session"] == "london"
    assert efficiency_ratio([100, 101, 102, 103], 3) > 0.95

    # pure chop: same prices repeating
    import math
    chop = [_bar(100 + 0.3*math.sin(i/2) - 0.02,
                 100 + 0.3*math.sin(i/2) + 0.08,
                 100 + 0.3*math.sin(i/2) - 0.08,
                 100 + 0.3*math.sin(i/2)) for i in range(130)]
    r2 = classify(chop)
    assert r2["trend"] in ("ranging", "mixed"), r2

    # too little history stays honest
    assert classify(trend[:30])["label"] == "unknown"


def test_sweep_veto_logic_for_model_d():
    """The sweep veto was written for breakouts; Model D trades the sweep by
    design. Waived only when the sweep is the SOLE blocker — any other veto
    (delta against, HVN, HTF block) still blocks D like everyone else."""
    prefixes = ("LIQUIDITY SWEEP", "ABSORPTION", "DELTA AGAINST",
                "price is sitting ON", "INTO HTF BLOCK")

    def only_sweep(flags):
        blocking = [f for f in flags if f.startswith(prefixes)]
        return bool(blocking) and all(
            f.startswith("LIQUIDITY SWEEP") for f in blocking)

    assert only_sweep(["higher timeframe is ranging",
                       "LIQUIDITY SWEEP — price rejected the level",
                       "weak candle: body only 9% of range"])
    assert not only_sweep(["LIQUIDITY SWEEP — price rejected the level",
                           "DELTA AGAINST — flow is +30% buy-side"])
    assert not only_sweep(["weak candle: mostly wick"])   # nothing blocking


def test_prop_guard_stops_before_the_firm_does():
    """5% is the firm's line; the guard's job is making it unreachable."""
    import os
    from basket_engine.learn.prop_guard import PropGuard

    os.environ.update({"SKLZ_PROP_GUARD": "1", "SKLZ_PROP_BASELINE": "10000",
                       "SKLZ_PROP_SOFT_PCT": "2.5", "SKLZ_PROP_HARD_PCT": "4"})
    try:
        logs = []
        g = PropGuard(log=logs.append)

        class IO:
            def __init__(self, eq): self.eq = eq; self.closed = 0
            def account(self): return {"equity": self.eq}
            def my_positions(self): return []
            def close_all(self): self.closed = 3; return 3

        io = IO(10000)
        assert g.check(io)["entries_ok"], "full equity trades normally"

        io.eq = 9740                       # -2.6% -> soft
        r = g.check(io)
        assert not r["entries_ok"] and "soft" in r["reason"]
        assert io.closed == 0, "soft stop must NOT flatten"

        io.eq = 9590                       # -4.1% -> hard
        r = g.check(io)
        assert not r["entries_ok"]
        assert io.closed == 3, "hard stop flattens everything"
        assert g.halted

        io.eq = 9800                       # recovery does not un-halt the day
        assert not g.check(io)["entries_ok"]
    finally:
        for k in ("SKLZ_PROP_GUARD", "SKLZ_PROP_BASELINE",
                  "SKLZ_PROP_SOFT_PCT", "SKLZ_PROP_HARD_PCT"):
            os.environ.pop(k, None)


def test_prop_guard_off_by_default():
    from basket_engine.learn.prop_guard import PropGuard
    g = PropGuard(log=lambda m: None)
    class IO:
        def account(self): raise RuntimeError("must not be called")
    assert g.check(IO())["entries_ok"], "disabled guard must be invisible"


def test_copy_event_respects_the_off_switch_and_missing_config():
    import os
    from basket_engine.learn.signal_publish import copy_event
    os.environ["SKLZ_COPY_PUBLISH"] = "0"
    try:
        assert copy_event("open", 123, "XAUUSD", 1) is False
    finally:
        os.environ.pop("SKLZ_COPY_PUBLISH", None)
    # no API url configured -> quietly refuses rather than raising
    os.environ.pop("SKLZ_API_URL", None)
    assert copy_event("open", 123, "XAUUSD", 1) is False


def test_prop_guard_split_anchors_and_target():
    """4%-daily / 7%-overall / 5%-target: each rule enforced separately."""
    import os
    from basket_engine.learn.prop_guard import PropGuard
    os.environ.update({
        "SKLZ_PROP_GUARD": "1", "SKLZ_PROP_BASELINE": "50000",
        "SKLZ_PROP_SOFT_PCT": "2", "SKLZ_PROP_HARD_PCT": "3",
        "SKLZ_PROP_TOTAL_SOFT_PCT": "4.5", "SKLZ_PROP_TOTAL_HARD_PCT": "5.5",
        "SKLZ_PROP_TARGET_PCT": "5"})
    try:
        logs = []
        g = PropGuard(log=logs.append)

        class IO:
            def __init__(s, eq): s.eq = eq; s.closed = 0
            def account(s): return {"equity": s.eq}
            def my_positions(s): return []
            def close_all(s): s.closed += 3; return 3

        io = IO(50000)
        assert g.check(io)["entries_ok"]

        # -3.5% overall must NOT halt (old single-threshold guard would):
        # simulate a new day anchoring at 48250, so day-dd is 0
        g2 = PropGuard(log=logs.append)
        io2 = IO(48250)
        assert g2.check(io2)["entries_ok"], "overall room must survive -3.5%"

        # -5.6% overall trips the TOTAL hard line even on a fresh day
        g3 = PropGuard(log=logs.append)
        io3 = IO(47200)
        r = g3.check(io3)
        assert not r["entries_ok"] and io3.closed == 3

        # +5% locks the pass and flattens
        g4 = PropGuard(log=logs.append)
        io4 = IO(52501)
        r = g4.check(io4)
        assert not r["entries_ok"] and g4.passed and io4.closed == 3
        io4.eq = 51000                     # profit shrink cannot unlock
        assert not g4.check(io4)["entries_ok"]
    finally:
        for k in list(os.environ):
            if k.startswith("SKLZ_PROP"):
                os.environ.pop(k, None)


def test_funded_protect_mode_floor():
    import os
    from basket_engine.learn.prop_guard import PropGuard
    os.environ.update({
        "SKLZ_PROP_GUARD": "1", "SKLZ_PROP_BASELINE": "50000",
        "SKLZ_PROP_TARGET_PCT": "5", "SKLZ_PROP_TARGET_MODE": "protect"})
    try:
        logs = []
        g = PropGuard(log=logs.append)
        class IO:
            def __init__(s, eq): s.eq = eq; s.closed = 0
            def account(s): return {"equity": s.eq}
            def my_positions(s): return []
            def close_all(s): s.closed += 2; return 2
        io = IO(52501)                        # +5.002%
        assert g.check(io)["entries_ok"], "protect mode keeps trading"
        assert g.floor is not None and abs(g.floor - 52000) < 1
        io.eq = 53100                          # runs higher, still trading
        assert g.check(io)["entries_ok"]
        io.eq = 51990                          # falls to the floor
        r = g.check(io)
        assert not r["entries_ok"] and io.closed == 2 and g.passed
    finally:
        for k in list(os.environ):
            if k.startswith("SKLZ_PROP"):
                os.environ.pop(k, None)


def test_blocked_symbols_env_parses():
    import os
    os.environ["SKLZ_BLOCKED_SYMBOLS"] = "XAGUSD, silver"
    try:
        blocked = {s.strip().upper() for s in
                   os.environ.get("SKLZ_BLOCKED_SYMBOLS", "").split(",")
                   if s.strip()}
        assert "XAGUSD" in blocked and "SILVER" in blocked
        assert "XAGUSD.r".upper().startswith(tuple(blocked)) or \
               any("XAGUSD.R".startswith(b) for b in blocked)
    finally:
        os.environ.pop("SKLZ_BLOCKED_SYMBOLS", None)


def _ohlcv(seq):
    return [{"open": o, "high": h, "low": lo, "close": c, "volume": v}
            for o, h, lo, c, v in seq]


def test_model_e_needs_reclaim_not_just_sweep():
    """A swept low that never reclaims is a downtrend — must not fire."""
    from basket_engine.learn.models import model_e
    pip = 0.0001
    prev = [(1.1000, 1.1050, 1.0950, 1.1010, 100)] * 24      # PL 1.0950
    swept_no_reclaim = [(1.0960, 1.0965, 1.0900, 1.0905, 100)] * 24
    h1 = _ohlcv(prev + swept_no_reclaim)
    m5 = _ohlcv([(1.0906, 1.0908, 1.0900, 1.0903, 50)] * 12)
    s = model_e(h1, m5, pip)
    assert not s.ok and any("reclaim" in b for b in s.blockers)

    # same sweep, but price closes back above the prior low
    reclaimed = [(1.0960, 1.0975, 1.0900, 1.0970, 100)] * 24
    h1 = _ohlcv(prev + reclaimed)
    m5 = _ohlcv([(1.0960, 1.0975, 1.0955, 1.0972, 50)] * 12)
    s = model_e(h1, m5, pip)
    assert s.ok and s.side == 1
    assert s.stop < 1.0950 < s.entry          # stop under the sweep low


def test_model_f_rejects_a_trending_window():
    """No range means nothing to manipulate — the POC model must decline."""
    from basket_engine.learn.models import model_f
    trend = _ohlcv([(1.10 + i * 0.001, 1.1005 + i * 0.001,
                    1.0995 + i * 0.001, 1.1004 + i * 0.001, 100)
                   for i in range(40)])
    m5 = _ohlcv([(1.14, 1.1405, 1.1395, 1.1400, 50)] * 12)
    s = model_f(trend, m5, 0.0001)
    assert not s.ok and any("trending" in b for b in s.blockers)


def test_poc_lands_in_the_heaviest_bucket():
    from basket_engine.learn.models import _poc
    bars = _ohlcv([(1.1000, 1.1010, 1.0990, 1.1005, 10)] * 5
                 + [(1.1000, 1.1002, 1.0998, 1.1000, 900)] * 5)
    p = _poc(bars)
    assert 1.0996 < p < 1.1004, p


def test_observation_record_survives_a_restart(tmp_path):
    """A weeks-long trial must not reset on every engine deploy."""
    import json, os
    from basket_engine.learn import runner as R
    path = tmp_path / "obs.json"

    # exercise the two helpers directly on a bare object
    obj = type("O", (), {})()
    obj._obs_path = str(path)
    obj._model_tally = {"E": [3, 1, 0]}
    obj._shadows = [{"kind": "observe", "sym": "XAUUSD", "model": "E",
                     "pkey": "XAUUSD:e", "side": 1, "entry": 1.0,
                     "stop": 0.9, "target": 1.2, "veto": "OBSERVE model_E",
                     "t": 0}]
    obj.log = lambda *a, **k: None
    R.LearningRunner._save_observations(obj)

    fresh = type("O", (), {})()
    fresh._obs_path = str(path)
    fresh._model_tally = {}
    fresh._shadows = []
    fresh.log = lambda *a, **k: None
    R.LearningRunner._load_observations(fresh)
    assert fresh._model_tally == {"E": [3, 1, 0]}
    assert len(fresh._shadows) == 1 and fresh._shadows[0]["sym"] == "XAUUSD"


def test_close_publish_retries_then_screams(monkeypatch):
    """A lost close strands followers in a trade — it must retry and shout."""
    import os
    from basket_engine.learn import signal_publish as sp
    os.environ["SKLZ_API_URL"] = "https://example.invalid"
    os.environ["SIGNAL_WEBHOOK_KEY"] = "k"
    calls = {"n": 0}

    def boom(*a, **k):
        calls["n"] += 1
        raise TimeoutError("nope")

    monkeypatch.setattr(sp.urllib.request, "urlopen", boom)
    monkeypatch.setattr(sp.time, "sleep", lambda *_: None)
    logs = []
    try:
        ok = sp.copy_event("close", 123, "XAUUSD", 1, log=logs.append)
        assert ok is False
        assert calls["n"] == 4, calls          # closes retry hard
        assert any("CLOSE NOT PUBLISHED" in x for x in logs)
        assert any("MAY STILL BE" in x for x in logs)

        calls["n"] = 0
        logs.clear()
        sp.copy_event("open", 124, "XAUUSD", 1, log=logs.append)
        assert calls["n"] == 2                 # opens are cheap to lose
        assert not any("CLOSE NOT PUBLISHED" in x for x in logs)
    finally:
        os.environ.pop("SKLZ_API_URL", None)
        os.environ.pop("SIGNAL_WEBHOOK_KEY", None)


def test_broker_suffixes_are_stripped_before_publishing(monkeypatch):
    """A follower on another broker has no symbol called EURJPY.."""
    import os, json
    from basket_engine.learn import signal_publish as sp
    os.environ["SKLZ_API_URL"] = "https://example.invalid"
    os.environ["SIGNAL_WEBHOOK_KEY"] = "k"
    seen = {}

    class R:
        def __init__(s, *a, **k): seen["body"] = json.loads(k.get("data") or a[1])
        def __enter__(s): return s
        def __exit__(s, *a): return False
        def read(s): return b'{"ok":true,"queued":3}'

    def fake_request(url, data=None, headers=None):
        seen["body"] = json.loads(data.decode())
        return "req"

    monkeypatch.setattr(sp.urllib.request, "Request", fake_request)
    monkeypatch.setattr(sp.urllib.request, "urlopen", lambda *a, **k: R())
    try:
        for raw, want in [("EURJPY..", "EURJPY"), ("XAUUSD..", "XAUUSD"),
                          ("US30.cash", "US30"), ("EURUSD", "EURUSD")]:
            sp.copy_event("open", 1, raw, 1, log=lambda *_: None)
            assert seen["body"]["symbol"] == want, (raw, seen["body"]["symbol"])
    finally:
        os.environ.pop("SKLZ_API_URL", None)
        os.environ.pop("SIGNAL_WEBHOOK_KEY", None)


def test_max_lots_env_caps_the_master():
    """A hard lot ceiling must beat the risk calculation, not average with it."""
    import os
    os.environ["SKLZ_MAX_LOTS"] = "0.1"
    try:
        cap = float(os.environ.get("SKLZ_MAX_LOTS", "0") or 0)
        lot_max, step, lot_min = 50.0, 0.01, 0.01
        wanted = 0.83                      # what 0.4% of 50k would justify
        hi = min(lot_max, cap)
        sized = round(max(lot_min, min(hi, round(wanted / step) * step)), 2)
        assert sized == 0.1, sized
        # and it must not raise a smaller size UP to the cap
        wanted = 0.03
        sized = round(max(lot_min, min(hi, round(wanted / step) * step)), 2)
        assert sized == 0.03, sized
    finally:
        os.environ.pop("SKLZ_MAX_LOTS", None)


def test_lot_ceiling_covers_every_sizing_mode(monkeypatch):
    """The ceiling must bind in equity-proportional mode too — that path
    returned early and let 3.12 lots of BTC onto a funded account."""
    import os
    from basket_engine.learn.entries import EntryController

    class IO:
        def spec(self, s):
            return {"lot_min": 0.01, "lot_max": 100.0, "lot_step": 0.01,
                    "tick_size": 0.01, "tick_value": 0.01, "digits": 2}
        def account(self): return {"equity": 50000.0}

    e = EntryController.__new__(EntryController)
    e.io = IO()
    e.log = lambda *a, **k: None
    e.risk_pct = 0.25
    e._size_raw = lambda symbol, sl: 5.01        # what per-equity mode gave
    os.environ["SKLZ_MAX_LOTS"] = "0.1"
    try:
        assert EntryController._size(e, "BTCUSD", 400.0) == 0.1
        e._size_raw = lambda symbol, sl: 0.03    # below the cap, untouched
        assert EntryController._size(e, "XAUUSD", 30.0) == 0.03
        e._size_raw = lambda symbol, sl: 0.0     # a refusal stays a refusal
        assert EntryController._size(e, "XAUUSD", 30.0) == 0.0
    finally:
        os.environ.pop("SKLZ_MAX_LOTS", None)


def test_in_flight_entry_blocks_a_second_ticket():
    """Two UKOIL tickets landed 3s apart because my_positions() lagged."""
    import time as _t
    recent = {}
    open_syms = set()          # MT5 has not caught up yet
    sym = "UKOIL"
    # first scan: nothing open, nothing in flight -> allowed, then recorded
    assert not (sym in open_syms or sym in recent)
    recent[sym] = _t.time()
    # second scan 3 seconds later: still nothing in my_positions()
    assert sym in recent, "the in-flight record must block the duplicate"
    # and it expires so the symbol is not banned forever
    recent[sym] = _t.time() - 120
    now = _t.time()
    for k, ts in list(recent.items()):
        if now - ts > 90:
            recent.pop(k, None)
    assert sym not in recent


def test_lot_ceiling_spares_forced_entries():
    """The cap governs the scanner, not the owner at the dashboard."""
    import os
    from basket_engine.learn.entries import EntryController

    class IO:
        def spec(self, s):
            return {"lot_min": 0.01, "lot_max": 100.0, "lot_step": 0.01,
                    "tick_size": 0.01, "tick_value": 0.01, "digits": 2}
        def account(self): return {"equity": 50000.0}

    e = EntryController.__new__(EntryController)
    e.io, e.log = IO(), (lambda *a, **k: None)
    e._size_raw = lambda symbol, sl: 2.5
    os.environ["SKLZ_MAX_LOTS"] = "0.1"
    try:
        assert EntryController._size(e, "XAUUSD", 30.0) == 0.1        # auto
        assert EntryController._size(e, "XAUUSD", 30.0,
                                     apply_ceiling=False) == 2.5      # forced
    finally:
        os.environ.pop("SKLZ_MAX_LOTS", None)


# ── A3: durable command protocol ─────────────────────────────────────
def _store(tmp_path):
    from basket_engine.command_store import CommandStore
    return CommandStore(str(tmp_path / "cmds.db"))


def test_lost_result_does_not_become_a_second_trade(tmp_path):
    """The most important test in the phase.

    Runner executes, the result POST is lost, the API redelivers the same
    command. The trade must NOT happen twice.
    """
    s = _store(tmp_path)
    executed = []

    def deliver(cid):
        if s.known(cid):
            return "resent stored result"
        s.begin(cid, "market")
        executed.append(cid)            # broker touched here
        s.finish(cid, {"ok": True, "ticket": 999})
        return "executed"

    assert deliver("c1") == "executed"
    assert deliver("c1") == "resent stored result"     # ack was lost
    assert deliver("c1") == "resent stored result"     # and again
    assert executed == ["c1"], executed
    assert s.result_for("c1")["ticket"] == 999


def test_dedup_survives_a_runner_restart(tmp_path):
    from basket_engine.command_store import CommandStore
    p = str(tmp_path / "cmds.db")
    s = CommandStore(p)
    s.begin("c2", "market")
    s.finish("c2", {"ok": True, "ticket": 5})
    s.close()
    s2 = CommandStore(p)                 # process died, came back
    assert s2.begin("c2") is False
    assert s2.result_for("c2")["ticket"] == 5


def test_interrupted_execution_is_reported_unknown_not_retried(tmp_path):
    """Crash between execution and the result write.

    We cannot tell whether the broker filled it. Re-running risks doubling
    a live position; refusing risks missing one. Missing is recoverable.
    """
    s = _store(tmp_path)
    s.begin("c3", "market")              # intent written, then the crash
    assert s.begin("c3") is False        # never executed again
    r = s.result_for("c3")
    assert r["state"] == "unknown" and r["ok"] is False


def test_expired_command_is_refused_and_recorded(tmp_path):
    s = _store(tmp_path)
    s.refuse("c4", "expired", "market")
    assert s.begin("c4") is False
    assert s.result_for("c4")["refused"] == "expired"


def test_two_legitimate_identical_trades_are_not_deduplicated(tmp_path):
    """Same symbol, side and lot twice on purpose must both execute."""
    s = _store(tmp_path)
    assert s.begin("c5", "market") is True
    assert s.begin("c6", "market") is True     # different command_id
    s.finish("c5", {"ok": True, "ticket": 1})
    s.finish("c6", {"ok": True, "ticket": 2})
    assert s.result_for("c5")["ticket"] != s.result_for("c6")["ticket"]


def test_claim_is_compare_and_swap_not_read_then_write():
    """Two polls must not both win the same row.

    Mirrors the API's update(...).eq(id).eq(status,'pending') — the second
    update matches nothing because the first already changed status.
    """
    row = {"id": 1, "status": "pending"}

    def claim():
        if row["status"] != "pending":
            return None                  # WHERE status='pending' matched 0
        row["status"] = "dispatched"
        return row

    assert claim() is not None
    assert claim() is None


def test_delivered_is_never_treated_as_executed():
    """Historical rows have unknown outcomes and must stay unknown."""
    terminal_success = {"succeeded"}
    for legacy in ("delivered", "dispatched", "pending", "expired", "failed"):
        assert legacy not in terminal_success


# ── A3.1: unknown outcomes and cross-Runner safety ───────────────────
def test_unknown_is_not_failed(tmp_path):
    """Two different facts that must never be collapsed."""
    from basket_engine.command_store import CommandStore
    s = CommandStore(str(tmp_path / "c.db"))
    s.begin("u1", "market")              # intent written, then the crash
    r = s.result_for("u1")
    assert r["state"] == "unknown"
    assert r.get("ok") is False
    assert "failed" not in str(r.get("state"))
    # and the API's mapping keeps it distinct
    stored = r["state"]                  # mirrors post_result: stored = state
    assert stored == "unknown" and stored != "failed"


def test_unknown_never_executes_again(tmp_path):
    from basket_engine.command_store import CommandStore
    s = CommandStore(str(tmp_path / "c.db"))
    touched = []

    def deliver(cid):
        if s.known(cid):
            return s.result_for(cid)
        s.begin(cid, "market")
        touched.append(cid)
        raise RuntimeError("crash before the result is written")

    try:
        deliver("u2")
    except RuntimeError:
        pass
    for _ in range(3):                   # redelivered repeatedly
        out = deliver("u2")
        assert out["state"] == "unknown"
    assert touched == ["u2"], "an unknown command was executed again"


def test_a_different_runner_cannot_take_over_a_lapsed_lease():
    """The cross-Runner duplicate window, closed.

    Runner A executes and loses its result. The lease lapses. Runner B
    shares the bot_name and has NO local record. It must not be offered
    the command.
    """
    now, ttl_gone = 100.0, False
    row = {"status": "dispatched", "lease_owner": "rn_A",
           "lease_expires_at": 50.0}

    def settle(polling_runner, ttl_expired):
        if row["status"] != "dispatched" or row["lease_expires_at"] >= now:
            return row["status"]
        if polling_runner == row["lease_owner"] and not ttl_expired:
            row["status"] = "pending"          # only its owner may reclaim
        elif ttl_expired:
            row["status"] = "unknown"          # never 'expired' — unproven
        return row["status"]

    assert settle("rn_B", False) == "dispatched"   # B gets nothing
    assert settle("rn_B", False) == "dispatched"   # still nothing
    assert settle("rn_A", False) == "pending"      # A may reclaim safely


def test_lapsed_lease_past_ttl_becomes_unknown_not_expired():
    """'expired' asserts it never executed. We cannot know that."""
    row = {"status": "dispatched", "lease_owner": "rn_A"}
    ttl_expired = True
    if row["status"] == "dispatched" and ttl_expired:
        row["status"] = "unknown"
    assert row["status"] == "unknown"
    assert row["status"] != "expired"


def test_installation_id_is_not_bot_name_or_account(tmp_path):
    from basket_engine.command_store import CommandStore
    s = CommandStore(str(tmp_path / "c.db"))
    rid = s.installation_id()
    for forbidden in ("SKLZ-RUNNER", "fxfactor24@gmail.com", "50061", ""):
        assert rid != forbidden
    assert rid.startswith("rn_")


def test_two_runners_same_bot_name_have_different_identities(tmp_path):
    from basket_engine.command_store import CommandStore
    a = CommandStore(str(tmp_path / "a.db")).installation_id()
    b = CommandStore(str(tmp_path / "b.db")).installation_id()
    assert a != b, "two installations must be distinguishable"


def test_executing_command_is_not_concurrently_claimable():
    """A lease lapsing mid-execution must not make the row claimable.

    Ownership, not timing, provides the guarantee: after the lapse the row
    stays 'dispatched' for everyone except its owner, so no second Runner
    can execute regardless of how long execution takes.
    """
    row = {"status": "dispatched", "lease_owner": "rn_A"}
    claimable_by_others = (row["status"] == "pending")
    assert not claimable_by_others


# ── demo Runner identity guards ──────────────────────────────────────
class _Acct:
    def __init__(self, login=52952532, server="ICMarketsSC-Demo",
                 trade_mode=0, company="IC Markets"):
        self.login, self.server, self.trade_mode = login, server, trade_mode
        self.company, self.balance, self.equity = company, 10000.0, 10000.0
        self.currency = "USD"


class _MT5:
    def __init__(self, acct): self._a = acct; self.path_used = None
    def initialize(self, path=None): self.path_used = path; return True
    def account_info(self): return self._a
    def last_error(self): return (0, "")


def _io(acct):
    from basket_engine.mt5io import BasketIO
    io = BasketIO.__new__(BasketIO)
    io.mt5 = _MT5(acct); io.magic = 1; io.log = lambda *a, **k: None
    return io


def test_account_reports_identity_not_just_money():
    """A3 read account() for the observed login and got nothing."""
    io = _io(_Acct())
    a = io.account()
    for field in ("login", "server", "demo", "company"):
        assert field in a, field
    assert a["login"] == 52952532


def test_runner_refuses_a_terminal_with_the_wrong_login():
    import os
    io = _io(_Acct(login=99999999))
    os.environ["SKLZ_EXPECT_LOGIN"] = "52952532"
    try:
        io.connect()
        raise AssertionError("started on the wrong account")
    except RuntimeError as exc:
        assert "REFUSING TO START" in str(exc)
        assert "99999999" in str(exc)
    finally:
        os.environ.pop("SKLZ_EXPECT_LOGIN", None)


def test_runner_refuses_a_real_money_account_when_demo_required():
    import os
    io = _io(_Acct(login=52952532, trade_mode=2))   # 2 = REAL
    os.environ["SKLZ_REQUIRE_DEMO"] = "1"
    try:
        io.connect()
        raise AssertionError("started on a live account")
    except RuntimeError as exc:
        assert "NOT a demo account" in str(exc)
    finally:
        os.environ.pop("SKLZ_REQUIRE_DEMO", None)


def test_the_demo_runner_starts_on_the_right_terminal():
    import os
    io = _io(_Acct())
    os.environ.update({"SKLZ_EXPECT_LOGIN": "52952532",
                       "SKLZ_REQUIRE_DEMO": "1",
                       "SKLZ_EXPECT_SERVER": "ICMarketsSC-Demo",
                       "SKLZ_MT5_PATH": r"C:\\MT5-Demo\\terminal64.exe"})
    try:
        info = io.connect()
        assert info["login"] == 52952532 and info["demo"] is True
        assert io.mt5.path_used.endswith("terminal64.exe")
    finally:
        for k in ("SKLZ_EXPECT_LOGIN", "SKLZ_REQUIRE_DEMO",
                  "SKLZ_EXPECT_SERVER", "SKLZ_MT5_PATH"):
            os.environ.pop(k, None)


def test_a_wrong_server_is_refused():
    import os
    io = _io(_Acct(server="ICMarketsSC-Live"))
    os.environ["SKLZ_EXPECT_SERVER"] = "Demo"
    try:
        io.connect()
        raise AssertionError("started on the wrong server")
    except RuntimeError as exc:
        assert "expected server containing" in str(exc)
    finally:
        os.environ.pop("SKLZ_EXPECT_SERVER", None)


def test_entry_record_price_field_is_entry_price_not_price():
    """A3 read `rec.price`, which does not exist, and reported 0."""
    from basket_engine.learn.capture import EntryRecord
    fields = set(EntryRecord.__dataclass_fields__)
    assert "entry_price" in fields
    assert "price" not in fields
    src = open("basket_engine/learn/runner.py").read()
    fn = src[src.index("def _cmd_market("):]
    fn = fn[:fn.index("\n    def ")]
    assert 'getattr(rec, "entry_price"' in fn
    assert 'getattr(rec, "price"' not in fn


def test_the_broker_answer_survives_to_the_result():
    src = open("basket_engine/mt5io.py").read()
    assert '"retcode": getattr(res, "retcode", None)' in src
    ent = open("basket_engine/learn/entries.py").read()
    assert 'rec.state["fill"]' in ent
    run = open("basket_engine/learn/runner.py").read()
    fn = run[run.index("def _cmd_market("):]
    fn = fn[:fn.index("\n    def ")]
    assert '"retcode": fill.get("retcode")' in fn
    assert '"broker_comment"' in fn


def test_the_runner_falls_back_when_the_market_is_shut(monkeypatch):
    """A weekend click on forex must not simply fail."""
    import os
    from basket_engine.learn.runner import LearningRunner as Runner
    r = Runner.__new__(Runner)
    r.log = lambda *a, **k: None
    r.entries_blocked = False
    tried = []

    class EC:
        def forced_custom(self, sym, side, note, lots=0, sl=0, tp=0):
            tried.append(sym)
            return None
    r.ec = EC()
    r.io = type("IO", (), {"spec": lambda s, x: {"trade_mode": 0},
                           "market_live": lambda s, x: False})()
    r.tf_min = 15
    os.environ["SKLZ_DEMO_FALLBACK_SYMBOL"] = "BTCUSD"
    try:
        Runner._cmd_market(r, {"symbol": "EURUSD", "side": "buy"})
    finally:
        os.environ.pop("SKLZ_DEMO_FALLBACK_SYMBOL", None)
    assert tried == ["BTCUSD"], tried


def test_tradable_uses_the_brokers_answer_not_the_clock():
    src = open("basket_engine/learn/runner.py").read()
    fn = src[src.index("def _tradable("):]
    fn = fn[:fn.index("\n    def ")]
    assert "market_live" in fn and "trade_mode" in fn
    for clock in ("datetime", "weekday", "hour"):
        assert clock not in fn, clock


def test_positions_command_is_read_only():
    src = open("basket_engine/learn/runner.py").read()
    fn = src[src.index("def _cmd_positions("):]
    fn = fn[:fn.index("\n    def ")]
    for write in ("order_send", "market(", "close(", "modify_sl"):
        assert write not in fn, write
    assert "my_positions()" in fn
    # it reports the broker's SL, which is what trailing actually moves
    assert '"sl": float(p.get("sl") or 0)' in fn


def test_positions_reads_the_keys_my_positions_returns():
    """my_positions() emits side/lots/open_price. Reading MT5's raw
    type/volume/price_open silently produced zeros."""
    import inspect
    from basket_engine.mt5io import BasketIO
    src = inspect.getsource(BasketIO.my_positions)
    emitted = {"ticket", "symbol", "side", "lots", "open_price", "profit",
               "sl", "tp", "comment"}
    for k in emitted:
        assert f'"{k}"' in src, k
    fn = open("basket_engine/learn/runner.py").read()
    fn = fn[fn.index("def _cmd_positions("):]
    fn = fn[:fn.index("\n    def ")]
    for good in ('p.get("side"', 'p.get("lots"', 'p.get("open_price"'):
        assert good in fn, good
    for bad in ('p.get("type"', 'p.get("volume"', 'p.get("price_open"'):
        assert bad not in fn, bad


def test_every_command_branch_merges_its_result():
    """`out = self._cmd_positions(o)` discarded the handler's answer, so
    the caller saw the initialised failure default with no comment."""
    import re
    src = open("basket_engine/learn/runner.py").read()
    block = src[src.index('if ctype == "market":'):src.index('result["broker_confirmed_at"]')]
    for branch in re.findall(r'ctype == "(\w+)":\s*\n\s*(.+)', block):
        name, line = branch
        assert "result.update(" in line, f"{name}: {line.strip()}"
