import os
from basket_engine.learn.playbook import Playbook, DEFAULT_RULES
from basket_engine.learn.trailing import desired_stop, initial_risk, _INITIAL_RISK
from basket_engine.learn.entries import order_comment


def _pb():
    pb = Playbook(path="/nonexistent/playbook.json", log=lambda *a: None)
    pb.rules = dict(DEFAULT_RULES)
    return pb


def test_playbook_blocks_strength_extreme_alone():
    ok, why = _pb().check(["strength_extreme"], "AUDJPY", "london")
    assert not ok and "alone" in why


def test_playbook_allows_confluence_in_london():
    assert _pb().check(["strength_extreme", "model_a"], "XAUUSD", "london")[0]


def test_playbook_gold_exempt_from_ny_rule():
    assert _pb().check(["strength_extreme", "model_a"], "XAUUSD", "newyork")[0]
    assert not _pb().check(["strength_extreme", "model_a"], "AUDJPY", "newyork")[0]


def test_playbook_model_c_only_ny():
    assert not _pb().check(["model_c"], "BTCUSD", "sydney_tokyo")[0]
    assert _pb().check(["model_c"], "BTCUSD", "newyork")[0]


def test_playbook_never_blocks_forced():
    assert _pb().check(["strength_extreme"], "EURJPY", "newyork", source="forced")[0]


def test_playbook_env_off(monkeypatch):
    monkeypatch.setenv("SKLZ_PLAYBOOK", "0")
    assert _pb().check(["strength_extreme"], "EURJPY", "newyork")[0]


def test_trailing_r_mode_waits_for_one_r(monkeypatch):
    monkeypatch.delenv("SKLZ_TRAIL_MODE", raising=False)
    # gold buy, 8.31 risk: old bands armed at +3.0; R-mode must not
    assert desired_stop(1, 4160.12, 4165.0, 4151.81, 0.1, "XAUUSD", risk=8.31)[0] is None
    sl, why = desired_stop(1, 4160.12, 4170.0, 4151.81, 0.1, "XAUUSD", risk=8.31)
    assert sl is not None and sl > 4160.12 and "secured" in why


def test_trailing_r_mode_sell():
    sl, _ = desired_stop(-1, 83506.0, 83200.0, 83788.0, 1.0, "BTCUSD", risk=282.0)
    assert sl is not None and sl < 83506.0


def test_trailing_pip_fallback_without_risk():
    sl, _ = desired_stop(1, 4160.12, 4163.5, 4151.81, 0.1, "XAUUSD")
    assert sl is not None  # legacy band behaviour unchanged


def test_initial_risk_cached_from_broker_sl():
    _INITIAL_RISK.clear()
    assert initial_risk(42, 1, 100.0, 99.0, None) == 1.0
    # after the stop has moved into profit the cache still answers
    assert initial_risk(42, 1, 100.0, 100.5, None) == 1.0


def test_order_comment_keeps_confluence_under_26():
    c = order_comment("auto", "structure_break+strength_extreme+model_c")
    assert c == "sklz-a SB+SE+C" and len(c) <= 26
    assert order_comment("forced", "dashboard") == "sklz-f DB"
