"""v3.34.0 — universal entry gate, session levels, liquidity bias, TOTT/Q,
B base, C ob, E trc/bounce, M asia/pre8/orb gates, P variants, partials."""
import os
from datetime import datetime, timezone

import pytest

from basket_engine.learn import levels as LV
from basket_engine.learn import models as MD
from basket_engine.learn import trailing as TR


def _bar(o, h, l, c, t=None, v=10):
    return {"open": o, "high": h, "low": l, "close": c, "time": t, "volume": v}


# ── universal entry confirmation ─────────────────────────────────────
def _gate_series(level=100.0):
    b = [_bar(99.0, 99.6, 98.8, 99.4)] * 6
    b += [_bar(99.4, 100.9, 99.3, 100.7)]            # body close above the line
    b += [_bar(100.7, 101.2, 100.6, 101.0)]
    b += [_bar(101.0, 101.1, 100.0, 100.3)]          # retest of 100
    b += [_bar(100.3, 100.4, 99.95, 100.05)]         # red bar at the line
    b += [_bar(100.0, 100.9, 100.0, 100.8)]          # bullish engulfing, closes above
    return b


def test_entry_confirmed_full_sequence():
    ok, why = MD.entry_confirmed(_gate_series(), 100.0, 1, 0.1)
    assert ok, why


def test_entry_confirmed_rejects_wick_only_break():
    b = [_bar(99.0, 99.6, 98.8, 99.4)] * 6 + [_bar(99.4, 100.9, 99.3, 99.8)] * 4
    ok, why = MD.entry_confirmed(b, 100.0, 1, 0.1)
    assert not ok and "BODY" in why


def test_entry_confirmed_rejects_chase_without_retest():
    b = [_bar(99.0, 99.6, 98.8, 99.4)] * 6 + [_bar(99.4, 100.9, 99.3, 100.7),
                                               _bar(100.7, 102.0, 100.6, 101.9),
                                               _bar(101.9, 103.0, 101.8, 102.9)]
    ok, why = MD.entry_confirmed(b, 100.0, 1, 0.1)
    assert not ok and "retest" in why


def test_entry_confirmed_rejects_extreme(monkeypatch):
    monkeypatch.setenv("SKLZ_NO_CHASE_ATR", "0.2")
    b = _gate_series()
    b[-1] = _bar(100.0, 103.0, 100.0, 102.9)         # engulfing but way off the line
    ok, why = MD.entry_confirmed(b, 100.0, 1, 0.1)
    assert not ok and "extreme" in why


# ── session levels / liquidity bias ──────────────────────────────────
def _session_bars():
    """Three days of M15 bars in UTC epoch time with distinct session ranges."""
    bars = []
    t = 1_700_000_000 // 86400 * 86400
    now = t + 3 * 86400 + 14 * 3600
    for d in range(3):
        for i in range(96):
            ts = t + d * 86400 + i * 900
            h = (i * 15 / 60.0) % 24
            base = 100 + d * 2
            if h >= 22 or h < 7:
                lo, hi = base - 1, base + 1
            elif h < 12:
                lo, hi = base - 3, base + 0.5        # London makes the low
            else:
                lo, hi = base - 0.5, base + 3        # NY makes the high
            bars.append(_bar((lo + hi) / 2, hi, lo, (lo + hi) / 2, ts))
    # today: partial, quiet, well inside
    for i in range(56):
        ts = t + 3 * 86400 + i * 900
        bars.append(_bar(104.5, 105.0, 104.0, 104.5, ts))
    return bars, datetime.fromtimestamp(now, tz=timezone.utc)


def test_session_levels_only_untested():
    bars, now = _session_bars()
    sl = LV.session_levels(bars, sessions=3, now_utc=now)
    labels = {lab for _, lab in sl["untested_highs"]} | {lab for _, lab in sl["untested_lows"]}
    assert sl["untested_highs"] and sl["untested_lows"]
    # the most recent NY high (107) is untested; older London lows were traded through by later days? no: lower
    assert any("NY" in lab for lab in labels)
    assert all(p > 104 for p, _ in sl["untested_highs"])


def test_liquidity_bias_counts_unswept_pools():
    bars = []
    px = 100.0
    for i in range(60):
        px += 0.4 if (i // 6) % 2 == 0 else -0.2       # stair-stepping up: lows left behind
        bars.append(_bar(px, px + 0.3, px - 0.3, px))
    lb = LV.liquidity_bias(bars)
    assert lb["below"] >= 1 and lb["bias"] in (-1, 0, 1)


# ── TOTT / Model Q ───────────────────────────────────────────────────
def test_ott_flips_with_trend():
    closes = [100 + i * 0.5 for i in range(60)] + [130 - i * 0.6 for i in range(60)]
    ma, line = MD.ott(closes, 14, 1.0)
    assert len(line) == len(closes)
    assert ma[59] > line[59] and ma[-1] < line[-1]


def test_model_q_buys_fresh_flip(monkeypatch):
    monkeypatch.setenv("SKLZ_Q_EMA", "0")
    monkeypatch.setenv("SKLZ_MIN_STOP_PIPS", "1")
    m30 = [_bar(100 - i * 0.2, 100 - i * 0.2 + 0.1, 100 - i * 0.2 - 0.3, 100 - i * 0.2 - 0.2) for i in range(60)]
    px = m30[-1]["close"]
    for i in range(10):
        px += 0.9
        m30.append(_bar(px - 0.8, px + 0.1, px - 0.9, px))
    m30.append(_bar(px, px + 0.2, px - 0.1, px + 0.1))     # forming
    s = MD.model_q(m30, 0.1)
    assert s.ok or any("flipped" in b or "old" in b or "RSI" in b for b in s.blockers), s.blockers
    if s.ok:
        assert s.side == 1 and s.target > s.entry > s.stop and s.tag == "q"


def test_model_q_rejects_chop():
    m30 = []
    for i in range(240):
        px = 100 + (0.8 if (i // 3) % 2 == 0 else -0.8)
        m30.append(_bar(px, px + 0.3, px - 0.3, px))
    s = MD.model_q(m30, 0.1)
    assert not s.ok


# ── B base zone ──────────────────────────────────────────────────────
def test_base_zone_finds_impulse_base_impulse():
    h1 = [_bar(100, 100.5, 99.5, 100.2)] * 10
    h1 += [_bar(100.2, 100.3, 97.0, 97.2),           # impulse down
           _bar(97.2, 97.6, 96.8, 97.3),              # indecisive (base)
           _bar(97.3, 100.6, 97.2, 100.4),            # impulse up
           _bar(100.4, 101.0, 100.2, 100.8), _bar(100.8, 101.4, 100.6, 101.2)]
    z = MD.base_zone(h1, 1)
    assert z and z["low"] == pytest.approx(96.8) and z["high"] == pytest.approx(97.6)


def test_model_b_base_mode_entry(monkeypatch):
    monkeypatch.setenv("SKLZ_B_ZONE", "base")
    monkeypatch.setenv("SKLZ_MIN_STOP_PIPS", "1")
    h4 = [_bar(95, 101, 94, 100)] * 5
    h1 = [_bar(100, 100.5, 99.5, 100.2)] * 10
    h1 += [_bar(100.2, 100.3, 97.0, 97.2), _bar(97.2, 97.6, 96.8, 97.3),
           _bar(97.3, 100.6, 97.2, 100.4), _bar(100.4, 101.0, 100.2, 100.8)]
    m5 = [_bar(99, 99.2, 98.8, 99.0)] * 10
    m5 += [_bar(98.0, 98.1, 97.4, 97.6), _bar(97.6, 97.8, 97.3, 97.5), _bar(97.5, 97.7, 97.2, 97.6),
           _bar(97.6, 97.95, 97.4, 97.9)]                # inside the zone, then close above the inside highs
    s = MD.model_b(h4, h1, m5, 0.1)
    assert s.ok, s.blockers
    assert s.tag == "b_base" and s.side == 1


# ── E trc trigger + bounce ───────────────────────────────────────────
def test_bos_ob_entry_waits_for_15m_bos():
    m15 = [_bar(101, 101.5, 100.5, 101)] * 10 + [_bar(101, 101.2, 99.0, 99.3), _bar(99.3, 99.6, 98.5, 99.0)]
    m5 = [_bar(99, 99.2, 98.8, 99.0)] * 12
    blk, why = MD._bos_ob_entry(m15, m5, 1, 0.1, 98.5)
    assert blk is None and "BOS" in why


def test_e_bounce_rejection_at_untested_low(monkeypatch):
    monkeypatch.setenv("SKLZ_MIN_STOP_PIPS", "1")
    s = MD.Setup(ok=False, model="x")
    m5 = [_bar(101, 101.3, 100.7, 101)] * 8 + [_bar(100.6, 100.7, 100.0, 100.3),
                                                _bar(100.3, 100.9, 99.95, 100.8)]   # wick to 100, closes up
    ok = MD._e_bounce(s, [(100.0, "London-1")], 1, m5, 0.1, [103.0])
    assert ok and s.tag == "e_ss" and s.target == 103.0


# ── M asia snapback ──────────────────────────────────────────────────
def test_model_m_asia_snapback(monkeypatch):
    monkeypatch.setenv("SKLZ_M_BOX", "asia")
    t0 = 1_700_000_000 // 86400 * 86400 + 23 * 3600        # 23:00 UTC box
    h1 = [_bar(100, 100.6, 99.4, 100.1, t0 - (30 - i) * 3600) for i in range(30)]
    h1.append(_bar(100, 101.0, 99.0, 100.2, t0))             # the box: 99-101
    h1.append(_bar(100.2, 101.8, 100.1, 101.6, t0 + 3600))   # break candle (close > 101)
    h1.append(_bar(101.6, 101.9, 101.2, 101.4, t0 + 7200))
    h1.append(_bar(101.4, 101.5, 100.9, 101.3, t0 + 10800))  # touches the box top
    h1.append(_bar(101.3, 102.2, 101.1, 102.0, t0 + 14400))  # snapback: closes back outside
    h1.append(_bar(102.0, 102.3, 101.9, 102.1, t0 + 18000))  # forming
    now = datetime.fromtimestamp(t0 + 18000 + 600, tz=timezone.utc)
    s = MD.model_m([], [], 0.1, {"h1": h1, "now": now})
    assert s.ok, s.blockers
    assert s.tag == "m_asia" and s.side == 1
    assert s.stop == pytest.approx(101.0 - 2 * 2.0)


# ── partials ─────────────────────────────────────────────────────────
class _IO:
    def __init__(self):
        self.closed, self.sl = [], {}
    def spec(self, s): return {"lot_step": 0.01, "lot_min": 0.01, "digits": 2}
    def close(self, pos): self.closed.append(pos); return True
    def modify_sl(self, t, sl, tp=None): self.sl[t] = sl; return True


def test_partial_closes_half_and_moves_to_be(monkeypatch):
    monkeypatch.setenv("SKLZ_PARTIAL_R", "1.0")
    monkeypatch.setenv("SKLZ_PARTIAL_PCT", "50")
    io = _IO()
    p = {"ticket": 9001, "symbol": "XAUUSD", "lots": 0.10, "sl": 99.0}
    TR._take_partial(io, p, 1, 100.0, 101.2, 1.0, 0.1, lambda *a: None, None)
    assert io.closed and io.closed[0]["lots"] == pytest.approx(0.05)
    assert io.sl[9001] == pytest.approx(100.05)
    # second call does nothing
    TR._take_partial(io, p, 1, 100.0, 101.5, 1.0, 0.1, lambda *a: None, None)
    assert len(io.closed) == 1


def test_partial_skips_minimum_lot(monkeypatch):
    monkeypatch.setenv("SKLZ_PARTIAL_R", "1.0")
    io = _IO()
    p = {"ticket": 9002, "symbol": "EURUSD", "lots": 0.01, "sl": 0}
    TR._take_partial(io, p, 1, 1.1, 1.102, 0.001, 0.0001, lambda *a: None, None)
    assert not io.closed


def test_entry_confirmed_engulfing_two_bars_back_still_counts():
    b = _gate_series()
    b += [_bar(100.8, 101.0, 100.6, 100.9), _bar(100.9, 101.1, 100.7, 101.0)]   # two quiet bars after
    ok, why = MD.entry_confirmed(b, 100.0, 1, 0.01)
    assert ok, why


def test_entry_confirmed_close_beyond_retest_bar_counts():
    b = [_bar(99.0, 99.6, 98.8, 99.4)] * 6
    b += [_bar(99.4, 100.9, 99.3, 100.7), _bar(100.7, 101.2, 100.6, 101.0),
          _bar(101.0, 101.1, 100.0, 100.4),          # retest bar, high 101.1
          _bar(100.4, 100.8, 100.3, 100.7), _bar(100.7, 101.3, 100.6, 101.2)]   # close > 101.1
    ok, why = MD.entry_confirmed(b, 100.0, 1, 0.01)
    assert ok, why
