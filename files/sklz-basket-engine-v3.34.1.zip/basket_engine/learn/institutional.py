"""SKLZ — institutional entry confirmation.

Replaces "price crossed a level" with a weighted assessment of whether a
breakout has institutional participation behind it, or is a liquidity sweep
dressed up as one.

THE HONEST PART
===============
The specified weighting puts 35% on Cluster Delta (20%) and DOM (15%). On
retail forex, delta is INFERRED from tick side and DOM usually does not exist
at all. Scoring absent inputs as zero would cap every trade at 85 and make an
80 threshold unreachable; scoring them as full marks would be a lie.

So the scorer only counts components whose data is genuinely present, then
normalises the rest to 100. Every result carries `inputs_used` and
`inputs_missing`, so a 92 built on seven live components is distinguishable
from a 92 built on four. The number never claims more than it saw.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import datetime, time, timezone

from basket_engine.learn import orderflow as OF

# component -> weight, per the specification
WEIGHTS = {
    "htf_trend": 15,
    "liquidity_sweep": 20,
    "cluster_delta": 20,
    "dom": 15,
    "volume_profile": 10,
    "retest": 10,
    "volume_strength": 5,
    "session": 5,
}


def threshold() -> float:
    try:
        return float(os.environ.get("SKLZ_INST_MIN_SCORE", 80))
    except (TypeError, ValueError):
        return 80.0


@dataclass
class Component:
    name: str
    score: float               # 0..1 within this component
    available: bool
    reason: str = ""


@dataclass
class Assessment:
    side: int = 0
    score: float = 0.0
    passed: bool = False
    components: list = field(default_factory=list)
    inputs_used: list = field(default_factory=list)
    inputs_missing: list = field(default_factory=list)
    flags: list = field(default_factory=list)
    verdict: str = ""
    # a hard block, independent of score. Some conditions are not "worth fewer
    # points" — they mean the trade is the wrong way round.
    veto: bool = False


# ── Step 1: higher timeframe bias ───────────────────────────────────
def _ema(vals: list[float], period: int) -> float:
    if not vals:
        return 0.0
    k = 2 / (period + 1)
    e = vals[0]
    for v in vals[1:]:
        e = v * k + e * (1 - k)
    return e


def htf_bias(bars_h1: list[dict], bars_d1: list[dict]) -> dict:
    """Structure plus EMAs plus the previous day's range."""
    if len(bars_h1) < 60:
        return {"bias": 0, "ranging": True, "reason": "not enough H1 history"}

    closes = [b["close"] for b in bars_h1]
    ema100 = _ema(closes[-200:], 100)
    ema200 = _ema(closes[-400:] or closes, 200)
    px = closes[-1]

    # market structure from swing points
    highs = [b["high"] for b in bars_h1[-40:]]
    lows = [b["low"] for b in bars_h1[-40:]]
    mid = len(highs) // 2
    hh = max(highs[mid:]) > max(highs[:mid])
    hl = min(lows[mid:]) > min(lows[:mid])
    lh = max(highs[mid:]) < max(highs[:mid])
    ll = min(lows[mid:]) < min(lows[:mid])

    bull = (px > ema100 and ema100 > ema200) or (hh and hl)
    bear = (px < ema100 and ema100 < ema200) or (lh and ll)

    pdh = pdl = None
    if len(bars_d1) >= 2:
        pdh, pdl = bars_d1[-2]["high"], bars_d1[-2]["low"]

    if bull and not bear:
        return {"bias": 1, "ranging": False, "ema100": ema100, "ema200": ema200,
                "pdh": pdh, "pdl": pdl,
                "reason": "bullish structure, price above both EMAs"}
    if bear and not bull:
        return {"bias": -1, "ranging": False, "ema100": ema100, "ema200": ema200,
                "pdh": pdh, "pdl": pdl,
                "reason": "bearish structure, price below both EMAs"}
    return {"bias": 0, "ranging": True, "ema100": ema100, "ema200": ema200,
            "pdh": pdh, "pdl": pdl,
            "reason": "no clear structure — ranging"}


# ── Step 2: liquidity zones ─────────────────────────────────────────
def liquidity_levels(bars_m15: list[dict], bars_d1: list[dict],
                     tolerance_pips: float, pip: float) -> dict:
    """Where stops are likely resting."""
    out = {"equal_highs": [], "equal_lows": [], "swing_highs": [],
           "swing_lows": [], "pdh": None, "pdl": None,
           "asian_high": None, "asian_low": None,
           "weekly_high": None, "weekly_low": None}
    if not bars_m15:
        return out

    highs = [b["high"] for b in bars_m15]
    lows = [b["low"] for b in bars_m15]
    tol = tolerance_pips * pip

    # swings
    for i in range(2, len(bars_m15) - 2):
        w_h = highs[i - 2:i + 3]
        w_l = lows[i - 2:i + 3]
        if highs[i] == max(w_h):
            out["swing_highs"].append(highs[i])
        if lows[i] == min(w_l):
            out["swing_lows"].append(lows[i])

    # equal highs / lows: clusters of swings within tolerance
    def _equals(points: list[float]) -> list[float]:
        eq = []
        for i, a in enumerate(points):
            matches = [b for b in points[i + 1:] if abs(a - b) <= tol]
            if matches:
                eq.append(round(sum([a] + matches) / (len(matches) + 1), 6))
        return eq[:10]

    out["equal_highs"] = _equals(out["swing_highs"])
    out["equal_lows"] = _equals(out["swing_lows"])

    if len(bars_d1) >= 2:
        out["pdh"], out["pdl"] = bars_d1[-2]["high"], bars_d1[-2]["low"]
    if len(bars_d1) >= 6:
        wk = bars_d1[-6:-1]
        out["weekly_high"] = max(b["high"] for b in wk)
        out["weekly_low"] = min(b["low"] for b in wk)

    # Asian range: 00:00-07:00 UTC of the current day
    today = datetime.now(timezone.utc).date()
    asian = [b for b in bars_m15
             if datetime.fromtimestamp(b["time"], timezone.utc).date() == today
             and datetime.fromtimestamp(b["time"], timezone.utc).hour < 7]
    if asian:
        out["asian_high"] = max(b["high"] for b in asian)
        out["asian_low"] = min(b["low"] for b in asian)
    return out


def sweep_check(side: int, bars_m15: list[dict], levels: dict,
                pip: float) -> dict:
    """Did price take out a liquidity pool and reject, or accept beyond it?

    A sweep that closes back inside is a stop hunt — the opposite of what we
    want to trade. A break that holds beyond the level is acceptance.
    """
    if len(bars_m15) < 3:
        return {"swept": False, "accepted": False, "reason": "not enough bars"}

    last = bars_m15[-1]
    pools_above = [p for p in (levels.get("equal_highs", []) +
                               levels.get("swing_highs", []) +
                               [levels.get("pdh"), levels.get("asian_high"),
                                levels.get("weekly_high")]) if p]
    pools_below = [p for p in (levels.get("equal_lows", []) +
                               levels.get("swing_lows", []) +
                               [levels.get("pdl"), levels.get("asian_low"),
                                levels.get("weekly_low")]) if p]

    prev_close = bars_m15[-2]["close"]

    if side > 0:
        # pools this bar reached through: above the previous close, and the
        # high got to them. Proximity to the wick is irrelevant — what counts
        # is whether we crossed a pool and where we closed relative to it.
        crossed = [p for p in pools_above
                   if p >= prev_close and last["high"] >= p]
        if not crossed:
            return {"swept": False, "accepted": True,
                    "reason": "no liquidity pool taken — clean move"}
        lvl = max(crossed)                     # the deepest pool reached
        wicked = last["close"] < lvl
        held = last["close"] > lvl
    else:
        crossed = [p for p in pools_below
                   if p <= prev_close and last["low"] <= p]
        if not crossed:
            return {"swept": False, "accepted": True,
                    "reason": "no liquidity pool taken — clean move"}
        lvl = min(crossed)
        wicked = last["close"] > lvl
        held = last["close"] < lvl

    if wicked:
        return {"swept": True, "accepted": False, "level": lvl,
                "reason": (f"price wicked through {lvl:.5f} and closed back "
                           f"inside — liquidity sweep, not a breakout")}
    if held:
        return {"swept": True, "accepted": True, "level": lvl,
                "reason": (f"took liquidity at {lvl:.5f} and closed beyond it "
                           f"— acceptance")}
    return {"swept": False, "accepted": False, "level": lvl,
            "reason": "at the level but undecided"}



def retest_held(side: int, bars: list[dict], level: float, pip: float,
                within_pips: float = 8, lookback: int = 6) -> dict:
    """Did price come back to the broken level and hold it?

    Entering the initial thrust means buying the bar everyone else saw. The
    retest is where the market says whether the break was real: former
    resistance holding as support is a different event from price simply
    having been there once.

    The trade-off is honest — many breaks never retest, and those are missed
    entirely. Whether that costs more than the false entries it avoids is an
    empirical question this records rather than assumes.
    """
    if len(bars) < 3:
        return {"tested": False, "held": None, "reason": "not enough bars"}

    tol = within_pips * pip
    recent = bars[-lookback:]

    came_back = False
    for b in recent:
        if side > 0 and b["low"] <= level + tol:
            came_back = True
        elif side < 0 and b["high"] >= level - tol:
            came_back = True

    if not came_back:
        return {"tested": False, "held": None,
                "reason": (f"no retest yet — price has not returned within "
                           f"{within_pips:.0f} pips of {level:.5f}")}

    last = bars[-1]
    if side > 0:
        held = last["close"] > level
    else:
        held = last["close"] < level

    return {"tested": True, "held": held,
            "reason": (f"retested {level:.5f} and held — former resistance is "
                       f"acting as support"
                       if held else
                       f"retested {level:.5f} and failed — price closed back "
                       f"through the level, so the break did not stick")}

# ── Step 5: candle acceptance ───────────────────────────────────────
def candle_acceptance(side: int, bar: dict, min_body_ratio: float = 0.55) -> dict:
    rng = bar["high"] - bar["low"]
    if rng <= 0:
        return {"accepted": False, "reason": "zero-range bar"}
    body = abs(bar["close"] - bar["open"])
    ratio = body / rng
    if side > 0:
        rejection = (bar["high"] - bar["close"]) / rng
        right_way = bar["close"] > bar["open"]
    else:
        rejection = (bar["close"] - bar["low"]) / rng
        right_way = bar["close"] < bar["open"]

    if not right_way:
        return {"accepted": False, "body_ratio": round(ratio, 2),
                "reason": "candle closed against the breakout direction"}
    if ratio < min_body_ratio:
        return {"accepted": False, "body_ratio": round(ratio, 2),
                "reason": (f"body only {ratio:.0%} of range — mostly wick, "
                           f"not acceptance")}
    if rejection > 0.35:
        return {"accepted": False, "body_ratio": round(ratio, 2),
                "reason": f"{rejection:.0%} rejection wick against the move"}
    return {"accepted": True, "body_ratio": round(ratio, 2),
            "reason": f"strong body ({ratio:.0%} of range), little rejection"}


# ── Step 7: volume strength ─────────────────────────────────────────
def volume_strength(bars: list[dict], multiple: float = 1.3) -> dict:
    if len(bars) < 50:
        return {"strong": False, "available": False,
                "reason": "not enough bars for a volume baseline"}
    vols = [b.get("volume", 0) for b in bars]
    cur = vols[-1]
    avg20 = sum(vols[-21:-1]) / 20
    avg50 = sum(vols[-51:-1]) / 50
    if avg20 <= 0:
        return {"strong": False, "available": False, "reason": "no volume data"}
    r20 = cur / avg20
    return {"strong": r20 >= multiple, "available": True,
            "ratio_20": round(r20, 2),
            "ratio_50": round(cur / avg50, 2) if avg50 else None,
            "reason": (f"breakout activity {r20:.1f}x the 20-bar average"
                       if r20 >= multiple else
                       f"activity only {r20:.1f}x average — weak participation"),
            "caveat": "tick volume counts price changes, not contracts"}


# ── Step 9: volume profile ──────────────────────────────────────────
def volume_profile(bars: list[dict], buckets: int = 40) -> dict:
    """POC, value area and node map, built from tick volume per price bucket."""
    if len(bars) < 30:
        return {"available": False, "reason": "not enough bars"}
    hi = max(b["high"] for b in bars)
    lo = min(b["low"] for b in bars)
    if hi <= lo:
        return {"available": False, "reason": "no range"}
    step = (hi - lo) / buckets
    hist = [0.0] * buckets
    for b in bars:
        v = b.get("volume", 0)
        if v <= 0:
            continue
        centre = (b["high"] + b["low"]) / 2
        idx = min(buckets - 1, max(0, int((centre - lo) / step)))
        hist[idx] += v
    total = sum(hist)
    if total <= 0:
        return {"available": False, "reason": "no volume"}

    poc_i = hist.index(max(hist))
    poc = lo + (poc_i + 0.5) * step

    # value area: expand from POC until 70% of volume is enclosed
    lo_i = hi_i = poc_i
    acc = hist[poc_i]
    while acc < total * 0.70 and (lo_i > 0 or hi_i < buckets - 1):
        left = hist[lo_i - 1] if lo_i > 0 else -1
        right = hist[hi_i + 1] if hi_i < buckets - 1 else -1
        if right >= left:
            hi_i += 1
            acc += max(right, 0)
        else:
            lo_i -= 1
            acc += max(left, 0)

    avg = total / buckets
    hvn = [lo + (i + 0.5) * step for i, v in enumerate(hist) if v > avg * 1.5]
    lvn = [lo + (i + 0.5) * step for i, v in enumerate(hist) if 0 < v < avg * 0.5]
    return {"available": True, "poc": round(poc, 6),
            "vah": round(lo + (hi_i + 1) * step, 6),
            "val": round(lo + lo_i * step, 6),
            "hvn": [round(x, 6) for x in hvn[:8]],
            "lvn": [round(x, 6) for x in lvn[:8]],
            "caveat": "built from tick volume, so this is an approximation"}


def profile_check(side: int, price: float, vp: dict, pip: float) -> dict:
    """Breaking into thin volume is easy; breaking into a wall is not."""
    if not vp.get("available"):
        return {"favourable": False, "available": False,
                "reason": vp.get("reason", "no profile")}
    # Are we AT a high-volume node right now?
    #
    # The original check only asked what was in the path ahead. But selling
    # from inside an HVN is the worse problem: that is where size rests and
    # where a break gets absorbed rather than continuing. Price sitting on a
    # node is a reason to stand aside, not merely a missing bonus.
    at_node = [h for h in vp.get("hvn", []) if abs(h - price) < 12 * pip]
    if at_node:
        return {"favourable": False, "available": True, "at_node": True,
                "reason": (f"price is sitting ON a high-volume node "
                           f"({at_node[0]:.5f}) — this is where size rests and "
                           f"breaks get absorbed, not where they continue")}

    ahead = [h for h in vp.get("hvn", [])
             if (h > price if side > 0 else h < price)]
    near_wall = [h for h in ahead if abs(h - price) < 30 * pip]
    thin = [l for l in vp.get("lvn", [])
            if (l > price if side > 0 else l < price)
            and abs(l - price) < 30 * pip]
    if near_wall:
        return {"favourable": False, "available": True,
                "reason": (f"high-volume node at {near_wall[0]:.5f} directly "
                           f"ahead — breaking into an institutional wall")}
    if thin:
        return {"favourable": True, "available": True,
                "reason": (f"low-volume pocket at {thin[0]:.5f} ahead — price "
                           f"moves easily through thin books")}
    return {"favourable": True, "available": True,
            "reason": "no volume wall in the path"}


# ── Step 10: session quality ────────────────────────────────────────
def session_quality(now: datetime | None = None, symbol: str = "") -> dict:
    now = now or datetime.now(timezone.utc)
    h = now.hour
    jpy = "JPY" in (symbol or "").upper()

    if 12 <= h < 16:
        return {"score": 1.0, "name": "London / New York overlap",
                "reason": "deepest liquidity of the day"}
    if 7 <= h < 12:
        return {"score": 0.9, "name": "London",
                "reason": "European liquidity, strong participation"}
    if 16 <= h < 19:
        return {"score": 0.75, "name": "New York",
                "reason": "US session, decent participation"}
    if 19 <= h < 21:
        return {"score": 0.35, "name": "late New York",
                "reason": "liquidity thinning into the close"}
    if 0 <= h < 7:
        return {"score": 0.7 if jpy else 0.3, "name": "Asian",
                "reason": ("JPY pair in its home session" if jpy else
                           "thin liquidity outside JPY pairs")}
    return {"score": 0.25, "name": "off-hours",
            "reason": "widest spreads, thinnest book"}


# ── Step 11: basket correlation ─────────────────────────────────────
CORRELATION = {
    "EURUSD": {"EURJPY": 1, "EURGBP": 1, "GBPUSD": 1, "USDCHF": -1},
    "GBPUSD": {"EURUSD": 1, "GBPJPY": 1, "USDCHF": -1},
    "AUDUSD": {"NZDUSD": 1, "AUDJPY": 1, "USDCAD": -1},
    "NZDUSD": {"AUDUSD": 1, "USDCAD": -1},
    "USDJPY": {"EURJPY": 1, "GBPJPY": 1},
    "XAUUSD": {"XAGUSD": 1, "USDCHF": -1, "EURUSD": 1},
}


def basket_agreement(symbol: str, side: int,
                     peer_moves: dict[str, float]) -> dict:
    """Do correlated instruments agree with this move?

    `peer_moves` maps symbol -> recent % change. A EURUSD break upward while
    every other euro cross falls is a single-pair anomaly, not a euro move.
    """
    rels = CORRELATION.get((symbol or "").upper()[:6])
    if not rels:
        return {"agree": True, "available": False,
                "reason": "no correlation map for this instrument"}
    checked = agreed = 0
    detail = []
    for peer, sign in rels.items():
        mv = peer_moves.get(peer)
        if mv is None or abs(mv) < 1e-9:
            continue
        checked += 1
        expected = side * sign
        if (mv > 0 and expected > 0) or (mv < 0 and expected < 0):
            agreed += 1
            detail.append(f"{peer} agrees")
        else:
            detail.append(f"{peer} disagrees")
    if not checked:
        return {"agree": True, "available": False,
                "reason": "no peer data available"}
    ratio = agreed / checked
    return {"agree": ratio >= 0.6, "available": True, "ratio": round(ratio, 2),
            "reason": (f"{agreed} of {checked} correlated instruments agree"
                       + (" — basket confirms" if ratio >= 0.6
                          else " — basket disagrees, likely a single-pair anomaly"))}


# ── Step 12: the score ──────────────────────────────────────────────
def assess(side: int, symbol: str, pip: float,
           bars_m15: list[dict], bars_h1: list[dict], bars_d1: list[dict],
           ticks: list[dict] | None = None,
           book: list[dict] | None = None,
           peer_moves: dict[str, float] | None = None,
           retest_done: bool | None = None,
           delta_override=None) -> Assessment:
    """Run the whole framework and produce a normalised confidence score."""
    a = Assessment(side=side)
    comps: list[Component] = []

    # 1 — higher timeframe
    bias = htf_bias(bars_h1, bars_d1)
    aligned = bias["bias"] == side
    comps.append(Component("htf_trend",
                           1.0 if aligned else (0.4 if bias["ranging"] else 0.0),
                           bool(bars_h1),
                           bias["reason"] + ("" if aligned else " — against this entry")))
    if bias["ranging"]:
        a.flags.append("higher timeframe is ranging")

    # 2 — liquidity sweep vs acceptance
    levels = liquidity_levels(bars_m15, bars_d1, 5, pip)
    sw = sweep_check(side, bars_m15, levels, pip)
    if sw.get("swept") and not sw.get("accepted"):
        comps.append(Component("liquidity_sweep", 0.0, True, sw["reason"]))
        a.flags.append("LIQUIDITY SWEEP — price rejected the level")
    else:
        comps.append(Component("liquidity_sweep",
                               1.0 if sw.get("accepted") else 0.3,
                               bool(bars_m15), sw["reason"]))

    # 5 — candle acceptance folds into the sweep component's evidence
    if bars_m15:
        ca = candle_acceptance(side, bars_m15[-1])
        if not ca["accepted"]:
            a.flags.append(f"weak candle: {ca['reason']}")
            comps[-1] = Component("liquidity_sweep",
                                  min(comps[-1].score, 0.3), True,
                                  comps[-1].reason + f"; {ca['reason']}")

    # 3 — cluster delta
    # measured volumes from the ClusterDelta bridge beat inferred tick delta
    d = delta_override if delta_override is not None else OF.classify_ticks(ticks or [])
    if d.quality == "none":
        comps.append(Component("cluster_delta", 0.0, False,
                               "no tick data — delta could not be assessed"))
    else:
        moved = (abs(bars_m15[-1]["close"] - bars_m15[-1]["open"]) / pip
                 if bars_m15 else 0)
        ab = OF.absorption(d, moved)
        div = OF.delta_divergence([b["close"] for b in bars_m15[-40:]],
                                  d.cumulative, side)
        # Delta pointing the WRONG WAY is a veto, not a low score.
        #
        # Selling while aggressive buying dominates means taking the opposite
        # side of the flow. With eight components normalising, a 0.15 here was
        # easily outvoted — an 89/100 trade could be entered directly against
        # measured order flow, which is the one thing this layer exists to
        # prevent.
        imb = getattr(d, "imbalance", 0.0)
        try:
            min_imb = float(os.environ.get("SKLZ_DELTA_VETO", "0.15"))
        except (TypeError, ValueError):
            min_imb = 0.15
        against = (side > 0 and imb < -min_imb) or (side < 0 and imb > min_imb)

        if against and d.quality in ("measured", "inferred"):
            a.veto = True
            a.flags.append(
                f"DELTA AGAINST — order flow is {imb:+.0%} "
                f"{'buy' if imb > 0 else 'sell'}-side while this is a "
                f"{'BUY' if side > 0 else 'SELL'}. Taking the other side of "
                f"the aggression.")
            comps.append(Component("cluster_delta", 0.0, True,
                                   f"delta {imb:+.0%} against the trade"))
        elif ab["absorbed"]:
            comps.append(Component("cluster_delta", 0.0, True, ab["reason"]))
            a.flags.append(f"ABSORPTION — {ab['reason']}")
        elif div["divergent"]:
            comps.append(Component("cluster_delta", 0.15, True, div["reason"]))
            a.flags.append(f"delta divergence — {div['reason']}")
        else:
            imb = ab.get("imbalance", 0)
            with_move = (imb > 0) == (side > 0)
            comps.append(Component("cluster_delta",
                                   min(1.0, abs(imb) * 2) if with_move else 0.2,
                                   True,
                                   f"delta {imb:+.0%} "
                                   f"{'with' if with_move else 'against'} the move "
                                   f"({d.quality})"))

    # 4 — DOM
    dom = OF.read_depth(book or [], side)
    comps.append(Component("dom", 1.0 if dom.get("supportive") else 0.3,
                           dom.get("available", False), dom["reason"]))

    # 8b — opposing HTF order block. Momentum is loudest exactly where the
    # other side's positions rest: selling INTO a 1H demand block is entering
    # at the one price where the sell is most likely to be absorbed. The
    # block that stops the move is a reason to stand aside (or wait for the
    # rejection the other way) — not a place to join the move.
    try:
        from basket_engine.learn.models import order_block as _ob
        cur_px = bars_m15[-1]["close"] if bars_m15 else 0.0
        opp = _ob(bars_h1 or [], -side)     # the block OPPOSING this trade
        if opp and cur_px:
            pad = 8 * pip
            inside = (opp["low"] - pad) <= cur_px <= (opp["high"] + pad)
            if inside:
                a.veto = True
                a.flags.append(
                    f"INTO HTF BLOCK — price is inside an opposing 1H order "
                    f"block {opp['low']:.5f}-{opp['high']:.5f}. This is where "
                    f"the other side's positions rest; momentum into it gets "
                    f"absorbed, not extended.")
    except Exception:
        pass

    # 9 — volume profile
    vp = volume_profile(bars_m15)
    pc = profile_check(side, bars_m15[-1]["close"] if bars_m15 else 0, vp, pip)
    if pc.get("at_node"):
        a.veto = True
        a.flags.append(pc["reason"])
    comps.append(Component("volume_profile", 1.0 if pc.get("favourable") else 0.2,
                           pc.get("available", False), pc["reason"]))
    if pc.get("available") and not pc["favourable"]:
        a.flags.append("breaking into a high-volume node")

    # 6 — retest, evaluated from the level the sweep identified
    if retest_done is None and sw.get("level") and bars_m15:
        rt = retest_held(side, bars_m15, float(sw["level"]), pip)
        if not rt["tested"]:
            comps.append(Component("retest", 0.45, True, rt["reason"]))
        elif rt["held"]:
            comps.append(Component("retest", 1.0, True, rt["reason"]))
        else:
            comps.append(Component("retest", 0.0, True, rt["reason"]))
            a.flags.append(f"retest failed — {rt['reason']}")
    elif retest_done is None:
        comps.append(Component("retest", 0.5, False,
                               "no level to retest against"))
    else:
        comps.append(Component("retest", 1.0 if retest_done else 0.0, True,
                               "level retested and held" if retest_done
                               else "no retest — entering into the initial thrust"))

    # 7 — volume strength
    vs = volume_strength(bars_m15)
    comps.append(Component("volume_strength", 1.0 if vs.get("strong") else 0.25,
                           vs.get("available", False), vs["reason"]))

    # 10 — session
    sq = session_quality(symbol=symbol)
    comps.append(Component("session", sq["score"], True,
                           f"{sq['name']} — {sq['reason']}"))

    # 11 — basket correlation adjusts the final score rather than scoring alone
    ba = basket_agreement(symbol, side, peer_moves or {})
    if ba.get("available") and not ba["agree"]:
        a.flags.append(f"basket disagrees — {ba['reason']}")

    # ── normalise over available components only ──
    live = [c for c in comps if c.available]
    dead = [c for c in comps if not c.available]
    total_w = sum(WEIGHTS[c.name] for c in live)
    raw = sum(WEIGHTS[c.name] * c.score for c in live)
    score = (raw / total_w * 100) if total_w else 0.0

    if ba.get("available") and not ba["agree"]:
        score *= 0.85                      # basket disagreement is a penalty

    a.components = [{"name": c.name, "score": round(c.score, 2),
                     "weight": WEIGHTS[c.name], "available": c.available,
                     "reason": c.reason} for c in comps]
    a.inputs_used = [c.name for c in live]
    a.inputs_missing = [c.name for c in dead]
    a.score = round(score, 1)
    # Some conditions are not "worth fewer points" — they mean the trade is
    # the wrong way round, and no score should override them.
    a.passed = (score >= threshold() and not a.veto and not any(
        f.startswith(("LIQUIDITY SWEEP", "ABSORPTION", "DELTA AGAINST",
                      "price is sitting ON", "INTO HTF BLOCK"))
        for f in a.flags))

    covered = round(total_w / sum(WEIGHTS.values()) * 100)
    if a.passed:
        a.verdict = (f"{a.score:.0f}/100 on {len(live)} of {len(comps)} checks "
                     f"({covered}% of the model's weight) — entry confirmed")
    elif any(f.startswith("LIQUIDITY SWEEP") for f in a.flags):
        a.verdict = "rejected — this is a liquidity sweep, not a breakout"
    elif any(f.startswith("ABSORPTION") for f in a.flags):
        a.verdict = "rejected — aggression is being absorbed; the move will likely fail"
    elif any(f.startswith("DELTA AGAINST") for f in a.flags):
        a.verdict = ("rejected — order flow is running the other way; this "
                     "would be taking the opposite side of the aggression")
    elif any(f.startswith("price is sitting ON") for f in a.flags):
        a.verdict = ("rejected — price is on a high-volume node, where breaks "
                     "get absorbed rather than continuing")
    elif any(f.startswith("INTO HTF BLOCK") for f in a.flags):
        a.verdict = ("rejected — entering directly into an opposing HTF "
                     "order block; the rejection the other way is the trade "
                     "worth waiting for")
    else:
        a.verdict = (f"{a.score:.0f}/100, below the {threshold():.0f} threshold "
                     f"({covered}% of the model's weight available)")
    return a
