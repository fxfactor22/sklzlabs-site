"""SKLZ — structured entry models A–G, X, and H–N (v3.31).

MODEL A — M15 break and retest
    A level breaks on M15, price returns to it, and the level holds as
    support/resistance. Entry on the hold, not the break.

MODEL B — HTF order block, fib 50 entry
    Price rejects from the 50% level of a 4H or 1H order block. A 5M engulfing
    candle confirms the rejection. A fib is drawn from that rejection line to
    the extreme reached, and entry is at the 50% retracement.

BOTH confirmed by RSI(2) with a 21-period SMA on M5.

WHY THE RSI TIMING MATTERS
==========================
RSI(2) is fast and mean-reverting. At the moment a level breaks it will be
deep overbought on a bullish break — so a rule of "buy only below 30" would
block every entry if it were read at the break.

It is read at the RETEST, which is a pullback, and that is exactly when RSI(2)
falls. The rule and the model agree only because of when the measurement is
taken. Read it at the wrong moment and the model never fires.

The 21-SMA of RSI is the slower reference: RSI below its own average says the
pullback is real rather than a single noisy print.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


# ── indicators ──────────────────────────────────────────────────────
def rsi(closes: list[float], period: int = 2) -> list[float]:
    """Wilder's RSI. Returns a list aligned to the input, padded at the front.

    Period 2 is deliberately short — it is a pullback detector, not a trend
    filter, and at that length it swings the full range within a few bars.
    """
    if len(closes) < period + 1:
        return [50.0] * len(closes)

    out = [50.0] * period
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0.0)
        losses += max(-d, 0.0)
    ag, al = gains / period, losses / period
    out.append(100.0 if al == 0 else 100 - 100 / (1 + ag / al))

    for i in range(period + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        ag = (ag * (period - 1) + max(d, 0.0)) / period
        al = (al * (period - 1) + max(-d, 0.0)) / period
        out.append(100.0 if al == 0 else 100 - 100 / (1 + ag / al))
    return out


def sma(values: list[float], period: int) -> list[float]:
    out, run = [], 0.0
    for i, v in enumerate(values):
        run += v
        if i >= period:
            run -= values[i - period]
        out.append(run / min(i + 1, period))
    return out


# ── shared confirmation ─────────────────────────────────────────────
def rsi_confirms(side: int, m5_closes: list[float],
                 period: int = 2, smooth: int = 21) -> dict:
    """RSI(2) against its 21-SMA, read at the entry bar.

    Buy wants RSI oversold (the pullback is deep enough to be worth entering).
    Sell wants overbought. The SMA comparison guards against a single spike:
    RSI can print 12 on one noisy bar and mean nothing.
    """
    if len(m5_closes) < smooth + period + 2:
        return {"ok": False, "reason": "not enough M5 bars for RSI"}

    r = rsi(m5_closes, period)
    rs = sma(r, smooth)
    cur, avg = r[-1], rs[-1]

    try:
        lo = float(os.environ.get("SKLZ_RSI_BUY_BELOW", "30"))
        hi = float(os.environ.get("SKLZ_RSI_SELL_ABOVE", "70"))
    except ValueError:
        lo, hi = 30.0, 70.0

    # Look back a few bars, not only at the current one.
    #
    # The "hold" that confirms a retest is itself upward movement, and RSI(2)
    # is fast enough to leave oversold on that single bar. Demanding RSI < 30
    # AT the entry bar means the condition is almost never true at the moment
    # you actually want to enter.
    #
    # The real signal is: it REACHED oversold during the pullback, and is now
    # turning back up. That is the classic short-RSI entry and it is what the
    # rule was reaching for.
    try:
        window = int(os.environ.get("SKLZ_RSI_LOOKBACK", "4"))
    except ValueError:
        window = 4
    recent = r[-window:]

    if side > 0:
        reached = min(recent) < lo
        turning = cur > recent[-2] if len(recent) > 1 else True
        ok = reached and turning
        why = (f"RSI(2) reached {min(recent):.0f} in the pullback (under "
               f"{lo:.0f}) and is turning up at {cur:.0f}"
               if ok else
               (f"RSI(2) got to {min(recent):.0f} but is not turning up yet"
                if reached else
                f"RSI(2) low was {min(recent):.0f} over the last {window} bars; "
                f"a buy wants it under {lo:.0f}. The pullback is not deep "
                f"enough."))
    else:
        reached = max(recent) > hi
        turning = cur < recent[-2] if len(recent) > 1 else True
        ok = reached and turning
        why = (f"RSI(2) reached {max(recent):.0f} (over {hi:.0f}) and is "
               f"turning down at {cur:.0f}"
               if ok else
               (f"RSI(2) got to {max(recent):.0f} but is not turning down yet"
                if reached else
                f"RSI(2) high was {max(recent):.0f} over the last {window} "
                f"bars; a sell wants it over {hi:.0f}."))

    return {"ok": ok, "rsi": round(cur, 1), "rsi_avg": round(avg, 1),
            "reason": why}


def engulfing(bars: list[dict], side: int) -> dict:
    """A 5M engulfing candle in the intended direction."""
    if len(bars) < 2:
        return {"ok": False, "reason": "not enough bars"}
    p, c = bars[-2], bars[-1]
    if side > 0:
        ok = (p["close"] < p["open"] and c["close"] > c["open"]
              and c["close"] > p["open"] and c["open"] <= p["close"])
    else:
        ok = (p["close"] > p["open"] and c["close"] < c["open"]
              and c["close"] < p["open"] and c["open"] >= p["close"])
    return {"ok": ok,
            "reason": ("5M engulfing candle in our direction" if ok
                       else "no 5M engulfing candle at this level")}


# ── Model A: M15 break and retest ───────────────────────────────────
@dataclass
class Setup:
    ok: bool
    model: str
    side: int = 0
    entry: float = 0.0
    level: float = 0.0
    stop: float = 0.0
    reasons: list = field(default_factory=list)
    blockers: list = field(default_factory=list)
    target: float = 0.0          # structural take-profit, 0 = none
    tag: str = ""                # report tag suffix: "" -> model_<letter>, "e_va" -> model_e_va
    fixed_tp: bool = False       # True: trailing must leave this trade alone


def find_m15_level(m15: list[dict], lookback: int = 40,
                   touches: int = 2, tol_frac: float = 0.0008) -> list[dict]:
    """Levels worth breaking: prices touched more than once.

    A level nobody traded twice is not a level, it is a coordinate.
    """
    if len(m15) < 12:
        return []
    window = m15[-lookback:]
    pts = []
    for i in range(2, len(window) - 2):
        h, l = window[i]["high"], window[i]["low"]
        if h >= max(window[i - 2]["high"], window[i - 1]["high"],
                    window[i + 1]["high"], window[i + 2]["high"]):
            pts.append(("high", h))
        if l <= min(window[i - 2]["low"], window[i - 1]["low"],
                    window[i + 1]["low"], window[i + 2]["low"]):
            pts.append(("low", l))

    levels = []
    for kind, price in pts:
        hit = [p for k, p in pts if k == kind
               and abs(p - price) <= price * tol_frac]
        if len(hit) >= touches:
            if not any(abs(l["price"] - price) <= price * tol_frac
                       for l in levels):
                levels.append({"kind": kind, "price": sum(hit) / len(hit),
                               "touches": len(hit)})
    return levels


def _a_value_area_levels(extra) -> list[dict]:
    """A `value_area` mode (video review): the edges of the composite value
    area (TPO by default, merged days with >= 50% overlap) are levels worth
    a break-retest. Needs H1 bars in extra (several days)."""
    h1 = (extra or {}).get("h1") or []
    if len(h1) < 48:
        return []
    try:
        from basket_engine.learn import levels as LV
        if os.environ.get("SKLZ_VA_COMPOSITE", "1") != "0":
            va = LV.composite_va(h1, now_utc=_now_utc(extra))
        else:
            va = LV.prev_day_value_area(h1, now_utc=_now_utc(extra))
    except Exception:  # noqa: BLE001
        return []
    if not va:
        return []
    days = int(va.get("days", 1) or 1)
    width = va["vah"] - va["val"]
    return [{"kind": "high", "price": va["vah"], "touches": days, "va": True, "width": width},
            {"kind": "low", "price": va["val"], "touches": days, "va": True, "width": width}]


def model_a(m15: list[dict], m5: list[dict], pip: float, extra=None) -> Setup:
    """M15 break, then retest, then enter on the hold.

    SKLZ_A_LEVELS=touches|value_area|both (default touches). Value-area
    levels (tag model_a_va) additionally need the break to clear the edge
    by SKLZ_A_VA_MIN_BREAK x VA width (0.25), the retest to hold within
    that distance, and an M5 break of structure before entry."""
    s = Setup(ok=False, model="A: M15 break-retest")
    mode = os.environ.get("SKLZ_A_LEVELS", "touches").strip().lower()
    levels = []
    if mode in ("touches", "both"):
        levels += find_m15_level(m15)
    if mode in ("value_area", "both"):
        levels += _a_value_area_levels(extra)
    if not levels:
        s.blockers.append("no M15 level with two or more touches"
                          if mode == "touches" else "no level (touches / value area) to trade")
        return s
    if len(m15) < 6:
        s.blockers.append("not enough M15 history")
        return s
    try:
        va_frac = float(os.environ.get("SKLZ_A_VA_MIN_BREAK", "0.25"))
    except ValueError:
        va_frac = 0.25

    for lv in levels:
        price, kind = lv["price"], lv["kind"]
        side = 1 if kind == "high" else -1
        is_va = bool(lv.get("va"))
        va_tol = va_frac * lv.get("width", 0.0) if is_va else 0.0

        # did a recent M15 bar close beyond it?
        broke_at = None
        for i in range(len(m15) - 6, len(m15)):
            if i < 1:
                continue
            b = m15[i]
            if side > 0 and b["close"] > price and m15[i - 1]["close"] <= price:
                broke_at = i
            if side < 0 and b["close"] < price and m15[i - 1]["close"] >= price:
                broke_at = i
        if broke_at is None:
            continue

        # has price come back to it and held? measured on M5 for precision
        tol = 6 * pip
        came_back = any(
            (side > 0 and b["low"] <= price + tol) or
            (side < 0 and b["high"] >= price - tol)
            for b in m5[-8:])
        if not came_back:
            s.blockers.append(f"broke {price:.5f} but has not retested it yet")
            continue

        last = m5[-1]
        held = last["close"] > price if side > 0 else last["close"] < price
        if not held:
            s.blockers.append(f"retested {price:.5f} and failed to hold")
            continue

        if is_va:
            # "significant" break: an M15 close at least va_tol beyond the edge
            far = max((b["close"] - price) * side for b in m15[broke_at:])
            if far < va_tol:
                s.blockers.append(f"VA edge {price:.5f} broken by only {far / pip:.1f} pips — not significant")
                continue
            # the retest must not go deep back inside the area
            deep = max((price - b["low"]) if side > 0 else (b["high"] - price) for b in m5[-8:])
            if deep > va_tol:
                s.blockers.append(f"retest went {deep / pip:.1f} pips back inside the value area — not holding")
                continue
            # break of structure on M5 in the breakout direction
            lows_, highs_ = swing_points(m5[-30:-1], 2)
            ref = [p for _, p in (highs_ if side > 0 else lows_)]
            if not ref or not ((last["close"] > max(ref[-2:])) if side > 0 else (last["close"] < min(ref[-2:]))):
                s.blockers.append("VA edge held; waiting for an M5 break of structure")
                continue

        rsi_c = rsi_confirms(side, [b["close"] for b in m5])
        if not rsi_c["ok"] and not is_va:
            s.blockers.append(rsi_c["reason"])
            continue

        s.ok = True
        s.side = side
        s.level = price
        s.entry = last["close"]
        s.stop = (min(b["low"] for b in m5[-6:]) - 2 * pip if side > 0
                  else max(b["high"] for b in m5[-6:]) + 2 * pip)
        if is_va:
            s.tag = "a_va"
            s.model = "A_VA: value-area break-retest"
            s.stop = (price - va_tol - 2 * pip) if side > 0 else (price + va_tol + 2 * pip)
        try:
            from basket_engine.learn.levels import structural_target
            s.target = structural_target(m5, side, s.entry, s.stop)[0] or 0.0
        except Exception:  # noqa: BLE001
            pass
        s.reasons = [
            (f"composite value-area edge {price:.5f} ({lv['touches']} day(s) of agreement), broken" if is_va
             else f"M15 level {price:.5f} touched {lv['touches']}x, then broken"),
            "price returned and the level held" + (" with an M5 break of structure" if is_va else ""),
            rsi_c["reason"] if rsi_c["ok"] else "RSI not required for value-area levels",
        ]
        return s

    return s


# ── Model B: HTF order block, fib 50 entry ──────────────────────────
def order_block(htf: list[dict], side: int, lookback: int = 30) -> dict | None:
    """The last opposing candle before the move that broke structure.

    That candle is where the position was built — the 50% of its range is the
    level worth watching, not its extreme.
    """
    if len(htf) < 6:
        return None
    window = htf[-lookback:]
    # start at len-2 so the candle immediately before the break is reachable —
    # that is usually THE order block, and len-3 skipped it entirely
    for i in range(len(window) - 2, 0, -1):
        c = window[i]
        nxt = window[i + 1] if i + 1 < len(window) else None
        if nxt is None:
            continue
        if side > 0 and c["close"] < c["open"] and nxt["close"] > c["high"]:
            return {"high": c["high"], "low": c["low"],
                    "mid": (c["high"] + c["low"]) / 2, "index": i}
        if side < 0 and c["close"] > c["open"] and nxt["close"] < c["low"]:
            return {"high": c["high"], "low": c["low"],
                    "mid": (c["high"] + c["low"]) / 2, "index": i}
    return None


def base_zone(h1: list[dict], side: int, lookback: int = 60) -> dict | None:
    """Impulse -> indecisive -> impulse (video review, 8 Oct). The
    indecisive bar(s) between two impulses are the zone. side=+1 wants the
    SECOND impulse bullish. Fresh (not closed through since) and, when
    SKLZ_B_BASE_HELD=1, revisited at least once and held."""
    if len(h1) < 12:
        return None
    atr = _atr(h1) or 1e-9
    win = h1[-lookback:]
    held_req = os.environ.get("SKLZ_B_BASE_HELD", "0") == "1"

    def impulsive(b):
        rng = (b["high"] - b["low"]) or 1e-9
        return abs(b["close"] - b["open"]) >= 0.6 * rng and abs(b["close"] - b["open"]) >= 0.8 * atr

    def indecisive(b):
        rng = (b["high"] - b["low"]) or 1e-9
        return abs(b["close"] - b["open"]) <= 0.4 * rng

    for i in range(len(win) - 2, 2, -1):          # win[-1] is the forming bar
        b2 = win[i]
        if not impulsive(b2) or ((b2["close"] > b2["open"]) != (side > 0)):
            continue
        j = i - 1
        base = []
        while j >= 1 and indecisive(win[j]) and len(base) < 3:
            base.insert(0, win[j]); j -= 1
        if not base or not impulsive(win[j]):
            continue
        lo, hi = min(b["low"] for b in base), max(b["high"] for b in base)
        after = win[i + 1:]
        cut = any((b["close"] < lo) if side > 0 else (b["close"] > hi) for b in after)
        if cut:
            continue
        touched = ([b for b in after if b["low"] <= hi] if side > 0
                   else [b for b in after if b["high"] >= lo])
        if held_req and not touched:
            continue
        return {"low": lo, "high": hi, "mid": (lo + hi) / 2, "bars": len(base)}
    return None


def _b_base_entry(s: Setup, h4: list[dict], h1: list[dict], m5: list[dict], pip: float) -> bool:
    """B `base` mode: 4H bias, base zone on H1, price enters the zone and
    does NOT close through its far side, builds >= 3 M5 bars inside, then
    an M5 close beyond the highest high (lows for sells) of those bars."""
    closed4 = h4[:-1] if len(h4) > 3 else h4
    ups = sum(1 for b in closed4[-3:] if b["close"] > b["open"])
    bias = 1 if ups >= 2 else -1 if ups <= 1 else 0
    if not bias:
        s.blockers.append("base: no 4H bias")
        return False
    z = base_zone(h1, bias)
    if not z:
        s.blockers.append("base: no fresh impulse-base-impulse zone on H1")
        return False
    side = bias
    tol = 2 * pip
    inside = [b for b in m5[-12:] if (b["low"] <= z["high"] + tol if side > 0 else b["high"] >= z["low"] - tol)]
    if len(inside) < 3:
        s.blockers.append(f"base: waiting for price to work inside the zone {z['low']:.5f}-{z['high']:.5f}")
        return False
    if any((b["close"] < z["low"]) if side > 0 else (b["close"] > z["high"]) for b in inside):
        s.blockers.append("base: price went straight through the zone — no trade")
        return False
    last = m5[-1]
    # the structure built INSIDE the zone — skip the bar that carried price in
    core = inside[1:-1] if len(inside) >= 4 else inside[:-1]
    ref = max(b["high"] for b in core) if side > 0 else min(b["low"] for b in core)
    if (side > 0 and last["close"] <= ref) or (side < 0 and last["close"] >= ref):
        s.blockers.append(f"base: structure forming in the zone; waiting for an M5 close {'above' if side > 0 else 'below'} {ref:.5f}")
        return False
    entry = last["close"]
    stop = (min(b["low"] for b in inside) - 2 * pip) if side > 0 else (max(b["high"] for b in inside) + 2 * pip)
    risk = abs(entry - stop)
    if risk < _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip:
        s.blockers.append("base: stop under the zone low is too tight")
        return False
    s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, ref, stop
    s.tag, s.model = "b_base", "B_BASE: impulse-base-impulse, M5 BOS"
    try:
        from basket_engine.learn.levels import structural_target
        tgt, _ = structural_target(m5, side, entry, stop)
        two_r = entry + side * 2 * risk
        s.target = (min(tgt, two_r) if side > 0 else max(tgt, two_r)) if tgt else two_r
    except Exception:  # noqa: BLE001
        s.target = entry + side * 2 * risk
    s.reasons = [f"4H bias {'bullish' if side > 0 else 'bearish'}; H1 base zone {z['low']:.5f}-{z['high']:.5f} ({z['bars']} bar(s))",
                 "price entered the zone, held it, built structure",
                 f"M5 closed {'above' if side > 0 else 'below'} {ref:.5f} — structure broke in our favour"]
    return True


def model_b(h4: list[dict], h1: list[dict], m5: list[dict],
            pip: float) -> Setup:
    """Rejection from the 50% of an HTF order block, entered at fib 50.
    SKLZ_B_ZONE=ob|base|both (default ob)."""
    s = Setup(ok=False, model="B: HTF block, fib 50")
    zone_mode = os.environ.get("SKLZ_B_ZONE", "ob").strip().lower()
    if zone_mode in ("base", "both"):
        if _b_base_entry(s, h4, h1, m5, pip):
            return s
        if zone_mode == "base":
            return s

    for side in (1, -1):
        blk = order_block(h4, side) or order_block(h1, side)
        if not blk:
            continue

        mid = blk["mid"]

        # has price rejected from the block's 50%?
        touched = any(
            (side > 0 and b["low"] <= mid + 4 * pip) or
            (side < 0 and b["high"] >= mid - 4 * pip)
            for b in m5[-30:])
        if not touched:
            continue

        # the extreme reached since that rejection — and it must be a REAL
        # run. A fib of a 2-pip move has levels 1 pip apart, which is spread.
        min_run = _min_pips("SKLZ_B_MIN_RUN_PIPS", 8.0) * pip
        if side > 0:
            extreme = max(b["high"] for b in m5[-30:])
            if extreme <= mid or (extreme - mid) < min_run:
                continue
            fib50 = mid + (extreme - mid) * 0.5
            at_fib = m5[-1]["low"] <= fib50 + 4 * pip
        else:
            extreme = min(b["low"] for b in m5[-30:])
            if extreme >= mid or (mid - extreme) < min_run:
                continue
            fib50 = mid - (mid - extreme) * 0.5
            at_fib = m5[-1]["high"] >= fib50 - 4 * pip

        if not at_fib:
            s.blockers.append(
                f"rejected from the block at {mid:.5f} but price is not back "
                f"at the 50% fib ({fib50:.5f}) yet")
            continue

        eng = engulfing(m5, side)
        if not eng["ok"]:
            s.blockers.append(eng["reason"])
            continue

        rsi_c = rsi_confirms(side, [b["close"] for b in m5])
        if not rsi_c["ok"]:
            s.blockers.append(rsi_c["reason"])
            continue

        s.ok = True
        s.side = side
        s.level = mid
        s.entry = m5[-1]["close"]
        s.stop = (blk["low"] - 2 * pip if side > 0 else blk["high"] + 2 * pip)
        if os.environ.get("SKLZ_B_TARGET", "liquidity").strip().lower() == "liquidity":
            try:
                from basket_engine.learn.levels import structural_target
                htf_lv = [p for _, p in (swing_points(h1, 2)[1] if side > 0 else swing_points(h1, 2)[0])]
                s.target = structural_target(m5, side, s.entry, s.stop, extra_levels=htf_lv)[0] or 0.0
            except Exception:  # noqa: BLE001
                pass
        s.reasons = [
            f"HTF order block {blk['low']:.5f}-{blk['high']:.5f}, "
            f"50% at {mid:.5f}",
            f"price rejected from it and ran to {extreme:.5f}",
            f"returned to the 50% fib at {fib50:.5f}",
            eng["reason"],
            rsi_c["reason"],
        ]
        return s

    return s




# ── Model C: 4H candle open + fair value gap ────────────────────────
def _min_pips(env: str, default: float) -> float:
    try:
        return float(os.environ.get(env, str(default)))
    except ValueError:
        return default


def fair_value_gap(bars: list[dict], side: int, lookback: int = 20,
                   min_height: float = 0.0) -> dict | None:
    """A three-candle gap: the middle candle moved so fast that the first and
    third don't overlap. That unfilled space is where the market skipped
    price levels, and it tends to get revisited.

    Bullish FVG: bar[i-2].high < bar[i].low  (gap below, price jumped up)
    Bearish FVG: bar[i-2].low  > bar[i].high (gap above, price fell through)
    """
    if len(bars) < 3:
        return None
    start = max(2, len(bars) - lookback)
    for i in range(len(bars) - 1, start - 1, -1):
        a, b = bars[i - 2], bars[i]
        if side > 0 and a["high"] < b["low"]:
            if (b["low"] - a["high"]) < min_height:
                continue                    # a gap smaller than noise is noise
            return {"top": b["low"], "bottom": a["high"],
                    "mid": (b["low"] + a["high"]) / 2, "index": i}
        if side < 0 and a["low"] > b["high"]:
            if (a["low"] - b["high"]) < min_height:
                continue
            return {"top": a["low"], "bottom": b["high"],
                    "mid": (a["low"] + b["high"]) / 2, "index": i}
    return None


def _c_ob_trigger(s: Setup, h4_open: float, extreme: float, side: int, m5: list[dict],
                  m30: list[dict], pip: float) -> bool:
    """C `ob` trigger (Power-of-3 clip, 8 Oct): after the trap, an M30 bar
    must take the PREVIOUS M30 bar's extreme and close back inside it (the
    'range' bar), then price retraces into the M5 order block of the
    reversal leg. Fills `s` and returns True when complete."""
    if len(m30) < 6:
        s.blockers.append("ob trigger: not enough M30 history")
        return False
    done = m30[:-1]
    rng_bar = None
    for i in range(len(done) - 1, max(1, len(done) - 8), -1):
        b, prev = done[i], done[i - 1]
        if side > 0 and b["low"] < prev["low"] and prev["low"] <= b["close"] <= prev["high"]:
            rng_bar = b; break
        if side < 0 and b["high"] > prev["high"] and prev["low"] <= b["close"] <= prev["high"]:
            rng_bar = b; break
    if rng_bar is None:
        s.blockers.append("ob trigger: no M30 bar has taken the prior bar's extreme and closed back inside")
        return False
    blk = order_block(m5, side, lookback=24)
    if not blk:
        s.blockers.append("ob trigger: no M5 order block on the reversal leg yet")
        return False
    last = m5[-1]
    tol = 2 * pip
    in_blk = ((last["low"] <= blk["high"] + tol and last["close"] >= blk["low"]) if side > 0
              else (last["high"] >= blk["low"] - tol and last["close"] <= blk["high"]))
    if not in_blk:
        s.blockers.append(f"ob trigger: waiting for the retrace into the M5 block {blk['low']:.5f}-{blk['high']:.5f}")
        return False
    s.ok, s.side, s.level, s.entry = True, side, blk["mid"], last["close"]
    s.stop = extreme - 2 * pip if side > 0 else extreme + 2 * pip
    s.tag, s.model = "c_ob", "C_OB: 4H open trap, M30 range bar, M5 block"
    try:
        from basket_engine.learn.levels import structural_target
        tgt, _ = structural_target(m5, side, s.entry, s.stop)
        two_r = s.entry + side * 2 * abs(s.entry - s.stop)
        s.target = (min(tgt, two_r) if side > 0 else max(tgt, two_r)) if tgt else two_r
    except Exception:  # noqa: BLE001
        pass
    s.reasons = [f"4H bias {'bullish' if side > 0 else 'bearish'}; price trapped beyond the 4H open ({h4_open:.5f})",
                 f"M30 range bar took the prior bar's extreme and closed back inside",
                 f"price retraced into the M5 order block {blk['low']:.5f}-{blk['high']:.5f}"]
    return True


def model_c(h4: list[dict], m5: list[dict], pip: float, extra=None) -> Setup:
    """4H open + FVG: the drop below a bullish 4H open is the trap, the fair
    value gap left on the way back is the entry.

    Mechanics, stripped of the video's "millions" framing:
      1. HTF bias from 4H structure (three closed candles)
      2. Price must have traded the WRONG side of the current 4H open —
         below it for longs. That counter-move is the setup, not a failure.
      3. The reversal back through leaves an FVG on M5.
      4. Enter on the retracement INTO that gap, stop beyond the
         counter-move's extreme.
    """
    s = Setup(ok=False, model="C: 4H open + FVG")
    if len(h4) < 5 or len(m5) < 20:
        s.blockers.append("not enough history for the 4H model")
        return s

    # bias from closed 4H candles — the forming one's colour isn't known yet
    closed = h4[:-1]
    ups = sum(1 for b in closed[-3:] if b["close"] > b["open"])
    if ups >= 2:
        side = 1
    elif ups <= 1 and sum(1 for b in closed[-3:]
                          if b["close"] < b["open"]) >= 2:
        side = -1
    else:
        s.blockers.append("4H candles are mixed — no bias")
        return s

    h4_open = h4[-1]["open"]

    # the counter-move: price must have traded the wrong side of the open
    recent = m5[-24:]
    if side > 0:
        dipped = min(b["low"] for b in recent) < h4_open
        extreme = min(b["low"] for b in recent)
    else:
        dipped = max(b["high"] for b in recent) > h4_open
        extreme = max(b["high"] for b in recent)
    if not dipped:
        s.blockers.append(
            f"price has not traded the far side of the 4H open "
            f"({h4_open:.5f}) — no trap, no setup")
        return s

    # A GBPUSD sell fired with a 0.5-pip "trap" and a 0.2-pip "FVG" — every
    # condition technically true, all of it inside the spread. Structure
    # smaller than noise is noise: the trap must be a real excursion and the
    # gap must be wider than the ordinary cost of crossing it.
    trap_depth = abs(h4_open - extreme)
    min_trap = _min_pips("SKLZ_C_MIN_TRAP_PIPS", 5.0) * pip
    if trap_depth < min_trap:
        s.blockers.append(
            f"trap beyond the 4H open is only {trap_depth / pip:.1f} pips — "
            f"price is hovering AT the open, not trapped beyond it "
            f"(needs {min_trap / pip:.0f})")
        return s

    # v3.33 gates (video review): the dip must SWEEP liquidity, not just
    # drift under the open, and structure must break back before the gap
    # counts. Both default on; SKLZ_C_SWEEP=0 / SKLZ_C_MSB=0 restore 3.32.
    if os.environ.get("SKLZ_C_SWEEP", "1") != "0":
        lows_, highs_ = swing_points(m5[-60:-24], 2)
        pool = [p for _, p in (lows_ if side > 0 else highs_)]
        swept_pool = ([p for p in pool if extreme < p < h4_open] if side > 0
                      else [p for p in pool if h4_open < p < extreme])
        if not swept_pool:
            s.blockers.append(
                f"trap below the 4H open took no prior M5 swing "
                f"{'low' if side > 0 else 'high'} — no liquidity swept (SKLZ_C_SWEEP)")
            return s
    if os.environ.get("SKLZ_C_MSB", "1") != "0":
        after = [b for b in recent if (b["low"] == extreme if side > 0 else b["high"] == extreme)]
        idx = recent.index(after[0]) if after else 0
        leg = recent[:idx + 1]
        lows_, highs_ = swing_points(leg, 1)
        ref = [p for _, p in (highs_ if side > 0 else lows_)]
        if ref:
            msb_lvl = min(ref) if side > 0 else max(ref)
            broke = any((b["close"] > msb_lvl) if side > 0 else (b["close"] < msb_lvl)
                        for b in recent[idx + 1:])
            if not broke:
                s.blockers.append(
                    f"trap in place but no M5 structure break back through "
                    f"{msb_lvl:.5f} yet (SKLZ_C_MSB)")
                return s

    trig = os.environ.get("SKLZ_C_TRIGGER", "fvg").strip().lower()
    if trig in ("ob", "either"):
        if _c_ob_trigger(s, h4_open, extreme, side, m5, (extra or {}).get("m30") or [], pip):
            return s
        if trig == "ob":
            return s

    min_gap = _min_pips("SKLZ_MIN_FVG_PIPS", 3.0) * pip
    fvg = fair_value_gap(m5, side, min_height=min_gap)
    if not fvg:
        s.blockers.append(
            f"no fair value gap of at least {min_gap / pip:.0f} pips on the "
            f"reversal yet")
        return s

    # entry: price retracing INTO the gap
    last = m5[-1]
    if side > 0:
        in_gap = last["low"] <= fvg["top"] and last["close"] >= fvg["bottom"]
    else:
        in_gap = last["high"] >= fvg["bottom"] and last["close"] <= fvg["top"]
    if not in_gap:
        s.blockers.append(
            f"FVG at {fvg['bottom']:.5f}-{fvg['top']:.5f} exists but price "
            f"has not retraced into it")
        return s

    rsi_c = rsi_confirms(side, [b["close"] for b in m5])
    if not rsi_c["ok"]:
        s.blockers.append(rsi_c["reason"])
        return s

    s.ok = True
    s.side = side
    s.level = fvg["mid"]
    s.entry = last["close"]
    s.stop = extreme - 2 * pip if side > 0 else extreme + 2 * pip
    try:
        from basket_engine.learn.levels import structural_target
        tgt, _ = structural_target(m5, side, s.entry, s.stop)
        s.target = tgt or 0.0
    except Exception:  # noqa: BLE001
        pass
    s.reasons = [
        f"4H bias {'bullish' if side > 0 else 'bearish'} from closed candles",
        f"price trapped the far side of the 4H open ({h4_open:.5f})",
        f"FVG {fvg['bottom']:.5f}-{fvg['top']:.5f} on the reversal, "
        f"price retraced into it",
        rsi_c["reason"],
    ]
    return s



# ── Model D: inducement sweep + change of character ─────────────────
def swing_points(bars: list[dict], k: int = 2) -> tuple[list, list]:
    """(lows, highs) as (index, price), using k-bar pivots."""
    lows, highs = [], []
    for i in range(k, len(bars) - k):
        if bars[i]["low"] <= min(b["low"] for b in bars[i-k:i+k+1]):
            lows.append((i, bars[i]["low"]))
        if bars[i]["high"] >= max(b["high"] for b in bars[i-k:i+k+1]):
            highs.append((i, bars[i]["high"]))
    return lows, highs


def model_d(m15: list[dict], m5: list[dict], pip: float) -> Setup:
    """Inducement sweep: the minor higher-low is the bait, not the target.

    Sequence (long side; mirrored for shorts):
      1. An obvious low L0, then a rally.
      2. A pullback forms a HIGHER low L1 — the inducement. Retail reads it
         as support and rests stops just beneath it.
      3. Price sweeps below L1 — collecting those stops — while holding
         above L0. The obvious low never trades.
      4. The sweep reverses with a change of character: price closes back
         above the minor high formed after L1.
      5. Entry on that close. Stop below the sweep low (the real risk point).
         If price instead takes L0 too, the read was wrong — which is exactly
         what the stop placement admits.
    """
    s = Setup(ok=False, model="D: inducement sweep")
    if len(m15) < 20 or len(m5) < 20:
        s.blockers.append("not enough history for the inducement model")
        return s

    lows, highs = swing_points(m15[-40:])
    if len(lows) < 2 or not highs:
        s.blockers.append("no clear swing structure on M15")
        return s

    for side in (1, -1):
        if side > 0:
            pts = lows
            # L0 then a HIGHER L1 after it, with a rally high between them
            for a in range(len(pts) - 1):
                i0, l0 = pts[a]
                for b in range(a + 1, len(pts)):
                    i1, l1 = pts[b]
                    if l1 <= l0:
                        continue
                    between = [h for hi, h in highs if i0 < hi < i1]
                    if not between:
                        continue
                    rally_high = max(between)
                    if (rally_high - l0) < 10 * pip:
                        continue

                    # the sweep, on M5: below L1, holding above L0
                    recent = m5[-16:]
                    swept = min(bb["low"] for bb in recent)
                    if not (swept < l1 and swept > l0 + 1 * pip):
                        continue

                    # change of character: closed back above the minor high
                    # formed after the inducement low
                    post = [h for hi, h in highs if hi > i1]
                    choch_ref = min(post) if post else l1 + 8 * pip
                    last = m5[-1]
                    if last["close"] <= choch_ref:
                        s.blockers.append(
                            f"swept the inducement at {l1:.5f} but no change "
                            f"of character yet (needs a close above "
                            f"{choch_ref:.5f})")
                        continue

                    rsi_c = rsi_confirms(side, [bb["close"] for bb in m5])
                    if not rsi_c["ok"]:
                        s.blockers.append(rsi_c["reason"])
                        continue

                    s.ok = True
                    s.side = 1
                    s.level = l1
                    s.entry = last["close"]
                    s.stop = swept - 2 * pip
                    try:
                        from basket_engine.learn.levels import structural_target
                        s.target = structural_target(m5, 1, s.entry, s.stop)[0] or 0.0
                    except Exception:  # noqa: BLE001
                        pass
                    s.reasons = [
                        f"inducement: higher-low {l1:.5f} above the real low "
                        f"{l0:.5f} — retail support with stops beneath",
                        f"swept to {swept:.5f}, collecting those stops while "
                        f"holding above {l0:.5f}",
                        f"change of character — closed back above "
                        f"{choch_ref:.5f}",
                        rsi_c["reason"],
                    ]
                    return s
        else:
            pts = highs
            for a in range(len(pts) - 1):
                i0, h0 = pts[a]
                for b in range(a + 1, len(pts)):
                    i1, h1 = pts[b]
                    if h1 >= h0:
                        continue
                    between = [l for li, l in lows if i0 < li < i1]
                    if not between:
                        continue
                    drop_low = min(between)
                    if (h0 - drop_low) < 10 * pip:
                        continue
                    recent = m5[-16:]
                    swept = max(bb["high"] for bb in recent)
                    if not (swept > h1 and swept < h0 - 1 * pip):
                        continue
                    post = [l for li, l in lows if li > i1]
                    choch_ref = max(post) if post else h1 - 8 * pip
                    last = m5[-1]
                    if last["close"] >= choch_ref:
                        s.blockers.append(
                            f"swept the inducement at {h1:.5f} but no change "
                            f"of character yet (needs a close below "
                            f"{choch_ref:.5f})")
                        continue
                    rsi_c = rsi_confirms(side, [bb["close"] for bb in m5])
                    if not rsi_c["ok"]:
                        s.blockers.append(rsi_c["reason"])
                        continue
                    s.ok = True
                    s.side = -1
                    s.level = h1
                    s.entry = last["close"]
                    s.stop = swept + 2 * pip
                    try:
                        from basket_engine.learn.levels import structural_target
                        s.target = structural_target(m5, -1, s.entry, s.stop)[0] or 0.0
                    except Exception:  # noqa: BLE001
                        pass
                    s.reasons = [
                        f"inducement: lower-high {h1:.5f} below the real high "
                        f"{h0:.5f}",
                        f"swept to {swept:.5f} while holding below {h0:.5f}",
                        f"change of character — closed back below "
                        f"{choch_ref:.5f}",
                        rsi_c["reason"],
                    ]
                    return s
    return s

# ── Model E: prior-session sweep & reclaim ──────────────────────────
# Source: owner-supplied strategy video (CallistoFx, "85% winrate").
# What the charts showed: mark the prior session's high and low, wait for
# price to SWEEP one of them, then reclaim it — trade the reclaim, target
# the opposite extreme. The clip framed it as Thursday/Friday/Monday-open
# specifically; that weekly-calendar filter is NOT encoded here because the
# frames could not confirm the direction rule, and a wrong calendar filter
# is worse than none. This is the general form: sweep of the previous
# 24h extreme, reclaimed.
def _e_wick_ok(swept: list[dict], level: float, side: int) -> bool:
    """Optional E refinement (SKLZ_E_WICK=1): the bar that swept the level
    must be a single-candle rejection — the "John Wick" candle of the box
    method: wick beyond the level at least twice the body, close back
    inside. Off by default so E's live behaviour is unchanged."""
    if os.environ.get("SKLZ_E_WICK", "0") != "1":
        return True
    for b in swept:
        body = abs(b["close"] - b["open"]) or 1e-9
        if side > 0:
            wick = level - b["low"]
            inside = b["close"] > level
        else:
            wick = b["high"] - level
            inside = b["close"] < level
        if inside and wick >= 2 * body:
            return True
    return False


def _e_sources(extra) -> list[str]:
    raw = os.environ.get("SKLZ_E_LEVELS", "extremes").strip().lower()
    if raw in ("all", "*"):
        return ["extremes", "value_area", "prev_day", "sessions", "trc"]
    return [x.strip() for x in raw.split(",") if x.strip()]


def _mss_fvg_entry(m15: list[dict], m5: list[dict], side: int, pip: float,
                   sweep_extreme: float) -> tuple[dict | None, str]:
    """Trigger used by the PDH/PDL variant (video: 'wait for a market
    structure shift, the first leg leaves an FVG, enter on the retrace').
    side=+1 after a low sweep: an M15 close above the last lower-high
    (the shift), then a bullish M5 FVG whose zone price has come back to.
    Returns (fvg, why)."""
    if len(m15) < 12 or len(m5) < 10:
        return None, "not enough bars for the structure-shift trigger"
    lows, highs = swing_points(m15[-30:-1], 2)
    last15 = m15[-1]
    if side > 0:
        ref = [p for _, p in highs if p > sweep_extreme]
        if not ref:
            return None, "no lower-high to shift through"
        if last15["close"] <= min(ref):
            return None, f"waiting for an M15 close above {min(ref):.5f} (structure shift)"
    else:
        ref = [p for _, p in lows if p < sweep_extreme]
        if not ref:
            return None, "no higher-low to shift through"
        if last15["close"] >= max(ref):
            return None, f"waiting for an M15 close below {max(ref):.5f} (structure shift)"
    min_gap = _min_pips("SKLZ_MIN_FVG_PIPS", 3.0) * pip
    fvg = fair_value_gap(m5, side, lookback=12, min_height=min_gap)
    if not fvg:
        return None, "structure shifted; no M5 fair value gap on the leg yet"
    last = m5[-1]
    in_gap = ((last["low"] <= fvg["top"] and last["close"] >= fvg["bottom"]) if side > 0
              else (last["high"] >= fvg["bottom"] and last["close"] <= fvg["top"]))
    if not in_gap:
        return None, f"FVG {fvg['bottom']:.5f}-{fvg['top']:.5f} waiting for the retrace"
    return fvg, f"structure shifted and price retraced into the FVG {fvg['bottom']:.5f}-{fvg['top']:.5f}"


def _bos_ob_entry(m15: list[dict], m5: list[dict], side: int, pip: float,
                  sweep_extreme: float) -> tuple[dict | None, str]:
    """CallistoFX 'TRC' trigger (8 Oct study): after the sweep, an M15
    break of structure against the sweep (close beyond the last swing),
    then a retrace into the M5 order block of the BOS leg. Returns
    (block, why)."""
    if len(m15) < 12 or len(m5) < 12:
        return None, "not enough bars for the BOS/OB trigger"
    lows, highs = swing_points(m15[-30:-1], 2)
    last15 = m15[-1]
    if side > 0:
        ref = [p for _, p in highs if p > sweep_extreme]
        if not ref or last15["close"] <= min(ref):
            return None, f"waiting for a 15M BOS above {min(ref):.5f}" if ref else "no 15M swing high to break"
    else:
        ref = [p for _, p in lows if p < sweep_extreme]
        if not ref or last15["close"] >= max(ref):
            return None, f"waiting for a 15M BOS below {max(ref):.5f}" if ref else "no 15M swing low to break"
    blk = order_block(m5, side, lookback=24)
    if not blk:
        return None, "15M BOS printed; no M5 order block on the leg yet"
    last = m5[-1]
    tol = 2 * pip
    in_blk = ((last["low"] <= blk["high"] + tol and last["close"] >= blk["low"]) if side > 0
              else (last["high"] >= blk["low"] - tol and last["close"] <= blk["high"]))
    if not in_blk:
        return None, f"15M BOS; waiting for the retest of the 5M block {blk['low']:.5f}-{blk['high']:.5f}"
    return blk, f"15M BOS against the sweep, price retested the 5M order block {blk['low']:.5f}-{blk['high']:.5f}"


def _e_bounce(s: Setup, levels: list[tuple[float, str]], side_for_low: int, m5: list[dict],
              pip: float, targets: list[float]) -> bool:
    """E bounce mode (untested-session-levels clip): touch an untested
    level, reject it (wick >= 50% of the bar, close back on the right
    side), no sweep required. Stop beyond the level, target the nearest
    untested level the other way (>= SKLZ_MIN_TARGET_RR)."""
    if not levels or len(m5) < 6:
        return False
    last = m5[-1]
    atr = _atr(m5[-40:]) or pip
    tol = max(3 * pip, 0.15 * atr)
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    from basket_engine.learn.levels import min_target_rr
    rng = (last["high"] - last["low"]) or 1e-9
    for lvl, label in levels:
        side = side_for_low
        body = abs(last["close"] - last["open"])
        if side > 0:
            touched = any(b["low"] <= lvl + tol for b in m5[-3:])
            wick = min(last["open"], last["close"]) - last["low"]
            reject = last["close"] > lvl and last["close"] > last["open"] and \
                (wick >= 0.3 * rng or body >= 0.5 * rng)
            stop = min(b["low"] for b in m5[-3:]) - 2 * pip
            stop = min(stop, lvl - 2 * pip)
        else:
            touched = any(b["high"] >= lvl - tol for b in m5[-3:])
            wick = last["high"] - max(last["open"], last["close"])
            reject = last["close"] < lvl and last["close"] < last["open"] and \
                (wick >= 0.3 * rng or body >= 0.5 * rng)
            stop = max(b["high"] for b in m5[-3:]) + 2 * pip
            stop = max(stop, lvl + 2 * pip)
        if not touched:
            continue
        if not reject:
            s.blockers.append(f"{label}: touched {lvl:.5f}, no rejection candle yet")
            continue
        entry = last["close"]
        risk = abs(entry - stop)
        if risk < min_stop:
            s.blockers.append(f"{label}: bounce stop too tight")
            continue
        cands = sorted([t for t in targets if (t - entry) * side > 0], key=lambda t: abs(t - entry))
        tgt = next((t for t in cands if abs(t - entry) / risk >= min_target_rr()), None)
        if tgt is None:
            s.blockers.append(f"{label}: no untested level the other way pays {min_target_rr():.1f}R")
            continue
        s.ok, s.side, s.entry, s.level, s.stop, s.target = True, side, entry, lvl, stop, tgt
        s.tag, s.model = "e_ss", "E_SS: untested session level bounce"
        s.reasons = [f"untested {label} {lvl:.5f} touched and rejected",
                     f"stop beyond it at {stop:.5f}; objective the untested level {tgt:.5f} ({abs(tgt - entry) / risk:.1f}R)"]
        return True
    return False


def _e_sweep_reclaim(s: Setup, pl: float, ph: float, label: str, trigger: str,
                     h1: list[dict], m5: list[dict], pip: float, extra,
                     need_rr: bool) -> bool:
    """Shared E core: sweep one edge of [pl, ph], confirm, target the other.
    Fills `s` and returns True when the setup is complete."""
    last = m5[-1]
    recent = h1[-24:][-8:]
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    m15 = (extra or {}).get("m15") or []
    for side in (1, -1):
        if side > 0:
            swept = [b for b in recent if b["low"] < pl]
            if not swept:
                continue
            ext = min(b["low"] for b in swept)
            lvl, opp = pl, ph
        else:
            swept = [b for b in recent if b["high"] > ph]
            if not swept:
                continue
            ext = max(b["high"] for b in swept)
            lvl, opp = ph, pl
        if trigger == "mss_fvg":
            fvg, why = _mss_fvg_entry(m15, m5, side, pip, ext)
            if fvg is None:
                s.blockers.append(f"{label}: {why}")
                continue
            confirm = why
        elif trigger == "bos_ob":
            blk, why = _bos_ob_entry(m15, m5, side, pip, ext)
            if blk is None:
                s.blockers.append(f"{label}: {why}")
                continue
            confirm = why
        else:
            reclaimed = last["close"] > lvl if side > 0 else last["close"] < lvl
            if not reclaimed:
                s.blockers.append(
                    f"{label}: swept {lvl:.5f} but has not reclaimed it — "
                    f"that is a {'downtrend' if side > 0 else 'uptrend'}, not a trap")
                continue
            if not _e_wick_ok(swept, lvl, side):
                s.blockers.append("SKLZ_E_WICK: the sweep bar is not a wick "
                                  "rejection (wick through the level >= 2x body, close inside)")
                continue
            confirm = f"price closed back {'above' if side > 0 else 'below'} it at {last['close']:.5f} — reclaimed"
        entry = last["close"]
        stop = ext - 2 * pip if side > 0 else ext + 2 * pip
        if abs(entry - stop) < min_stop:
            s.blockers.append(f"{label}: reclaim stop is too tight to be real")
            continue
        if (entry >= opp) if side > 0 else (entry <= opp):
            s.blockers.append(f"{label}: already at the opposite extreme — no room")
            continue
        rr = abs(opp - entry) / abs(entry - stop)
        if need_rr:
            from basket_engine.learn.levels import min_target_rr
            if rr < min_target_rr():
                s.blockers.append(f"{label}: opposite edge pays only {rr:.1f}R")
                continue
        s.ok, s.side, s.entry, s.level, s.stop, s.target = True, side, entry, lvl, stop, opp
        s.reasons = [f"{label} {lvl:.5f} swept to {ext:.5f}", confirm,
                     f"opposite edge {opp:.5f} is the objective ({rr:.1f}R)"]
        return True
    return False


def model_e(h1: list[dict], m5: list[dict], pip: float, extra=None) -> Setup:
    """Sweep of a range edge, then reclaimed — trade back across the range.

    Level sources (SKLZ_E_LEVELS, comma list or `all`; default `extremes`):
      extremes   the previous 24h block's high/low        -> tag model_e
      value_area yesterday's VAL/VAH, only when yesterday  -> tag model_e_va
                 closed INSIDE its own value area (balance)
      prev_day   yesterday's high/low (PDH/PDL)            -> tag model_e_pd
    Trigger: SKLZ_E_TRIGGER=reclaim|mss_fvg (default reclaim); the prev_day
    variant uses SKLZ_E_PD_TRIGGER (default mss_fvg) as in its source video.
    The opposite edge is the target; variants need SKLZ_MIN_TARGET_RR.
    """
    s = Setup(ok=False, model="E: session sweep reclaim")
    if len(h1) < 40 or len(m5) < 12:
        s.blockers.append("not enough history for the session-sweep model")
        return s
    trig = os.environ.get("SKLZ_E_TRIGGER", "reclaim").strip().lower()
    for src in _e_sources(extra):
        if src == "extremes":
            prev = h1[-48:-24] if len(h1) >= 48 else h1[:-24]
            if len(prev) < 12 or len(h1[-24:]) < 4:
                s.blockers.append("not enough session history")
                continue
            ph, pl = max(b["high"] for b in prev), min(b["low"] for b in prev)
            if ph - pl <= 0:
                s.blockers.append("prior session has no range")
                continue
            s.tag = "e"
            if _e_sweep_reclaim(s, pl, ph, "prior session", trig, h1, m5, pip, extra, False):
                return s
        elif src == "value_area":
            from basket_engine.learn import levels as LV
            va = LV.prev_day_value_area(h1, now_utc=_now_utc(extra))
            pd = LV.prev_day_range(h1, _now_utc(extra))
            if not va or not pd:
                s.blockers.append("value_area: not enough daily history")
                continue
            if not (va["val"] <= pd["close"] <= va["vah"]):
                s.blockers.append("value_area: yesterday closed outside its value area — not balanced")
                continue
            s.tag = "e_va"
            s.model = "E_VA: value-area sweep reclaim"
            if _e_sweep_reclaim(s, va["val"], va["vah"], "value area", trig, h1, m5, pip, extra, True):
                return s
            s.model = "E: session sweep reclaim"
        elif src == "prev_day":
            from basket_engine.learn import levels as LV
            pd = LV.prev_day_range(h1, _now_utc(extra))
            if not pd:
                s.blockers.append("prev_day: not enough daily history")
                continue
            s.tag = "e_pd"
            s.model = "E_PD: previous-day sweep"
            t2 = os.environ.get("SKLZ_E_PD_TRIGGER", "mss_fvg").strip().lower()
            if _e_sweep_reclaim(s, pd["low"], pd["high"], "previous day", t2, h1, m5, pip, extra, True):
                return s
            s.model = "E: session sweep reclaim"
        elif src == "sessions":
            # untested session highs/lows (8 Oct clip): bounce, no sweep needed
            from basket_engine.learn import levels as LV
            m15 = (extra or {}).get("m15") or []
            sl = LV.session_levels(m15 if len(m15) >= 100 else h1, now_utc=_now_utc(extra))
            if not sl["untested_highs"] and not sl["untested_lows"]:
                s.blockers.append("sessions: no untested session extremes")
                continue
            if os.environ.get("SKLZ_E_BOUNCE", "1") != "0":
                hi_t = [p for p, _ in sl["untested_highs"]]
                lo_t = [p for p, _ in sl["untested_lows"]]
                if _e_bounce(s, sl["untested_lows"], 1, m5, pip, hi_t):
                    return s
                if _e_bounce(s, sl["untested_highs"], -1, m5, pip, lo_t):
                    return s
            s.tag = ""
        elif src == "trc":
            # CallistoFX TRC: Asian high/low (or equal highs/lows) swept,
            # 15M BOS against it, 5M order-block retest
            from basket_engine.learn import levels as LV
            sl = LV.session_levels(h1, sessions=1, now_utc=_now_utc(extra))
            asia = [x for x in sl["all"] if x[2] == "Asian"]
            if not asia:
                s.blockers.append("trc: no completed Asian session in the window")
                continue
            ah, al, _, _ = asia[-1]
            s.tag = "e_trc"
            s.model = "E_TRC: Asian sweep, 15M BOS, 5M block"
            if _e_sweep_reclaim(s, al, ah, "Asian range", "bos_ob", h1, m5, pip, extra, True):
                return s
            s.model = "E: session sweep reclaim"
    s.tag = ""
    if not s.blockers:
        s.blockers.append("prior session extremes intact — nothing swept")
    return s


# ── Model F: accumulation, manipulation, POC retest ─────────────────
# Source: owner-supplied strategy video (volume-profile clip).
# What the charts showed: a boxed ACCUMULATION range, a MANIPULATION leg
# that sweeps out of it and closes back in, the volume-profile POC of that
# range drawn as a line, and the entry taken when price returns to the POC
# and holds. Stop beyond the manipulation wick.
def _poc(bars: list[dict], bins: int = 24) -> float:
    """Volume point of control: the price bucket that traded the most.

    Each bar's volume is spread evenly across the prices it covered — a
    coarse profile, but the POC of a coarse profile and a fine one land in
    the same place, and this needs no tick history.
    """
    if not bars:
        return 0.0
    hi = max(b["high"] for b in bars)
    lo = min(b["low"] for b in bars)
    if hi <= lo:
        return 0.0
    step = (hi - lo) / bins
    buckets = [0.0] * bins
    def _span(a: float, b2: float) -> tuple[int, int]:
        i0 = min(bins - 1, max(0, int((a - lo) / step)))
        i1 = min(bins - 1, max(0, int((b2 - lo) / step)))
        return (i0, i1) if i0 <= i1 else (i1, i0)

    for b in bars:
        vol = float(b.get("volume") or 0.0) or 1.0
        # 40% of a bar's volume spread over its whole range, 60% over its
        # body. Wicks are where price was rejected; bodies are where it was
        # accepted, and the POC is a question about acceptance.
        wick_lo, wick_hi = _span(b["low"], b["high"])
        share = vol * 0.4 / (wick_hi - wick_lo + 1)
        for i in range(wick_lo, wick_hi + 1):
            buckets[i] += share
        body_lo, body_hi = _span(b["open"], b["close"])
        share = vol * 0.6 / (body_hi - body_lo + 1)
        for i in range(body_lo, body_hi + 1):
            buckets[i] += share
    top_i = max(range(bins), key=lambda i: buckets[i])
    return lo + (top_i + 0.5) * step


def _model_f_range(m15: list[dict], m5: list[dict], pip: float) -> Setup:
    """Range accumulation -> manipulation out of it -> POC retest.

    Sequence (long; mirrored for shorts):
      1. An accumulation window: price rotates inside a range instead of
         trending — most closes sit in the middle of it.
      2. Manipulation: price trades BELOW the range low, then closes back
         INSIDE. The stops under the range have been collected.
      3. The volume POC of the accumulation window is the fair price of
         that whole rotation. Price returns to it.
      4. Entry when price is at the POC and the last M5 close holds above
         it. Stop below the manipulation low.
    """
    s = Setup(ok=False, model="F: POC retest after manipulation")
    if len(m15) < 40 or len(m5) < 12:
        s.blockers.append("not enough history for the POC model")
        return s

    window = m15[-40:-8]
    tail = m15[-8:]
    rh = max(b["high"] for b in window)
    rl = min(b["low"] for b in window)
    height = rh - rl
    if height <= 0:
        s.blockers.append("accumulation window has no range")
        return s

    # a range ROTATES; a trend DISPLACES. A uniform trend puts exactly half
    # its closes inside the middle band, so the band test alone passes
    # trends — net displacement is the discriminator that does not.
    drift = abs(window[-1]["close"] - window[0]["close"])
    mid_lo = rl + height * 0.2
    mid_hi = rh - height * 0.2
    inside = sum(1 for b in window if mid_lo <= b["close"] <= mid_hi)
    if drift > height * 0.5 or inside < len(window) * 0.5:
        s.blockers.append(
            "the window is trending, not accumulating — no range to "
            "manipulate")
        return s

    poc = _poc(window)
    if poc <= 0:
        s.blockers.append("could not read a volume POC")
        return s

    last = m5[-1]
    tol = max(height * 0.08, 3 * pip)
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip

    for side in (1, -1):
        if side > 0:
            manip = [b for b in tail if b["low"] < rl]
            if not manip:
                continue
            manip_low = min(b["low"] for b in manip)
            if tail[-1]["close"] <= rl:
                s.blockers.append(
                    f"swept the range low {rl:.5f} and has not closed back "
                    f"inside — the range is broken, not manipulated")
                continue
            if abs(last["close"] - poc) > tol:
                s.blockers.append(
                    f"manipulated, but price is not at the POC {poc:.5f} yet "
                    f"— waiting for the retest")
                continue
            if last["close"] < poc:
                s.blockers.append(
                    f"at the POC {poc:.5f} but not holding above it")
                continue
            entry = last["close"]
            stop = manip_low - 2 * pip
            if entry - stop < min_stop:
                continue
            s.reasons = [
                f"accumulation range {rl:.5f}-{rh:.5f}, POC at {poc:.5f}",
                f"manipulation swept to {manip_low:.5f} and closed back in",
                f"price returned to the POC and is holding above it"]
        else:
            manip = [b for b in tail if b["high"] > rh]
            if not manip:
                continue
            manip_high = max(b["high"] for b in manip)
            if tail[-1]["close"] >= rh:
                s.blockers.append(
                    f"swept the range high {rh:.5f} and has not closed back "
                    f"inside — the range is broken, not manipulated")
                continue
            if abs(last["close"] - poc) > tol:
                s.blockers.append(
                    f"manipulated, but price is not at the POC {poc:.5f} yet "
                    f"— waiting for the retest")
                continue
            if last["close"] > poc:
                s.blockers.append(
                    f"at the POC {poc:.5f} but not holding below it")
                continue
            entry = last["close"]
            stop = manip_high + 2 * pip
            if stop - entry < min_stop:
                continue
            s.reasons = [
                f"accumulation range {rl:.5f}-{rh:.5f}, POC at {poc:.5f}",
                f"manipulation swept to {manip_high:.5f} and closed back in",
                f"price returned to the POC and is holding below it"]

        s.ok = True
        s.side = side
        s.entry = entry
        s.level = poc
        s.stop = stop
        return s

    if not s.blockers:
        s.blockers.append("no manipulation out of the accumulation range")
    return s


def _model_f_trend(m15: list[dict], m5: list[dict], pip: float, extra=None) -> Setup:
    """F `trend` mode (video review): POC of the last IMPULSE LEG as a
    pullback entry in an established trend.

      1. Bias: >= 2 consecutive higher highs AND higher lows on M15 pivots
         (mirror for shorts).
      2. Leg: last confirmed pivot low -> pivot high. POC of the M5 bars
         across that leg (SKLZ_F_POC_SOURCE=leg) or yesterday's POC
         (=prev_day).
      3. Pullback reaches the POC (tol SKLZ_F_POC_TOL x leg height, 0.15)
         and the last M5 bar REJECTS it: closes back on the trend side with
         a wick >= 50% of its range.
      4. Stop beyond the rejection wick; target = the leg high; needs
         SKLZ_MIN_TARGET_RR.
    """
    s = Setup(ok=False, model="F_TREND: impulse-leg POC pullback", tag="f_trend")
    if len(m15) < 40 or len(m5) < 30:
        s.blockers.append("not enough history for the trend-POC model")
        return s
    lows, highs = swing_points(m15[-60:-1], 2)
    if len(lows) < 3 or len(highs) < 3:
        s.blockers.append("not enough M15 pivots to read a trend")
        return s
    try:
        tol_f = float(os.environ.get("SKLZ_F_POC_TOL", "0.15"))
    except ValueError:
        tol_f = 0.15
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    last = m5[-1]
    rng = (last["high"] - last["low"]) or 1e-9
    for side in (1, -1):
        hh = highs[-1][1] > highs[-2][1] > highs[-3][1]
        hl = lows[-1][1] > lows[-2][1] > lows[-3][1]
        lh = highs[-1][1] < highs[-2][1] < highs[-3][1]
        ll = lows[-1][1] < lows[-2][1] < lows[-3][1]
        if side > 0 and not (hh and hl):
            continue
        if side < 0 and not (lh and ll):
            continue
        # the leg: last pivot low -> the high after it (long); mirror short
        if side > 0:
            lo_i, lo_p = lows[-1]
            later = [(i, p) for i, p in highs if i > lo_i]
            if not later:
                s.blockers.append("trend up but the leg has no confirmed high yet")
                continue
            hi_i, hi_p = max(later, key=lambda x: x[1])
            leg_lo, leg_hi = lo_p, hi_p
            a, b = lo_i, hi_i
        else:
            hi_i, hi_p = highs[-1]
            later = [(i, p) for i, p in lows if i > hi_i]
            if not later:
                s.blockers.append("trend down but the leg has no confirmed low yet")
                continue
            lo_i, lo_p = min(later, key=lambda x: x[1])
            leg_lo, leg_hi = lo_p, hi_p
            a, b = hi_i, lo_i
        height = leg_hi - leg_lo
        if height <= 0:
            continue
        src = os.environ.get("SKLZ_F_POC_SOURCE", "leg").strip().lower()
        if src == "prev_day":
            from basket_engine.learn import levels as LV
            va = LV.prev_day_value_area(m15, now_utc=_now_utc(extra), source="volume")
            poc = va["poc"] if va else 0.0
        else:
            base = m15[-60:-1]
            leg_bars = base[a:b + 1]
            # finer profile from M5 when the leg's time span is known
            if leg_bars and leg_bars[0].get("time") and m5[-1].get("time"):
                t0, t1 = int(leg_bars[0]["time"]), int(leg_bars[-1]["time"]) + 900
                m5_leg = [x for x in m5 if x.get("time") and t0 <= int(x["time"]) < t1]
                leg_bars = m5_leg or leg_bars
            poc = _poc(leg_bars) if leg_bars else 0.0
        if poc <= 0:
            s.blockers.append("could not read the leg's POC")
            continue
        tol = max(height * tol_f, 3 * pip)
        touched = any(abs((x["low"] if side > 0 else x["high"]) - poc) <= tol for x in m5[-6:])
        if not touched:
            s.blockers.append(f"trend intact; waiting for the pullback into the leg POC {poc:.5f}")
            continue
        if side > 0:
            reject = last["close"] > poc and last["close"] > last["open"] and \
                (min(last["open"], last["close"]) - last["low"]) >= 0.5 * rng
            stop = min(x["low"] for x in m5[-4:]) - 2 * pip
            target = leg_hi
        else:
            reject = last["close"] < poc and last["close"] < last["open"] and \
                (last["high"] - max(last["open"], last["close"])) >= 0.5 * rng
            stop = max(x["high"] for x in m5[-4:]) + 2 * pip
            target = leg_lo
        if not reject:
            s.blockers.append(f"at the leg POC {poc:.5f} but no rejection candle yet")
            continue
        entry = last["close"]
        risk = abs(entry - stop)
        if risk < min_stop:
            s.blockers.append("rejection stop is too tight to be real")
            continue
        from basket_engine.learn.levels import min_target_rr
        rr = abs(target - entry) / risk
        if rr < min_target_rr():
            s.blockers.append(f"leg extreme {target:.5f} pays only {rr:.1f}R from the POC")
            continue
        s.ok, s.side, s.entry, s.level, s.stop, s.target = True, side, entry, poc, stop, target
        s.reasons = [
            f"trend {'up' if side > 0 else 'down'}: three stepping pivots on M15",
            f"impulse leg {leg_lo:.5f}-{leg_hi:.5f}, POC at {poc:.5f}",
            f"pullback rejected the POC; target the leg extreme {target:.5f} ({rr:.1f}R)"]
        return s
    if not s.blockers:
        s.blockers.append("no stepping trend on M15")
    return s


def model_f(m15: list[dict], m5: list[dict], pip: float, extra=None) -> Setup:
    """SKLZ_F_MODE=range|trend|both (default range = the 3.32 behaviour)."""
    mode = os.environ.get("SKLZ_F_MODE", "range").strip().lower()
    tried = []
    if mode in ("range", "both"):
        r = _model_f_range(m15, m5, pip)
        if r.ok:
            return r
        tried.append(r)
    if mode in ("trend", "both"):
        t = _model_f_trend(m15, m5, pip, extra)
        if t.ok:
            return t
        tried.append(t)
    if not tried:
        return _model_f_range(m15, m5, pip)
    return min(tried, key=lambda x: len(x.blockers))


# ── Model G: liquidity sweep + FVG reversal ─────────────────────────
# Source: owner-supplied breakdowns (two NQ 1-minute trades, NY open and
# London). What the charts showed: a liquidity pool ABOVE (relative equal
# highs / the prior session high) with a higher-timeframe imbalance on the
# same shelf (H1/H4 FVG); a wick THROUGH the pool that closed back below;
# then displacement leaving a bearish FVG on the entry timeframe; stop
# above the wick, target the internal liquidity the run started from —
# and only when that pays at least 2R (the reference trade paid ~5.6R).
# Model E already trades the sweep alone and its paper record (44W/179L)
# is the argument for the three extra gates here: the pool must be real,
# the sweep must be followed by displacement, and the target must pay.
def _atr(bars: list[dict], n: int = 14) -> float:
    if len(bars) < 2:
        return 0.0
    trs = []
    for i in range(1, len(bars)):
        h, l, pc = bars[i]["high"], bars[i]["low"], bars[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    trs = trs[-n:]
    return sum(trs) / len(trs) if trs else 0.0


def _equal_levels(points: list, tol: float, high: bool) -> list:
    """Clusters of >=2 swings within tol -> (level, count). The level is the
    cluster's extreme (the price the stops actually sit beyond)."""
    out, used = [], set()
    for i, (_, pa) in enumerate(points):
        if i in used:
            continue
        grp = [pa]
        for j, (_, pb) in enumerate(points[i + 1:], i + 1):
            if abs(pb - pa) <= tol:
                grp.append(pb); used.add(j)
        if len(grp) >= 2:
            out.append((max(grp) if high else min(grp), len(grp)))
    return out


def _all_fvgs(bars: list[dict], side: int, lookback: int = 40,
              min_height: float = 0.0) -> list[dict]:
    """Every FVG in the window (fair_value_gap returns only the newest)."""
    out = []
    start = max(2, len(bars) - lookback)
    for i in range(start, len(bars)):
        a, b = bars[i - 2], bars[i]
        if side < 0 and a["low"] > b["high"] and a["low"] - b["high"] >= min_height:
            out.append({"top": a["low"], "bottom": b["high"], "index": i})
        elif side > 0 and a["high"] < b["low"] and b["low"] - a["high"] >= min_height:
            out.append({"top": b["low"], "bottom": a["high"], "index": i})
    return out


def _in_kill_zone() -> bool:
    """London 07–10 UTC, New York 12–16 UTC. SKLZ_G_KILLZONES=0 lifts it."""
    if os.environ.get("SKLZ_G_KILLZONES", "1") == "0":
        return True
    from datetime import datetime, timezone
    h = datetime.now(timezone.utc).hour + datetime.now(timezone.utc).minute / 60
    return 7 <= h <= 10 or 12 <= h <= 16


def model_g(h1: list[dict], m5: list[dict], pip: float,
            m15: list[dict] | None = None,
            h4: list[dict] | None = None) -> Setup:
    """Liquidity sweep + displacement FVG. Mirrored for longs.

    Sequence (short):
      1. POOL — relative equal highs on M15 (or M5), or the prior 24h high.
      2. SWEEP — within the last 12 M5 bars a wick trades above the pool
         and the bar closes back below. A close above is a breakout: stand
         aside (that is Model E's whole failure mode).
      3. DISPLACEMENT — after the sweep bar, a bearish M5 FVG at least
         0.15 ATR tall. No gap, no trade.
      4. HTF confluence (score only): H1/H4 bearish FVG overlapping the
         sweep zone.
      5. STOP above the sweep wick (+0.15 ATR). TARGET = nearest swing low
         below entry that pays SKLZ_G_MIN_RR (default 2.0); none pays, no
         trade. The runner's paper tracker resolves at 2R, so this is what
         its scoreboard measures.
    """
    s = Setup(ok=False, model="G: liquidity sweep + FVG")
    if len(m5) < 40 or len(h1) < 24:
        s.blockers.append("not enough history for the sweep+FVG model")
        return s
    atr = _atr(m5) or pip * 10
    try:
        min_rr = float(os.environ.get("SKLZ_G_MIN_RR", "2.0"))
    except ValueError:
        min_rr = 2.0
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    pool_src = m15 if m15 and len(m15) >= 20 else m5
    lows_p, highs_p = swing_points(pool_src[-80:])
    prev24 = h1[-24:]
    ph = max(b["high"] for b in prev24)
    pl = min(b["low"] for b in prev24)
    last = m5[-1]
    recent = m5[-12:]

    for side in (-1, 1):
        # 1. pools --------------------------------------------------
        pools = []
        if side < 0:
            for lvl, n in _equal_levels(highs_p, 0.25 * atr, True):
                pools.append((lvl, f"relative equal highs ×{n} at {lvl:.5f}", 20))
            pools.append((ph, f"prior 24h high {ph:.5f}", 15))
        else:
            for lvl, n in _equal_levels(lows_p, 0.25 * atr, False):
                pools.append((lvl, f"relative equal lows ×{n} at {lvl:.5f}", 20))
            pools.append((pl, f"prior 24h low {pl:.5f}", 15))
        # 2. the sweep ----------------------------------------------
        hit = None
        for lvl, label, pts in pools:
            for i in range(len(m5) - 1, len(m5) - 13, -1):
                b = m5[i]
                if side < 0 and b["high"] > lvl and b["close"] < lvl:
                    cand = (i, b["high"], lvl, label)
                elif side > 0 and b["low"] < lvl and b["close"] > lvl:
                    cand = (i, b["low"], lvl, label)
                else:
                    continue
                if hit is None or cand[0] > hit[0]:
                    hit = cand
                break
        if hit is None:
            if side < 0 and any(b["high"] > lvl and b["close"] >= lvl
                                for lvl, _, _ in pools for b in recent):
                s.blockers.append("price closed THROUGH the pool — breakout, not a sweep")
            continue
        si, extreme, level, label = hit
        taken = [lab for lv, lab, _ in pools
                 if (extreme >= lv if side < 0 else extreme <= lv)]
        score = 25 + sum(pt for lv, _, pt in pools
                         if (extreme >= lv if side < 0 else extreme <= lv))
        reasons = [f"{label} swept to {extreme:.5f} and price closed back "
                   f"{'below' if side < 0 else 'above'} it"]
        reasons += [f"the same wick also took {lab}" for lab in taken if lab != label]
        # 3. displacement FVG after the sweep bar ---------------------
        after = m5[si:si + 8]
        gaps = _all_fvgs(after, side, lookback=len(after), min_height=0.15 * atr)
        if not gaps:
            s.blockers.append(f"{label} swept but no displacement FVG yet — "
                              f"a sweep without displacement is just a wick")
            continue
        g = gaps[-1]
        score += 20
        reasons.append(f"displacement left a {'bearish' if side < 0 else 'bullish'} "
                       f"FVG {g['bottom']:.5f}–{g['top']:.5f} on M5")
        # 4. HTF confluence ------------------------------------------
        lo, hi = (min(level, extreme) - 0.5 * atr, max(level, extreme) + 0.5 * atr)
        for name, bars_, pts in (("H1", h1, 15), ("H4", h4 or [], 10)):
            for z in _all_fvgs(bars_, side, lookback=40):
                if z["bottom"] <= hi and z["top"] >= lo:
                    score += pts
                    reasons.append(f"sweep ran into {name} FVG "
                                   f"{z['bottom']:.5f}–{z['top']:.5f} — HTF imbalance")
                    break
        # 5. stop / target / R ---------------------------------------
        entry = last["close"]
        stop = extreme + 0.15 * atr if side < 0 else extreme - 0.15 * atr
        risk = abs(entry - stop)
        if risk < min_stop:
            s.blockers.append("sweep stop is too tight to be real")
            continue
        before = m5[max(0, si - 80):si]
        lows_b, highs_b = swing_points(before)
        if side < 0:
            cands = sorted([v for _, v in lows_b if v < entry] + [pl] if pl < entry
                           else [v for _, v in lows_b if v < entry], reverse=True)
        else:
            cands = sorted([v for _, v in highs_b if v > entry] + [ph] if ph > entry
                           else [v for _, v in highs_b if v > entry])
        target = None
        for v in cands:                       # nearest pool that PAYS
            if abs(v - entry) / risk >= min_rr:
                target = v
                break
        if target is None:
            s.blockers.append(f"no internal liquidity pays {min_rr:.1f}R from here")
            continue
        rr = abs(target - entry) / risk
        score += 10
        reasons.append(f"objective is the internal liquidity at {target:.5f} — {rr:.1f}R")
        if not _in_kill_zone():
            s.blockers.append("outside London/NY kill zones (SKLZ_G_KILLZONES=0 to lift)")
            continue
        # v3.33: optional confirmation stack (video review) — the sweep must
        # be reacting from a respected HTF FVG and the sweep candles' opens
        # must have been closed through (change in state of delivery).
        if os.environ.get("SKLZ_G_CONFIRM", "0") == "1":
            ok_c, why_c = confirmation_stack(m15 or [], h1, m5, side, si, atr)
            if not ok_c:
                s.blockers.append(f"{label} swept — confirmation stack: {why_c}")
                continue
            score += 10
            reasons.append(why_c)
        reasons.append(f"score {min(score, 100)}/100")
        s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, level, stop
        s.target = target
        s.reasons = reasons
        return s

    if not s.blockers:
        s.blockers.append("no liquidity pool has been swept")
    return s


# ── Confirmation stack (v3.33) ──────────────────────────────────────
# From the "Confirmation Model" clip: a sweep is tradeable only when (2)
# price is reacting FROM a respected M15/H1 fair value gap, (3) the M1/M5
# gap left by the sweep is closed back through (inverse FVG) and (4) a
# candle closes beyond the OPENS of the candle series that delivered the
# sweep — the change in state of delivery. Used by P (mandatory) and by G
# when SKLZ_G_CONFIRM=1. SKLZ_CONFIRM_ENTRY=close|poc picks where the entry
# price comes from (the confirming close, or the sweep leg's volume POC).
def htf_fvg_context(m15: list[dict], h1: list[dict], side: int,
                    zone_lo: float, zone_hi: float) -> tuple[bool, str]:
    """Is the sweep zone sitting inside an M15/H1 FVG in OUR direction that
    has not been closed through (respected)? side=+1 wants a bullish gap."""
    for name, bars_ in (("H1", h1), ("M15", m15)):
        for z in _all_fvgs(bars_, side, lookback=60):
            if z["bottom"] <= zone_hi and z["top"] >= zone_lo:
                # respected: no close beyond the far edge since it formed
                after = bars_[z["index"] + 1:]
                cut = any((b["close"] < z["bottom"]) if side > 0 else (b["close"] > z["top"])
                          for b in after)
                if not cut:
                    return True, f"reacting from a respected {name} FVG {z['bottom']:.5f}-{z['top']:.5f}"
                return False, f"{name} FVG at the sweep was cut through, not respected"
    return False, "sweep is not reacting from an M15/H1 fair value gap"


def cisd(bars: list[dict], sweep_idx: int, side: int) -> tuple[bool, float, str]:
    """Change in state of delivery. side=+1 (after a LOW sweep): find the
    run of down-close candles ending at the sweep bar, take the HIGHEST
    open of that run; a later candle must CLOSE above it. Returns
    (ok, level, why)."""
    if sweep_idx <= 0 or sweep_idx >= len(bars):
        return False, 0.0, "no sweep bar"
    i = sweep_idx
    run = []
    while i >= 0 and ((bars[i]["close"] < bars[i]["open"]) if side > 0 else (bars[i]["close"] > bars[i]["open"])):
        run.append(bars[i]); i -= 1
    if not run:
        # the sweep bar itself closed against the sweep — use its open
        run = [bars[sweep_idx]]
    lvl = max(b["open"] for b in run) if side > 0 else min(b["open"] for b in run)
    for b in bars[sweep_idx + 1:]:
        if (b["close"] > lvl) if side > 0 else (b["close"] < lvl):
            return True, lvl, f"CISD: closed {'above' if side > 0 else 'below'} the sweep series' opens at {lvl:.5f}"
    return False, lvl, f"waiting for a close {'above' if side > 0 else 'below'} {lvl:.5f} (CISD)"


def inverse_fvg(bars: list[dict], sweep_idx: int, side: int,
                min_height: float = 0.0) -> tuple[bool, str]:
    """side=+1: the move INTO the low left a bearish gap; price has since
    closed back ABOVE it (the gap failed = inverse FVG)."""
    lo = max(2, sweep_idx - 6)
    seg = bars[lo:sweep_idx + 1]
    gaps = _all_fvgs(seg, -side, lookback=len(seg), min_height=min_height)
    if not gaps:
        return False, "no gap on the move into the sweep to invert"
    g = gaps[-1]
    for b in bars[sweep_idx + 1:]:
        if (b["close"] > g["top"]) if side > 0 else (b["close"] < g["bottom"]):
            return True, f"inverse FVG: closed back through the gap {g['bottom']:.5f}-{g['top']:.5f}"
    return False, f"gap {g['bottom']:.5f}-{g['top']:.5f} not yet closed through"


def confirmation_stack(m15: list[dict], h1: list[dict], ltf: list[dict], side: int,
                       sweep_idx: int, atr: float) -> tuple[bool, str]:
    """All of: HTF FVG context, inverse FVG, CISD. Returns (ok, why)."""
    if sweep_idx < 0 or sweep_idx >= len(ltf):
        return False, "no sweep bar"
    sw = ltf[sweep_idx]
    ok1, why1 = htf_fvg_context(m15, h1, side, sw["low"] - 0.3 * atr, sw["high"] + 0.3 * atr)
    if not ok1:
        return False, why1
    ok2, why2 = inverse_fvg(ltf, sweep_idx, side)
    if not ok2:
        return False, why2
    ok3, _, why3 = cisd(ltf, sweep_idx, side)
    if not ok3:
        return False, why3
    return True, f"{why1}; {why2}; {why3}"


def confirm_entry_price(ltf: list[dict], sweep_idx: int, side: int) -> float:
    """SKLZ_CONFIRM_ENTRY=poc returns the sweep leg's volume POC (a limit-
    style retrace entry); anything else returns the last close."""
    if os.environ.get("SKLZ_CONFIRM_ENTRY", "close").strip().lower() == "poc":
        leg = ltf[max(0, sweep_idx - 6):sweep_idx + 1]
        poc = _poc(leg) if leg else 0.0
        if poc > 0:
            return poc
    return ltf[-1]["close"]


# ── MODEL P — 8 AM range sweep -> IFVG / CISD reversal (v3.33) ─────
# Video 2 of the review: the 08:00 America/New_York H1 candle is the
# range; a key H1 level must sit just beyond the swept edge; the sweep
# must reach it; the M1 reversal signature is the confirmation stack;
# target is the OPPOSITE edge of the 8 AM range.
def _ny_hour_bounds(now_utc, hour: int = 8) -> tuple[int, int] | None:
    """UTC epoch bounds of today's `hour`:00 America/New_York H1 candle."""
    try:
        from zoneinfo import ZoneInfo
        ny = now_utc.astimezone(ZoneInfo("America/New_York"))
        start = ny.replace(hour=hour, minute=0, second=0, microsecond=0)
        t0 = int(start.timestamp())
        return t0, t0 + 3600
    except Exception:  # noqa: BLE001
        return None


def _p_range_setup(s: Setup, h1, ltf, m15, pip, t0: int, t1: int, win_to: int,
                   now_server: int, label: str, tag: str) -> bool:
    """One P range: the H1 candle [t0, t1) in server time; sweeps are valid
    from t1 until win_to. Fills `s` when complete."""
    rng = [b for b in h1 if t0 <= int(b["time"]) < t1]
    if not rng or int(h1[-1]["time"]) < t1:
        s.blockers.append(f"{label}: range candle not closed yet")
        return False
    if now_server >= win_to:
        s.blockers.append(f"{label}: window closed")
        return False
    rh, rl = max(b["high"] for b in rng), min(b["low"] for b in rng)
    if rh <= rl:
        return False
    atr_h = _atr(h1) or pip
    try:
        key_mult = float(os.environ.get("SKLZ_P_KEY_MAX_ATR", "0.5"))
    except ValueError:
        key_mult = 0.5
    before = [b for b in h1 if int(b["time"]) < t0][-80:]
    lows_h, highs_h = swing_points(before, 2)
    eq_lo = [l for l, _ in _equal_levels(lows_h, 0.2 * atr_h, False)]
    eq_hi = [l for l, _ in _equal_levels(highs_h, 0.2 * atr_h, True)]
    keys_below = sorted({p for _, p in lows_h} | set(eq_lo))
    keys_above = sorted({p for _, p in highs_h} | set(eq_hi))
    ltf_after = [(i, b) for i, b in enumerate(ltf) if b.get("time") and int(b["time"]) >= t1]
    if len(ltf_after) < 5:
        s.blockers.append(f"{label}: waiting for post-range price action")
        return False
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    atr_l = _atr(ltf) or pip
    from basket_engine.learn.levels import min_target_rr
    for side in (1, -1):
        if side > 0:
            keys = [k for k in keys_below if rl - key_mult * atr_h <= k < rl]
            if not keys:
                s.blockers.append(f"{label}: no H1 key level just below the range low {rl:.5f}")
                continue
            key = max(keys)
            swept = [(i, b) for i, b in ltf_after if b["low"] <= key]
            if not swept:
                s.blockers.append(f"{label}: low {rl:.5f} not yet swept into the key level {key:.5f}")
                continue
            si = min(swept, key=lambda x: x[1]["low"])[0]
            ext, opp = ltf[si]["low"], rh
        else:
            keys = [k for k in keys_above if rh < k <= rh + key_mult * atr_h]
            if not keys:
                s.blockers.append(f"{label}: no H1 key level just above the range high {rh:.5f}")
                continue
            key = min(keys)
            swept = [(i, b) for i, b in ltf_after if b["high"] >= key]
            if not swept:
                s.blockers.append(f"{label}: high {rh:.5f} not yet swept into the key level {key:.5f}")
                continue
            si = max(swept, key=lambda x: x[1]["high"])[0]
            ext, opp = ltf[si]["high"], rl
        ok_c, why_c = confirmation_stack(m15, h1, ltf, side, si, atr_l)
        if not ok_c:
            s.blockers.append(f"{label}: {'low' if side > 0 else 'high'} swept — {why_c}")
            continue
        entry = confirm_entry_price(ltf, si, side)
        stop = ext - 0.15 * atr_l if side > 0 else ext + 0.15 * atr_l
        risk = abs(entry - stop)
        if risk < min_stop:
            s.blockers.append(f"{label}: sweep stop is too tight to be real")
            continue
        rr = abs(opp - entry) / risk
        if rr < min_target_rr():
            s.blockers.append(f"{label}: opposite edge {opp:.5f} pays only {rr:.1f}R")
            continue
        s.ok, s.side, s.entry, s.level, s.stop, s.target = True, side, entry, key, stop, opp
        s.tag = tag
        s.model = f"P{'' if tag == 'p' else '_' + tag[2:].upper()}: {label} sweep, IFVG reversal"
        s.reasons = [f"{label} {rl:.5f}-{rh:.5f}; key level {key:.5f} beyond the {'low' if side > 0 else 'high'}",
                     f"swept to {ext:.5f} into the key level", why_c,
                     f"objective: opposite edge {opp:.5f} ({rr:.1f}R)"]
        return True
    return False


def _p_open_setup(s: Setup, h1, m15, m5, ltf, pip, t_open: int, now_server: int) -> bool:
    """P `open` — the Judas swing (8 Oct clip). Window: the first
    SKLZ_P_OPEN_MINS (15) minutes after the open. Bias from unswept
    liquidity (levels.liquidity_bias on M15); the manipulation leg runs
    AGAINST the bias into an M5/M15 FVG and takes the last internal swing
    inside it; entry on the M1 inverse-FVG body close (CISD optional,
    SKLZ_P_OPEN_CISD=0). Stop at the manipulation extreme; target the
    nearest unfilled HTF gap / untested level on the bias side (>= 2R)."""
    try:
        mins = int(os.environ.get("SKLZ_P_OPEN_MINS", "15"))
        min_rr = float(os.environ.get("SKLZ_P_OPEN_MIN_RR", "2.0"))
    except ValueError:
        mins, min_rr = 15, 2.0
    if not (t_open <= now_server < t_open + mins * 60):
        s.blockers.append("open: outside the opening window")
        return False
    from basket_engine.learn import levels as LV
    lb = LV.liquidity_bias(m15[-120:]) if m15 else {"bias": 0}
    bias = lb.get("bias", 0)
    if not bias:
        s.blockers.append("open: no liquidity bias (pools balanced)")
        return False
    side = bias                                   # trade WITH the draw, after the fake-out against it
    after = [(i, b) for i, b in enumerate(ltf) if b.get("time") and int(b["time"]) >= t_open]
    if len(after) < 3:
        s.blockers.append("open: waiting for the opening candles")
        return False
    # manipulation = move against the bias into an HTF (M5/M15) FVG in the bias direction
    atr_l = _atr(ltf) or pip
    gaps = _all_fvgs(m15, side, lookback=40) + _all_fvgs(m5, side, lookback=40)
    if not gaps:
        s.blockers.append("open: no M5/M15 fair value gap for the manipulation to trade into")
        return False
    if side > 0:
        si = min(after, key=lambda x: x[1]["low"])[0]
        ext = ltf[si]["low"]
        hit = [g for g in gaps if g["bottom"] <= ext <= g["top"] + 0.3 * atr_l]
    else:
        si = max(after, key=lambda x: x[1]["high"])[0]
        ext = ltf[si]["high"]
        hit = [g for g in gaps if g["bottom"] - 0.3 * atr_l <= ext <= g["top"]]
    if not hit:
        s.blockers.append(f"open: manipulation to {ext:.5f} has not reached an HTF gap")
        return False
    # it must take the last internal swing inside/near the gap
    pre = [b for b in m5 if b.get("time") and int(b["time"]) < t_open][-30:]
    lows_, highs_ = swing_points(pre, 1)
    internal = [p for _, p in (lows_ if side > 0 else highs_)]
    if internal and not ((ext < min(internal[-2:])) if side > 0 else (ext > max(internal[-2:]))):
        s.blockers.append("open: manipulation has not taken the internal swing — stops still resting")
        return False
    ok_i, why_i = inverse_fvg(ltf, si, side)
    if not ok_i:
        s.blockers.append(f"open: {why_i}")
        return False
    if os.environ.get("SKLZ_P_OPEN_CISD", "0") == "1":
        ok_c, _, why_c = cisd(ltf, si, side)
        if not ok_c:
            s.blockers.append(f"open: {why_c}")
            return False
    entry = ltf[-1]["close"]
    stop = ext - 0.15 * atr_l if side > 0 else ext + 0.15 * atr_l
    risk = abs(entry - stop)
    if risk < _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip:
        s.blockers.append("open: stop at the manipulation extreme is too tight")
        return False
    sl_ = LV.session_levels(m15, now_utc=None) if m15 else {"untested_highs": [], "untested_lows": []}
    ex_lv = [p for p, _ in (sl_["untested_highs"] if side > 0 else sl_["untested_lows"])]
    opp_gaps = _all_fvgs(m15, -side, lookback=60)
    ex_lv += [g["mid"] if "mid" in g else (g["top"] + g["bottom"]) / 2 for g in opp_gaps]
    tgt, why_t = LV.structural_target(m5, side, entry, stop, extra_levels=ex_lv, min_rr=min_rr)
    if tgt is None:
        s.blockers.append(f"open: {why_t}")
        return False
    s.ok, s.side, s.entry, s.level, s.stop, s.target = True, side, entry, ext, stop, tgt
    s.tag, s.model = "p_open", "P_OPEN: Judas swing at the open"
    s.reasons = [f"liquidity bias {'up' if side > 0 else 'down'} (pools above {lb.get('above')} / below {lb.get('below')})",
                 f"manipulation to {ext:.5f} into an HTF gap, internal swing taken",
                 why_i, f"objective {tgt:.5f} ({abs(tgt - entry) / risk:.1f}R)"]
    return True


def model_p(h1: list[dict], m5: list[dict], pip: float, extra=None) -> Setup:
    """P: session-range sweep -> IFVG/CISD reversal.

    SKLZ_P_RANGE_HOURS_NY=8      comma list of NY range hours (7,8 ...)
    SKLZ_P_SESSIONS=ny           ny,london,asia — London range = the 02:00
                                 ET candle (window 03-05), Asia = 20:00 ET
                                 (window 21-00); tags p_ldn / p_asia
    SKLZ_P_OPEN=0                1 adds the Judas-swing open variant (p_open)
    """
    s = Setup(ok=False, model="P: 8AM range sweep, IFVG reversal", tag="p")
    ex = extra or {}
    ltf = ex.get("m1") or m5
    m15 = ex.get("m15") or []
    if len(h1) < 30 or len(ltf) < 30:
        s.blockers.append("not enough history for the range-sweep model")
        return s
    if not h1[-1].get("time"):
        s.blockers.append("bars carry no timestamps — the range candle cannot be found")
        return s
    now = _now_utc(ex)
    off = _server_offset(h1, now)
    now_server = int(now.timestamp()) + off
    try:
        from zoneinfo import ZoneInfo
        ny = now.astimezone(ZoneInfo("America/New_York"))
    except Exception:  # noqa: BLE001
        s.blockers.append("timezone data unavailable")
        return s

    def _ny(h, m=0):
        return int(ny.replace(hour=h, minute=m, second=0, microsecond=0).timestamp()) + off

    plans = []
    sessions = {x.strip().lower() for x in os.environ.get("SKLZ_P_SESSIONS", "ny").split(",") if x.strip()}
    if "ny" in sessions:
        try:
            hours = [int(x) for x in os.environ.get("SKLZ_P_RANGE_HOURS_NY", "8").split(",") if x.strip()]
        except ValueError:
            hours = [8]
        for h in hours:
            tag = "p" if h == 8 else f"p_{h}"
            win_end = _ny(h + 1) + int(os.environ.get("SKLZ_P_NY_WINDOW_H", "3")) * 3600
            plans.append((f"{h:02d}:00 NY range", tag, _ny(h), _ny(h + 1), win_end))
    if "london" in sessions:
        plans.append(("02:00 NY (London) range", "p_ldn", _ny(2), _ny(3), _ny(5)))
    if "asia" in sessions:
        plans.append(("20:00 NY (Asia) range", "p_asia", _ny(20), _ny(21), _ny(23, 59)))
    for label, tag, t0, t1, win_to in plans:
        if _p_range_setup(s, h1, ltf, m15, pip, t0, t1, win_to, now_server, label, tag):
            return s
    if os.environ.get("SKLZ_P_OPEN", "0") == "1":
        if _p_open_setup(s, h1, m15, m5, ltf, pip, _ny(9, 30), now_server):
            return s
    s.tag = "p"
    if not s.blockers:
        s.blockers.append("ranges intact")
    return s


# ── MODEL O — open-candle straddle (v3.33) ─────────────────────────
# Video 1 of the review (YM, M1): at 09:29 NY mark the most recent swing
# high and low (wick extremes); buy-stop above / sell-stop below; a fill
# counts ONLY during the 09:30 candle; fixed SL / TP (3:1); one trade a
# day; the other order is cancelled. This function returns a PLAN, not a
# Setup — the runner's open-watcher places the pending orders.
def model_o_plan(m1: list[dict], pip: float, spread: float = 0.0,
                 extra=None) -> dict:
    """{ok, high, low, sl_dist, tp_dist, why}. `m1` must end with the
    forming 09:29 bar (its extremes count; a break ON it invalidates)."""
    if len(m1) < 20:
        return {"ok": False, "why": "not enough M1 history"}
    try:
        look = int(os.environ.get("SKLZ_O_LOOKBACK", "30"))
        sl_pts = float(os.environ.get("SKLZ_O_SL_PTS", "10"))
        rr = float(os.environ.get("SKLZ_O_RR", "3"))
        spread_mult = float(os.environ.get("SKLZ_O_SL_MIN_SPREADS", "3"))
    except ValueError:
        look, sl_pts, rr, spread_mult = 30, 10.0, 3.0, 3.0
    done = m1[-look - 1:-1]
    forming = m1[-1]
    lows, highs = swing_points(done, 2)
    if not lows or not highs:
        return {"ok": False, "why": "no swing high/low in the lookback"}
    hi, lo = highs[-1][1], lows[-1][1]
    if forming["high"] > hi or forming["low"] < lo:
        return {"ok": False, "why": "the 09:29 candle already broke a level — setup invalid",
                "high": hi, "low": lo}
    sl_dist = max(sl_pts * pip, spread_mult * spread)
    return {"ok": True, "high": hi, "low": lo, "sl_dist": sl_dist,
            "tp_dist": rr * sl_dist,
            "why": f"straddle {lo:.5f} / {hi:.5f}, SL {sl_dist / pip:.0f} pts, TP {rr:g}R"}


# ── Optimized Trend Tracker (v3.34, Model Q) ───────────────────────
# Public formula (Anıl Özekşi): a VAR (variable-index) moving average with
# a percent band and SuperTrend-style flip logic. TOTT = two OTT lines at
# ±coeff around it; the MA crossing above the upper line is the buy
# signal, below the lower line the sell signal.
def _var_ma(closes: list[float], n: int) -> list[float]:
    if not closes:
        return []
    alpha = 2.0 / (n + 1)
    out = [closes[0]]
    ups = [0.0] * len(closes)
    dns = [0.0] * len(closes)
    for i in range(1, len(closes)):
        d = closes[i] - closes[i - 1]
        ups[i] = max(d, 0.0)
        dns[i] = max(-d, 0.0)
    for i in range(1, len(closes)):
        lo = max(0, i - 8)
        vud = sum(ups[lo:i + 1]); vdd = sum(dns[lo:i + 1])
        cmo = abs((vud - vdd) / (vud + vdd)) if (vud + vdd) else 0.0
        out.append(alpha * cmo * closes[i] + (1 - alpha * cmo) * out[-1])
    return out


def ott(closes: list[float], length: int = 14, percent: float = 1.0) -> tuple[list[float], list[float]]:
    """(ma, ott_line) aligned to `closes`."""
    ma = _var_ma(closes, length)
    if not ma:
        return [], []
    long_stop = ma[0] * (1 - percent / 100)
    short_stop = ma[0] * (1 + percent / 100)
    direction = 1
    line = []
    for v in ma:
        fark = v * percent / 100
        ls = v - fark
        ss = v + fark
        ls = max(ls, long_stop) if v > long_stop else ls
        ss = min(ss, short_stop) if v < short_stop else ss
        if direction == -1 and v > short_stop:
            direction = 1
        elif direction == 1 and v < long_stop:
            direction = -1
        long_stop, short_stop = ls, ss
        mt = long_stop if direction == 1 else short_stop
        line.append(mt * (200 + percent) / 200 if v > mt else mt * (200 - percent) / 200)
    return ma, line


def model_q(m30: list[dict], pip: float, extra=None) -> Setup:
    """Q: TOTT band flip (video review, 8 Oct).

    On M30 (SKLZ_Q_TF): the VAR-MA crosses above the upper TOTT line
    (OTT x (1+coeff)) within the last SKLZ_Q_MAX_AGE bars = buy signal;
    RSI(14) > 50; the last closed candle is bullish; close above EMA200
    (SKLZ_Q_EMA, 0 = off); not choppy (<= SKLZ_Q_MAX_FLIPS flips in 20
    bars). Stop below the lower line, target SKLZ_Q_RR x risk. Mirror
    for sells."""
    s = Setup(ok=False, model="Q: TOTT band flip", tag="q")
    try:
        length = int(os.environ.get("SKLZ_Q_PERIOD", "14"))
        pct = float(os.environ.get("SKLZ_Q_PCT", "1.0"))
        coeff = float(os.environ.get("SKLZ_Q_COEFF", "0.1"))
        ema_n = int(os.environ.get("SKLZ_Q_EMA", "200"))
        rr = float(os.environ.get("SKLZ_Q_RR", "1.5"))
        max_age = int(os.environ.get("SKLZ_Q_MAX_AGE", "2"))
        max_flips = int(os.environ.get("SKLZ_Q_MAX_FLIPS", "2"))
    except ValueError:
        length, pct, coeff, ema_n, rr, max_age, max_flips = 14, 1.0, 0.1, 200, 1.5, 2, 2
    need = max(60, ema_n + 10 if ema_n else 60)
    if len(m30) < need:
        s.blockers.append(f"need {need} bars for the TOTT model")
        return s
    closed = m30[:-1]
    closes = [b["close"] for b in closed]
    ma, line = ott(closes, length, pct)
    up = [v * (1 + coeff / 100) for v in line]
    dn = [v * (1 - coeff / 100) for v in line]
    # state per bar: +1 above upper, -1 below lower, else previous
    state = []
    st = 0
    for i in range(len(ma)):
        if ma[i] > up[i]:
            st = 1
        elif ma[i] < dn[i]:
            st = -1
        state.append(st)
    flips = sum(1 for a, b in zip(state[-21:-1], state[-20:]) if a != b and a != 0)
    if flips > max_flips:
        s.blockers.append(f"choppy: {flips} band flips in the last 20 bars")
        return s
    side = state[-1]
    if side == 0:
        s.blockers.append("no band state yet")
        return s
    age = 0
    for k in range(len(state) - 1, 0, -1):
        if state[k - 1] != side:
            break
        age += 1
    if age > max_age:
        s.blockers.append(f"band flipped {age} bars ago — signal too old (SKLZ_Q_MAX_AGE)")
        return s
    r = rsi(closes, 14)[-1]
    if (side > 0 and r <= 50) or (side < 0 and r >= 50):
        s.blockers.append(f"RSI {r:.0f} does not agree with the {'buy' if side > 0 else 'sell'} signal")
        return s
    last = closed[-1]
    if (side > 0 and last["close"] <= last["open"]) or (side < 0 and last["close"] >= last["open"]):
        s.blockers.append("waiting for a full candle close in the signal's direction")
        return s
    if ema_n:
        e = _ema_series(closes, ema_n)[-1]
        if (side > 0 and last["close"] < e) or (side < 0 and last["close"] > e):
            s.blockers.append(f"close on the wrong side of EMA{ema_n} ({e:.5f})")
            return s
    entry = last["close"]
    band = dn[-1] if side > 0 else up[-1]
    stop = band - 2 * pip if side > 0 else band + 2 * pip
    risk = abs(entry - stop)
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    if risk < min_stop:
        s.blockers.append("band stop is too tight to be real")
        return s
    s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, band, stop
    s.target = entry + side * rr * risk
    s.reasons = [f"TOTT({length},{pct:g}%) flipped {'bullish' if side > 0 else 'bearish'} {age} bar(s) ago",
                 f"RSI(14) {r:.0f} agrees; candle closed in direction" + (f"; EMA{ema_n} agrees" if ema_n else ""),
                 f"stop beyond the band {band:.5f}, objective {s.target:.5f} ({rr:g}R)"]
    return s


# ── MODEL X — the fake structure shift ──────────────────────────────
# Gold repeats one sequence: a low, a break of structure up, then price
# trades BELOW that low (often closes below it) and everyone sells the
# "bearish shift". If the sweep landed on a strong level — the wick between
# a big bull candle and the bear candle after it, or the 50% of an
# imbalance — and price closes back above the low, the shift was a trap.
# Entry at the 50% of the displacement leg, stop under the sweep, target
# the high the sequence started from, at SKLZ_X_MIN_RR (default 2.0).
# Stands aside when the MAJOR low was taken or the sweep reacted off
# nothing — those shifts may be real. Mirrored for shorts.
def _x_swing_lows(c: list[dict], k: int = 2) -> list:
    return [(i, c[i]["low"]) for i in range(k, len(c) - k)
            if all(c[i]["low"] < c[j]["low"] for j in range(i - k, i + k + 1) if j != i)]


def _x_swing_highs(c: list[dict], k: int = 2) -> list:
    return [(i, c[i]["high"]) for i in range(k, len(c) - k)
            if all(c[i]["high"] > c[j]["high"] for j in range(i - k, i + k + 1) if j != i)]


def _x_wick_levels(c: list[dict], atr: float, bullish: bool) -> list:
    """Boundary between a big bull candle and the bear candle after it (long
    setup): the wick where the trapped traders sit. Mirrored for shorts."""
    out = []
    for i in range(1, len(c)):
        a, b = c[i - 1], c[i]
        big = abs(a["close"] - a["open"]) >= 0.8 * atr
        if bullish and big and a["close"] > a["open"] and b["close"] < b["open"]:
            out.append(min(a["close"], b["open"]))
        elif not bullish and big and a["close"] < a["open"] and b["close"] > b["open"]:
            out.append(max(a["close"], b["open"]))
    return out


def _x_imbalance_mids(c: list[dict], bullish: bool) -> list:
    out = []
    for i in range(2, len(c)):
        a, b = c[i - 2], c[i]
        if bullish and b["low"] > a["high"]:
            out.append((a["high"] + b["low"]) / 2)
        elif not bullish and a["low"] > b["high"]:
            out.append((a["low"] + b["high"]) / 2)
    return out


def _x_side(c: list[dict], htf: list[dict], atr: float, sign: int,
            min_rr: float):
    """One direction. Returns Setup (ok), ("blocked", why) or None (no sequence)."""
    n = len(c)
    up = sign > 0
    sgn = 1 if up else -1
    lows = _x_swing_lows(c) if up else [(i, -v) for i, v in _x_swing_highs(c)]
    highs = _x_swing_highs(c) if up else [(i, -v) for i, v in _x_swing_lows(c)]
    seq = None
    for li, lv in lows:
        prior = [v for i, v in highs if i < li]
        later = [(i, v) for i, v in highs if i > li]
        if not prior or not later:
            continue
        hi_i, hi_v = later[0]
        if hi_v <= max(prior):
            continue                                    # no break of structure
        for si in range(max(hi_i + 1, n - 15), n):      # the sweep must be recent
            b = c[si]
            ext = (b["low"] if up else b["high"]) * sgn
            if ext < lv:
                seq = (li, lv, hi_i, hi_v, si, ext, b["close"] * sgn < lv)
                break
        if seq:
            break
    if not seq:
        return None
    li, lv, hi_i, hi_v, si, sweep_ext, closed_below = seq
    earlier = [v for i, v in lows if i < li]
    if earlier and sweep_ext < min(earlier[-3:]):
        return None                                     # MAJOR low taken — real shift
    reasons = [f"low {abs(lv):.5f} → break of structure at {abs(hi_v):.5f}, "
               f"then swept to {abs(sweep_ext):.5f}"
               + (" — and CLOSED below it (the trap everyone sells)" if closed_below else "")]
    score = 25
    # reaction off a strong level
    tol = 0.35 * atr
    src = htf or c
    hit = None
    for lvl in _x_wick_levels(src, atr, up):
        if abs(lvl * sgn - sweep_ext) <= tol:
            hit = ("wick level (bull candle → bear candle)", lvl); break
    if hit is None:
        for mid in _x_imbalance_mids(src, up):
            if abs(mid * sgn - sweep_ext) <= tol:
                hit = ("50% of an imbalance", mid); break
    if hit is None:
        return ("blocked", f"sweep at {abs(sweep_ext):.5f} reacted off nothing — no wick "
                           f"level or imbalance midpoint within {tol:.5f}; that shift may be real")
    score += 25
    reasons.append(f"the sweep reacted off a {hit[0]} at {hit[1]:.5f}")
    # valid BOS: close back through the swept low
    rec = None
    for ri in range(si + 1, min(n, si + 7)):
        if c[ri]["close"] * sgn > lv:
            rec = ri; break
    if rec is None:
        return ("blocked", "swept but not reclaimed yet — no close back "
                           f"{'above' if up else 'below'} {abs(lv):.5f}")
    score += 25
    reasons.append(f"closed back {'above' if up else 'below'} {abs(lv):.5f} at "
                   f"{c[rec]['close']:.5f} — the VALID break of structure; trend unchanged")
    # entry at the 50% of the displacement leg
    leg_hi = max((b["high"] if up else b["low"]) * sgn for b in c[si:rec + 1])
    mid = (sweep_ext + leg_hi) / 2
    last = c[-1]
    lo_, hi_ = sorted((last["low"] * sgn, last["high"] * sgn))
    if not (abs(last["close"] * sgn - mid) <= 0.6 * atr or lo_ <= mid <= hi_):
        return ("blocked", f"waiting for the retracement into the 50% of the leg at {mid * sgn:.5f}")
    entry = last["close"]
    stop = (sweep_ext - 0.15 * atr) * sgn
    tp = hi_v * sgn
    risk = abs(entry - stop)
    if risk <= 0:
        return None
    rr = abs(tp - entry) / risk
    if rr < min_rr:
        return ("blocked", f"the high at {tp:.5f} pays only {rr:.1f}R from the 50% — stood aside")
    score += 15
    reasons.append(f"entry at the 50% of the leg ({mid * sgn:.5f}); stop under the sweep; "
                   f"objective the high at {tp:.5f} — {rr:.1f}R")
    reasons.append(f"score {min(score, 100)}/100")
    return Setup(ok=True, model="X: fake structure shift", side=sign, entry=entry,
                 level=abs(lv), stop=stop, reasons=reasons)


def model_x(m5: list[dict], h1: list[dict] | None, pip: float) -> Setup:
    """Fake structure shift on M5; H1 supplies the wick levels / imbalances
    when present, else M5 does. Both directions tried; the first that fires
    wins, the nearest blocker is kept when nothing does."""
    s = Setup(ok=False, model="X: fake structure shift")
    if len(m5) < 30:
        s.blockers.append("not enough M5 bars for the sequence")
        return s
    c = m5[-120:]
    atr = _atr(c) or pip
    min_rr = float(os.environ.get("SKLZ_X_MIN_RR", "2.0"))
    min_stop = float(os.environ.get("SKLZ_MIN_STOP_PIPS", "0")) * pip
    for sign in (1, -1):
        r = _x_side(c, h1 or [], atr, sign, min_rr)
        if isinstance(r, Setup):
            if abs(r.entry - r.stop) < min_stop:
                s.blockers.append("sweep stop is too tight to be real")
                continue
            return r
        if isinstance(r, tuple):
            s.blockers.append(r[1])
    if not s.blockers:
        s.blockers.append("no low → BOS → sweep sequence on M5")
    return s


# ── shared helpers for the H–N batch ────────────────────────────────
def _sma_last(vals: list[float], n: int) -> float:
    if len(vals) < n or n <= 0:
        return 0.0
    return sum(vals[-n:]) / n


def _sma_series(vals: list[float], n: int) -> list[float]:
    out, run = [], 0.0
    for i, v in enumerate(vals):
        run += v
        if i >= n:
            run -= vals[i - n]
        out.append(run / n if i >= n - 1 else float("nan"))
    return out


def _ema_series(vals: list[float], n: int) -> list[float]:
    if not vals:
        return []
    k = 2.0 / (n + 1)
    out = [vals[0]]
    for v in vals[1:]:
        out.append(out[-1] + k * (v - out[-1]))
    return out


def _heikin(bars: list[dict]) -> list[dict]:
    """Heikin Ashi candles from plain OHLC."""
    out = []
    for i, b in enumerate(bars):
        c = (b["open"] + b["high"] + b["low"] + b["close"]) / 4
        if i == 0:
            o = (b["open"] + b["close"]) / 2
        else:
            o = (out[-1]["open"] + out[-1]["close"]) / 2
        out.append({"open": o, "close": c, "high": max(b["high"], o, c),
                    "low": min(b["low"], o, c)})
    return out


def _now_utc(extra) -> "datetime":
    from datetime import datetime, timezone
    if extra and extra.get("now") is not None:
        return extra["now"]
    return datetime.now(timezone.utc)


def _server_offset(bars: list[dict], now_utc) -> int:
    """Broker bar times are server-clock epochs. The forming bar opened a
    few minutes ago, so (bar time − real UTC) rounded to the hour is the
    server's offset. 0 when bars carry no time."""
    if not bars or not bars[-1].get("time"):
        return 0
    try:
        diff = int(bars[-1]["time"]) - int(now_utc.timestamp())
    except Exception:  # noqa: BLE001
        return 0
    return int(round(diff / 3600.0)) * 3600


def _window_ok(env: str, default: str, now_utc) -> bool:
    """'7-10' means 07:00–10:00 UTC. '0-24' or 0 lifts the gate."""
    raw = os.environ.get(env, default)
    if raw in ("0", "", "0-24"):
        return True
    try:
        a, b = raw.split("-")
        h = now_utc.hour + now_utc.minute / 60
        return float(a) <= h < float(b)
    except Exception:  # noqa: BLE001
        return True


def _nearest_paying(levels: list[float], entry: float, risk: float,
                    side: int, min_rr: float):
    """The nearest level in the trade direction that pays min_rr, or None."""
    cands = sorted([v for v in levels if (v - entry) * side > 0],
                   key=lambda v: abs(v - entry))
    for v in cands:
        if abs(v - entry) / risk >= min_rr:
            return v
    return None


def _symbol_allowed(extra, env: str, default: str) -> bool:
    raw = os.environ.get(env, default)
    if raw.strip() in ("", "*", "all"):
        return True
    sym = str((extra or {}).get("symbol") or "").upper()
    if not sym:
        return True                       # unknown symbol: do not gate
    return any(sym.startswith(p.strip().upper())
               for p in raw.split(",") if p.strip())


# ── MODEL H — Heikin Ashi flip, London open ─────────────────────────
# Continuation, not reversal: trend ribbon rising, the HA colour flips
# back in the trend's favour with NO wick against it, in the London
# window. Stop under the last opposite-colour run; target the nearest
# swing that pays SKLZ_H_MIN_RR.
def model_h(m15: list[dict], pip: float, extra=None) -> Setup:
    s = Setup(ok=False, model="H: Heikin Ashi flip")
    if len(m15) < 60:
        s.blockers.append("not enough M15 history for the HA flip")
        return s
    if not _window_ok("SKLZ_H_WINDOW", "7-10", _now_utc(extra)):
        s.blockers.append("outside the London window (SKLZ_H_WINDOW=0 to lift)")
        return s
    closes = [b["close"] for b in m15]
    e20, e50 = _ema_series(closes, 20), _ema_series(closes, 50)
    ha = _heikin(m15)
    flip, prev, live = ha[-2], ha[-3], ha[-1]        # flip = last CLOSED candle
    min_rr = float(os.environ.get("SKLZ_H_MIN_RR", "2.0"))
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    lows, highs = swing_points(m15[:-2], 3)
    for side in (1, -1):
        up = side > 0
        trend = (e20[-1] > e50[-1] and e20[-1] > e20[-4] and closes[-1] > e20[-1]) if up \
            else (e20[-1] < e50[-1] and e20[-1] < e20[-4] and closes[-1] < e20[-1])
        if not trend:
            s.blockers.append(f"ribbon not {'rising' if up else 'falling'} — no {'long' if up else 'short'} bias")
            continue
        was_against = (prev["close"] < prev["open"]) if up else (prev["close"] > prev["open"])
        now_with = (flip["close"] > flip["open"]) if up else (flip["close"] < flip["open"])
        still = (live["close"] >= live["open"]) if up else (live["close"] <= live["open"])
        if not (was_against and now_with and still):
            s.blockers.append("no HA colour flip in the trend's favour on the last closed candle")
            continue
        rng = flip["high"] - flip["low"]
        wick = (min(flip["open"], flip["close"]) - flip["low"]) if up \
            else (flip["high"] - max(flip["open"], flip["close"]))
        if rng > 0 and wick > 0.2 * rng:
            s.blockers.append("the flip candle has a wick against the trend — that is chop, not a flip")
            continue
        # stop under the opposite-colour run that just ended (real bars)
        i = len(m15) - 3
        ext = m15[i]["low"] if up else m15[i]["high"]
        while i > 0 and ((ha[i]["close"] < ha[i]["open"]) if up else (ha[i]["close"] > ha[i]["open"])):
            ext = min(ext, m15[i]["low"]) if up else max(ext, m15[i]["high"])
            i -= 1
        entry = closes[-1]
        stop = ext - 2 * pip if up else ext + 2 * pip
        risk = abs(entry - stop)
        if risk < min_stop:
            s.blockers.append("flip stop is too tight to be real")
            continue
        levels = [v for _, v in (highs if up else lows)]
        tgt = _nearest_paying(levels, entry, risk, side, min_rr)
        if tgt is None:
            s.blockers.append(f"no prior swing pays {min_rr:.1f}R from the flip")
            continue
        s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, e20[-1], stop
        s.reasons = [f"EMA20 {'above' if up else 'below'} EMA50 and {'rising' if up else 'falling'} — trend ribbon in favour",
                     f"Heikin Ashi flipped {'green' if up else 'red'} with no wick against it (London window)",
                     f"stop {'under' if up else 'over'} the last {'red' if up else 'green'} run at {ext:.5f}",
                     f"objective the prior swing at {tgt:.5f} — {abs(tgt - entry) / risk:.1f}R"]
        return s
    return s


# ── MODEL J — trend break-retest, nested demand ─────────────────────
# H1: above a rising EMA100 with HH/HL. The last higher high that was
# BROKEN is the zone. Inside it, M5 prints an impulse (>=3 same-colour
# bars); the last opposite bar before it is the demand block. Enter on
# the return into that block; stop under it; target the HTF swing.
def model_j(h1: list[dict], m5: list[dict], pip: float, extra=None) -> Setup:
    s = Setup(ok=False, model="J: trend break-retest, nested demand")
    if len(h1) < 130 or len(m5) < 40:
        s.blockers.append("not enough history for the nested-demand model")
        return s
    closes = [b["close"] for b in h1]
    e100 = _ema_series(closes, 100)
    atr_h = _atr(h1) or pip
    atr_m = _atr(m5) or pip
    min_rr = float(os.environ.get("SKLZ_J_MIN_RR", "1.5"))
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    lows, highs = swing_points(h1[:-1], 3)
    # adjacent bars sharing one extreme are ONE swing, not two
    def _dedupe(pts):
        out = []
        for i, v in pts:
            if out and abs(out[-1][1] - v) < 1e-9 and i - out[-1][0] <= 3:
                continue
            out.append((i, v))
        return out
    lows, highs = _dedupe(lows), _dedupe(highs)
    for side in (1, -1):
        up = side > 0
        if up and not (closes[-1] > e100[-1] and e100[-1] > e100[-10]):
            s.blockers.append("H1 not above a rising EMA100 — no long trend")
            continue
        if not up and not (closes[-1] < e100[-1] and e100[-1] < e100[-10]):
            s.blockers.append("H1 not below a falling EMA100 — no short trend")
            continue
        piv_with = highs if up else lows          # the broken level's kind
        piv_other = lows if up else highs
        if len(piv_with) < 2 or len(piv_other) < 2:
            s.blockers.append("not enough H1 swings to read structure")
            continue
        ok_struct = (piv_with[-1][1] > piv_with[-2][1] and piv_other[-1][1] > piv_other[-2][1]) if up \
            else (piv_with[-1][1] < piv_with[-2][1] and piv_other[-1][1] < piv_other[-2][1])
        if not ok_struct:
            s.blockers.append("H1 structure is not HH/HL (or LH/LL) — no clear trend")
            continue
        # the most recent swing that was BROKEN by a close after it
        zone = None
        for idx, lvl in reversed(piv_with):
            later = h1[idx + 1:]
            if any((b["close"] > lvl) if up else (b["close"] < lvl) for b in later):
                zone = lvl
                break
        if zone is None:
            s.blockers.append("no broken H1 swing to retest")
            continue
        band = 0.25 * atr_h
        last_h1 = h1[-1]
        inside = (last_h1["low"] <= zone + band and last_h1["close"] >= zone - 2 * band) if up \
            else (last_h1["high"] >= zone - band and last_h1["close"] <= zone + 2 * band)
        if not inside:
            s.blockers.append(f"price has not pulled back into the broken level {zone:.5f}")
            continue
        # M5 impulse from the zone, and the demand block before it
        c = m5[-40:]
        n = len(c)
        block = None
        for i in range(n - 4, 1, -1):
            run = []
            j = i
            while j < n and ((c[j]["close"] > c[j]["open"]) if up else (c[j]["close"] < c[j]["open"])):
                run.append(c[j]); j += 1
            if len(run) < 3:
                continue
            span = abs(run[-1]["close"] - run[0]["open"])
            start_in_zone = (abs(run[0]["low"] - zone) <= 2 * band) if up else (abs(run[0]["high"] - zone) <= 2 * band)
            if span >= 1.5 * atr_m and start_in_zone:
                d = c[i - 1]
                opp = (d["close"] < d["open"]) if up else (d["close"] > d["open"])
                if opp:
                    block = (d, i - 1)
                    break
        if block is None:
            s.blockers.append("no M5 impulse out of the zone, so no demand block to buy from")
            continue
        d, di = block
        top, bot = max(d["open"], d["close"]), min(d["open"], d["close"])
        last = c[-1]
        back = (last["low"] <= top and last["close"] >= d["low"]) if up \
            else (last["high"] >= bot and last["close"] <= d["high"])
        if not back or di >= n - 2:
            s.blockers.append(f"waiting for the return into the demand block {bot:.5f}–{top:.5f}")
            continue
        entry = last["close"]
        stop = d["low"] - 2 * pip if up else d["high"] + 2 * pip
        risk = abs(entry - stop)
        if risk < min_stop:
            s.blockers.append("demand-block stop is too tight to be real")
            continue
        # the "previous high" of the video: pivots, plus the current run's
        # extreme (not a pivot yet while price is still near it)
        run_ext = max(b["high"] for b in h1[-30:]) if up else min(b["low"] for b in h1[-30:])
        tgt = _nearest_paying([v for _, v in piv_with] + [run_ext], entry, risk, side, min_rr)
        if tgt is None:
            s.blockers.append(f"no H1 swing pays {min_rr:.1f}R from the block")
            continue
        s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, zone, stop
        s.reasons = [f"H1 {'above rising' if up else 'below falling'} EMA100 with {'HH/HL' if up else 'LH/LL'} structure",
                     f"broken swing {zone:.5f} retested — old {'resistance' if up else 'support'} as {'support' if up else 'resistance'}",
                     f"M5 impulse from the zone; demand block {bot:.5f}–{top:.5f} (the last {'red' if up else 'green'} candle before it)",
                     f"entered on the return into the block; objective the H1 swing at {tgt:.5f} — {abs(tgt - entry) / risk:.1f}R"]
        return s
    return s


# ── MODEL K — 4H sweep-engulf ───────────────────────────────────────
# One closed 4H candle does the whole job: it trades beyond the previous
# candle's extreme (the manipulation) and closes beyond the previous
# candle's body (the engulf). Entry at that close, stop at its extreme.
def model_k(h4: list[dict], m5: list[dict], pip: float, extra=None) -> Setup:
    s = Setup(ok=False, model="K: 4H sweep-engulf")
    if len(h4) < 6 or not m5:
        s.blockers.append("not enough 4H history")
        return s
    sw, pv = h4[-2], h4[-3]                       # last CLOSED candle and the one before
    atr = _atr(h4) or pip
    min_rr = float(os.environ.get("SKLZ_K_MIN_RR", "2.0"))
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    # only in the first 30 minutes after the 4H close, when bar times exist
    t_m5, t_h4 = m5[-1].get("time"), h4[-1].get("time")
    if t_m5 and t_h4 and (int(t_m5) - int(t_h4)) > 30 * 60:
        s.blockers.append("more than 30 minutes since the 4H close — the entry was at the close")
        return s
    lows, highs = swing_points(h4[:-2], 2)
    for side in (1, -1):
        up = side > 0
        swept = sw["low"] < pv["low"] if up else sw["high"] > pv["high"]
        engulf = sw["close"] > max(pv["open"], pv["close"]) if up else sw["close"] < min(pv["open"], pv["close"])
        if not swept:
            s.blockers.append(f"the last 4H candle did not sweep the previous {'low' if up else 'high'}")
            continue
        if not engulf:
            s.blockers.append("swept but did not close beyond the previous 4H body — no engulf")
            continue
        entry = m5[-1]["close"]
        if abs(entry - sw["close"]) > 0.25 * atr:
            s.blockers.append(f"price already {abs(entry - sw['close']):.5f} from the 4H close — not chasing")
            continue
        stop = sw["low"] - 2 * pip if up else sw["high"] + 2 * pip
        risk = abs(entry - stop)
        if risk < min_stop:
            s.blockers.append("4H stop is too tight to be real")
            continue
        tgt = _nearest_paying([v for _, v in (highs if up else lows)], entry, risk, side, min_rr)
        if tgt is None:
            s.blockers.append(f"no prior 4H swing pays {min_rr:.1f}R from here")
            continue
        s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, pv["low"] if up else pv["high"], stop
        s.reasons = [f"4H candle swept the previous {'low' if up else 'high'} {s.level:.5f} to {sw['low'] if up else sw['high']:.5f}",
                     f"and closed at {sw['close']:.5f}, {'above' if up else 'below'} the previous body — the engulf",
                     f"stop at the sweep extreme; objective the 4H swing at {tgt:.5f} — {abs(tgt - entry) / risk:.1f}R"]
        return s
    return s


# ── MODEL L — accumulation-candle sweep, breaker retest ─────────────
# H1 wide-body candle marks the range. The entry frame sweeps one side,
# then breaks the leg that made the sweep: the last candle of that leg
# is the breaker. Enter on the retest of the breaker, stop beyond it.
def model_l(h1: list[dict], entry_bars: list[dict], pip: float, extra=None) -> Setup:
    s = Setup(ok=False, model="L: accumulation sweep, breaker retest")
    if not _symbol_allowed(extra, "SKLZ_L_SYMBOLS", "XAUUSD"):
        s.blockers.append("symbol not in SKLZ_L_SYMBOLS")
        return s
    if len(h1) < 30 or len(entry_bars) < 60:
        s.blockers.append("not enough history for the breaker model")
        return s
    atr_h = _atr(h1) or pip
    acc = None
    for b in reversed(h1[-25:-1]):
        rng = b["high"] - b["low"]
        if rng >= 1.2 * atr_h and abs(b["close"] - b["open"]) >= 0.65 * rng:
            acc = b
            break
    if acc is None:
        s.blockers.append("no H1 accumulation candle (big body, small wicks) in the last day")
        return s
    H, L = acc["high"], acc["low"]
    c = entry_bars[-90:]
    n = len(c)
    rr = float(os.environ.get("SKLZ_L_RR", "2.0"))
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    for side in (-1, 1):
        up = side > 0                               # up = long off the LOW sweep
        lvl = L if up else H
        beyond = [i for i, b in enumerate(c)
                  if ((b["low"] < lvl) if up else (b["high"] > lvl))]
        if not beyond:
            s.blockers.append(f"the {'low' if up else 'high'} {lvl:.5f} of the accumulation candle has not been swept")
            continue
        si = min(beyond, key=lambda i: c[i]["low"] if up else -c[i]["high"])
        # the leg into the sweep: walk back to its start (last opposite pivot)
        j = si
        while j > 0 and ((c[j - 1]["low"] >= c[j]["low"]) if up else (c[j - 1]["high"] <= c[j]["high"])):
            j -= 1
        while j > 0 and ((c[j - 1]["high"] < c[j]["high"]) if up else (c[j - 1]["low"] > c[j]["low"])) and si - j < 30:
            j -= 1
        leg_ext = max(b["high"] for b in c[j:si + 1]) if up else min(b["low"] for b in c[j:si + 1])
        # the break: a close beyond the leg's start extreme AFTER the sweep
        broke = [i for i in range(si + 1, n)
                 if ((c[i]["close"] > leg_ext) if up else (c[i]["close"] < leg_ext))]
        if not broke:
            s.blockers.append(f"swept the {'low' if up else 'high'} but the leg has not been broken — no breaker yet")
            continue
        # the breaker: last candle of the sweep leg coloured WITH the leg
        bk = None
        for i in range(si, j - 1, -1):
            if (c[i]["close"] < c[i]["open"]) if up else (c[i]["close"] > c[i]["open"]):
                bk = c[i]; break
        if bk is None:
            s.blockers.append("no candle to serve as the breaker")
            continue
        top, bot = max(bk["open"], bk["close"]), min(bk["open"], bk["close"])
        last = c[-1]
        back = (last["low"] <= top and last["close"] >= bot - 0.3 * (top - bot + pip)) if up \
            else (last["high"] >= bot and last["close"] <= top + 0.3 * (top - bot + pip))
        if not back:
            s.blockers.append(f"waiting for the retest of the breaker {bot:.5f}–{top:.5f}")
            continue
        entry = last["close"]
        stop = bk["low"] - 2 * pip if up else bk["high"] + 2 * pip
        risk = abs(entry - stop)
        if risk < min_stop:
            s.blockers.append("breaker stop is too tight to be real")
            continue
        tgt = entry + side * rr * risk
        s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, lvl, stop
        s.reasons = [f"H1 accumulation candle {L:.5f}–{H:.5f}; its {'low' if up else 'high'} was swept to {c[si]['low'] if up else c[si]['high']:.5f}",
                     f"the sweep leg then broke ({'above' if up else 'below'} {leg_ext:.5f}) — the leg's last candle is the breaker {bot:.5f}–{top:.5f}",
                     f"entered on the retest of the breaker; stop beyond it; objective {tgt:.5f} — {rr:.1f}R"]
        return s
    return s


# ── MODEL M — day-box breakout, 1B pullback ─────────────────────────
# The day's range up to the US open is the box. An M10 CLOSE outside it
# locks the direction. The entry is the pullback: an M2 bar piercing the
# 1B — Bollinger(4, 4, source=open) — against the break. Stop at the
# European-session extreme, not the candle.
def _model_m_day(m10: list[dict], m2: list[dict], pip: float, extra=None) -> Setup:
    s = Setup(ok=False, model="M: day-box breakout, 1B pullback")
    if len(m10) < 60 or len(m2) < 30:
        s.blockers.append("not enough M10/M2 history for the box model")
        return s
    if not all(b.get("time") for b in (m10[-1], m2[-1])):
        s.blockers.append("bars carry no timestamps — the day box cannot be drawn")
        return s
    now = _now_utc(extra)
    if not _window_ok("SKLZ_M_WINDOW", "13.5-15.5", now):
        s.blockers.append("outside the US-open window (SKLZ_M_WINDOW=0 to lift)")
        return s
    off = _server_offset(m10, now)
    day0 = (int(now.timestamp()) + off) // 86400 * 86400          # server midnight
    open_t = day0 + int(13.5 * 3600)                                 # 13:30 UTC in server clock
    eu0 = day0 + 7 * 3600
    box = [b for b in m10 if day0 <= int(b["time"]) < open_t]
    if len(box) < 6:
        s.blockers.append("not enough of today's session to draw the box")
        return s
    bh, bl = max(b["high"] for b in box), min(b["low"] for b in box)
    eu = [b for b in m10 if eu0 <= int(b["time"]) < open_t] or box
    eu_h, eu_l = max(b["high"] for b in eu), min(b["low"] for b in eu)
    # the first CLOSED M10 bar after the open that closes outside the box
    brk = None
    for b in m10[:-1]:
        if int(b["time"]) < open_t:
            continue
        if b["close"] > bh:
            brk = (1, b); break
        if b["close"] < bl:
            brk = (-1, b); break
    if brk is None:
        s.blockers.append(f"no M10 close outside today's box {bl:.5f}–{bh:.5f} yet")
        return s
    side, bb = brk
    up = side > 0
    rr = float(os.environ.get("SKLZ_M_RR", "2.0"))
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    opens = [b["open"] for b in m2[-4:]]
    mid = sum(opens) / 4
    sd = (sum((o - mid) ** 2 for o in opens) / 4) ** 0.5
    upper, lower = mid + 4 * sd, mid - 4 * sd
    last = m2[-1]
    if int(last["time"]) <= int(bb["time"]):
        s.blockers.append("the M2 bars have not caught up with the break yet")
        return s
    pierced = (last["low"] <= lower) if up else (last["high"] >= upper)
    if not pierced or sd <= 0:
        s.blockers.append(f"box broke {'up' if up else 'down'} — waiting for the pullback to pierce the 1B")
        return s
    entry = last["close"]
    stop = eu_l - 2 * pip if up else eu_h + 2 * pip
    risk = abs(entry - stop)
    if risk < min_stop:
        s.blockers.append("session-extreme stop is too tight to be real")
        return s
    if (entry <= stop) if up else (entry >= stop):
        s.blockers.append("price is already beyond the session extreme — the stop makes no sense")
        return s
    tgt = entry + side * rr * risk
    s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, bh if up else bl, stop
    s.target = tgt
    s.reasons = [f"day box {bl:.5f}–{bh:.5f}; M10 closed {'above' if up else 'below'} it at {bb['close']:.5f} — breakout confirmed",
                 f"M2 pulled back and pierced the {'lower' if up else 'upper'} 1B (BB 4/4/open) — the entry",
                 f"stop at the European-session {'low' if up else 'high'} {eu_l if up else eu_h:.5f}; objective {tgt:.5f} — {rr:.1f}R"]
    return s


def _model_m_orb(m5: list[dict], pip: float, extra=None, box: str = "orb") -> Setup:
    """M `orb` / `london` boxes (video review).

    orb    : the first SKLZ_M_ORB_MINS (15) minutes after the NY cash open
             (09:30 America/New_York). Break = an M5 bar CLOSES outside the
             box AND the move leaves an FVG through the edge (a wick or a
             bare close is not a breakout). Entry on the retrace into that
             FVG (SKLZ_M_PULLBACK=fvg) or at market on the break (=none).
    london : the 04:00-09:00 NY box; entries only after 09:30, break on
             touch (pullback none) by default, no entry after 11:00 NY.
    Stop: SKLZ_M_STOP=fvg|range|candle (default fvg for orb, candle for
    london). Target SKLZ_M_RR x risk (default 2), capped at one box height
    for orb. One trade per box per day.
    """
    tag = {"orb": "m_orb", "london": "m_lon", "pre8": "m_pre8"}.get(box, "m_lon")
    s = Setup(ok=False, model=f"M_{tag[2:].upper()}: opening-range breakout", tag=tag)
    if len(m5) < 40 or not m5[-1].get("time"):
        s.blockers.append("not enough timestamped M5 history for the box")
        return s
    now = _now_utc(extra)
    try:
        from zoneinfo import ZoneInfo
        ny = now.astimezone(ZoneInfo("America/New_York"))
    except Exception:  # noqa: BLE001
        s.blockers.append("timezone data unavailable")
        return s
    off = _server_offset(m5, now)
    def _ny(h, m=0):
        return int(ny.replace(hour=h, minute=m, second=0, microsecond=0).timestamp()) + off
    if box == "orb":
        try:
            mins = int(os.environ.get("SKLZ_M_ORB_MINS", "15"))
        except ValueError:
            mins = 15
        b0, b1 = _ny(9, 30), _ny(9, 30) + mins * 60
        entry_from, entry_to = b1, _ny(12, 0)
        pull = os.environ.get("SKLZ_M_PULLBACK", "fvg").strip().lower()
        stop_mode = os.environ.get("SKLZ_M_STOP", "fvg").strip().lower()
    elif box == "pre8":
        # the 08:00-08:15 ET M15 candle; break-retest after the 09:30 open
        b0, b1 = _ny(8, 0), _ny(8, 15)
        entry_from, entry_to = _ny(9, 30), _ny(11, 30)
        pull = os.environ.get("SKLZ_M_PRE8_PULLBACK", "retest").strip().lower()
        stop_mode = os.environ.get("SKLZ_M_PRE8_STOP", "range").strip().lower()
    else:
        b0, b1 = _ny(4, 0), _ny(9, 0)
        entry_from, entry_to = _ny(9, 30), _ny(11, 0)
        pull = os.environ.get("SKLZ_M_LON_PULLBACK", "none").strip().lower()
        stop_mode = os.environ.get("SKLZ_M_LON_STOP", "candle").strip().lower()
    tnow = int(now.timestamp()) + off
    if tnow < entry_from:
        s.blockers.append(f"{box} box: before the entry window")
        return s
    if tnow >= entry_to:
        s.blockers.append(f"{box} box: entry window closed for today")
        return s
    bars_box = [b for b in m5 if b0 <= int(b["time"]) < b1]
    if not bars_box:
        s.blockers.append(f"{box} box: no bars in the box window")
        return s
    bh, bl = max(b["high"] for b in bars_box), min(b["low"] for b in bars_box)
    height = bh - bl
    if height <= 0:
        return s
    after = [b for b in m5 if int(b["time"]) >= entry_from]
    done = after[:-1]                               # completed bars only
    brk = None
    for i, b in enumerate(done):
        if b["close"] > bh:
            brk = (1, i); break
        if b["close"] < bl:
            brk = (-1, i); break
    if brk is None:
        # london mode may enter on the TOUCH of the forming bar
        if pull == "none" and after:
            f = after[-1]
            if f["high"] > bh:
                brk = (1, len(done))
            elif f["low"] < bl:
                brk = (-1, len(done))
        if brk is None:
            s.blockers.append(f"{box} box {bl:.5f}-{bh:.5f} intact — no break yet")
            return s
    side, bi = brk
    up = side > 0
    if box == "orb":
        # v3.34 (gold ORB clip): HTF bias gate and a BOS requirement
        h4 = (extra or {}).get("h4") or []
        if os.environ.get("SKLZ_M_ORB_BIAS", "1") != "0" and len(h4) >= 4:
            closed4 = h4[:-1]
            ups = sum(1 for b in closed4[-3:] if b["close"] > b["open"])
            bias = 1 if ups >= 2 else -1
            if bias != side:
                s.blockers.append(f"orb: box broke {'up' if up else 'down'} against the 4H bias — no trade")
                return s
        if os.environ.get("SKLZ_M_ORB_NEED_BOS", "1") != "0" and bi < len(done):
            pre = [b for b in m5 if int(b["time"]) < entry_from][-30:]
            lows_, highs_ = swing_points(pre, 2)
            ref = [p for _, p in (highs_ if up else lows_)]
            if ref:
                sw = max(ref[-2:]) if up else min(ref[-2:])
                if (done[bi]["close"] <= sw) if up else (done[bi]["close"] >= sw):
                    s.blockers.append(f"orb: break candle has not closed beyond the recent swing {sw:.5f} (SKLZ_M_ORB_NEED_BOS)")
                    return s
    try:
        rr = float(os.environ.get("SKLZ_M_RR", "2.0"))
    except ValueError:
        rr = 2.0
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    min_gap = _min_pips("SKLZ_MIN_FVG_PIPS", 3.0) * pip
    last = m5[-1]
    fvg = None
    if pull == "fvg" or stop_mode == "fvg":
        seg = after[max(0, bi - 2):bi + 3]
        gaps = _all_fvgs(seg, side, lookback=len(seg), min_height=min_gap)
        # the gap must straddle or sit beyond the box edge — the break itself
        gaps = [g for g in gaps if (g["top"] >= bh if up else g["bottom"] <= bl)]
        fvg = gaps[-1] if gaps else None
    if pull == "retest":
        edge = bh if up else bl
        tol_r = max(3 * pip, 0.15 * (_atr(m5[-40:]) or pip))
        back = ([b for b in after[bi + 1:-1] if b["low"] <= edge + tol_r] if up
                else [b for b in after[bi + 1:-1] if b["high"] >= edge - tol_r])
        if not back:
            s.blockers.append(f"{box} box broke; waiting for the retest of {edge:.5f}")
            return s
        if (last["close"] <= edge) if up else (last["close"] >= edge):
            s.blockers.append(f"{box} box: retest of {edge:.5f} not holding the break side")
            return s
        entry = last["close"]
    elif pull == "fvg":
        if fvg is None:
            s.blockers.append(f"{box} box broke {'up' if up else 'down'} but left no FVG through the edge — not a real breakout yet")
            return s
        in_gap = ((last["low"] <= fvg["top"] and last["close"] >= fvg["bottom"]) if up
                  else (last["high"] >= fvg["bottom"] and last["close"] <= fvg["top"]))
        if not in_gap:
            s.blockers.append(f"{box} box broke; waiting for the retrace into the FVG {fvg['bottom']:.5f}-{fvg['top']:.5f}")
            return s
        entry = last["close"]
    else:
        entry = last["close"] if bi < len(done) else (bh if up else bl)
    if stop_mode == "fvg" and fvg is not None:
        stop = (fvg["bottom"] - 2 * pip) if up else (fvg["top"] + 2 * pip)
    elif stop_mode == "candle":
        bb = after[bi]
        stop = (bb["low"] - 2 * pip) if up else (bb["high"] + 2 * pip)
    else:
        stop = (bl - 2 * pip) if up else (bh + 2 * pip)
    risk = abs(entry - stop)
    if risk < min_stop:
        stop = entry - side * min_stop
        risk = min_stop
    tgt = entry + side * rr * risk
    if box == "orb":
        if os.environ.get("SKLZ_M_ORB_TARGET", "liquidity").strip().lower() == "liquidity":
            try:
                from basket_engine.learn.levels import structural_target, session_levels
                sl_ = session_levels(m5, now_utc=now)
                ex_lv = [p for p, _ in (sl_["untested_highs"] if up else sl_["untested_lows"])]
                t2, _ = structural_target(m5, side, entry, stop, extra_levels=ex_lv, min_rr=1.0)
                if t2:
                    tgt = t2
            except Exception:  # noqa: BLE001
                pass
        else:
            cap = entry + side * height
            tgt = min(tgt, cap) if up else max(tgt, cap)
        if abs(tgt - entry) / risk < 1.0:
            s.blockers.append("orb: nothing to aim at within 1R — box too small / no liquidity")
            return s
    s.ok, s.side, s.entry, s.level, s.stop, s.target = True, side, entry, bh if up else bl, stop, tgt
    s.reasons = [f"{box} box {bl:.5f}-{bh:.5f}; broke {'up' if up else 'down'}"
                 + (f" with FVG {fvg['bottom']:.5f}-{fvg['top']:.5f}" if fvg else ""),
                 f"entry {entry:.5f}, stop {stop:.5f} ({stop_mode}), objective {tgt:.5f} — {abs(tgt - entry) / risk:.1f}R"]
    return s


def _model_m_asia(h1: list[dict], pip: float, extra=None) -> Setup:
    """M `asia` box — the snapback entry (8 Oct clip).

    Box = the H1 candle opening at SKLZ_M_ASIA_OPEN_UTC (23). Break candle
    = first H1 close outside. Snapback = a later H1 bar that touches the
    box edge and closes back outside in the break direction -> entry on
    that close. Stop = SKLZ_M_ASIA_STOP_BOXES (2) box heights from the
    edge. Target: measured move (prior range height from the pullback
    point) or 2R, whichever is nearer; min SKLZ_MIN_TARGET_RR. Valid
    until the next box forms; one trade per day."""
    s = Setup(ok=False, model="M_ASIA: opening-box snapback", tag="m_asia")
    if len(h1) < 30 or not h1[-1].get("time"):
        s.blockers.append("asia box: not enough timestamped H1 history")
        return s
    now = _now_utc(extra)
    off = _server_offset(h1, now)
    try:
        open_h = int(os.environ.get("SKLZ_M_ASIA_OPEN_UTC", "23"))
        boxes = float(os.environ.get("SKLZ_M_ASIA_STOP_BOXES", "2"))
    except ValueError:
        open_h, boxes = 23, 2.0
    tnow = int(now.timestamp()) + off
    day0 = tnow // 86400 * 86400
    t_open = day0 + open_h * 3600
    if t_open > tnow:
        t_open -= 86400                         # the box that opened yesterday evening
    bars = [b for b in h1 if int(b["time"]) >= t_open]
    if len(bars) < 3:
        s.blockers.append("asia box: box candle not closed yet")
        return s
    box = bars[0]
    bh, bl = box["high"], box["low"]
    height = bh - bl
    if height <= 0:
        return s
    done = bars[1:-1]
    brk = None
    for i, b in enumerate(done):
        if b["close"] > bh:
            brk = (1, i); break
        if b["close"] < bl:
            brk = (-1, i); break
    if brk is None:
        s.blockers.append(f"asia box {bl:.5f}-{bh:.5f} intact — no H1 break candle yet")
        return s
    side, bi = brk
    up = side > 0
    edge = bh if up else bl
    # a close beyond the opposite edge after the break = setup broken
    if any((b["close"] < bl) if up else (b["close"] > bh) for b in done[bi + 1:]):
        s.blockers.append("asia box: price closed through the far side after the break — setup broken")
        return s
    touched = [i for i, b in enumerate(done[bi + 1:], bi + 1)
               if (b["low"] <= edge if up else b["high"] >= edge)]
    if not touched:
        s.blockers.append(f"asia box broke {'up' if up else 'down'}; waiting for the return to {edge:.5f}")
        return s
    last = done[-1]
    snap = (last["low"] <= edge and last["close"] > bh) if up else (last["high"] >= edge and last["close"] < bl)
    if not snap:
        # the snapback may be the bar AFTER the touch
        snap = touched[-1] < len(done) - 1 and ((last["close"] > bh) if up else (last["close"] < bl))
    if not snap:
        s.blockers.append(f"asia box: returned to {edge:.5f}; waiting for the snapback close outside")
        return s
    entry = last["close"]
    stop = edge - side * boxes * height
    risk = abs(entry - stop)
    if risk <= 0:
        return s
    # measured move: prior range (before the box) height from the pullback point
    prior = [b for b in h1 if int(b["time"]) < t_open][-24:]
    pull_pt = min(b["low"] for b in done[touched[0]:]) if up else max(b["high"] for b in done[touched[0]:])
    measured = pull_pt + side * ((max(b["high"] for b in prior) - min(b["low"] for b in prior)) if prior else 2 * risk)
    two_r = entry + side * 2 * risk
    tgt = min(measured, two_r) if up else max(measured, two_r)
    from basket_engine.learn.levels import min_target_rr
    if abs(tgt - entry) / risk < min_target_rr():
        tgt = two_r
    s.ok, s.side, s.entry, s.level, s.stop, s.target = True, side, entry, edge, stop, tgt
    s.reasons = [f"Asian opening box {bl:.5f}-{bh:.5f}; H1 broke {'up' if up else 'down'}",
                 f"price returned to {edge:.5f} and snapped back out (close {entry:.5f})",
                 f"stop {boxes:g} box heights away at {stop:.5f}; objective {tgt:.5f} ({abs(tgt - entry) / risk:.1f}R)"]
    return s


def model_m(m10: list[dict], m2: list[dict], pip: float, extra=None) -> Setup:
    """SKLZ_M_BOX=day|orb|london, comma list or `all` (default day)."""
    raw = os.environ.get("SKLZ_M_BOX", "day").strip().lower()
    boxes = (["day", "orb", "london", "pre8", "asia"] if raw in ("all", "*")
             else [x.strip() for x in raw.split(",") if x.strip()])
    tried = []
    m5 = (extra or {}).get("m5") or []
    for box in boxes:
        if box == "day":
            r = _model_m_day(m10, m2, pip, extra)
        elif box in ("orb", "london", "pre8"):
            r = _model_m_orb(m5, pip, extra, box)
        elif box == "asia":
            r = _model_m_asia((extra or {}).get("h1") or [], pip, extra)
        else:
            continue
        if r.ok:
            return r
        tried.append(r)
    if not tried:
        return _model_m_day(m10, m2, pip, extra)
    return min(tried, key=lambda x: len(x.blockers))


# ── MODEL N — MA ladder break-retest ────────────────────────────────
# Three long simple MAs are the only levels. Buy the RETEST of a broken
# MA (never the break), target the next MA up the ladder. A twice-failed
# approach is sold back toward the MA below.
def model_n(m5_long: list[dict], pip: float, extra=None) -> Setup:
    s = Setup(ok=False, model="N: MA ladder break-retest")
    if not _symbol_allowed(extra, "SKLZ_N_SYMBOLS", "XAUUSD"):
        s.blockers.append("symbol not in SKLZ_N_SYMBOLS")
        return s
    periods = [int(x) for x in os.environ.get("SKLZ_N_PERIODS", "200,400,600").split(",")]
    need = max(periods) + 40
    if len(m5_long) < need:
        s.blockers.append(f"need {need} M5 bars for the MA ladder")
        return s
    closes = [b["close"] for b in m5_long]
    series = [_sma_series(closes, p) for p in periods]
    lines_now = sorted(v[-1] for v in series)
    atr = _atr(m5_long[-60:]) or pip
    tol = 0.15 * atr
    min_rr = float(os.environ.get("SKLZ_N_MIN_RR", "1.5"))
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    c = m5_long
    n = len(c)
    W = 30
    for side in (1, -1):
        up = side > 0
        for ser in series:
            line = ser[-1]
            # break: a close crossing the line within the window
            bi = None
            for i in range(n - W, n - 1):
                if (c[i - 1]["close"] < ser[i - 1] and c[i]["close"] > ser[i]) if up \
                        else (c[i - 1]["close"] > ser[i - 1] and c[i]["close"] < ser[i]):
                    bi = i
            if bi is not None:
                last = c[-1]
                touched = (last["low"] <= line + tol and last["close"] > line) if up \
                    else (last["high"] >= line - tol and last["close"] < line)
                held = all((b["close"] > ser[k]) if up else (b["close"] < ser[k])
                           for k, b in enumerate(c) if k > bi) and touched
                if held:
                    entry = last["close"]
                    lo = min(b["low"] for b in c[-3:]) if up else max(b["high"] for b in c[-3:])
                    stop = lo - 2 * pip if up else lo + 2 * pip
                    risk = abs(entry - stop)
                    if risk < min_stop:
                        s.blockers.append("retest stop is too tight to be real")
                        continue
                    nxt = _nearest_paying([v for v in lines_now if abs(v - line) > tol], entry, risk, side, min_rr)
                    if nxt is None:
                        s.blockers.append(f"the next MA does not pay {min_rr:.1f}R from the retest")
                        continue
                    s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, line, stop
                    s.reasons = [f"price broke {'above' if up else 'below'} the MA at {line:.5f} and came back to test it",
                                 f"the retest held (close {'above' if up else 'below'} the line) — entry on the retest, never the break",
                                 f"objective the next MA in the ladder at {nxt:.5f} — {abs(nxt - entry) / risk:.1f}R"]
                    return s
            # failed break: two touches from the other side, no close through, then rejection
            touches = [i for i in range(n - W, n - 1)
                       if ((c[i]["high"] >= ser[i] - tol and c[i]["close"] < ser[i]) if not up
                           else (c[i]["low"] <= ser[i] + tol and c[i]["close"] > ser[i]))]
            # NOTE: for a SHORT (not up) the failed break is an approach from BELOW
            if not up and len(touches) >= 2:
                crossed = any(c[i]["close"] > ser[i] for i in range(touches[0], n))
                last = c[-1]
                if not crossed and last["close"] < c[touches[-1]]["low"]:
                    entry = last["close"]
                    stop = line + tol + 2 * pip
                    risk = abs(entry - stop)
                    if risk < min_stop:
                        s.blockers.append("rejection stop is too tight to be real")
                        continue
                    nxt = _nearest_paying([v for v in lines_now if abs(v - line) > tol], entry, risk, -1, min_rr)
                    if nxt is None:
                        s.blockers.append(f"the MA below does not pay {min_rr:.1f}R from the rejection")
                        continue
                    s.ok, s.side, s.entry, s.level, s.stop = True, -1, entry, line, stop
                    s.reasons = [f"price tested the MA at {line:.5f} twice from below and never closed above it",
                                 f"then closed under the last test bar — the break failed",
                                 f"objective the MA below at {nxt:.5f} — {abs(nxt - entry) / risk:.1f}R"]
                    return s
            if up and len(touches) >= 2:
                crossed = any(c[i]["close"] < ser[i] for i in range(touches[0], n))
                last = c[-1]
                if not crossed and last["close"] > c[touches[-1]]["high"]:
                    entry = last["close"]
                    stop = line - tol - 2 * pip
                    risk = abs(entry - stop)
                    if risk < min_stop:
                        s.blockers.append("rejection stop is too tight to be real")
                        continue
                    nxt = _nearest_paying([v for v in lines_now if abs(v - line) > tol], entry, risk, 1, min_rr)
                    if nxt is None:
                        s.blockers.append(f"the MA above does not pay {min_rr:.1f}R from the rejection")
                        continue
                    s.ok, s.side, s.entry, s.level, s.stop = True, 1, entry, line, stop
                    s.reasons = [f"price tested the MA at {line:.5f} twice from above and never closed below it",
                                 f"then closed over the last test bar — the break failed",
                                 f"objective the MA above at {nxt:.5f} — {abs(nxt - entry) / risk:.1f}R"]
                    return s
    if not s.blockers:
        s.blockers.append("no MA break-retest or failed break in the window")
    return s


def _enabled() -> set[str]:
    """Which models may fire. SKLZ_MODELS_ENABLED="a,b,d" runs without C.

    Exists because the V1 backtest showed Model C losing on gold even at
    ZERO spread across 33 trades while firing more than all others combined.
    That is one 3-week window, not a verdict — so this is a switch for the
    owner, not a deletion by the machine. The journal's had_model rows will
    settle it properly.
    """
    raw = os.environ.get("SKLZ_MODELS_ENABLED", "a,b,c,d")
    return {x.strip().lower() for x in raw.split(",") if x.strip()}


ALL_MODELS = ("a", "b", "c", "d", "e", "f", "g", "x", "h", "j", "k", "l", "m", "n", "p", "q")


def evaluate(m15: list[dict], m5: list[dict], h1: list[dict],
             h4: list[dict], pip: float, extra: dict | None = None) -> Setup:
    """Try the enabled models; A first because it needs less to be true.

    `extra` carries what the newer models need beyond the four frames:
    symbol, and the optional M1 / M2 / M10 / long-M5 series the runner
    fetches only when the model that wants them is enabled."""
    en = _enabled()
    off = Setup(ok=False, model="disabled")
    ex = extra or {}
    ex.setdefault("m15", m15)
    ex.setdefault("h1", h1)
    a = model_a(m15, m5, pip, ex) if "a" in en else off
    if a.ok:
        return a
    b = model_b(h4, h1, m5, pip) if "b" in en else off
    if b.ok:
        return b
    cm = model_c(h4, m5, pip, ex) if "c" in en else off
    if cm.ok:
        return cm
    d = model_d(m15, m5, pip) if "d" in en else off
    if d.ok:
        return d
    ex.setdefault("m15", m15)
    ex.setdefault("h1", h1)
    e = model_e(h1, m5, pip, ex) if "e" in en else off
    if e.ok:
        return e
    f = model_f(m15, m5, pip, ex) if "f" in en else off
    if f.ok:
        return f
    g = model_g(h1, m5, pip, m15, h4) if "g" in en else off
    if g.ok:
        return g
    x = model_x(m5, h1, pip) if "x" in en else off
    if x.ok:
        return x
    tried = [a, b, cm, d, e, f, g, x]
    for tag in ("h", "j", "k", "l", "m", "n", "p", "q"):
        if tag not in en:
            continue
        r = call_model(tag, m15, m5, h1, h4, pip, ex)
        if r.ok:
            return r
        tried.append(r)
    # none fired — return whichever got furthest, so the log says why
    return min(tried, key=lambda s: len(s.blockers))


def call_model(tag: str, m15, m5, h1, h4, pip, extra: dict | None = None) -> Setup:
    """One dispatch for every caller (live chain and paper observer), so a
    new model's signature is declared once — G needs H1+H4 for its zones,
    L/M/N need the extra frames the runner fetches on demand."""
    fn = globals().get(f"model_{tag}")
    if fn is None:
        return Setup(ok=False, model=f"{tag.upper()}: unknown")
    ex = extra or {}
    ex.setdefault("m15", m15)
    ex.setdefault("h1", h1)
    if tag == "a":
        return fn(m15, m5, pip, ex)
    if tag == "b":
        return fn(h4, h1, m5, pip)
    if tag == "c":
        return fn(h4, m5, pip, ex)
    if tag == "e":
        return fn(h1, m5, pip, ex)
    if tag == "f":
        return fn(m15, m5, pip, ex)
    if tag == "p":
        return fn(h1, m5, pip, ex)
    if tag == "q":
        return fn(ex.get("m30") or [], pip, ex)
    if tag == "g":
        return fn(h1, m5, pip, m15, h4)
    if tag == "x":
        return fn(m5, h1, pip)
    if tag == "h":
        return fn(m15, pip, ex)
    if tag == "j":
        return fn(h1, m5, pip, ex)
    if tag == "k":
        return fn(h4, m5, pip, ex)
    if tag == "l":
        return fn(h1, ex.get("m1") or m5, pip, ex)
    if tag == "m":
        ex.setdefault("m5", m5)
        ex.setdefault("h4", h4)
        return fn(ex.get("m10") or [], ex.get("m2") or [], pip, ex)
    if tag == "n":
        return fn(ex.get("m5_long") or m5, pip, ex)
    return fn(m15, m5, pip)


# ── universal entry confirmation (v3.33.1) ──────────────────────────
# Owner's rule, applied to EVERY auto entry (models included): a model may
# say "setup", but the ORDER waits for
#   1. an M5 candle whose BODY closes beyond the line (not a wick),
#   2. a retest of that line,
#   3. an M5 engulfing candle in the trade's direction that closes on the
#      right side of the line,
#   4. and the entry must be near the line — never at the extreme of the
#      move (SKLZ_NO_CHASE_ATR, default 1.5 M5-ATR from the line).
# The "line" is whatever the setup is built on: the broken level (A, M),
# the swept level (D, E, G, P, X), the block / gap / POC (B, C, F).
def entry_confirmed(m5_closed: list[dict], level: float, side: int, pip: float,
                    lookback: int = 36) -> tuple[bool, str]:
    if len(m5_closed) < 8 or not level:
        return False, "not enough closed M5 bars to confirm"
    atr = _atr(m5_closed[-40:]) or pip
    tol = max(6 * pip, 0.15 * atr)
    try:
        chase = float(os.environ.get("SKLZ_NO_CHASE_ATR", "1.5"))
    except ValueError:
        chase = 1.5
    win = m5_closed[-lookback:]
    base = len(m5_closed) - len(win)
    # 1. body close beyond the line
    brk = None
    for i, b in enumerate(win):
        body_lo, body_hi = min(b["open"], b["close"]), max(b["open"], b["close"])
        if (side > 0 and body_lo > level) or (side < 0 and body_hi < level):
            brk = i
            break
    if brk is None:
        return False, (f"no M5 candle has BODY-closed {'above' if side > 0 else 'below'} "
                       f"{level:.5f} yet — a wick is not a break")
    # 2. retest after the break
    rt = None
    for i in range(brk + 1, len(win)):
        b = win[i]
        if (side > 0 and b["low"] <= level + tol) or (side < 0 and b["high"] >= level - tol):
            rt = i
    if rt is None:
        return False, (f"body-closed through {level:.5f} but no retest of the line yet — "
                       f"entering here is chasing the move")
    # 3. confirmation candle AFTER the retest: a 5M engulfing in direction
    #    within the last SKLZ_CONFIRM_BARS (3) closed bars, or a close
    #    beyond the retest bar's extreme (the retest high taken out for a
    #    long). Either one, closing on the right side of the line.
    last = win[-1]
    if (side > 0 and last["close"] <= level) or (side < 0 and last["close"] >= level):
        return False, f"retest of {level:.5f} is not holding the break side"
    try:
        nb = max(1, int(os.environ.get("SKLZ_CONFIRM_BARS", "3")))
    except ValueError:
        nb = 3
    confirmed = False
    lo_k = max(rt, len(win) - nb, 1)
    for k in range(len(win) - 1, lo_k - 1, -1):
        if engulfing(win[:k + 1], side)["ok"]:
            confirmed = True
            break
    if not confirmed:
        rb = win[rt]
        if (side > 0 and last["close"] > rb["high"]) or (side < 0 and last["close"] < rb["low"]):
            confirmed = True
    if not confirmed:
        return False, f"retest holding at {level:.5f}; waiting for a 5M engulfing candle (or a close beyond the retest bar) in direction"
    # 4. no chasing the extreme
    dist = abs(last["close"] - level)
    if atr and dist > chase * atr:
        return False, (f"price is {dist / atr:.1f} ATR from the line {level:.5f} — "
                       f"that is the extreme of the move, not the retest (SKLZ_NO_CHASE_ATR={chase:g})")
    return True, (f"M5 body-closed through {level:.5f}, retested it, held, and printed a "
                  f"5M engulfing in direction")


# ── break-entry confirmation for scanner-led entries ────────────────
def break_entry_confirmed(m5: list[dict], level: float, side: int,
                          pip: float) -> tuple[bool, str]:
    """A confirmed break ENTRY needs more than a confirmed break.

    The candle closing beyond the level says the break is real. It does not
    say the entry is: the profitable version waits for price to come BACK to
    the broken level, hold it, and print a 5M engulfing in the break's
    direction. Without that, half of "breakouts" are entered at the far end
    of the move — maximum chase, minimum information — and the sweep that
    closes back through collects the stop.

    Sequence, from the owner's own losing-trade review:
      break (already confirmed upstream) -> retest of the line ->
      hold -> 5M engulfing in direction -> enter.
    """
    if len(m5) < 6:
        return False, "not enough M5 bars to confirm the retest"

    tol = 6 * pip
    recent = m5[-10:]
    if side > 0:
        came_back = any(b["low"] <= level + tol for b in recent)
    else:
        came_back = any(b["high"] >= level - tol for b in recent)
    if not came_back:
        return False, (f"broke {level:.5f} but has not retested it — "
                       f"entering here is chasing the far end of the move")

    last = m5[-1]
    held = last["close"] > level if side > 0 else last["close"] < level
    if not held:
        return False, (f"retested {level:.5f} and is not holding the break "
                       f"side — this is how sweeps look")

    eng = engulfing(m5, side)
    if not eng["ok"]:
        return False, (f"retest holding at {level:.5f}, waiting for a 5M "
                       f"engulfing candle to confirm direction")

    return True, (f"break of {level:.5f} retested, held, and confirmed by a "
                  f"5M engulfing — continuation, not a sweep")
