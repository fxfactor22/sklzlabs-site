"""Entry controller — the THREE streams into the learning journal.

  forced_entry(...)   YOU trigger it from the runner, with a note.
  auto_entry(...)     a scanner triggers it, tagged with the strategy name.

Both snapshot full market state at the instant of entry and journal it.
Both place a real (demo) order through the same IO the basket engine uses.
"""
from __future__ import annotations

import os

from datetime import datetime, timezone

from basket_engine.learn.capture import EntryRecord, Journal, snapshot


def _is_fx(symbol: str) -> bool:
    """A plain currency pair, not a metal, crypto, index or energy contract.

    The distinction matters because a minimum lot size is a reasonable answer
    to "NZDUSD moves too slowly to be worth 0.01 lots" and a bad answer to
    anything whose pip is already worth ten times as much.
    """
    s = (symbol or "").upper()
    for suf in ("..", ".", "m", "c", "r", "_", "#"):
        if s.endswith(suf):
            s = s[: -len(suf)]
    s = s.strip(".")

    NON_FX = ("XAU", "GOLD", "XAG", "SILVER", "XPT", "XPD",
              "BTC", "ETH", "XRP", "LTC", "SOL", "DOGE", "ADA", "BNB",
              "US30", "US500", "NAS", "SPX", "GER", "DE40", "UK100",
              "JP225", "AUS200", "USTEC", "IDX",
              "USO", "UKO", "WTI", "BRENT", "OIL", "NGAS")
    if any(s.startswith(x) for x in NON_FX):
        return False

    CCY = {"USD", "EUR", "GBP", "JPY", "AUD", "NZD", "CAD", "CHF",
           "SEK", "NOK", "DKK", "SGD", "HKD", "MXN", "ZAR", "TRY",
           "PLN", "CZK", "HUF", "CNH"}
    return len(s) >= 6 and s[:3] in CCY and s[3:6] in CCY


def lot_ceiling(symbol: str) -> tuple[float, str]:
    """The lot cap that applies to this symbol, and which setting set it.

    SKLZ_MAX_LOTS is the global ceiling. SKLZ_MAX_LOTS_BY_SYMBOL overrides
    it per symbol — "XAUUSD:0.06,XAGUSD:0.06" — because a gold stop is
    hundreds of pips wide and the same lot size carries several times the
    risk of a forex pair. Matching ignores broker suffixes (XAUUSD.c,
    GOLD#, XAUUSDm) by comparing the leading letters. 0 = no cap.
    """
    def _f(v):
        try:
            return float(v or 0)
        except (TypeError, ValueError):
            return 0.0
    sym = (symbol or "").upper()
    raw = os.environ.get("SKLZ_MAX_LOTS_BY_SYMBOL", "")
    best, best_len = 0.0, 0
    for part in raw.split(","):
        if ":" not in part:
            continue
        k, v = part.split(":", 1)
        k = k.strip().upper()
        if k and sym.startswith(k) and len(k) > best_len:
            best, best_len = _f(v.strip()), len(k)
    if best_len:
        return best, f"SKLZ_MAX_LOTS_BY_SYMBOL ({sym[:best_len]})"
    return _f(os.environ.get("SKLZ_MAX_LOTS", "0")), "SKLZ_MAX_LOTS"



# MT5 truncates order comments at 26 characters. "sklz-auto structure_break+
# strength_extreme" lost its second signal, so the deal history — the record
# that survives any journal bug — could not say which combination won. Short
# codes keep the whole confluence inside the limit; the journal keeps the long
# names; tools\model_report.py decodes these.
SIGNAL_CODES = {
    "strength_extreme": "SE", "structure_break": "SB", "sweep_reversal": "SR",
    "dashboard": "DB", "testing": "T",
}


def order_comment(source: str, strategy: str) -> str:
    src = "a" if str(source).startswith("auto") else "f"
    parts = []
    for name in str(strategy).split("+"):
        name = name.strip()
        if not name:
            continue
        if name in SIGNAL_CODES:
            parts.append(SIGNAL_CODES[name])
        elif name.startswith("model_") and len(name) > 6:
            parts.append(name[6:].upper())          # model_c -> C
        else:
            parts.append(name[:6])
    return f"sklz-{src} {'+'.join(parts)}"[:26]

class EntryController:
    def __init__(self, io, journal: Journal, tf_min: int = 60,
                 lookback: int = 24, risk_pct: float = 0.5, log=print) -> None:
        self.io = io
        self.journal = journal
        self.tf_min = tf_min
        self.lookback = lookback
        self.risk_pct = risk_pct
        self.log = log

    def _size(self, symbol: str, sl_dist: float,
              apply_ceiling: bool = True) -> float:
        """Size the trade, then apply the absolute lot ceiling.

        _size_raw has two modes with several exits, and a ceiling placed on
        one of them is not a ceiling. A 50k account once opened 3.12 lots of
        BTC because the equity-proportional path returned before reaching a
        cap that guarded only the risk-based path. So the cap lives HERE,
        at the single door every sizing decision must pass through.
        """
        lots = self._size_raw(symbol, sl_dist)
        if not apply_ceiling:
            # A forced entry is a human decision. The ceiling exists to stop
            # the SCANNER from sizing beyond what the account should carry
            # unattended; it is not there to overrule the owner at the
            # dashboard. Autonomy is capped, deliberate action is not.
            return lots
        cap, cap_name = lot_ceiling(symbol)
        if cap <= 0 or lots <= 0:
            return lots
        spec = self.io.spec(symbol)
        lot_min = float(spec.get("lot_min", 0.01) or 0.01)
        if lots > cap:
            capped = max(lot_min, cap)
            self.log(f"[size] {symbol} sizing wanted {lots:g} lots — "
                     f"capped at {capped:g} by {cap_name}")
            # If the broker minimum is ABOVE the ceiling the trade cannot
            # honour the limit at all; refusing is the honest answer.
            if lot_min > cap:
                self.log(f"[size] REFUSED {symbol}: broker minimum "
                         f"{lot_min:g} exceeds the {cap:g} lot ceiling")
                return 0.0
            return round(capped, 2)
        return lots

    def _size_raw(self, symbol: str, sl_dist: float) -> float:
        eq = float(self.io.account().get("equity", 0) or 0)
        spec = self.io.spec(symbol)

        # ── equity-proportional mode ──────────────────────────────
        # SKLZ_LOT_PER_EQUITY=100 with SKLZ_LOT_UNIT=0.01 means
        # "0.01 lots for every $100 of equity". Simple, predictable,
        # and it scales down as the account shrinks.
        #
        # Note this sizes by ACCOUNT SIZE, not by stop distance — so a
        # wide stop risks more than a tight one. Risk per trade varies
        # with the setup; that is the trade-off for predictability.
        try:
            per = float(os.environ.get("SKLZ_LOT_PER_EQUITY", "0") or 0)
        except ValueError:
            per = 0.0
        if per > 0:
            try:
                unit = float(os.environ.get("SKLZ_LOT_UNIT", "0.01"))
            except ValueError:
                unit = 0.01
            lots = (eq / per) * unit
            step = spec["lot_step"]
            lots = round(lots / step) * step
            lots = max(spec["lot_min"], min(spec["lot_max"], lots))

            # A floor for the slow instruments. FX majors move little enough
            # that 0.01 lots earns pennies, so a minimum is reasonable — but it
            # is a FLOOR, not an override. The risk cap below still applies,
            # and if the floor breaches it the cap wins and says so. Setting a
            # lot size should not be a way to quietly choose 6% risk.
            try:
                floor = float(os.environ.get("SKLZ_MIN_LOT_FX", "0"))
            except ValueError:
                floor = 0.0
            # The floor applies to FX ONLY. Gold, silver, crypto, indices and
            # oil already carry large per-pip values — a floor there multiplies
            # risk rather than making a slow instrument worth trading.
            if floor > 0 and _is_fx(symbol):
                lots = max(lots, floor)

            # HARD RISK CAP.
            #
            # Equity-proportional sizing ignores stop distance, which is fine
            # on FX where stops are similar, and dangerous everywhere else. A
            # 131-pip silver stop at 0.02 lots risks $131 — on a $197 account
            # that is 66% of everything on one trade, at the same lot size a
            # 20-pip EURUSD stop would risk $4.
            #
            # So whatever the sizing mode says, never risk more than
            # SKLZ_MAX_RISK_PCT of equity. Cut the size to fit, and if even
            # the minimum lot breaches the cap, refuse the trade entirely.
            try:
                cap_pct = float(os.environ.get("SKLZ_MAX_RISK_PCT", "2"))
            except ValueError:
                cap_pct = 2.0

            if cap_pct > 0 and sl_dist > 0 and spec.get("tick_size", 0) > 0:
                per_lot = (sl_dist / spec["tick_size"]) * spec["tick_value"]
                if per_lot > 0:
                    max_risk = eq * cap_pct / 100.0
                    risk_at_size = per_lot * lots
                    if risk_at_size > max_risk:
                        safe = max_risk / per_lot
                        safe = int(safe / step) * step      # round DOWN
                        if safe < spec["lot_min"]:
                            self.log(
                                f"[size] REFUSED {symbol}: even {spec['lot_min']} "
                                f"lots risks ${per_lot * spec['lot_min']:.2f} on a "
                                f"${eq:.2f} account, past the {cap_pct:g}% cap "
                                f"(${max_risk:.2f}). The stop is too wide for this "
                                f"account size.")
                            return 0.0
                        floor_note = ""
                        try:
                            fl = float(os.environ.get("SKLZ_MIN_LOT_FX", "0"))
                            if fl > 0 and abs(lots - fl) < 1e-9:
                                floor_note = (f" (SKLZ_MIN_LOT_FX={fl} asked for "
                                              f"more; the risk cap wins)")
                        except ValueError:
                            pass
                        self.log(
                            f"[size] {symbol} cut {lots} -> {safe} lots: "
                            f"{lots} would risk ${risk_at_size:.2f} of a "
                            f"${eq:.2f} account ({risk_at_size/eq*100:.2f}%), "
                            f"cap is {cap_pct:g}%{floor_note}")
                        lots = safe

            return round(lots, 2)

        # ── risk-based mode (default) ─────────────────────────────
        if sl_dist <= 0 or spec["tick_size"] <= 0:
            return spec["lot_min"]
        risk = eq * self.risk_pct / 100.0
        per_lot = (sl_dist / spec["tick_size"]) * spec["tick_value"]
        if per_lot <= 0:
            return spec["lot_min"]
        lots = risk / per_lot
        step = spec["lot_step"]
        return round(max(spec["lot_min"],
                         min(spec["lot_max"], round(lots/step)*step)), 2)


    def affordable(self, symbol: str, lots: float, side: int = 1) -> dict:
        """Can this account carry this position without crowding out others?

        Indices and similar instruments tie up far more margin than FX or
        gold. On a small account one US500 position can consume most of the
        free margin, so the next four setups get rejected — the account ends
        up concentrated in whatever happened to trigger first, which is the
        opposite of a basket.

        Under SKLZ_HEAVY_MIN_EQUITY the heavy instruments are simply not
        traded. The SIGNAL still goes out: the setup is just as valid for
        someone with a larger account, and withholding it would be withholding
        information rather than protecting anyone.
        """
        try:
            floor = float(os.environ.get("SKLZ_HEAVY_MIN_EQUITY", "1000"))
        except ValueError:
            floor = 1000.0
        try:
            max_margin_pct = float(os.environ.get("SKLZ_MAX_MARGIN_PCT", "25"))
        except ValueError:
            max_margin_pct = 25.0

        acct = self.io.account() or {}
        eq = float(acct.get("equity") or 0)
        free = float(acct.get("free_margin") or eq)
        if eq <= 0:
            return {"ok": True, "reason": ""}          # unknown, do not block

        need = 0.0
        try:
            need = self.io.margin_required(symbol, lots, side)
        except Exception:
            need = 0.0

        # what gold costs to hold is the yardstick: anything materially
        # heavier is what crowds a small account out
        gold_need = 0.0
        try:
            gold_need = self.io.margin_required("XAUUSD", lots, side)
        except Exception:
            pass

        if need <= 0:
            return {"ok": True, "reason": "margin unknown"}

        if gold_need > 0 and need > gold_need * 1.2 and eq < floor:
            return {"ok": False, "signal_anyway": True,
                    "reason": (f"{symbol} needs ${need:.2f} margin — more than "
                               f"gold (${gold_need:.2f}) — and this account is "
                               f"${eq:.2f}, under the ${floor:.0f} floor for "
                               f"heavy instruments. Signal published, trade "
                               f"skipped.")}

        if need > free * max_margin_pct / 100.0:
            return {"ok": False, "signal_anyway": True,
                    "reason": (f"{symbol} would tie up ${need:.2f} of "
                               f"${free:.2f} free margin "
                               f"({need/free*100:.0f}%), past the "
                               f"{max_margin_pct:.0f}% cap. One position should "
                               f"not crowd out the rest of the basket. "
                               f"Signal published, trade skipped.")}

        return {"ok": True, "reason": ""}


    def cost_viable(self, symbol: str, sl_dist: float) -> dict:
        """Is the spread small enough for this trade to be worth taking?

        Every trade pays the spread twice in effect — you enter at the worse
        side and exit at the worse side. On a setup targeting 30 pips with a
        4-pip spread, costs are 13% of the move before anything else happens.
        Across ninety trades that is the difference between a small edge and a
        slow loss, and it is invisible on any individual trade.

        The check is relative, not absolute: 3 pips is cheap on gold and
        expensive on EURUSD.
        """
        try:
            max_pct = float(os.environ.get("SKLZ_MAX_SPREAD_PCT", "12"))
        except ValueError:
            max_pct = 12.0
        if max_pct <= 0 or sl_dist <= 0:
            return {"ok": True}

        try:
            bid = self.io.price(symbol, -1)
            ask = self.io.price(symbol, 1)
            spread = abs(ask - bid)
        except Exception:
            return {"ok": True, "reason": "spread unknown"}

        if spread <= 0:
            return {"ok": True}

        # Measure the spread against the TARGET, not the stop.
        #
        # The first version compared it to the stop, which overstates the cost:
        # you enter at the ask and the stop distance already includes what you
        # paid. What the spread genuinely erodes is the profit — every winner
        # gives the spread back before it gives you anything. A 2.8 pip spread
        # on a 20 pip stop looked like 14% and got blocked; against the 40 pip
        # target it is 7%, which is tolerable.
        try:
            rr = float(os.environ.get("SKLZ_TARGET_R", "2"))
        except ValueError:
            rr = 2.0
        target = sl_dist * max(1.0, rr)
        pct = spread / target * 100
        if pct > max_pct:
            try:
                from basket_engine.learn.trailing import pip_size
                pip = pip_size(symbol, self.io.spec(symbol).get("digits"))
            except Exception:
                pip = 0.0001
            return {"ok": False,
                    "reason": (f"spread is {spread/pip:.1f} pips against a "
                               f"{target/pip:.0f} pip target — {pct:.0f}% of "
                               f"the reward, past the {max_pct:.0f}% limit. "
                               f"Costs would take too much of this trade.")}
        return {"ok": True, "spread_pct": round(pct, 1)}

    def _atr(self, symbol: str) -> float:
        closes = self.io.closes(symbol, self.tf_min, self.lookback + 2)
        if len(closes) < 3:
            return 0.0
        d = [abs(b-a) for a, b in zip(closes, closes[1:])]
        return sum(d)/len(d)

    def _enter(self, source: str, strategy: str, symbol: str, side: int,
               note: str, sl_mult: float, tp_mult: float,
               lots_override: float = 0.0, sl_price: float = 0.0,
               tp_price: float = 0.0) -> EntryRecord | None:
        if not self.io.has_symbol(symbol):
            self.log(f"[entry] unknown symbol {symbol}")
            return None
        if hasattr(self.io, "market_live") and not self.io.market_live(symbol):
            self.log(f"[entry] NOTE: {symbol} market looks closed (stale tick) — "
                     f"order may be rejected or fill Monday. Proceeding as you asked.")
        atr = self._atr(symbol)
        sl_dist = sl_mult * atr
        px = self.io.price(symbol, side)
        if not px:
            # no live price means the market is shut. Refusing cleanly here is
            # honest; proceeding produced a crash on a weekend gold order.
            self.log(f"[entry] {symbol} refused — no live price (market "
                     f"closed). Try again after the Sunday open.")
            return None
        digits = self.io.spec(symbol)["digits"]

        # structure-aware stop: sit just beyond the nearest M15 pivot, clamped
        # to the configured pip band. Falls back to ATR if structure is
        # unreadable, and an explicit sl_price always wins.
        if not sl_price and os.environ.get("SKLZ_SL_STRUCTURE", "1") != "0":
            try:
                from basket_engine.learn import stops as _stops
                st = _stops.stop_for(self.io, symbol, side, px, log=self.log)
                if st:
                    sl_price = st["sl"]
            except Exception as exc:
                self.log(f"[stop] structure read failed ({type(exc).__name__}); "
                         f"using ATR distance")

        sl = round(sl_price, digits) if sl_price else round(px - side * sl_dist, digits)
        if sl_price:
            sl_dist = abs(px - sl_price)
        # is this genuinely a new bet, or the same one again in a costume?
        try:
            from basket_engine.learn import exposure as EXP
            open_now = []
            for p in self.io.my_positions():
                open_now.append({"symbol": p.get("symbol"),
                                 "side": p.get("side", 1),
                                 "lots": p.get("volume", 0.01)})
            probe = EXP.would_breach(open_now, symbol, side, 0.01)
            if not probe.get("ok"):
                self.log(f"[exposure] {symbol} skipped — {probe.get('reason', '')}")
                self.log(f"[exposure] currently: {EXP.describe(open_now)}")
                return None
        except Exception:
            pass

        cost = self.cost_viable(symbol, sl_dist)
        if not cost.get("ok"):
            self.log(f"[cost] {symbol} skipped — {cost.get('reason', '')}")
            return None

        lots = lots_override or self._size(symbol, sl_dist,
                                           apply_ceiling=(source != "forced"))
        if not lots or lots <= 0:
            self.log(f"[entry] {symbol} skipped — position size would breach "
                     f"the risk cap")
            return None
        tp = round(tp_price, digits) if tp_price else 0.0
        res = self.io.market(symbol, side, lots, sl,
                             order_comment(source, strategy), tp=tp)
        if res.get("ok") and float(res.get("price") or 0) <= 0:
            # the order filled but the broker did not tell us at what price.
            # Recording 0 corrupts the journal and the trailing engine, so
            # fall back to the current market price and say what happened.
            fallback = 0.0
            try:
                fallback = float(self.io.price(symbol, side))
            except Exception:
                pass
            self.log(f"[entry] FILL PRICE UNAVAILABLE for {symbol} — "
                     f"using market {fallback} for the record")
            res["price"] = fallback
        if not res.get("ok"):
            code = res.get("retcode")
            try:
                from basket_engine.mt5io import RETCODES
                why = RETCODES.get(code, "")
            except Exception:
                why = ""
            self.log(f"[entry] FAIL {symbol}: {code}"
                     + (f" — {why}" if why else ""))
            return None
        st = snapshot(self.io, symbol, self.tf_min, self.lookback)
        rec = EntryRecord(
            ts=datetime.now(timezone.utc).isoformat(), source=source,
            strategy=strategy, symbol=symbol, side=side, lots=lots,
            entry_price=res["price"], note=note, state=st.__dict__,
            ticket=res.get("ticket"), sl_price=sl or None, tp_price=tp or None)
        # Keep the broker's own answer with the record. It was discarded
        # here, so a dashboard order could report a ticket but never a
        # fill price, a retcode or the broker's comment.
        try:
            rec.state["fill"] = {
                "retcode": res.get("retcode"),
                "comment": res.get("comment", ""),
                "price": res.get("price"),
                "volume": res.get("volume", lots)}
        except Exception:  # noqa: BLE001
            pass

        # every filled entry feeds the copy network — auto, console-forced,
        # and dashboard orders alike. This is the one choke point they all
        # pass through, which is exactly why the hook lives here and not in
        # the scan loop (a forced test trade must copy like a real one).
        try:
            from basket_engine.learn import signal_publish as _sp
            _sp.copy_event("open", rec.ticket, symbol, side,
                           lots=lots, price=rec.entry_price,
                           sl=rec.sl_price, tp=rec.tp_price, log=self.log)
        except Exception:
            pass
        # capture the market state BEFORE journaling, so the context is
        # persisted with the entry rather than lost
        try:
            from basket_engine.learn import trade_context as TC
            rec.context = TC.capture_entry(
                self.io, symbol, side, strategy,
                quality=getattr(self, "_last_quality", None),
                institutional=getattr(self, "_last_institutional", None),
                orderflow=getattr(self, "_last_orderflow", None))
            rec.context["ticket"] = res.get("ticket")
            rec.context["sl_price"] = sl or None
            rec.context["tp_price"] = tp or None
            rec.context["lots"] = lots
        except Exception as exc:  # noqa: BLE001
            self.log(f"[research] context capture failed: {type(exc).__name__}")

        self.journal.record_entry(rec)
        self.log(f"[{source}] {'BUY' if side>0 else 'SELL'} {lots} {symbol} "
                 f"@ {res['price']} · {strategy}"
                 + (f" · \"{note}\"" if note else ""))
        return rec

    # ---- stream 1: YOU, with a reason ----
    def forced_entry(self, symbol: str, side: int, note: str,
                     sl_mult: float = 2.0, tp_mult: float = 3.0) -> EntryRecord | None:
        """A deliberate entry you're taking to TEACH the system.
        `note` is your reasoning — the label that makes learning work."""
        return self._enter("forced", note.split()[0].lower() if note else "manual",
                            symbol, side, note, sl_mult, tp_mult)

    def forced_custom(self, symbol: str, side: int, note: str,
                      lots: float = 0.0, sl: float = 0.0,
                      tp: float = 0.0) -> EntryRecord | None:
        """Dashboard entry with optional explicit lots / SL / TP.
        Blank fields fall back to risk-based sizing and ATR stop."""
        return self._enter("forced", "dashboard", symbol, side, note,
                           2.0, 3.0, lots_override=lots,
                           sl_price=sl, tp_price=tp)

    # ---- stream 2: the bot's scanners ----
    def auto_entry(self, scanner: str, symbol: str, side: int, detail: str,
                   sl_mult: float = 2.0, tp_mult: float = 3.0,
                   sl_price: float = 0.0, tp_price: float = 0.0) -> EntryRecord | None:
        """A scanner-triggered entry — a HYPOTHESIS being tested, not trusted.
        v3.33: a model-led entry may hand over its own structural stop and
        target (SKLZ_MODEL_SL / SKLZ_MODEL_TP in the runner)."""
        return self._enter("auto", scanner, symbol, side, detail, sl_mult, tp_mult,
                           sl_price=sl_price, tp_price=tp_price)

    # ---- stream 3: pending straddles (Model O, M london box) ----
    def place_pending(self, strategy: str, symbol: str, side: int, price: float,
                      sl_price: float, tp_price: float, note: str,
                      expire_epoch: int | None = None) -> dict | None:
        """Size and place a stop order; nothing is journaled until it fills
        (see record_fill). Returns the broker's answer or None."""
        if not self.io.has_symbol(symbol):
            self.log(f"[pending] unknown symbol {symbol}")
            return None
        digits = self.io.spec(symbol)["digits"]
        sl_dist = abs(price - sl_price)
        if sl_dist <= 0:
            return None
        cost = self.cost_viable(symbol, sl_dist)
        if not cost.get("ok"):
            self.log(f"[cost] {symbol} pending skipped — {cost.get('reason', '')}")
            return None
        lots = self._size(symbol, sl_dist, apply_ceiling=True)
        if not lots or lots <= 0:
            self.log(f"[pending] {symbol} skipped — size would breach the risk cap")
            return None
        res = self.io.pending(symbol, side, lots, round(price, digits),
                              round(sl_price, digits), round(tp_price, digits) if tp_price else 0.0,
                              order_comment("auto", strategy), expire_epoch)
        if not res.get("ok"):
            self.log(f"[pending] FAIL {symbol}: {res.get('retcode')}")
            return None
        res.update({"lots": lots, "symbol": symbol, "side": side, "price": price,
                    "sl": sl_price, "tp": tp_price, "strategy": strategy, "note": note})
        self.log(f"[pending] {'BUY_STOP' if side > 0 else 'SELL_STOP'} {lots} {symbol} "
                 f"@ {price} SL {sl_price} TP {tp_price or '-'} · {strategy} · #{res['ticket']}")
        return res

    def record_fill(self, pend: dict, pos: dict) -> EntryRecord | None:
        """A pending order became a position: journal it and feed the copy
        network exactly like a market entry."""
        try:
            st = snapshot(self.io, pend["symbol"], self.tf_min, self.lookback)
            rec = EntryRecord(
                ts=datetime.now(timezone.utc).isoformat(), source="auto",
                strategy=pend["strategy"], symbol=pend["symbol"], side=pend["side"],
                lots=float(pos.get("lots") or pend["lots"]),
                entry_price=float(pos.get("open_price") or pend["price"]),
                note=pend.get("note", ""), state=st.__dict__,
                ticket=pos.get("ticket") or pend.get("ticket"),
                sl_price=float(pos.get("sl") or pend["sl"]) or None,
                tp_price=float(pos.get("tp") or pend.get("tp") or 0) or None)
            try:
                from basket_engine.learn import signal_publish as _sp
                _sp.copy_event("open", rec.ticket, rec.symbol, rec.side, lots=rec.lots,
                               price=rec.entry_price, sl=rec.sl_price, tp=rec.tp_price, log=self.log)
            except Exception:
                pass
            try:
                from basket_engine.learn import trade_context as TC
                rec.context = TC.capture_entry(self.io, rec.symbol, rec.side, rec.strategy)
                rec.context.update({"ticket": rec.ticket, "sl_price": rec.sl_price,
                                    "tp_price": rec.tp_price, "lots": rec.lots, "pending": True})
            except Exception:  # noqa: BLE001
                pass
            self.journal.record_entry(rec)
            self.log(f"[auto] {'BUY' if rec.side > 0 else 'SELL'} {rec.lots} {rec.symbol} "
                     f"@ {rec.entry_price} · {rec.strategy} (pending filled #{rec.ticket})")
            return rec
        except Exception as exc:  # noqa: BLE001
            self.log(f"[pending] record_fill failed: {type(exc).__name__}: {exc}")
            return None
