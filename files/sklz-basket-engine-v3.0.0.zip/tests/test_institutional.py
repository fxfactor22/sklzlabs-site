"""Institutional confirmation: the cases that must never pass."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from basket_engine.learn import institutional as INST
from basket_engine.learn import orderflow as OF


def _bars(n, start, drift, vol=0.0004, v=100):
    out, p = [], start
    for i in range(n):
        o = p
        p += drift
        out.append({"time": 1700000000 + i * 900, "open": o,
                    "high": max(o, p) + vol * 0.3, "low": min(o, p) - vol * 0.3,
                    "close": p, "volume": v, "real_volume": 0})
    return out


def test_absent_inputs_are_not_scored_as_zero():
    """Missing DOM must not silently cap the score — it is normalised out."""
    m15, h1, d1 = _bars(120, 1.14, 0.0001), _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001)
    a = INST.assess(1, "EURUSD", 0.0001, m15, h1, d1)
    assert "dom" in a.inputs_missing
    assert "dom" not in a.inputs_used
    assert a.score > 0


def _swing_bar(t, o, h, l, c, v=100):
    return {"time": t, "open": o, "high": h, "low": l, "close": c,
            "volume": v, "real_volume": 0}


def _double_top(level=1.1450):
    """Price rallies to `level` twice and rejects — stops rest above it."""
    bars, t = [], 1700000000
    p = 1.1400
    for _ in range(30):                       # rally toward the level
        bars.append(_swing_bar(t, p, p + 0.0004, p - 0.0002, p + 0.0003))
        p += 0.0003
        t += 900
    bars.append(_swing_bar(t, p, level, p - 0.0003, level - 0.0010))   # peak 1
    t += 900
    p = level - 0.0010
    for _ in range(12):                       # pull back
        bars.append(_swing_bar(t, p, p + 0.0002, p - 0.0005, p - 0.0004))
        p -= 0.0004
        t += 900
    for _ in range(12):                       # rally back
        bars.append(_swing_bar(t, p, p + 0.0005, p - 0.0002, p + 0.0004))
        p += 0.0004
        t += 900
    bars.append(_swing_bar(t, p, level, p - 0.0003, level - 0.0012))   # peak 2
    t += 900
    p = level - 0.0012
    for _ in range(10):                       # drift back up, staying BELOW
        bars.append(_swing_bar(t, p, p + 0.0002, p - 0.0002, p + 0.0001))
        p += 0.0001
        t += 900
    assert p < level, "fixture must approach the pool from below"
    return bars, t, level


def test_liquidity_sweep_is_rejected():
    """Price wicks above a double top and closes back inside — a stop hunt."""
    bars, t, level = _double_top()
    bars.append(_swing_bar(t, level - 0.0004, level + 0.0015,
                           level - 0.0006, level - 0.0005, 320))
    a = INST.assess(1, "EURUSD", 0.0001, bars,
                    _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001))
    assert not a.passed, f"a sweep must never pass (scored {a.score})"
    assert any("SWEEP" in f for f in a.flags), f"flags were {a.flags}"


def test_acceptance_beyond_the_level_is_not_a_sweep():
    """Same level, but price closes decisively beyond it."""
    bars, t, level = _double_top()
    bars.append(_swing_bar(t, level - 0.0004, level + 0.0020,
                           level - 0.0005, level + 0.0018, 320))
    a = INST.assess(1, "EURUSD", 0.0001, bars,
                    _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001))
    assert not any("SWEEP" in f for f in a.flags), f"flags were {a.flags}"


def test_absorption_blocks_entry():
    d = OF.DeltaResult(buy_volume=800, sell_volume=200, delta=600,
                       cumulative=[1] * 50, quality="inferred")
    r = OF.absorption(d, price_move_pips=1)
    assert r["absorbed"] is True
    assert r["side"] == "seller"


def test_absorption_clears_when_price_moves():
    d = OF.DeltaResult(buy_volume=800, sell_volume=200, delta=600,
                       cumulative=[1] * 50, quality="inferred")
    assert OF.absorption(d, price_move_pips=30)["absorbed"] is False


def test_wick_breakout_is_not_acceptance():
    bar = {"open": 1.1400, "high": 1.1430, "low": 1.1398, "close": 1.1404}
    assert INST.candle_acceptance(1, bar)["accepted"] is False


def test_strong_body_is_acceptance():
    bar = {"open": 1.1400, "high": 1.1422, "low": 1.1399, "close": 1.1420}
    assert INST.candle_acceptance(1, bar)["accepted"] is True


def test_delta_divergence_detected():
    closes = [1.14 + i * 0.0001 for i in range(24)]
    cum = [100 - i * 3 for i in range(24)]
    assert OF.delta_divergence(closes, cum, 1)["divergent"] is True


def test_no_book_reports_unavailable_not_bearish():
    r = OF.read_depth([], 1)
    assert r["available"] is False
    assert "no order book" in r["reason"]


def test_basket_disagreement_penalises():
    m15, h1, d1 = _bars(120, 1.14, 0.0001), _bars(200, 1.135, 0.0002), _bars(20, 1.12, 0.001)
    agree = INST.assess(1, "EURUSD", 0.0001, m15, h1, d1,
                        peer_moves={"EURJPY": 0.3, "EURGBP": 0.2, "GBPUSD": 0.2})
    disagree = INST.assess(1, "EURUSD", 0.0001, m15, h1, d1,
                           peer_moves={"EURJPY": -0.3, "EURGBP": -0.2, "GBPUSD": -0.2})
    assert disagree.score < agree.score


def test_session_scores_overlap_highest():
    from datetime import datetime, timezone
    overlap = INST.session_quality(datetime(2026, 7, 30, 13, tzinfo=timezone.utc))
    asian = INST.session_quality(datetime(2026, 7, 30, 3, tzinfo=timezone.utc))
    assert overlap["score"] > asian["score"]


def test_jpy_gets_credit_in_asian_session():
    from datetime import datetime, timezone
    t = datetime(2026, 7, 30, 3, tzinfo=timezone.utc)
    assert (INST.session_quality(t, "USDJPY")["score"]
            > INST.session_quality(t, "EURUSD")["score"])


def test_runner_actually_has_the_institutional_method():
    """The scan loop calls self._institutional. If the method is missing the
    call raises AttributeError, gets swallowed by the fallback, and the whole
    layer silently does nothing — which is exactly what happened once.
    Compiling is not the same as being wired up."""
    from basket_engine.learn.runner import LearningRunner
    assert hasattr(LearningRunner, "_institutional"), \
        "LearningRunner._institutional is missing — the scan loop calls it"
    import inspect
    src = inspect.getsource(LearningRunner)
    assert "self._institutional(" in src, "nothing calls it"


def test_every_method_the_runner_calls_on_itself_exists():
    """Catch any other self._foo() that was never defined."""
    import inspect, re
    from basket_engine.learn.runner import LearningRunner
    src = inspect.getsource(LearningRunner)
    called = set(re.findall(r"self\.(_[a-z_]+)\(", src))
    defined = {n for n in dir(LearningRunner) if n.startswith("_")}
    missing = {c for c in called if c not in defined}
    assert not missing, f"called but never defined: {sorted(missing)}"


def test_published_signal_carries_the_traded_levels():
    """A signal whose stop differs from the one the bot is trading tells
    subscribers a level nobody is using. If the caller supplies real levels,
    they must appear in the payload rather than being recomputed."""
    import inspect
    from basket_engine.learn import signal_publish
    src = inspect.getsource(signal_publish.publish)
    assert "actual_sl" in src, "publish() must accept the executed stop"
    assert 'payload["sl"]' in src, "the real stop must reach the payload"


def test_entry_record_stores_the_placed_levels():
    from basket_engine.learn.capture import EntryRecord
    r = EntryRecord(ts="", source="auto", strategy="x", symbol="AUDUSD",
                    side=1, lots=0.03, entry_price=0.70333,
                    sl_price=0.70133, tp_price=0.70606)
    assert r.sl_price == 0.70133 and r.tp_price == 0.70606


def test_bridge_rejects_stale_data():
    """Old flow scored against a fresh breakout is worse than no flow."""
    import os, tempfile, time
    from basket_engine.learn import orderflow as OF
    d = tempfile.mkdtemp()
    os.environ["SKLZ_MT5_FILES_DIR"] = d
    p = os.path.join(d, "sklz_delta_EURUSD.csv")
    with open(p, "w") as f:
        f.write("time,ask_volume,bid_volume,delta,cum_delta\n")
        f.write("1700000000,100,50,50,50\n")
    os.utime(p, (time.time() - 4000, time.time() - 4000))
    assert OF.read_bridge("EURUSD").quality == "none"
    os.environ.pop("SKLZ_MT5_FILES_DIR", None)


def test_bridge_flags_wrong_buffer_indices():
    """All-zero volumes mean the EA is reading the wrong buffers. Say so
    rather than reporting a confident delta of zero."""
    import os, tempfile
    from basket_engine.learn import orderflow as OF
    d = tempfile.mkdtemp()
    os.environ["SKLZ_MT5_FILES_DIR"] = d
    with open(os.path.join(d, "sklz_delta_EURUSD.csv"), "w") as f:
        f.write("time,ask_volume,bid_volume,delta,cum_delta\n")
        f.write("1700000000,0,0,0,0\n")
    r = OF.read_bridge("EURUSD")
    assert r.quality == "none"
    assert "buffer indices" in r.note
    os.environ.pop("SKLZ_MT5_FILES_DIR", None)


def test_measured_delta_overrides_tick_inference():
    from basket_engine.learn import orderflow as OF
    measured = OF.DeltaResult(buy_volume=900, sell_volume=300, delta=600,
                              cumulative=[10] * 40, quality="measured")
    m15 = _bars(120, 1.14, 0.0001)
    a = INST.assess(1, "EURUSD", 0.0001, m15, _bars(200, 1.135, 0.0002),
                    _bars(20, 1.12, 0.001), delta_override=measured)
    assert "cluster_delta" in a.inputs_used


def test_correlated_positions_are_one_bet():
    """Four dollar-short positions are not diversification."""
    from basket_engine.learn import exposure as EXP
    pos = [{"symbol": "EURUSD", "side": 1, "lots": 0.01},
           {"symbol": "USDCHF", "side": -1, "lots": 0.01},
           {"symbol": "XAUUSD", "side": 1, "lots": 0.01},
           {"symbol": "USDJPY", "side": -1, "lots": 0.01}]
    net = EXP.exposure_map(pos)
    assert net["USD"] < 0, "all four are short USD"
    assert abs(net["USD"]) == 0.04, "exposure should compound, not offset"
    r = EXP.would_breach(pos, "GBPUSD", 1, 0.01)
    assert r["ok"] is False, "a fifth dollar-short trade must be refused"


def test_reducing_exposure_is_never_blocked():
    from basket_engine.learn import exposure as EXP
    pos = [{"symbol": "EURUSD", "side": 1, "lots": 0.01}] * 4
    assert EXP.would_breach(pos, "EURUSD", -1, 0.01)["ok"] is True


def test_retest_distinguishes_hold_from_fail():
    from basket_engine.learn.institutional import retest_held
    def bar(h, l, c):
        return {"open": c, "high": h, "low": l, "close": c, "volume": 100}
    held = retest_held(1, [bar(1.147, 1.144, 1.1465), bar(1.1468, 1.1448, 1.1452),
                           bar(1.1475, 1.1451, 1.147)], 1.145, 0.0001)
    assert held["tested"] and held["held"]
    failed = retest_held(1, [bar(1.147, 1.144, 1.1465), bar(1.1466, 1.1435, 1.1442),
                             bar(1.1448, 1.143, 1.1438)], 1.145, 0.0001)
    assert failed["tested"] and not failed["held"]
