#!/usr/bin/env python3
"""
model_report.py — wins / losses per model, per session (Asian / London / NY), per pair.

Reads the engine's JSONL journal (entry + exit rows keyed by ticket), joins them,
and — if run on the MT5 machine with --mt5 — backfills every missing or zeroed exit
straight from MT5 deal history, so broker-side closes (trailing SL, TP) that the
engine never logged still count.

Usage
  python tools/model_report.py --journal journal.jsonl --since 2026-09-28
  python tools/model_report.py --journal journal.jsonl --since 2026-09-28 --mt5
  python tools/model_report.py --journal journal.jsonl --since 2026-09-28 --mt5 --csv out.csv

Session boundaries (UTC, change with --tz-offset if your timestamps are broker time):
  Asian   21:00 – 06:59
  London  07:00 – 12:59
  NY      13:00 – 20:59
"""
import argparse, csv, json, sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone

# ---------- config -----------------------------------------------------------
SESSION_BOUNDS = [  # (start_hour_utc_inclusive, end_hour_utc_exclusive, label)
    (21, 24, "Asian"), (0, 7, "Asian"),
    (7, 13, "London"),
    (13, 21, "NY"),
]
# if the entry row already carries a session name, map it to the three buckets
SESSION_ALIASES = {
    "asian": "Asian", "asia": "Asian", "sydney": "Asian", "tokyo": "Asian",
    "sydney_tokyo": "Asian", "rollover": "Asian",
    "london": "London", "lon": "London", "eu": "London", "europe": "London",
    "ny": "NY", "new_york": "NY", "newyork": "NY", "us": "NY", "america": "NY",
}
MODEL_FIELDS = ("model", "strategy", "models", "signal", "source")
FLAT_EPS = 0.005          # |pnl| below this counts as flat/breakeven
# -----------------------------------------------------------------------------


# order comments: old engine wrote "sklz-auto model_c" (truncated at 26 chars);
# new engine writes "sklz-a SB+SE+C" — decode both back to full signal names
_CODES = {"SE": "strength_extreme", "SB": "structure_break", "SR": "sweep_reversal",
          "DB": "dashboard", "T": "testing"}


def decode_comment(comment):
    c = (comment or "").split("·")[0].strip()
    src = None
    for pre, s_ in (("sklz-auto ", "auto"), ("sklz-forced ", "forced"),
                    ("sklz-a ", "auto"), ("sklz-f ", "forced"), ("sklz-", None)):
        if c.startswith(pre):
            c, src = c[len(pre):].strip(), s_
            break
    if not c:
        return None, src
    parts = []
    for tok in c.split("+"):
        tok = tok.strip()
        if not tok:
            continue
        if tok in _CODES:
            parts.append(_CODES[tok])
        elif len(tok) == 1 and tok.isalpha() and tok.isupper():
            parts.append(f"model_{tok.lower()}")
        elif re.fullmatch(r"[A-Z]_[A-Z]{2,6}", tok):
            parts.append(f"model_{tok.lower()}")          # E_VA -> model_e_va (v3.33 variants)
        else:
            parts.append(tok)
    if c.endswith("+") or (len(c) >= 16 and "+" in c and len(parts) == 1):
        parts.append("?")          # old truncated confluence — partner unknown
    return "+".join(parts), src


def parse_ts(s):
    if s is None:
        return None
    if isinstance(s, (int, float)):
        return datetime.fromtimestamp(s, tz=timezone.utc)
    s = str(s).replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def session_of(dt, tz_offset_hours, hint=None):
    if hint:
        h = str(hint).strip().lower()
        for k, v in SESSION_ALIASES.items():
            if k in h:
                return v
    if dt is None:
        return "unknown"
    hour = (dt - timedelta(hours=tz_offset_hours)).hour
    for a, b, label in SESSION_BOUNDS:
        if a <= hour < b:
            return label
    return "unknown"


def model_of(row):
    for f in MODEL_FIELDS:
        v = row.get(f)
        if v:
            if isinstance(v, (list, tuple)):
                return "+".join(str(x) for x in v)
            return str(v)
    # fall back to anything that looks like model_x inside a note/comment
    for f in ("note", "comment", "reason"):
        v = row.get(f)
        if v and "model_" in str(v):
            return str(v).split("·")[0].strip()
    return "unknown"


def load_journal(path, since):
    trades = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            t = row.get("ticket") or row.get("position") or row.get("position_id")
            if t is None:
                continue
            t = int(t)
            kind = (row.get("type") or row.get("event") or "").lower()
            rec = trades.setdefault(t, {"ticket": t})
            if kind in ("entry", "open", "auto", "forced"):
                ts = parse_ts(row.get("ts") or row.get("time"))
                if since and ts and ts < since:
                    trades.pop(t, None)
                    continue
                rec.update({
                    "entry_ts": ts,
                    "symbol": row.get("symbol") or row.get("pair"),
                    "side": row.get("side"),
                    "lots": row.get("lots") or row.get("volume"),
                    "entry_price": row.get("entry_price") or row.get("price"),
                    "sl_price": row.get("sl_price") or row.get("sl"),
                    "model": model_of(row),
                    "source": row.get("source"),
                    "session_hint": (row.get("state") or {}).get("session") or row.get("session"),
                })
            elif kind in ("exit", "close", "closed"):
                xts = parse_ts(row.get("ts") or row.get("time"))
                if since and xts and xts < since:
                    if not rec.get("entry_ts"):
                        trades.pop(t, None)
                    continue
                rec.update({
                    "exit_ts": parse_ts(row.get("ts") or row.get("time")),
                    "exit_price": row.get("exit_price") or row.get("price"),
                    "pnl": row.get("pnl") if row.get("pnl") is not None else row.get("profit"),
                    "exit_reason": row.get("reason") or row.get("outcome"),
                })
    return trades


def backfill_from_mt5(trades, since):
    try:
        import MetaTrader5 as mt5
    except ImportError:
        print("!! MetaTrader5 package not installed — skipping backfill", file=sys.stderr)
        return trades
    if not mt5.initialize():
        print(f"!! mt5.initialize failed: {mt5.last_error()}", file=sys.stderr)
        return trades
    frm = since or datetime(2000, 1, 1, tzinfo=timezone.utc)
    deals = mt5.history_deals_get(frm, datetime.now(timezone.utc) + timedelta(days=1)) or []
    by_pos = defaultdict(list)
    for d in deals:
        # trade deals only — balance/deposit/credit rows have no position and would
        # otherwise show up as a giant "unknown" win
        if d.type not in (mt5.DEAL_TYPE_BUY, mt5.DEAL_TYPE_SELL) or not d.position_id:
            continue
        by_pos[d.position_id].append(d)
    reason_names = {getattr(mt5, k): k.replace("DEAL_REASON_", "") for k in dir(mt5) if k.startswith("DEAL_REASON_")}
    filled = 0
    for pos_id, ds in by_pos.items():
        ins = [d for d in ds if d.entry == mt5.DEAL_ENTRY_IN]
        outs = [d for d in ds if d.entry in (mt5.DEAL_ENTRY_OUT, mt5.DEAL_ENTRY_OUT_BY)]
        if not outs:
            continue  # still open
        rec = trades.setdefault(pos_id, {"ticket": pos_id, "model": "unknown (not in journal)"})
        if ins and not rec.get("entry_ts"):
            i = ins[0]
            rec.update({
                "entry_ts": datetime.fromtimestamp(i.time, tz=timezone.utc),
                "symbol": i.symbol, "lots": i.volume, "entry_price": i.price,
                "side": 1 if i.type == mt5.DEAL_TYPE_BUY else -1,
            })
            if i.comment and rec.get("model", "").startswith("unknown"):
                m, src = decode_comment(i.comment)
                rec["model"] = m or rec["model"]
                if src:
                    rec["source"] = src
        pnl_logged = rec.get("pnl")
        if rec.get("exit_ts") is None or not rec.get("exit_price") or pnl_logged in (None, 0, 0.0):
            last = outs[-1]
            rec.update({
                "exit_ts": datetime.fromtimestamp(last.time, tz=timezone.utc),
                "exit_price": last.price,
                "pnl": round(sum(d.profit + d.swap + d.commission for d in outs), 2),
                "exit_reason": reason_names.get(last.reason, str(last.reason)),
                "backfilled": True,
            })
            filled += 1
    mt5.shutdown()
    print(f"-- backfilled {filled} exit(s) from MT5 history", file=sys.stderr)
    return trades


def outcome(pnl):
    if pnl is None:
        return "open/unknown"
    if pnl > FLAT_EPS:
        return "win"
    if pnl < -FLAT_EPS:
        return "loss"
    return "flat"


def tally(trades, keyfn):
    agg = defaultdict(lambda: {"win": 0, "loss": 0, "flat": 0, "pnl": 0.0, "gross_win": 0.0, "gross_loss": 0.0})
    for r in trades:
        o = r["outcome"]
        if o == "open/unknown":
            continue
        a = agg[keyfn(r)]
        a[o] += 1
        a["pnl"] += r["pnl"]
        if o == "win":
            a["gross_win"] += r["pnl"]
        elif o == "loss":
            a["gross_loss"] += r["pnl"]
    return agg


def fmt_table(title, agg, key_label):
    rows = []
    for k, a in agg.items():
        n = a["win"] + a["loss"] + a["flat"]
        wr = a["win"] / n * 100 if n else 0
        pf = (a["gross_win"] / -a["gross_loss"]) if a["gross_loss"] < 0 else float("inf") if a["gross_win"] > 0 else 0
        avg_w = a["gross_win"] / a["win"] if a["win"] else 0.0
        avg_l = a["gross_loss"] / a["loss"] if a["loss"] else 0.0
        exp = a["pnl"] / n if n else 0.0
        rows.append((k, a["win"], a["loss"], a["flat"], n, wr, a["pnl"], pf, avg_w, avg_l, exp))
    rows.sort(key=lambda r: (-r[1], r[2], -r[6]))  # most wins first, then fewer losses
    w = max([len(str(r[0])) for r in rows] + [len(key_label), 8])
    out = [f"\n{title}", "-" * len(title),
           f"{key_label:<{w}}  {'W':>4} {'L':>4} {'flat':>4} {'n':>4}  {'win%':>5}  {'net P/L':>9}  {'PF':>5}  {'avg W':>7} {'avg L':>8}  {'per trade':>9}"]
    for r in rows:
        pf = "inf" if r[7] == float("inf") else f"{r[7]:.2f}"
        out.append(f"{str(r[0]):<{w}}  {r[1]:>4} {r[2]:>4} {r[3]:>4} {r[4]:>4}  {r[5]:>4.0f}%  {r[6]:>9.2f}  {pf:>5}  {r[8]:>7.2f} {r[9]:>8.2f}  {r[10]:>9.2f}")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--journal", default="learning_journal.jsonl")
    ap.add_argument("--since", help="YYYY-MM-DD (UTC)")
    ap.add_argument("--mt5", action="store_true", help="backfill missing exits from MT5 history (run on the MT5 machine)")
    ap.add_argument("--tz-offset", type=float, default=0.0, help="hours to subtract from timestamps to get UTC (broker time offset)")
    ap.add_argument("--csv", help="write per-trade rows to this CSV")
    ap.add_argument("--split-components", action="store_true",
                    help="also credit each component of a confluence entry (a+b+c) separately")
    args = ap.parse_args()

    since = datetime.fromisoformat(args.since).replace(tzinfo=timezone.utc) if args.since else None
    import os
    if os.path.exists(args.journal):
        trades = load_journal(args.journal, since)
    else:
        print(f"-- no journal at {args.journal}; using MT5 history only", file=sys.stderr)
        trades = {}
        if not args.mt5:
            sys.exit("nothing to read: pass --journal <path> or --mt5")
    if args.mt5:
        trades = backfill_from_mt5(trades, since)

    rows = []
    orphans = 0
    for t, r in trades.items():
        if since and r.get("entry_ts") and r["entry_ts"] < since:
            continue
        if not r.get("entry_ts") and not r.get("backfilled"):
            # an exit row whose entry predates --since (or was never journaled)
            # and that MT5 history did not supply either — no model, no pair,
            # no session: it can only pollute every table as "unknown"
            orphans += 1
            continue
        r["session"] = session_of(r.get("entry_ts"), args.tz_offset, r.get("session_hint"))
        r["symbol"] = r.get("symbol") or "unknown"
        r["model"] = r.get("model") or "unknown"
        try:
            r["pnl"] = float(r["pnl"]) if r.get("pnl") is not None else None
        except (TypeError, ValueError):
            r["pnl"] = None
        r["outcome"] = outcome(r["pnl"])
        rows.append(r)

    closed = [r for r in rows if r["outcome"] != "open/unknown"]
    open_or_missing = [r for r in rows if r["outcome"] == "open/unknown"]
    zero_exits = [r for r in closed if r.get("exit_price") in (None, 0, 0.0)]

    print(f"journal: {args.journal}   since: {args.since or 'all'}   trades: {len(rows)}   closed: {len(closed)}   no-exit: {len(open_or_missing)}"
          + (f"   (ignored {orphans} exit-only rows with no entry in range)" if orphans else ""))
    tot = tally(closed, lambda r: "ALL")["ALL"]
    n = tot["win"] + tot["loss"] + tot["flat"]
    print(f"overall: {tot['win']}W / {tot['loss']}L / {tot['flat']} flat   win% {tot['win']/n*100 if n else 0:.0f}   net {tot['pnl']:+.2f}")

    def _src(r):
        if r.get("source"):
            return "forced (dashboard/console)" if str(r["source"]).startswith("f") else "auto (engine)"
        return "forced (dashboard/console)" if str(r.get("model", "")).startswith(("dashboard", "testing")) else "auto (engine)"
    print(fmt_table("AUTO vs FORCED", tally(closed, _src), "source"))
    print(fmt_table("BY MODEL", tally(closed, lambda r: r["model"]), "model"))
    if args.split_components:
        comp = []
        for r in closed:
            for c in str(r["model"]).split("+"):
                rr = dict(r); rr["model"] = c.strip(); comp.append(rr)
        print(fmt_table("BY MODEL COMPONENT (confluence entries credited to each signal)", tally(comp, lambda r: r["model"]), "signal"))
    print(fmt_table("BY SESSION", tally(closed, lambda r: r["session"]), "session"))
    print(fmt_table("BY PAIR", tally(closed, lambda r: r["symbol"]), "pair"))
    print(fmt_table("BY MODEL x SESSION", tally(closed, lambda r: f"{r['model']} | {r['session']}"), "model | session"))
    print(fmt_table("BY MODEL x PAIR", tally(closed, lambda r: f"{r['model']} | {r['symbol']}"), "model | pair"))
    print(fmt_table("BY PAIR x SESSION", tally(closed, lambda r: f"{r['symbol']} | {r['session']}"), "pair | session"))

    # ── exit diagnostics: are winners being cut short? ──────────────────────
    def _reason(r):
        rs = str(r.get("exit_reason") or "?").lower()
        if rs in ("win", "loss", "flat"):
            rs = "?"
        if rs.startswith("sl") or rs == "stop":
            rs = "sl (trailed, in profit)" if r["pnl"] > 0 else "sl (initial stop)"
        return f"{rs} | {r['outcome']}"
    print(fmt_table("BY EXIT REASON (how trades actually closed)", tally(closed, _reason), "reason | outcome"))

    # winner size measured against the typical full loss on the same pair (≈ 1R proxy)
    avg_loss = {}
    for sym in {r["symbol"] for r in closed}:
        ls = [-r["pnl"] for r in closed if r["symbol"] == sym and r["outcome"] == "loss"]
        if ls:
            avg_loss[sym] = sum(ls) / len(ls)
    buckets = [(0.25, "< 0.25 R"), (0.5, "0.25-0.5 R"), (1.0, "0.5-1 R"), (2.0, "1-2 R"), (float("inf"), ">= 2 R")]
    dist = defaultdict(lambda: {"n": 0, "pnl": 0.0})
    for r in closed:
        if r["outcome"] != "win" or r["symbol"] not in avg_loss:
            continue
        ratio = r["pnl"] / avg_loss[r["symbol"]]
        for lim, name in buckets:
            if ratio < lim:
                dist[name]["n"] += 1; dist[name]["pnl"] += r["pnl"]; break
    nw = sum(d["n"] for d in dist.values())
    if nw:
        print("\nWINNER SIZE vs AVERAGE LOSS ON SAME PAIR  (1 R ≈ that pair's average losing trade)")
        print("-" * 78)
        for _, name in buckets:
            d = dist.get(name)
            if d:
                print(f"{name:<12} {d['n']:>4} winners  {d['n']/nw*100:>4.0f}%   total {d['pnl']:>+9.2f}")
        tot_w = sum(r["pnl"] for r in closed if r["outcome"] == "win")
        tot_l = -sum(r["pnl"] for r in closed if r["outcome"] == "loss")
        nl = sum(1 for r in closed if r["outcome"] == "loss")
        if nl and nw:
            payoff = (tot_w / nw) / (tot_l / nl)
            wr = nw / (nw + nl)
            be = 1 / (1 + payoff)
            print(f"payoff ratio avg W / avg L = {payoff:.2f}   win rate {wr*100:.0f}%   "
                  f"break-even win rate at this payoff = {be*100:.0f}%")

    # hold time: are winners closed faster than losers?
    def _mins(r):
        if r.get("entry_ts") and r.get("exit_ts"):
            return (r["exit_ts"] - r["entry_ts"]).total_seconds() / 60
        return None
    for lab in ("win", "loss"):
        ms = sorted(m for m in (_mins(r) for r in closed if r["outcome"] == lab) if m is not None and m >= 0)
        if ms:
            med = ms[len(ms) // 2]
            print(f"median hold {lab:<4}: {med:>6.0f} min  (n={len(ms)})")

    if zero_exits:
        print(f"\n!! {len(zero_exits)} closed trade(s) have exit_price 0/None in the journal — exit logger bug; use --mt5 to backfill:")
        for r in zero_exits[:20]:
            print(f"   {r['ticket']} {r['symbol']} {r['model']} pnl={r['pnl']}")
    if open_or_missing:
        print(f"\n{len(open_or_missing)} ticket(s) with no exit row (open, or closed by broker and never logged):")
        for r in open_or_missing[:30]:
            print(f"   {r['ticket']} {r['symbol']} {r['model']} opened {r.get('entry_ts')}")

    if args.csv:
        with open(args.csv, "w", newline="", encoding="utf-8") as fh:
            wri = csv.writer(fh)
            wri.writerow(["ticket", "symbol", "model", "session", "side", "lots", "entry_ts", "entry_price",
                          "exit_ts", "exit_price", "pnl", "outcome", "exit_reason", "backfilled", "sl_price"])
            for r in sorted(rows, key=lambda r: r.get("entry_ts") or datetime.min.replace(tzinfo=timezone.utc)):
                wri.writerow([r["ticket"], r["symbol"], r["model"], r["session"], r.get("side"), r.get("lots"),
                              r.get("entry_ts"), r.get("entry_price"), r.get("exit_ts"), r.get("exit_price"),
                              r.get("pnl"), r["outcome"], r.get("exit_reason"), r.get("backfilled", False), r.get("sl_price")])
        print(f"\nwrote {args.csv}")


if __name__ == "__main__":
    main()
