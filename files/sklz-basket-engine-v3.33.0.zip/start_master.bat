@echo off
title SKLZ MASTER - Upcomers PROP 1444538 ($50k) - v3.33.0
cd /d C:\Users\Administrator
set SKLZ_MT5_PATH=C:\Program Files\MetaTrader 5 IC Markets Global\terminal64.exe
set SKLZ_EXPECT_LOGIN=1444538
set SKLZ_EXPECT_SERVER=Upcomers-Server
set SKLZ_BOT_NAME=SKLZ Master
set SKLZ_ALLOW_LIVE=I_ACCEPT_THE_RISK
set SKLZ_API_URL=https://api.sklzlabs.com
set SKLZ_BOT_KEY=
set SIGNAL_WEBHOOK_KEY=
set SKLZ_PUBLISH_SIGNALS=1
set SKLZ_INST_MIN_SCORE=75

REM ================== v3.33.0 - models from the October video review ==========
REM New letters: o = 09:30 open-candle straddle (US30), p = 8AM range sweep reversal
set SKLZ_MODELS_ENABLED=a,b,c,d,e,f,g,x,h,j,k,l,m,n,o,p

REM Variants run as their own report tags so the numbers can rank them:
REM   model_a / model_a_va    model_e / model_e_va / model_e_pd
REM   model_f / model_f_trend model_m / model_m_orb / model_m_lon
set SKLZ_A_LEVELS=both
set SKLZ_E_LEVELS=all
set SKLZ_F_MODE=both
set SKLZ_M_BOX=all
set SKLZ_G_CONFIRM=1
set SKLZ_C_SWEEP=1
set SKLZ_C_MSB=1

REM Model O: US30 straddle at the 09:30 NY candle, 10 pts SL (floor 3x spread), 3:1
set SKLZ_O_SYMBOLS=US30
set SKLZ_O_SL_PTS=10
set SKLZ_O_RR=3

REM Structural targets: model entries carry their own stop and target to the broker.
REM A target must pay at least this many R or the model stands aside.
set SKLZ_MODEL_SL=1
set SKLZ_MODEL_TP=1
set SKLZ_MIN_TARGET_RR=1.5

REM Gold vs the dollar index: score first (logs [xmkt] on every gold entry).
REM After two weeks of lines, switch to gate if the split shows it pays.
set SKLZ_XAU_DXY=score

REM ================== prop guard - Upcomers 4%% daily / 7%% total ==============
set SKLZ_PROP_GUARD=1
set SKLZ_PROP_BASELINE=50000
set SKLZ_PROP_SOFT_PCT=1.5
set SKLZ_PROP_HARD_PCT=2.8
set SKLZ_PROP_TOTAL_SOFT_PCT=4.0
set SKLZ_PROP_TOTAL_HARD_PCT=5.5
set SKLZ_DAY_RESET_UTC_HOUR=21
set SKLZ_PROP_TARGET_PCT=0
set SKLZ_PROP_TARGET_MODE=protect
set SKLZ_PROP_MAX_OPEN=3

REM ================== sizing ==================================================
set SKLZ_MAX_RISK_PCT=0.5
set SKLZ_MAX_LOTS=0.2
set SKLZ_MAX_LOTS_BY_SYMBOL=XAUUSD:0.08,XAGUSD:0.01,BTCUSD:0.05,US30:0.2,NAS100:0.1

REM ================== exits ===================================================
REM r = R-multiples of each trade's own stop (3.32). structure = after the first
REM lock the stop follows the last completed M5 swing instead of a fixed band.
REM Model O is never trailed (SKLZ_TRAIL_SKIP_CODES=O, default).
set SKLZ_TRAIL_MODE=r
set SKLZ_TRAIL_TRIGGER_R=0.8
set SKLZ_TRAIL_DIST_R=0.5

REM Playbook: playbook.json, hot-reloads. 0 = off.
set SKLZ_PLAYBOOK=1

REM Oil killed the last prop account on a weekend gap; EURJPY/NZDUSD never paid.
set SKLZ_BLOCKED_SYMBOLS=EURJPY,NZDUSD,UKOIL,USOIL,XBRUSD,XTIUSD,BRENT,WTI,UKOUSD,USOUSD
REM ============================================================================

python learn_main.py --auto
