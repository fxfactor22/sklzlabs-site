"""SKLZ — shared level sources (v3.33).

Everything here is a pure function over bar lists so the models can be
unit-tested without a terminal. Bars are dicts with open/high/low/close,
optional volume (MT5 tick volume) and time (server-clock epoch seconds).

Level sources added from the October video review:
    value_area()        VAL / POC / VAH of a bar window — by VOLUME (tick
                        volume, what MT5 gives us) or by TPO (time at price,
                        exact from the bars themselves)
    composite_va()      merge consecutive days whose value areas overlap by
                        >= 50% into one distribution (the "CVA")
    prev_day_range()    yesterday's high / low / close, server-day aligned
    session_vwap()      VWAP since the server day started (or since an hour)
    rel_volume()        this bar's volume vs the same minute on prior days
    value_migration()   are the daily value areas stepping up, down or flat
    low_volume_nodes()  the valleys of a profile — price moves fast through them
    structural_target() nearest opposing liquidity in the trade direction that
                        pays SKLZ_MIN_TARGET_RR; None when nothing does
"""
from __future__ import annotations

import os
from datetime import datetime, timezone


# ── profile ──────────────────────────────────────────────────────────
def _profile(bars: list[dict], bins: int, source: str) -> tuple[float, float, list[float]]:
    """(lo, step, buckets). `source` is "volume" or "tpo"."""
    hi = max(b["high"] for b in bars)
    lo = min(b["low"] for b in bars)
    if hi <= lo:
        return lo, 0.0, []
    step = (hi - lo) / bins
    buckets = [0.0] * bins

    def _span(a: float, b2: float) -> tuple[int, int]:
        i0 = min(bins - 1, max(0, int((a - lo) / step)))
        i1 = min(bins - 1, max(0, int((b2 - lo) / step)))
        return (i0, i1) if i0 <= i1 else (i1, i0)

    for b in bars:
        if source == "tpo":
            # one unit of TIME per bar, spread over the prices it touched
            w0, w1 = _span(b["low"], b["high"])
            share = 1.0 / (w1 - w0 + 1)
            for i in range(w0, w1 + 1):
                buckets[i] += share
            continue
        vol = float(b.get("volume") or 0.0) or 1.0
        w0, w1 = _span(b["low"], b["high"])
        share = vol * 0.4 / (w1 - w0 + 1)
        for i in range(w0, w1 + 1):
            buckets[i] += share
        b0, b1 = _span(b["open"], b["close"])
        share = vol * 0.6 / (b1 - b0 + 1)
        for i in range(b0, b1 + 1):
            buckets[i] += share
    return lo, step, buckets


def value_area(bars: list[dict], pct: float = 0.70, bins: int = 40,
               source: str | None = None) -> dict | None:
    """{val, poc, vah, lo, hi, source}. The area is grown from the POC
    outward, one bucket at a time on the heavier side, until it holds
    `pct` of the profile — the textbook construction."""
    if not bars:
        return None
    src = (source or os.environ.get("SKLZ_VA_SOURCE", "tpo")).lower()
    lo, step, buckets = _profile(bars, bins, src)
    if not buckets or step <= 0:
        return None
    total = sum(buckets)
    if total <= 0:
        return None
    poc_i = max(range(bins), key=lambda i: buckets[i])
    a = b = poc_i
    acc = buckets[poc_i]
    while acc < total * pct and (a > 0 or b < bins - 1):
        up = buckets[b + 1] if b < bins - 1 else -1.0
        dn = buckets[a - 1] if a > 0 else -1.0
        if up >= dn:
            b += 1; acc += up
        else:
            a -= 1; acc += dn
    return {"val": lo + a * step, "vah": lo + (b + 1) * step,
            "poc": lo + (poc_i + 0.5) * step,
            "lo": lo, "hi": lo + bins * step, "source": src,
            "buckets": buckets, "step": step}


def low_volume_nodes(va: dict, frac: float = 0.35) -> list[tuple[float, float]]:
    """Price bands whose bucket is below `frac` of the mean bucket — the
    valleys. Returns [(lo, hi), ...] merged into contiguous bands."""
    if not va or not va.get("buckets"):
        return []
    bk, step, lo = va["buckets"], va["step"], va["lo"]
    mean = sum(bk) / len(bk)
    out, run = [], None
    for i, v in enumerate(bk):
        if v < mean * frac:
            if run is None:
                run = [lo + i * step, lo + (i + 1) * step]
            else:
                run[1] = lo + (i + 1) * step
        elif run is not None:
            out.append(tuple(run)); run = None
    if run is not None:
        out.append(tuple(run))
    return out


# ── day handling ─────────────────────────────────────────────────────
def _server_day(bars: list[dict], now_utc: datetime | None = None) -> tuple[int, int]:
    """(day0, offset): server midnight of the CURRENT day in server epoch
    seconds, and the server-vs-UTC offset. 0,0 when bars have no time."""
    if not bars or not bars[-1].get("time"):
        return 0, 0
    now = now_utc or datetime.now(timezone.utc)
    try:
        diff = int(bars[-1]["time"]) - int(now.timestamp())
    except Exception:  # noqa: BLE001
        return 0, 0
    off = int(round(diff / 3600.0)) * 3600
    day0 = (int(now.timestamp()) + off) // 86400 * 86400
    return day0, off


def split_days(bars: list[dict], now_utc: datetime | None = None) -> list[list[dict]]:
    """Bars grouped by server day, oldest first; the last group is today."""
    day0, _ = _server_day(bars, now_utc)
    if not day0:
        return [bars]
    groups: dict[int, list[dict]] = {}
    for b in bars:
        try:
            d = int(b["time"]) // 86400 * 86400
        except Exception:  # noqa: BLE001
            continue
        groups.setdefault(d, []).append(b)
    return [groups[k] for k in sorted(groups)]


def prev_day_range(bars: list[dict], now_utc: datetime | None = None) -> dict | None:
    """{high, low, close, open} of the last COMPLETED server day."""
    days = split_days(bars, now_utc)
    if len(days) < 2:
        return None
    d = days[-2]
    return {"high": max(b["high"] for b in d), "low": min(b["low"] for b in d),
            "open": d[0]["open"], "close": d[-1]["close"], "bars": len(d)}


def prev_day_value_area(bars: list[dict], now_utc: datetime | None = None,
                        rth_utc: tuple[float, float] | None = None, **kw) -> dict | None:
    """Value area of yesterday. `rth_utc=(13.5, 20)` keeps only the bars
    in that UTC window (the US regular session) — the futures-style
    profile the scalping videos use."""
    days = split_days(bars, now_utc)
    if len(days) < 2:
        return None
    d = days[-2]
    if rth_utc and bars[-1].get("time"):
        _, off = _server_day(bars, now_utc)
        keep = []
        for b in d:
            h = ((int(b["time"]) - off) % 86400) / 3600.0
            if rth_utc[0] <= h < rth_utc[1]:
                keep.append(b)
        d = keep or d
    return value_area(d, **kw)


def composite_va(bars: list[dict], max_days: int = 10, overlap: float = 0.5,
                 now_utc: datetime | None = None, **kw) -> dict | None:
    """Walk back from yesterday, merging days while each one's value area
    overlaps the running composite by >= `overlap` of the smaller area.
    Returns {val, vah, poc, days} — poc is the POC of the merged bars."""
    days = split_days(bars, now_utc)[:-1]          # completed days only
    if not days:
        return None
    merged, cva = [], None
    for d in reversed(days[-max_days:]):
        va = value_area(d, **kw)
        if va is None:
            break
        if cva is None:
            cva, merged = va, list(d)
            continue
        lo = max(va["val"], cva["val"]); hi = min(va["vah"], cva["vah"])
        inter = max(0.0, hi - lo)
        small = min(va["vah"] - va["val"], cva["vah"] - cva["val"]) or 1e-9
        if inter / small < overlap:
            break
        merged = list(d) + merged
        cva = value_area(merged, **kw)
    if cva is None:
        return None
    out = dict(cva)
    out["days"] = len(split_days(merged, now_utc)) if merged else 1
    return out


def value_migration(bars: list[dict], days: int = 3,
                    now_utc: datetime | None = None, **kw) -> dict:
    """Are the daily value areas stepping higher or lower?
    {"bias": +1|-1|0, "mids": [...], "days": n}. Needs `days` completed
    days; monotone mids in one direction = bias in that direction."""
    groups = split_days(bars, now_utc)[:-1]
    mids = []
    for d in groups[-days:]:
        va = value_area(d, **kw)
        if va:
            mids.append((va["val"] + va["vah"]) / 2)
    if len(mids) < 2:
        return {"bias": 0, "mids": mids, "days": len(mids)}
    up = all(b > a for a, b in zip(mids, mids[1:]))
    dn = all(b < a for a, b in zip(mids, mids[1:]))
    return {"bias": 1 if up else -1 if dn else 0, "mids": mids, "days": len(mids)}


# ── vwap / relative volume ───────────────────────────────────────────
def session_vwap(bars: list[dict], since_hour_utc: float | None = None,
                 now_utc: datetime | None = None) -> float | None:
    """Volume-weighted average price of today's bars (or of today's bars
    from `since_hour_utc` on, e.g. 13.5 for the US cash session)."""
    day0, off = _server_day(bars, now_utc)
    if not day0:
        return None
    start = day0
    if since_hour_utc is not None:
        # day0 is server-clock midnight; a UTC hour maps to server = utc + off
        start = day0 + int(since_hour_utc * 3600) + off
    pv = vv = 0.0
    for b in bars:
        try:
            t = int(b["time"])
        except Exception:  # noqa: BLE001
            continue
        if t < start:
            continue
        v = float(b.get("volume") or 0.0) or 1.0
        pv += v * (b["high"] + b["low"] + b["close"]) / 3.0
        vv += v
    return pv / vv if vv > 0 else None


def rel_volume(bars: list[dict], days: int = 5) -> float | None:
    """Last completed bar's volume / mean volume of the same time-of-day
    bar over the previous `days` days. 1.0 = normal, 2.0 = double."""
    if len(bars) < 3 or not bars[-2].get("time"):
        return None
    cur = bars[-2]
    try:
        tod = int(cur["time"]) % 86400
    except Exception:  # noqa: BLE001
        return None
    hist = [float(b.get("volume") or 0) for b in bars[:-2]
            if b.get("time") and int(b["time"]) % 86400 == tod]
    hist = hist[-days:]
    if not hist or sum(hist) <= 0:
        return None
    return (float(cur.get("volume") or 0)) / (sum(hist) / len(hist))


# ── structural targets ───────────────────────────────────────────────
def _pivots(bars: list[dict], k: int = 2) -> tuple[list[float], list[float]]:
    lows, highs = [], []
    for i in range(k, len(bars) - k):
        if bars[i]["low"] <= min(b["low"] for b in bars[i - k:i + k + 1]):
            lows.append(bars[i]["low"])
        if bars[i]["high"] >= max(b["high"] for b in bars[i - k:i + k + 1]):
            highs.append(bars[i]["high"])
    return lows, highs


def min_target_rr() -> float:
    try:
        return float(os.environ.get("SKLZ_MIN_TARGET_RR", "1.5"))
    except ValueError:
        return 1.5


def structural_target(bars: list[dict], side: int, entry: float, stop: float,
                      extra_levels: list[float] | None = None,
                      min_rr: float | None = None,
                      lvn_va: dict | None = None) -> tuple[float | None, str]:
    """Nearest opposing liquidity in the trade direction that pays min_rr.

    Liquidity = swing highs (for longs) / swing lows (for shorts) from
    k-bar pivots, plus any `extra_levels` (range edges, VA edges, PDH/PDL).
    If `lvn_va` is given and the target sits inside a HIGH-volume node the
    target is pulled to the node's near edge so the fill is realistic.
    Returns (price, why) — price None when nothing pays."""
    risk = abs(entry - stop)
    if risk <= 0:
        return None, "no risk defined"
    rr = min_rr if min_rr is not None else min_target_rr()
    lows, highs = _pivots(bars)
    cands = list(highs if side > 0 else lows) + list(extra_levels or [])
    cands = sorted({c for c in cands if (c - entry) * side > 0},
                   key=lambda v: abs(v - entry))
    for c in cands:
        if abs(c - entry) / risk < rr:
            continue
        tgt = c
        if lvn_va and lvn_va.get("buckets"):
            bk, step, lo = lvn_va["buckets"], lvn_va["step"], lvn_va["lo"]
            mean = sum(bk) / len(bk)
            i = min(len(bk) - 1, max(0, int((c - lo) / step)))
            if bk[i] > mean * 1.5:                     # thick node: stop short of it
                tgt = (lo + i * step) if side > 0 else (lo + (i + 1) * step)
                if abs(tgt - entry) / risk < rr:
                    continue
        return tgt, f"opposing liquidity at {tgt:.5f} pays {abs(tgt - entry) / risk:.1f}R"
    return None, f"no opposing liquidity pays {rr:.1f}R from {entry:.5f}"
