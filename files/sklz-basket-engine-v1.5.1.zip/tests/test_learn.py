import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from basket_engine.learn.capture import Journal, EntryRecord, snapshot, _session
from basket_engine.learn.entries import EntryController
from basket_engine.learn.scanners import SCANNERS, sweep_reversal, structure_break
from basket_engine.learn.review import summarize, _fallback
from datetime import datetime, timezone


def synth(a, b, n=30): return [a+(b-a)*i/(n-1) for i in range(n)]

class FakeIO:
    def __init__(self):
        self.equity=10000.0; self.series={}; self.prices={}; self.t=1; self.orders=[]
    def account(self): return {"equity":self.equity,"balance":self.equity}
    def closes(self,s,tf,n): return self.series.get(s,[])[-n:]
    def has_symbol(self,s): return s in self.series or s in self.prices
    def spec(self,s): return {"point":1e-4,"tick_value":1.0,"tick_size":1e-4,
        "lot_min":0.01,"lot_step":0.01,"lot_max":100.0,"digits":5}
    def price(self,s,side): return self.prices.get(s,1.0)
    def market(self,sym,side,lots,sl,comment):
        t=self.t; self.t+=1
        self.orders.append({"symbol":sym,"side":side,"lots":lots,"ticket":t})
        return {"ok":True,"ticket":t,"price":self.price(sym,side)}


def test_session_buckets():
    assert _session(datetime(2026,7,18,9,tzinfo=timezone.utc))=="london"
    assert _session(datetime(2026,7,18,14,tzinfo=timezone.utc))=="london_ny_overlap"
    assert _session(datetime(2026,7,18,18,tzinfo=timezone.utc))=="newyork"


def test_forced_entry_records_note(tmp_path):
    io=FakeIO(); io.series={"EURUSD":synth(1.0,1.02)}; io.prices={"EURUSD":1.02}
    j=Journal(str(tmp_path/"j.jsonl"))
    ec=EntryController(io,j)
    rec=ec.forced_entry("EURUSD",+1,"London sweep + USD weak")
    assert rec and rec.source=="forced" and rec.note=="London sweep + USD weak"
    assert io.orders and rec.ticket==io.orders[0]["ticket"]
    rows=j.load_day()
    assert any(r["type"]=="entry" and r["note"]=="London sweep + USD weak" for r in rows)


def test_auto_entry_tagged(tmp_path):
    io=FakeIO(); io.series={"EURUSD":synth(1.0,1.02)}; io.prices={"EURUSD":1.02}
    j=Journal(str(tmp_path/"j.jsonl"))
    ec=EntryController(io,j)
    rec=ec.auto_entry("sweep_reversal","EURUSD",-1,"swept highs")
    assert rec.source=="auto" and rec.strategy=="sweep_reversal"


def test_reconcile_stitches_outcome(tmp_path):
    io=FakeIO(); io.series={"EURUSD":synth(1.0,1.02)}; io.prices={"EURUSD":1.02}
    j=Journal(str(tmp_path/"j.jsonl"))
    ec=EntryController(io,j)
    rec=ec.forced_entry("EURUSD",+1,"test")
    j.record_exit(rec.ticket, 1.03, 42.0)
    closed=j.reconcile()
    assert closed[0]["outcome"]=="win" and closed[0]["pnl"]==42.0


def test_scanners_fire():
    io=FakeIO()
    # 26 bars: flat base, poke above the prior max, then reject down
    base=[1.00+0.0001*i for i in range(28)]   # 28 bars, max ~1.0027
    io.series={"EURUSD":base+[1.010, 1.004]}  # 30 total; prev poke>max, last<prev
    io.prices={"EURUSD":1.004}
    r=sweep_reversal(io,"EURUSD",60,24)
    assert r is not None and r[0]==-1, r
    # clean break up: flat window then a close above it (need lookback+2=26)
    io.series={"EURUSD":[1.00]*27+[1.05]}
    r2=structure_break(io,"EURUSD",60,24)
    assert r2 is not None and r2[0]==+1, r2


def test_summarize_forced_vs_auto():
    closed=[
        {"source":"forced","strategy":"sweep","outcome":"win","pnl":50,"state":{"session":"london"}},
        {"source":"forced","strategy":"sweep","outcome":"win","pnl":30,"state":{"session":"london"}},
        {"source":"auto","strategy":"sweep_reversal","outcome":"loss","pnl":-20,"state":{"session":"off"}},
        {"source":"auto","strategy":"sweep_reversal","outcome":"win","pnl":10,"state":{"session":"off"}},
    ]
    s=summarize(closed)
    assert s["by_source"]["forced"]["win_rate"]==1.0
    assert s["by_source"]["auto"]["win_rate"]==0.5
    fb=_fallback(s)
    assert "forced 100%" in fb["forced_vs_auto"] and "auto 50%" in fb["forced_vs_auto"]


def test_review_never_proposes_without_ai():
    # fallback must return empty proposals, never auto-changes
    s=summarize([{"source":"forced","outcome":"win","pnl":5,"state":{}}])
    fb=_fallback(s)
    assert fb["proposals"]==[]
