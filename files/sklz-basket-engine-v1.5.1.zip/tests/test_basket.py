import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from basket_engine.strength import currency_strength, rank, pair_for, roc
from basket_engine.manager import BasketManager, Config
from basket_engine.mt5io import BasketIO


# ────────────────────────── strength engine ──────────────────────────
def synth(start, end, n=30):
    return [start + (end - start) * i / (n - 1) for i in range(n)]

def test_roc():
    assert abs(roc([100]*10 + [110], 10) - 0.10) < 1e-9
    assert roc([100], 10) == 0.0

def test_usd_weak_detected():
    data = {  # everything rising vs USD, USD pairs falling
        "EURUSD": synth(1.00, 1.02), "GBPUSD": synth(1.20, 1.23),
        "AUDUSD": synth(0.60, 0.61), "USDJPY": synth(150, 147),
        "USDCHF": synth(0.90, 0.885),
    }
    s = currency_strength(data, 24)
    assert s["USD"] < 0, s
    ranked = rank(s)
    assert ranked[-1][0] == "USD" or s["USD"] < -0.005

def test_pair_for():
    avail = {"EURUSD", "GBPJPY"}
    assert pair_for("EUR", "USD", avail) == ("EURUSD", 1)
    assert pair_for("USD", "EUR", avail) == ("EURUSD", -1)
    assert pair_for("JPY", "GBP", avail) == ("GBPJPY", -1)
    assert pair_for("AUD", "CAD", avail) is None


# ────────────────────────── fake MT5 world ──────────────────────────
class FakeIO:
    """Implements the BasketIO surface with a controllable world."""
    def __init__(self):
        self.equity = 10000.0
        self.prices = {}
        self.series = {}
        self.positions = []
        self.next_ticket = 1
        self.closed = []
    def account(self): return {"equity": self.equity, "balance": self.equity}
    def closes(self, s, tf, n): return self.series.get(s, [])[-n:]
    def has_symbol(self, s): return s in self.series or s in self.prices
    def spec(self, s): return {"point": 0.0001, "tick_value": 1.0,
        "tick_size": 0.0001, "lot_min": 0.01, "lot_step": 0.01,
        "lot_max": 100.0, "digits": 5}
    def price(self, s, side): return self.prices.get(s, 1.0)
    def my_positions(self): return list(self.positions)
    def basket_profit(self): return sum(p["profit"] for p in self.positions)
    def market(self, symbol, side, lots, sl, comment):
        t = self.next_ticket; self.next_ticket += 1
        self.positions.append({"ticket": t, "symbol": symbol, "side": side,
            "lots": lots, "open_price": self.price(symbol, side),
            "profit": 0.0, "comment": comment})
        return {"ok": True, "ticket": t, "price": self.price(symbol, side)}
    def close(self, pos):
        self.positions = [p for p in self.positions if p["ticket"] != pos["ticket"]]
        self.closed.append(pos); return True
    def close_all(self):
        n = len(self.positions); self.closed += self.positions
        self.positions = []; return n


def usd_weak_world():
    io = FakeIO()
    io.series = {
        "EURUSD": synth(1.00, 1.03), "GBPUSD": synth(1.20, 1.24),
        "AUDUSD": synth(0.60, 0.615), "NZDUSD": synth(0.55, 0.565),
        "USDJPY": synth(150, 145), "USDCHF": synth(0.90, 0.88),
        "USDCAD": synth(1.36, 1.34),
    }
    io.prices = {s: v[-1] for s, v in io.series.items()}
    return io


# ────────────────────────── basket lifecycle ──────────────────────────
def test_usd_basket_opens_5_legs_correct_directions():
    io = usd_weak_world()
    m = BasketManager(io, Config(mode="usd_basket"), log=lambda *_: None)
    assert m.try_open()
    sides = {p["symbol"]: p["side"] for p in io.positions}
    assert sides["EURUSD"] == 1 and sides["GBPUSD"] == 1 and sides["AUDUSD"] == 1
    assert sides["USDJPY"] == -1 and sides["USDCHF"] == -1
    assert len(io.positions) == 5

def test_no_entry_when_flat():
    io = usd_weak_world()
    io.series = {s: synth(1.0, 1.0001) for s in io.series}   # dead market
    m = BasketManager(io, Config(mode="usd_basket"), log=lambda *_: None)
    assert not m.try_open()

def test_basket_tp_closes_all():
    io = usd_weak_world()
    m = BasketManager(io, Config(mode="usd_basket", basket_tp_pct=1.0),
                      log=lambda *_: None)
    m.try_open()
    for p in io.positions: p["profit"] = 25.0    # 5 x 25 = 125 > 100 (1%)
    reason = m.manage()
    assert reason and "TP" in reason and len(io.positions) == 0
    assert not m.st.open

def test_basket_sl_closes_all():
    io = usd_weak_world()
    m = BasketManager(io, Config(mode="usd_basket", basket_sl_pct=1.0),
                      log=lambda *_: None)
    m.try_open()
    for p in io.positions: p["profit"] = -25.0
    reason = m.manage()
    assert reason and "SL" in reason and len(io.positions) == 0

def test_breakeven_protect():
    io = usd_weak_world()
    m = BasketManager(io, Config(mode="usd_basket", basket_tp_pct=1.0,
                                 be_arm=0.5), log=lambda *_: None)
    m.try_open()
    for p in io.positions: p["profit"] = 12.0    # 60 >= 50 -> BE armed
    assert m.manage() is None and m.st.be_armed
    for p in io.positions: p["profit"] = -0.5    # sinks to <= 0
    reason = m.manage()
    assert reason and "breakeven" in reason and len(io.positions) == 0

def test_trail_giveback():
    io = usd_weak_world()
    m = BasketManager(io, Config(mode="usd_basket", basket_tp_pct=2.0,
                                 trail_arm=0.4, trail_giveback=0.4),
                      log=lambda *_: None)
    m.try_open()
    for p in io.positions: p["profit"] = 18.0    # 90 >= 80 (=200*0.4) arm trail
    assert m.manage() is None and m.st.trail_armed
    for p in io.positions: p["profit"] = 10.0    # 50 <= 90*(1-0.4)=54 -> close
    reason = m.manage()
    assert reason and "trail" in reason and len(io.positions) == 0

def test_cooldown_blocks_reentry():
    io = usd_weak_world()
    m = BasketManager(io, Config(mode="usd_basket", cooldown_bars=6),
                      log=lambda *_: None)
    m.try_open()
    for p in io.positions: p["profit"] = 100.0
    m.manage()
    assert not m.try_open()                      # cooling down
    m.st.bar_index += 10
    assert m.try_open()                          # cooldown passed

def test_metals_alignment():
    io = FakeIO()
    io.series = {"XAUUSD": synth(2000, 2040), "XAGUSD": synth(25, 25.6),
                 "XPTUSD": synth(900, 918)}
    io.prices = {s: v[-1] for s, v in io.series.items()}
    m = BasketManager(io, Config(mode="metals"), log=lambda *_: None)
    assert m.try_open()
    assert all(p["side"] == 1 for p in io.positions) and len(io.positions) == 3

def test_metals_no_entry_on_conflict():
    io = FakeIO()
    io.series = {"XAUUSD": synth(2000, 2040), "XAGUSD": synth(25, 24.4),
                 "XPTUSD": synth(900, 918)}
    io.prices = {s: v[-1] for s, v in io.series.items()}
    m = BasketManager(io, Config(mode="metals"), log=lambda *_: None)
    assert not m.try_open()                      # silver disagrees -> no basket

def test_strength_hedge_picks_extremes():
    io = usd_weak_world()
    for s, (a, b) in {"EURJPY": (160, 167), "EURGBP": (0.84, 0.842),
                      "GBPJPY": (185, 192), "AUDJPY": (95, 97)}.items():
        io.series[s] = synth(a, b); io.prices[s] = b   # 11 pairs total
    m = BasketManager(io, Config(mode="strength_hedge"), log=lambda *_: None)
    ok = m.try_open()
    assert ok and len(io.positions) == 1

def test_orphan_adoption():
    io = usd_weak_world()
    io.positions = [{"ticket": 9, "symbol": "EURUSD", "side": 1, "lots": 0.1,
                     "open_price": 1.0, "profit": 5.0, "comment": "old"}]
    m = BasketManager(io, Config(), log=lambda *_: None)
    m.adopt_orphans()
    assert m.st.open and len(m.st.legs) == 1

def test_sizing_respects_risk():
    io = usd_weak_world()
    m = BasketManager(io, Config(basket_risk_pct=1.0), log=lambda *_: None)
    lots = m._size_leg("EURUSD", 0.2, 0.0050)    # $20 risk over 50 pips
    # 20 / (0.0050/0.0001 * 1.0) = 0.4 lots
    assert abs(lots - 0.4) < 0.011
