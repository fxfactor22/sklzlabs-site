"""SKLZ Learning Runner — entry point.

    set SKLZ_API_URL=https://api.sklzlabs.com
    set SKLZ_BOT_KEY=...
    set ANTHROPIC_API_KEY=...            (for AI review; optional)
    python learn_main.py

DEMO ONLY. Trades are placed on whatever MT5 terminal is open & logged in.
The AI review PROPOSES parameter changes; it never applies them.
"""
from __future__ import annotations

import os
import threading
import time
from datetime import datetime, timezone

from basket_engine import MAGIC
from basket_engine.mt5io import BasketIO
from basket_engine.telemetry import Telemetry
from basket_engine.learn.runner import LearningRunner

BANNER = """
╔══════════════════════════════════════════════════════════════╗
║  SKLZ LEARNING RUNNER — DEMO ONLY                            ║
║  Learns from YOUR entries (with notes) + scanner hypotheses. ║
║  End-of-day AI PROPOSES changes — you decide. Never auto-set.║
╚══════════════════════════════════════════════════════════════╝
Commands:
  buy  EURUSD  <your reason>      forced BUY with a note the AI will learn from
  sell GBPUSD  <your reason>      forced SELL with a note
  scan                            run famous-strategy scanners once
  auto on | auto off              toggle automatic scanner entries
  review                          run the end-of-day AI review now
  journal                         push today's trades to your SKLZ Journal
  status                          positions + today's tally
  quit
"""


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--auto", action="store_true",
                    help="scanners place entries automatically")
    ap.add_argument("--headless", action="store_true",
                    help="no interactive prompt (for the auto-restart wrapper)")
    args = ap.parse_args()

    print(BANNER)
    io = BasketIO(MAGIC)
    acct = io.connect()
    if not acct.get("demo", True):
        print("!! LIVE ACCOUNT — learning runner is demo-only. Exiting.")
        return
    print(f"connected: {acct['login']} @ {acct['server']} "
          f"(equity {acct['equity']:.2f} {acct['currency']}, DEMO)")

    runner = LearningRunner(io, auto=args.auto)
    if args.auto: print('AUTO mode: scanners will place demo entries.')
    tel = Telemetry("Learning Runner [demo]", "MULTI", "demo")
    if tel.enabled:
        print("telemetry: SKLZ dashboard connected")

    stop = threading.Event()

    def background():
        last_hb = last_scan = 0.0
        while not stop.is_set():
            now = time.time()
            try:
                runner.sync_exits()
                if now - last_scan > 60:
                    runner.scan_once()
                    last_scan = now
                if now - last_hb > 30 and tel.enabled:
                    a = io.account()
                    from basket_engine.learn.review import summarize
                    s = summarize(runner.journal.reconcile())
                    tel.heartbeat(a.get("equity", 0), a.get("balance", 0),
                                  {"trades_today": s["trades"],
                                   "win_rate": s["win_rate"],
                                   "pnl_today": s["total_pnl"],
                                   "auto": runner.auto})
                    last_hb = now
            except Exception as exc:  # noqa: BLE001
                print(f"[bg] {type(exc).__name__}: {exc}")
            stop.wait(5)

    t = threading.Thread(target=background, daemon=True)
    t.start()

    if args.headless:
        # unattended: run until killed, auto-review once per day at ~21:00 UTC
        print("headless mode — Ctrl+C to stop. Daily review at ~21:00 UTC.\n")
        last_review_day = None
        try:
            while True:
                now = datetime.now(timezone.utc)
                if now.hour == 21 and now.strftime("%Y-%m-%d") != last_review_day:
                    runner.review()
                    last_review_day = now.strftime("%Y-%m-%d")
                time.sleep(30)
        except (KeyboardInterrupt, EOFError):
            stop.set()
            runner.review()
            print("stopped.")
        return

    print("ready. Type commands (or 'quit'). Background scan + telemetry running.\n")

    try:
        while True:
            line = input("> ").strip()
            if not line:
                continue
            parts = line.split()
            cmd = parts[0].lower()
            if cmd == "quit":
                break
            elif cmd == "buy":
                runner.cmd_buy(parts)
            elif cmd == "sell":
                runner.cmd_sell(parts)
            elif cmd == "scan":
                n = runner.scan_once()
                print(f"  scan complete ({n} auto-entries)" if runner.auto
                      else "  scan complete (auto OFF — signals logged, not traded)")
            elif cmd == "auto" and len(parts) > 1:
                runner.auto = parts[1].lower() == "on"
                print(f"  auto-entries {'ON' if runner.auto else 'OFF'}")
            elif cmd == "review":
                runner.review()
            elif cmd == "journal":
                from basket_engine.learn import journal_push
                closed = runner.journal.reconcile()
                journal_push.push(closed, log=print)
            elif cmd == "status":
                runner.status()
            else:
                print("  unknown command — buy/sell/scan/auto/review/status/quit")
    except (KeyboardInterrupt, EOFError):
        pass
    finally:
        stop.set()
        print("\nrunning end-of-day review before exit...")
        try:
            runner.review()
        except Exception as exc:  # noqa: BLE001
            print(f"review skipped: {exc}")
        print("stopped. Open trades remain in MT5.")


if __name__ == "__main__":
    main()
