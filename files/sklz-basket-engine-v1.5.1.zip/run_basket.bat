@echo off
title SKLZ Basket Engine
cd /d "%~dp0"
if "%SKLZ_BOT_KEY%"=="" (
  echo Set your keys first in THIS window:
  echo   set SKLZ_API_URL=https://api.sklzlabs.com
  echo   set SKLZ_BOT_KEY=your-key
  echo Then run:  run_basket.bat usd_basket
  exit /b 1
)
set MODE=%1
if "%MODE%"=="" set MODE=usd_basket
python -m basket_engine.main --mode %MODE%
