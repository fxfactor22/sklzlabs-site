SKLZ BASKET ENGINE v1.0.0 — DEMO ONLY, UNVALIDATED
===================================================
Trades baskets as ONE strategy: entries open all legs together; exits fire
on AGGREGATE basket P/L (basket TP / SL / breakeven / trail). No leg is
managed alone. Magic number 771005 — never touches other bots' positions.

MODES
  usd_basket       one USD view through 5 pairs (EUR/GBP/AUD longs vs
                   USDJPY/USDCHF shorts, or the mirror when USD is strong)
  metals           XAU + XAG (+XPT if available), entered only when their
                   momentum AGREES — a conflict means no basket
  strength_hedge   long the strongest major vs short the weakest via their
                   cross — market-direction exposure minimised

INSTALL (Windows VPS, beside the bot runner)
  1. Unzip to Downloads\sklz-basket-engine
  2. MT5 open and logged in (demo)
  3. Command Prompt:
       cd /d "%USERPROFILE%\Downloads\sklz-basket-engine"
       set SKLZ_API_URL=https://api.sklzlabs.com
       set SKLZ_BOT_KEY=<your key>
       python -m basket_engine.main --mode usd_basket
  Options: --risk 1.0  --tp 1.0  --sl 1.0   (all % of equity, basket-level)

DASHBOARD
  Appears in the SKLZ Bot Monitor as its own session
  ("Basket — USD Currency Basket [demo]") with per-leg P/L, basket P/L,
  peak, and armed protections in the live stats.

HONESTY
  Refuses live accounts. Journals every open/close to basket_journal.jsonl
  for the daily AI review. Nothing here is validated — the demo period and
  the journal exist to earn (or deny) that validation.

  Ctrl+C stops the ENGINE ONLY — open legs stay in MT5 and are adopted
  automatically on relaunch.
