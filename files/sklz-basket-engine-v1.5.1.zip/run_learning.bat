@echo off
REM ── SKLZ Learning Runner — auto-restart wrapper ──
REM Relaunches the runner if it crashes or the VPS reboots. Because it takes
REM interactive commands, this wrapper runs it in AUTO mode (scanners fire on
REM their own) so it collects data unattended. For manual tagged entries, run
REM learn_main.py directly in a normal window instead.
title SKLZ Learning Runner (auto-restart)
cd /d "%~dp0"

if "%SKLZ_BOT_KEY%"=="" (
  echo Set your environment first, e.g.:
  echo   set SKLZ_API_URL=https://api.sklzlabs.com
  echo   set SKLZ_BOT_KEY=your-key
  echo   set ANTHROPIC_API_KEY=your-key
  echo Then run: run_learning.bat
  pause
  exit /b 1
)

:loop
echo [%date% %time%] starting learning runner (auto mode)...
python learn_main.py --auto --headless
echo [%date% %time%] runner exited. Restarting in 15s (Ctrl+C to stop)...
timeout /t 15 /nobreak >nul
goto loop
