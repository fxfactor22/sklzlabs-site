@echo off
REM Registers the learning runner to start automatically when the VPS boots.
REM Run this ONCE (double-click or from Command Prompt). Requires the env vars
REM to be set as SYSTEM/USER variables (not just session) so they survive reboot.
set TASKNAME=SKLZ_Learning_Runner
schtasks /create /tn "%TASKNAME%" /tr "\"%~dp0run_learning.bat\"" /sc onlogon /rl highest /f
echo.
echo Task "%TASKNAME%" installed — the learning runner will start on next logon.
echo IMPORTANT: set SKLZ_API_URL, SKLZ_BOT_KEY, ANTHROPIC_API_KEY as PERSISTENT
echo user variables (System Properties - Environment Variables), or the wrapper
echo will stop and ask for them. To remove: schtasks /delete /tn "%TASKNAME%" /f
pause
