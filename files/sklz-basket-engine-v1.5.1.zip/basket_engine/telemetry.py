"""Dashboard telemetry — same API contract as the main runner, so the basket
appears in the SKLZ Bot Monitor as its own live session."""
from __future__ import annotations

import json
import os
import urllib.request


class Telemetry:
    def __init__(self, bot_label: str, symbol_label: str, mode: str) -> None:
        self.api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        self.key = os.environ.get("SKLZ_BOT_KEY", "")
        self.bot = bot_label
        self.symbol = symbol_label
        self.mode = mode
        self.session_id = None
        self.enabled = bool(self.api and self.key)

    def _post(self, path: str, payload: dict) -> dict | None:
        if not self.enabled:
            return None
        try:
            req = urllib.request.Request(
                self.api + path, data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {self.key}"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except Exception as exc:  # noqa: BLE001 — never kill trading for telemetry
            print(f"[telemetry] {type(exc).__name__}: {exc}")
            return None

    def heartbeat(self, equity: float, balance: float, stats: dict) -> None:
        res = self._post("/api/bot/heartbeat", {
            "session_id": self.session_id, "bot": self.bot,
            "symbol": self.symbol, "timeframe": "H1", "mode": self.mode,
            "equity": equity, "balance": balance, "stats": stats})
        if res and res.get("session_id"):
            self.session_id = res["session_id"]

    def event(self, kind: str, message: str, data: dict | None = None) -> None:
        if self.session_id:
            self._post("/api/bot/events", {
                "session_id": self.session_id,
                "events": [{"kind": kind, "message": message,
                            "data": data or {}}]})
