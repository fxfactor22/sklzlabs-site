"""SKLZ Learning Layer — captures entries (yours + the bot's) with full market
state, then reviews the day with AI to PROPOSE (never auto-apply) improvements.

Design principle, non-negotiable:
    The AI proposes. You dispose. Nothing here mutates live parameters.
    Every suggestion is validated against the recorded journal and presented
    for morning approval — because auto-tuning against past trades is
    curve-fitting, and your own 27M-tick research is why we don't trust it blind.
"""
