"""The 'famous strategies' as opportunity scanners.

Each returns (side, detail) or None. These are HYPOTHESES: your own 27M-tick
research showed them at coin-flip out-of-sample, so we log their entries to
MEASURE them against your discretionary entries — not because we trust them.
"""
from __future__ import annotations


def _closes(io, sym, tf, n):
    return io.closes(sym, tf, n)


def sweep_reversal(io, symbol, tf_min, lookback):
    """Liquidity sweep: price pokes beyond the recent extreme then reverses."""
    c = _closes(io, symbol, tf_min, lookback + 3)
    if len(c) < lookback + 3:
        return None
    # the extreme is the RANGE BEFORE the poke: exclude the last two bars
    body = c[:-2]
    hi, lo = max(body), min(body)
    prev, last = c[-2], c[-1]          # prev = the poke bar, last = the reaction
    if prev > hi and last < prev:      # swept highs, rejected down
        return (-1, f"sweep of highs {hi:.5f} then rejection")
    if prev < lo and last > prev:      # swept lows, rejected up
        return (+1, f"sweep of lows {lo:.5f} then rejection")
    return None


def structure_break(io, symbol, tf_min, lookback):
    """Market-structure shift: close breaks the prior swing with momentum."""
    c = _closes(io, symbol, tf_min, lookback + 2)
    if len(c) < lookback + 2:
        return None
    window = c[-lookback-1:-1]
    hi, lo = max(window), min(window)
    if c[-1] > hi:
        return (+1, f"break of structure above {hi:.5f}")
    if c[-1] < lo:
        return (-1, f"break of structure below {lo:.5f}")
    return None


def strength_extreme(io, symbol, tf_min, lookback):
    """Currency-strength: enter the strongest-vs-weakest in the symbol's legs."""
    from basket_engine.strength import currency_strength, rank, PAIRS
    if len(symbol) < 6:
        return None
    base, quote = symbol[:3], symbol[3:6]
    avail = {p for p in PAIRS if io.has_symbol(p)}
    data = {p: io.closes(p, tf_min, lookback+2) for p in avail}
    data = {p: c for p, c in data.items() if len(c) > lookback}
    if len(data) < 6:
        return None
    s = currency_strength(data, lookback)
    if base not in s or quote not in s:
        return None
    diff = s[base] - s[quote]
    if diff > 0.002:
        return (+1, f"{base} stronger than {quote} ({diff:+.4f})")
    if diff < -0.002:
        return (-1, f"{base} weaker than {quote} ({diff:+.4f})")
    return None


SCANNERS = {
    "sweep_reversal": sweep_reversal,
    "structure_break": structure_break,
    "strength_extreme": strength_extreme,
}
