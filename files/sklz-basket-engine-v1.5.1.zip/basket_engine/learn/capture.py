"""Market-state capture — the heart of learning from YOUR entries.

At the instant of any entry (forced-by-you or auto-by-scanner) we snapshot the
full state so the end-of-day review has something real to reason over. The
richer the snapshot, the better the AI can find what your winning entries share.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone

from basket_engine.strength import currency_strength, rank


@dataclass
class MarketState:
    """Everything true about the market at entry time."""
    ts: str
    symbol: str
    session: str                      # sydney|tokyo|london|newyork|off
    strength: dict = field(default_factory=dict)     # per-currency
    strongest: str = ""
    weakest: str = ""
    volatility: float = 0.0           # ATR-proxy, fraction
    regime: str = ""                  # trending|ranging|volatile
    price: float = 0.0
    roc_fast: float = 0.0             # short-window momentum
    roc_slow: float = 0.0             # long-window momentum


@dataclass
class EntryRecord:
    """One entry, its origin, your reasoning, and (later) its outcome."""
    ts: str
    source: str                       # "forced" | "auto"
    strategy: str                     # tag: your note key OR scanner name
    symbol: str
    side: int                         # +1 buy / -1 sell
    lots: float
    entry_price: float
    note: str = ""                    # YOUR reason (forced) or scanner detail
    state: dict = field(default_factory=dict)
    # filled at exit:
    exit_price: float | None = None
    exit_ts: str | None = None
    pnl: float | None = None
    outcome: str | None = None        # "win" | "loss" | "flat"
    ticket: int | None = None


def _session(now: datetime) -> str:
    h = now.hour  # UTC
    if 22 <= h or h < 7:  return "sydney_tokyo"
    if 7 <= h < 12:       return "london"
    if 12 <= h < 16:      return "london_ny_overlap"
    if 16 <= h < 21:      return "newyork"
    return "off"


def snapshot(io, symbol: str, tf_min: int, lookback: int) -> MarketState:
    """Build a MarketState from live IO. Pure enough to test with a fake IO."""
    from basket_engine.strength import PAIRS
    now = datetime.now(timezone.utc)
    avail = {p for p in PAIRS if io.has_symbol(p)}
    data = {p: io.closes(p, tf_min, lookback + 2) for p in avail}
    data = {p: c for p, c in data.items() if len(c) > lookback}
    strength = currency_strength(data, lookback) if len(data) >= 6 else {}
    ranked = rank(strength) if strength else []
    closes = io.closes(symbol, tf_min, lookback + 2)
    price = closes[-1] if closes else 0.0
    roc_fast = (closes[-1]/closes[-4]-1) if len(closes) > 4 else 0.0
    roc_slow = (closes[-1]/closes[-1-lookback]-1) if len(closes) > lookback else 0.0
    # volatility proxy
    diffs = [abs(b-a) for a, b in zip(closes, closes[1:])] if len(closes) > 2 else [0]
    atr = sum(diffs)/len(diffs) if diffs else 0.0
    vol = atr/price if price else 0.0
    regime = ("volatile" if vol > 0.004 else
              "trending" if abs(roc_slow) > 0.003 else "ranging")
    return MarketState(
        ts=now.isoformat(), symbol=symbol, session=_session(now),
        strength={k: round(v, 5) for k, v in strength.items()},
        strongest=ranked[0][0] if ranked else "",
        weakest=ranked[-1][0] if ranked else "",
        volatility=round(vol, 5), regime=regime, price=price,
        roc_fast=round(roc_fast, 5), roc_slow=round(roc_slow, 5))


class Journal:
    """Append-only entry journal. One file; the AI review reads it whole."""
    def __init__(self, path: str) -> None:
        self.path = path
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

    def record_entry(self, rec: EntryRecord) -> None:
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps({"type": "entry", **asdict(rec)}) + "\n")

    def record_exit(self, ticket: int, exit_price: float, pnl: float) -> None:
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps({
                "type": "exit", "ticket": ticket,
                "ts": datetime.now(timezone.utc).isoformat(),
                "exit_price": exit_price, "pnl": pnl,
                "outcome": "win" if pnl > 0 else "loss" if pnl < 0 else "flat",
            }) + "\n")

    def load_day(self, day: str | None = None) -> list[dict]:
        if not os.path.exists(self.path):
            return []
        day = day or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        out = []
        with open(self.path, encoding="utf-8") as f:
            for line in f:
                try:
                    r = json.loads(line)
                    if r.get("ts", "").startswith(day):
                        out.append(r)
                except json.JSONDecodeError:
                    continue
        return out

    def reconcile(self, day: str | None = None) -> list[dict]:
        """Stitch exits onto their entries by ticket -> closed EntryRecords."""
        rows = self.load_day(day)
        entries = {r["ticket"]: r for r in rows
                   if r["type"] == "entry" and r.get("ticket")}
        for r in rows:
            if r["type"] == "exit" and r["ticket"] in entries:
                e = entries[r["ticket"]]
                e.update(exit_price=r["exit_price"], exit_ts=r["ts"],
                         pnl=r["pnl"], outcome=r["outcome"])
        return list(entries.values())
