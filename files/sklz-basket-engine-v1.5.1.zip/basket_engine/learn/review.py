"""End-of-day AI review — PROPOSES improvements, applies NOTHING.

Reads the day's reconciled entries (yours + scanners, with outcomes) and asks
Claude to compare your discretionary reads against the scanner hypotheses and
suggest parameter changes — lot size, SL/TP multiples, which strategy earned
its keep, which scanner setting would catch better entries.

Output is a report + a list of PROPOSED changes with reasoning. A human
approves them the next morning. Auto-tuning against past trades is
curve-fitting; the whole architecture refuses it on purpose.
"""
from __future__ import annotations

import json
import os
from collections import defaultdict


def summarize(closed: list[dict]) -> dict:
    """Deterministic stats the AI (and you) can trust — no model needed."""
    by_source = defaultdict(lambda: {"n": 0, "wins": 0, "pnl": 0.0})
    by_strategy = defaultdict(lambda: {"n": 0, "wins": 0, "pnl": 0.0})
    by_session = defaultdict(lambda: {"n": 0, "wins": 0, "pnl": 0.0})
    for e in closed:
        if e.get("outcome") is None:
            continue
        w = 1 if e["outcome"] == "win" else 0
        pnl = e.get("pnl") or 0.0
        for bucket, key in ((by_source, e.get("source", "?")),
                            (by_strategy, e.get("strategy", "?")),
                            (by_session, (e.get("state") or {}).get("session", "?"))):
            bucket[key]["n"] += 1
            bucket[key]["wins"] += w
            bucket[key]["pnl"] += pnl

    def rate(d):
        return {k: {"n": v["n"],
                    "win_rate": round(v["wins"]/v["n"], 3) if v["n"] else 0,
                    "pnl": round(v["pnl"], 2)} for k, v in d.items()}

    total = [e for e in closed if e.get("outcome")]
    wins = sum(1 for e in total if e["outcome"] == "win")
    return {
        "trades": len(total),
        "win_rate": round(wins/len(total), 3) if total else 0,
        "total_pnl": round(sum(e.get("pnl") or 0 for e in total), 2),
        "by_source": rate(by_source),
        "by_strategy": rate(by_strategy),
        "by_session": rate(by_session),
    }


REVIEW_SYSTEM = """You are the SKLZ end-of-day trading review. You analyze one \
day of demo trades from two sources: "forced" (the trader's own discretionary \
entries, each with a note explaining their reasoning) and "auto" (scanner \
entries from famous strategies like sweeps and structure breaks).

Critical context you must honor:
- SKLZ's own research on 27M ticks showed the famous strategies (SMC/ICT/\
order-flow) perform at coin-flip out-of-sample. Treat scanner ("auto") entries \
as hypotheses being measured, NOT as validated edges.
- The trader's discretionary ("forced") entries may contain real edge that \
fixed rules miss. A central question every day: are the forced entries \
outperforming the auto scanners? If so, WHAT do the winning forced entries \
share (session, strength alignment, regime, the trader's notes)?
- You PROPOSE changes; you never apply them. Every suggestion needs a reason \
grounded in the day's data and a caution that one day is a tiny sample.
- Never promise profit. Never suggest removing risk controls. If the sample is \
too small (<5 trades in a bucket) say so rather than over-concluding.

Return STRICT JSON only:
{
 "headline": "one honest sentence on the day",
 "forced_vs_auto": "what the comparison shows, with the numbers",
 "winning_pattern": "what the trader's winning entries share, or 'insufficient data'",
 "proposals": [
   {"change":"lot_size|sl_mult|tp_mult|scanner_setting|strategy_focus",
    "suggestion":"concrete change",
    "reason":"grounded in today's data",
    "confidence":"low|medium|high",
    "caution":"the risk or sample caveat"}
 ],
 "note_to_trader": "one honest coaching line"
}"""


def build_prompt(stats: dict, closed: list[dict]) -> str:
    trimmed = [{
        "source": e["source"], "strategy": e["strategy"], "symbol": e["symbol"],
        "side": e["side"], "note": e.get("note", ""),
        "outcome": e.get("outcome"), "pnl": e.get("pnl"),
        "session": (e.get("state") or {}).get("session"),
        "regime": (e.get("state") or {}).get("regime"),
        "strongest": (e.get("state") or {}).get("strongest"),
        "weakest": (e.get("state") or {}).get("weakest"),
    } for e in closed if e.get("outcome")]
    return (f"Day statistics (deterministic):\n{json.dumps(stats, indent=2)}\n\n"
            f"All closed entries with the trader's notes:\n"
            f"{json.dumps(trimmed, indent=2)}\n\n"
            f"Produce the review JSON.")


def ai_review(stats: dict, closed: list[dict]) -> dict:
    """Call Claude if a key is present; otherwise return a deterministic
    fallback so the review NEVER hard-fails on the VPS."""
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key or not closed:
        return _fallback(stats)
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)
        msg = client.messages.create(
            model="claude-sonnet-4-6", max_tokens=1400,
            system=REVIEW_SYSTEM,
            messages=[{"role": "user", "content": build_prompt(stats, closed)}])
        text = "".join(b.text for b in msg.content if b.type == "text")
        text = text.strip().removeprefix("```json").removeprefix("```").removesuffix("```")
        return json.loads(text)
    except Exception as exc:  # noqa: BLE001
        fb = _fallback(stats)
        fb["headline"] = f"(AI review unavailable: {type(exc).__name__}) " + fb["headline"]
        return fb


def _fallback(stats: dict) -> dict:
    """No-AI review: still gives the honest forced-vs-auto comparison."""
    src = stats.get("by_source", {}) or {}
    f = src.get("forced", {}) or {}
    a = src.get("auto", {}) or {}
    cmp = "insufficient data"
    if f.get("n") and a.get("n"):
        cmp = (f"forced {f['win_rate']:.0%} ({f['n']}) vs "
               f"auto {a['win_rate']:.0%} ({a['n']})")
    return {
        "headline": f"{stats.get('trades',0)} trades, "
                    f"{stats.get('win_rate',0):.0%} win, "
                    f"{stats.get('total_pnl',0):+.2f} P/L",
        "forced_vs_auto": cmp,
        "winning_pattern": "insufficient data" if stats.get("trades",0) < 5 else
                           "set ANTHROPIC_API_KEY for pattern analysis",
        "proposals": [],
        "note_to_trader": "Deterministic summary only — add ANTHROPIC_API_KEY "
                          "for AI suggestions. One day is a tiny sample; keep logging.",
    }
