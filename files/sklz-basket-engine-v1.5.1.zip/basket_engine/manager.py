"""BasketManager — the aggregate brain.

Modes (mapped 1:1 to the classic basket types):
  usd_basket      Currency basket: one view on USD expressed through 5 pairs.
                  USD weak  -> BUY EURUSD/GBPUSD/AUDUSD, SELL USDJPY/USDCHF.
                  USD strong -> mirror image.
  metals          Correlation basket: XAUUSD + XAGUSD (+XPTUSD if the broker
                  has it), entered together when their momentum aligns.
  strength_hedge  Hedged basket: long the strongest major vs short the
                  weakest, market-direction exposure minimised.

Exits are BASKET-LEVEL ONLY:
  * basket take-profit   (fraction of equity)
  * basket stop          (fraction of equity)
  * basket breakeven     (once TP*be_arm reached, close if it sinks to 0)
  * basket trail         (after TP*trail_arm, close on giveback of the peak)
Per-leg SLs exist only as broker-side disaster insurance, set WIDE (3*ATR);
the basket logic is expected to act first.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field

from basket_engine.strength import currency_strength, pair_for, rank


@dataclass
class Config:
    mode: str = "usd_basket"          # usd_basket | metals | strength_hedge
    timeframe_min: int = 60
    lookback: int = 24                # strength/momentum window (bars)
    entry_threshold: float = 0.0015   # min |strength| / momentum to act
    basket_risk_pct: float = 1.0      # total risk across all legs
    basket_tp_pct: float = 1.0        # +1% equity -> close basket
    basket_sl_pct: float = 1.0        # -1% equity -> close basket
    be_arm: float = 0.5               # armed at 50% of TP
    trail_arm: float = 0.8            # trail from 80% of TP
    trail_giveback: float = 0.4       # close if 40% of peak given back
    cooldown_bars: int = 6
    max_spread_frac: float = 0.0     # reserved
    metals_symbols: tuple = ("XAUUSD", "XAGUSD", "XPTUSD")


@dataclass
class BasketState:
    open: bool = False
    legs: list = field(default_factory=list)
    opened_at: float = 0.0
    peak_profit: float = 0.0
    be_armed: bool = False
    trail_armed: bool = False
    last_close_bar: int = -10_000
    bar_index: int = 0


class BasketManager:
    def __init__(self, io, cfg: Config, journal=None, log=print) -> None:
        self.io = io
        self.cfg = cfg
        self.st = BasketState()
        self.journal = journal
        self.log = log

    # ─────────────────────────── helpers ───────────────────────────
    def _equity(self) -> float:
        return float(self.io.account().get("equity", 0.0) or 0.0)

    def _atr_proxy(self, symbol: str) -> float:
        """Mean absolute bar-to-bar close change over the lookback — a robust
        volatility proxy that needs only closes."""
        closes = self.io.closes(symbol, self.cfg.timeframe_min,
                                self.cfg.lookback + 2)
        if len(closes) < 3:
            return 0.0
        diffs = [abs(b - a) for a, b in zip(closes, closes[1:])]
        return sum(diffs) / len(diffs)

    def _size_leg(self, symbol: str, weight: float, sl_dist: float) -> float:
        eq = self._equity()
        spec = self.io.spec(symbol)
        risk_money = eq * (self.cfg.basket_risk_pct / 100.0) * weight
        if sl_dist <= 0 or spec["tick_size"] <= 0:
            return 0.0
        money_per_lot = (sl_dist / spec["tick_size"]) * spec["tick_value"]
        if money_per_lot <= 0:
            return 0.0
        lots = risk_money / money_per_lot
        step = spec["lot_step"]
        lots = max(spec["lot_min"], min(spec["lot_max"], round(lots / step) * step))
        return round(lots, 2)

    # ─────────────────────────── signals ───────────────────────────
    def _signal_usd_basket(self) -> list[tuple[str, int, float]] | None:
        pairs = ["EURUSD", "GBPUSD", "AUDUSD", "NZDUSD", "USDJPY", "USDCHF", "USDCAD"]
        data = {p: self.io.closes(p, self.cfg.timeframe_min, self.cfg.lookback + 2)
                for p in pairs if self.io.has_symbol(p)}
        if len(data) < 5:
            return None
        s = currency_strength(data, self.cfg.lookback)
        usd = s.get("USD", 0.0)
        if abs(usd) < self.cfg.entry_threshold:
            return None
        d = -1 if usd > 0 else +1        # USD strong -> sell the antis
        legs = []
        for sym, sgn in (("EURUSD", +1), ("GBPUSD", +1), ("AUDUSD", +1),
                         ("USDJPY", -1), ("USDCHF", -1)):
            if sym in data:
                legs.append((sym, sgn * d, 0.2))
        self.log(f"[signal] USD strength {usd:+.4f} -> "
                 f"{'BEARISH' if d>0 else 'BULLISH'}-USD basket, {len(legs)} legs")
        return legs if len(legs) >= 4 else None

    def _signal_metals(self) -> list[tuple[str, int, float]] | None:
        syms = [s for s in self.cfg.metals_symbols if self.io.has_symbol(s)]
        if len(syms) < 2:
            return None
        rocs = {}
        for s in syms:
            closes = self.io.closes(s, self.cfg.timeframe_min, self.cfg.lookback + 2)
            if len(closes) > self.cfg.lookback:
                rocs[s] = closes[-1] / closes[-1 - self.cfg.lookback] - 1.0
        if len(rocs) < 2:
            return None
        vals = list(rocs.values())
        aligned_up = all(v > self.cfg.entry_threshold for v in vals)
        aligned_dn = all(v < -self.cfg.entry_threshold for v in vals)
        if not (aligned_up or aligned_dn):
            return None
        d = +1 if aligned_up else -1
        w = 1.0 / len(rocs)
        self.log(f"[signal] metals momentum aligned {'UP' if d>0 else 'DOWN'}: "
                 + ", ".join(f"{k} {v:+.3%}" for k, v in rocs.items()))
        return [(s, d, w) for s in rocs]

    def _signal_strength_hedge(self) -> list[tuple[str, int, float]] | None:
        from basket_engine.strength import PAIRS
        available = {p for p in PAIRS if self.io.has_symbol(p)}
        data = {p: self.io.closes(p, self.cfg.timeframe_min, self.cfg.lookback + 2)
                for p in available}
        data = {p: c for p, c in data.items() if len(c) > self.cfg.lookback}
        if len(data) < 10:
            return None
        ranked = rank(currency_strength(data, self.cfg.lookback))
        (top, ts), (bot, bs) = ranked[0], ranked[-1]
        if ts - bs < 2 * self.cfg.entry_threshold:
            return None
        hit = pair_for(top, bot, available)
        if hit is None:
            return None
        sym, direction = hit
        self.log(f"[signal] strength hedge: LONG {top} ({ts:+.4f}) vs "
                 f"SHORT {bot} ({bs:+.4f}) via {sym}")
        return [(sym, direction, 1.0)]

    # ─────────────────────────── lifecycle ───────────────────────────
    def try_open(self) -> bool:
        if self.st.open:
            return False
        if self.st.bar_index - self.st.last_close_bar < self.cfg.cooldown_bars:
            return False
        sig = {"usd_basket": self._signal_usd_basket,
               "metals": self._signal_metals,
               "strength_hedge": self._signal_strength_hedge}[self.cfg.mode]()
        if not sig:
            return False
        placed = []
        for symbol, side, weight in sig:
            atr = self._atr_proxy(symbol)
            sl_dist = 3.0 * atr
            lots = self._size_leg(symbol, weight, sl_dist)
            if lots <= 0:
                continue
            entry = self.io.price(symbol, side)
            sl = entry - side * sl_dist
            res = self.io.market(symbol, side, lots,
                                 round(sl, self.io.spec(symbol)["digits"]),
                                 f"sklz-basket {self.cfg.mode}")
            if res.get("ok"):
                placed.append({"symbol": symbol, "side": side, "lots": lots,
                               "entry": res["price"]})
                self.log(f"  [open] {'BUY' if side>0 else 'SELL'} {lots} {symbol}"
                         f" @ {res['price']}")
            else:
                self.log(f"  [FAIL] {symbol}: retcode {res.get('retcode')}")
        if not placed:
            return False
        self.st.open = True
        self.st.legs = placed
        self.st.opened_at = time.time()
        self.st.peak_profit = 0.0
        self.st.be_armed = self.st.trail_armed = False
        self._journal("basket_open", {"mode": self.cfg.mode, "legs": placed})
        return True

    def manage(self) -> str | None:
        """Basket-level exit logic. Returns close reason or None."""
        if not self.st.open:
            return None
        eq = self._equity()
        pnl = self.io.basket_profit()
        tp = eq * self.cfg.basket_tp_pct / 100.0
        sl = -eq * self.cfg.basket_sl_pct / 100.0
        self.st.peak_profit = max(self.st.peak_profit, pnl)
        if not self.st.be_armed and pnl >= tp * self.cfg.be_arm:
            self.st.be_armed = True
            self.log(f"[basket] breakeven ARMED at {pnl:+.2f}")
        if not self.st.trail_armed and pnl >= tp * self.cfg.trail_arm:
            self.st.trail_armed = True
            self.log(f"[basket] trail ARMED at {pnl:+.2f}")

        reason = None
        if pnl >= tp:
            reason = f"basket TP hit ({pnl:+.2f} >= {tp:.2f})"
        elif pnl <= sl:
            reason = f"basket SL hit ({pnl:+.2f} <= {sl:.2f})"
        elif self.st.trail_armed and self.st.peak_profit > 0 and \
                pnl <= self.st.peak_profit * (1 - self.cfg.trail_giveback):
            reason = (f"basket trail ({pnl:+.2f} gave back "
                      f">{self.cfg.trail_giveback:.0%} of peak {self.st.peak_profit:+.2f})")
        elif self.st.be_armed and pnl <= 0:
            reason = f"basket breakeven protect ({pnl:+.2f})"
        if reason:
            n = self.io.close_all()
            self.log(f"[basket] CLOSE ALL ({n} legs) — {reason}")
            self._journal("basket_close", {
                "reason": reason, "pnl": pnl, "peak": self.st.peak_profit,
                "held_sec": time.time() - self.st.opened_at})
            self.st.open = False
            self.st.legs = []
            self.st.last_close_bar = self.st.bar_index
        return reason

    def adopt_orphans(self) -> None:
        """On restart, adopt any positions with our magic as the open basket."""
        pos = self.io.my_positions()
        if pos and not self.st.open:
            self.st.open = True
            self.st.legs = [{"symbol": p["symbol"], "side": p["side"],
                             "lots": p["lots"], "entry": p["open_price"]}
                            for p in pos]
            self.log(f"[recover] adopted {len(pos)} open legs from a previous run")

    def stats(self) -> dict:
        pos = self.io.my_positions()
        return {
            "mode": self.cfg.mode,
            "basket_open": self.st.open,
            "legs": [{"s": p["symbol"], "d": p["side"], "lots": p["lots"],
                      "pl": round(p["profit"], 2)} for p in pos],
            "basket_pl": round(sum(p["profit"] for p in pos), 2),
            "peak": round(self.st.peak_profit, 2),
            "be_armed": self.st.be_armed, "trail_armed": self.st.trail_armed,
        }

    def _journal(self, kind: str, data: dict) -> None:
        if self.journal:
            self.journal(kind, data)
