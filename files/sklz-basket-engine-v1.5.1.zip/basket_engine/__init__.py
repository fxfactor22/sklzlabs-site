"""SKLZ Basket Engine — trades groups of instruments as ONE strategy.

The principle (and the whole point): the performance of the basket matters,
not any individual leg. Entries open all legs together; exits are decided on
AGGREGATE basket P/L — basket target, basket stop, basket breakeven, basket
trail. No leg is ever managed alone.

DEMO-ONLY, UNVALIDATED. This engine expresses classic basket concepts
(currency baskets, correlation baskets, strength hedges). None of these have
been validated by SKLZ backtests; the journal + daily review exist to build
that evidence before any live-account discussion.
"""
__version__ = "1.0.0"
MAGIC = 771005
