"""Currency-strength engine.

Strength of a currency = its average rate-of-change against every counterpart
we have data for, sign-adjusted for quote/base position. Pure functions —
fully testable without MT5.
"""
from __future__ import annotations

MAJORS = ["USD", "EUR", "GBP", "JPY", "CHF", "AUD", "CAD", "NZD"]

# the 28 combinations as they are conventionally quoted
PAIRS = [
    "EURUSD", "GBPUSD", "AUDUSD", "NZDUSD", "USDJPY", "USDCHF", "USDCAD",
    "EURGBP", "EURJPY", "EURCHF", "EURAUD", "EURCAD", "EURNZD",
    "GBPJPY", "GBPCHF", "GBPAUD", "GBPCAD", "GBPNZD",
    "AUDJPY", "AUDCHF", "AUDCAD", "AUDNZD",
    "NZDJPY", "NZDCHF", "NZDCAD",
    "CADJPY", "CADCHF", "CHFJPY",
]


def roc(closes: list[float], lookback: int) -> float:
    """Rate of change over `lookback` bars, as a fraction."""
    if len(closes) <= lookback or closes[-1 - lookback] == 0:
        return 0.0
    return closes[-1] / closes[-1 - lookback] - 1.0


def currency_strength(pair_closes: dict[str, list[float]],
                      lookback: int = 24) -> dict[str, float]:
    """Score each major by mean signed ROC across its pairs.

    pair_closes: {"EURUSD": [...closes oldest->newest...], ...}
    Returns {"USD": -0.0012, "EUR": 0.0008, ...} — higher = stronger.
    """
    scores: dict[str, list[float]] = {c: [] for c in MAJORS}
    for pair, closes in pair_closes.items():
        if len(pair) < 6:
            continue
        base, quote = pair[:3], pair[3:6]
        if base not in scores or quote not in scores:
            continue
        r = roc(closes, lookback)
        scores[base].append(r)      # pair up => base strengthened
        scores[quote].append(-r)    # ...and quote weakened
    return {c: (sum(v) / len(v) if v else 0.0) for c, v in scores.items()}


def rank(strength: dict[str, float]) -> list[tuple[str, float]]:
    """Strongest first."""
    return sorted(strength.items(), key=lambda kv: kv[1], reverse=True)


def pair_for(a: str, b: str, available: set[str]) -> tuple[str, int] | None:
    """Return (symbol, direction) expressing LONG currency `a` vs `b`.
    direction +1 = buy the symbol, -1 = sell it. None if no such pair."""
    if a + b in available:
        return a + b, +1
    if b + a in available:
        return b + a, -1
    return None
