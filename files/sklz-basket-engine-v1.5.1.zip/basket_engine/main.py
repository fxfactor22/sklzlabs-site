"""SKLZ Basket Engine — entry point.

    set SKLZ_API_URL=https://api.sklzlabs.com
    set SKLZ_BOT_KEY=...
    python -m basket_engine.main --mode usd_basket

Runs against whatever MT5 terminal is open and logged in. DEMO ONLY.
"""
from __future__ import annotations

import argparse
import json
import os
import time
from datetime import datetime, timezone

from basket_engine import MAGIC, __version__
from basket_engine.manager import BasketManager, Config
from basket_engine.mt5io import BasketIO
from basket_engine.telemetry import Telemetry

BANNER = f"""
╔══════════════════════════════════════════════════════════╗
║  SKLZ BASKET ENGINE v{__version__} — DEMO ONLY, UNVALIDATED      ║
║  Baskets are managed on AGGREGATE P/L, never per-leg.    ║
╚══════════════════════════════════════════════════════════╝"""


def journal_writer(path: str):
    def write(kind: str, data: dict) -> None:
        rec = {"ts": datetime.now(timezone.utc).isoformat(),
               "kind": kind, **data}
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    return write


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="usd_basket",
                    choices=["usd_basket", "metals", "strength_hedge"])
    ap.add_argument("--risk", type=float, default=1.0, help="basket risk %%")
    ap.add_argument("--tp", type=float, default=1.0, help="basket TP %% of equity")
    ap.add_argument("--sl", type=float, default=1.0, help="basket SL %% of equity")
    ap.add_argument("--interval", type=int, default=60, help="loop seconds")
    args = ap.parse_args()

    print(BANNER)
    cfg = Config(mode=args.mode, basket_risk_pct=args.risk,
                 basket_tp_pct=args.tp, basket_sl_pct=args.sl)
    io = BasketIO(MAGIC)
    acct = io.connect()
    if not acct.get("demo", True):
        print("!! LIVE ACCOUNT DETECTED — this engine is demo-only. Exiting.")
        return
    print(f"connected: {acct['login']} @ {acct['server']} "
          f"(equity {acct['equity']:.2f} {acct['currency']}, DEMO)")

    label = {"usd_basket": "Basket — USD Currency Basket",
             "metals": "Basket — Metals Correlation",
             "strength_hedge": "Basket — Strength Hedge"}[args.mode]
    tel = Telemetry(label + " [demo]", "MULTI", "demo")
    if tel.enabled:
        print("telemetry: SKLZ dashboard connected")
    else:
        print("telemetry: OFF (set SKLZ_API_URL and SKLZ_BOT_KEY)")

    jr = journal_writer(os.path.join(os.path.dirname(__file__), "..",
                                     "basket_journal.jsonl"))
    mgr = BasketManager(io, cfg, journal=jr)
    mgr.adopt_orphans()

    hb_every, last_hb = 30, 0.0
    print(f"mode={args.mode} risk={args.risk}% tp={args.tp}% sl={args.sl}% — "
          f"scanning every {args.interval}s. Ctrl+C stops the ENGINE "
          f"(open legs stay in MT5).")
    try:
        while True:
            mgr.st.bar_index += 1
            reason = mgr.manage()
            if reason:
                tel.event("basket_close", reason, mgr.stats())
            elif not mgr.st.open:
                if mgr.try_open():
                    tel.event("basket_open", f"{args.mode} basket opened",
                              mgr.stats())
            if time.time() - last_hb > hb_every:
                a = io.account()
                tel.heartbeat(a.get("equity", 0), a.get("balance", 0),
                              mgr.stats())
                last_hb = time.time()
            time.sleep(args.interval if not mgr.st.open else
                       min(args.interval, 15))
    except KeyboardInterrupt:
        s = mgr.stats()
        print(f"\nstopped. basket_open={s['basket_open']} "
              f"pl={s['basket_pl']:+.2f} — legs remain in MT5; relaunch "
              f"adopts them automatically.")


if __name__ == "__main__":
    main()
