"""Publish REAL scanner findings to the SKLZ signals pipeline.

Everything here comes from live market data via MT5:
  - the setup is a genuine scanner hit (sweep / structure break / strength)
  - entry is the live price, SL/TP are computed from live ATR
  - nothing is invented; if there is no setup, nothing is sent

Honest framing is enforced in the note: these scanners are HYPOTHESES per
SKLZ's own 27M-tick research (often coin-flip out-of-sample), so signals are
published as PLANS with levels, never as promises.

Env:
  SKLZ_API_URL           https://api.sklzlabs.com
  SIGNAL_WEBHOOK_KEY     the webhook key from the signals pipeline
  SKLZ_PUBLISH_SIGNALS   "1" to enable publishing (default off)
  SKLZ_SIGNAL_MIN_GAP    minutes between signals per symbol (default 60)
"""
from __future__ import annotations

import json
import os
import time
import urllib.request

_LAST_SENT: dict = {}


def _enabled() -> bool:
    return os.environ.get("SKLZ_PUBLISH_SIGNALS", "") == "1"


def _min_gap_min() -> int:
    try:
        return int(os.environ.get("SKLZ_SIGNAL_MIN_GAP", "60"))
    except ValueError:
        return 60


def _atr(io, symbol: str, tf_min: int, n: int = 14) -> float:
    """Simple ATR proxy from close-to-close moves on live bars."""
    c = io.closes(symbol, tf_min, n + 1)
    if len(c) < 3:
        return 0.0
    moves = [abs(c[i] - c[i - 1]) for i in range(1, len(c))]
    return sum(moves) / len(moves) if moves else 0.0


def publish(io, symbol: str, side: int, strategy: str, detail: str,
            tf_min: int, log=print) -> bool:
    """Send ONE real signal. Returns True if sent."""
    if not _enabled():
        return False
    api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
    key = os.environ.get("SIGNAL_WEBHOOK_KEY", "")
    if not (api and key):
        return False

    # rate limit per symbol so the channel isn't spammed
    gap = _min_gap_min() * 60
    now = time.time()
    if now - _LAST_SENT.get(symbol, 0) < gap:
        return False

    # LIVE data — price and ATR straight from the terminal
    try:
        price = io.price(symbol, side)
        atr = _atr(io, symbol, tf_min)
    except Exception as exc:  # noqa: BLE001
        log(f"[signal] could not read live data for {symbol}: {exc}")
        return False
    if not price or not atr:
        return False

    payload = {
        "symbol": symbol,
        "side": "buy" if side > 0 else "sell",
        "price": round(price, 5),
        "atr": round(atr, 5),
        "timeframe": f"M{tf_min}" if tf_min < 60 else f"H{tf_min // 60}",
        "note": f"SKLZ bot scan — {strategy}: {detail}. "
                f"Plan, not a promise — manage your own risk.",
    }
    try:
        req = urllib.request.Request(
            f"{api}/api/signals/webhook/{key}",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as r:
            res = json.loads(r.read().decode())
        if res.get("ok"):
            _LAST_SENT[symbol] = now
            lv = res.get("levels", {})
            log(f"[signal] PUBLISHED {payload['side'].upper()} {symbol} "
                f"@ {lv.get('entry')} SL {lv.get('sl')} TP {lv.get('tp')} "
                f"-> {res.get('category')} channel")
            return True
        log(f"[signal] rejected: {res}")
    except Exception as exc:  # noqa: BLE001
        log(f"[signal] publish failed: {type(exc).__name__}: {exc}")
    return False
