"""Thin MT5 wrapper — every call the basket engine needs, nothing more.

MetaTrader5 import is guarded so the whole engine is testable on any OS;
tests inject a fake through BasketIO(client=fake).
"""
from __future__ import annotations

import time

try:
    import MetaTrader5 as _mt5
except ImportError:          # tests / macOS
    _mt5 = None


class BasketIO:
    def __init__(self, magic: int, client=None) -> None:
        self.mt5 = client or _mt5
        self.magic = magic
        if self.mt5 is None:
            raise RuntimeError("MetaTrader5 package not available")

    # ---- lifecycle ----
    def connect(self) -> dict:
        if not self.mt5.initialize():
            raise RuntimeError(f"MT5 initialize failed: {self.mt5.last_error()}")
        acct = self.mt5.account_info()
        if acct is None:
            raise RuntimeError("MT5: no account — open & log in the terminal first")
        return {"login": acct.login, "server": acct.server,
                "balance": acct.balance, "equity": acct.equity,
                "currency": acct.currency, "demo": acct.trade_mode == 0}

    def account(self) -> dict:
        a = self.mt5.account_info()
        return {"balance": a.balance, "equity": a.equity} if a else {}

    # ---- data ----
    def closes(self, symbol: str, timeframe_min: int, count: int) -> list[float]:
        tf = {5: self.mt5.TIMEFRAME_M5, 15: self.mt5.TIMEFRAME_M15,
              60: self.mt5.TIMEFRAME_H1, 240: self.mt5.TIMEFRAME_H4}[timeframe_min]
        rates = self.mt5.copy_rates_from_pos(symbol, tf, 0, count)
        return [r["close"] for r in rates] if rates is not None else []

    def has_symbol(self, symbol: str) -> bool:
        info = self.mt5.symbol_info(symbol)
        if info is None:
            return False
        if not info.visible:
            self.mt5.symbol_select(symbol, True)
        return True

    def spec(self, symbol: str) -> dict:
        s = self.mt5.symbol_info(symbol)
        return {"point": s.point, "tick_value": s.trade_tick_value,
                "tick_size": s.trade_tick_size, "lot_min": s.volume_min,
                "lot_step": s.volume_step, "lot_max": s.volume_max,
                "digits": s.digits}

    def price(self, symbol: str, side: int) -> float:
        t = self.mt5.symbol_info_tick(symbol)
        return t.ask if side > 0 else t.bid

    # ---- positions ----
    def my_positions(self) -> list[dict]:
        out = []
        for p in (self.mt5.positions_get() or []):
            if p.magic != self.magic:
                continue
            out.append({"ticket": p.ticket, "symbol": p.symbol,
                        "side": 1 if p.type == 0 else -1, "lots": p.volume,
                        "open_price": p.price_open, "profit": p.profit,
                        "sl": getattr(p, "sl", 0.0) or 0.0,
                        "tp": getattr(p, "tp", 0.0) or 0.0,
                        "comment": p.comment})
        return out

    def basket_profit(self) -> float:
        return sum(p["profit"] for p in self.my_positions())

    # ---- orders ----
    def market(self, symbol: str, side: int, lots: float, sl: float,
               comment: str, tp: float = 0.0) -> dict:
        req = {
            "action": self.mt5.TRADE_ACTION_DEAL, "symbol": symbol,
            "volume": lots,
            "type": self.mt5.ORDER_TYPE_BUY if side > 0 else self.mt5.ORDER_TYPE_SELL,
            "price": self.price(symbol, side), "sl": sl, "tp": tp or 0.0,
            "magic": self.magic, "comment": comment[:26],
            "type_time": self.mt5.ORDER_TIME_GTC,
            "type_filling": self.mt5.ORDER_FILLING_IOC,
        }
        for attempt in range(3):
            res = self.mt5.order_send(req)
            if res is not None and res.retcode == self.mt5.TRADE_RETCODE_DONE:
                return {"ok": True, "ticket": res.order, "price": res.price}
            time.sleep(0.6)
            req["price"] = self.price(symbol, side)
        rc = getattr(res, "retcode", "n/a") if res is not None else "none"
        return {"ok": False, "retcode": rc}

    def modify_sl(self, ticket: int, new_sl: float,
                  new_tp: float | None = None) -> bool:
        """Move the stop on an open position. Returns True if the broker accepted."""
        try:
            pos = None
            for p in (self.mt5.positions_get() or []):
                if p.ticket == ticket:
                    pos = p
                    break
            if pos is None:
                return False
            digits = self.mt5.symbol_info(pos.symbol).digits
            req = {
                "action": self.mt5.TRADE_ACTION_SLTP,
                "position": ticket,
                "symbol": pos.symbol,
                "sl": round(float(new_sl), digits),
                "tp": round(float(new_tp if new_tp is not None else pos.tp), digits),
            }
            res = self.mt5.order_send(req)
            return bool(res and res.retcode == self.mt5.TRADE_RETCODE_DONE)
        except Exception:
            return False

    def close(self, pos: dict) -> bool:
        side = -pos["side"]
        req = {
            "action": self.mt5.TRADE_ACTION_DEAL, "symbol": pos["symbol"],
            "volume": pos["lots"], "position": pos["ticket"],
            "type": self.mt5.ORDER_TYPE_BUY if side > 0 else self.mt5.ORDER_TYPE_SELL,
            "price": self.price(pos["symbol"], side),
            "magic": self.magic, "comment": "basket-close",
            "type_time": self.mt5.ORDER_TIME_GTC,
            "type_filling": self.mt5.ORDER_FILLING_IOC,
        }
        res = self.mt5.order_send(req)
        return res is not None and res.retcode == self.mt5.TRADE_RETCODE_DONE

    def close_all(self) -> int:
        n = 0
        for p in self.my_positions():
            if self.close(p):
                n += 1
        return n


    def closed_trades_since(self, minutes: int = 1440) -> list[dict]:
        """ALL closed round-trip trades on the account in the last N minutes —
        includes trades opened manually in MT5, not just bot trades.
        Groups deals by position_id; a position is 'closed' when its net
        volume returns to zero (an out deal exists)."""
        try:
            from datetime import datetime, timedelta
            frm = datetime.now() - timedelta(minutes=minutes)
            deals = self.mt5.history_deals_get(frm, datetime.now() + timedelta(hours=2))
            if not deals:
                return []
            by_pos: dict = {}
            for d in deals:
                if d.type not in (0, 1):        # 0=buy,1=sell trade deals only
                    continue
                by_pos.setdefault(d.position_id, []).append(d)
            out = []
            for pid, ds in by_pos.items():
                ds.sort(key=lambda x: x.time)
                has_in = any(getattr(x, "entry", 0) == 0 for x in ds)   # DEAL_ENTRY_IN
                has_out = any(getattr(x, "entry", 0) == 1 for x in ds)  # DEAL_ENTRY_OUT
                if not (has_in and has_out):
                    continue                    # still open or partial
                first = ds[0]
                pnl = round(sum(x.profit + x.swap + x.commission for x in ds), 2)
                out.append({
                    "position_id": pid,
                    "symbol": first.symbol,
                    "side": 1 if first.type == 0 else -1,
                    "lots": round(sum(x.volume for x in ds if getattr(x, "entry", 0) == 0), 2),
                    "entry_price": first.price,
                    "exit_price": ds[-1].price,
                    "pnl": pnl,
                    "opened_at": datetime.fromtimestamp(first.time).isoformat(),
                    "closed_at": datetime.fromtimestamp(ds[-1].time).isoformat(),
                    "comment": (getattr(first, "comment", "") or ""),
                })
            return out
        except Exception:
            return []

    def realized_pnl(self, ticket: int) -> float | None:
        """Exact realized P/L for a closed position, from deal history.
        Sums profit + swap + commission of all deals on this position."""
        try:
            from datetime import datetime, timedelta
            deals = self.mt5.history_deals_get(
                datetime.now() - timedelta(days=14),
                datetime.now() + timedelta(hours=2), position=ticket)
            if not deals:
                return None
            # only trade deals on THIS position — never balance/deposit rows
            deals = [d for d in deals
                     if getattr(d, "position_id", ticket) == ticket
                     and d.type in (0, 1)]
            if not deals:
                return None
            return round(sum(d.profit + d.swap + d.commission for d in deals), 2)
        except Exception:
            return None

    def market_live(self, symbol: str, max_age_sec: int = 120) -> bool:
        """True only if this symbol has a tick within max_age_sec — i.e. the
        market is actually open. Prevents scanners acting on frozen weekend data."""
        try:
            import time as _t
            t = self.mt5.symbol_info_tick(symbol)
            if t is None or not t.time:
                return False
            return (_t.time() - t.time) <= max_age_sec
        except Exception:
            return False
