"""Entry controller — the THREE streams into the learning journal.

  forced_entry(...)   YOU trigger it from the runner, with a note.
  auto_entry(...)     a scanner triggers it, tagged with the strategy name.

Both snapshot full market state at the instant of entry and journal it.
Both place a real (demo) order through the same IO the basket engine uses.
"""
from __future__ import annotations

import os

from datetime import datetime, timezone

from basket_engine.learn.capture import EntryRecord, Journal, snapshot


class EntryController:
    def __init__(self, io, journal: Journal, tf_min: int = 60,
                 lookback: int = 24, risk_pct: float = 0.5, log=print) -> None:
        self.io = io
        self.journal = journal
        self.tf_min = tf_min
        self.lookback = lookback
        self.risk_pct = risk_pct
        self.log = log

    def _size(self, symbol: str, sl_dist: float) -> float:
        eq = float(self.io.account().get("equity", 0) or 0)
        spec = self.io.spec(symbol)

        # ── equity-proportional mode ──────────────────────────────
        # SKLZ_LOT_PER_EQUITY=100 with SKLZ_LOT_UNIT=0.01 means
        # "0.01 lots for every $100 of equity". Simple, predictable,
        # and it scales down as the account shrinks.
        #
        # Note this sizes by ACCOUNT SIZE, not by stop distance — so a
        # wide stop risks more than a tight one. Risk per trade varies
        # with the setup; that is the trade-off for predictability.
        try:
            per = float(os.environ.get("SKLZ_LOT_PER_EQUITY", "0") or 0)
        except ValueError:
            per = 0.0
        if per > 0:
            try:
                unit = float(os.environ.get("SKLZ_LOT_UNIT", "0.01"))
            except ValueError:
                unit = 0.01
            lots = (eq / per) * unit
            step = spec["lot_step"]
            lots = round(lots / step) * step
            return round(max(spec["lot_min"],
                             min(spec["lot_max"], lots)), 2)

        # ── risk-based mode (default) ─────────────────────────────
        if sl_dist <= 0 or spec["tick_size"] <= 0:
            return spec["lot_min"]
        risk = eq * self.risk_pct / 100.0
        per_lot = (sl_dist / spec["tick_size"]) * spec["tick_value"]
        if per_lot <= 0:
            return spec["lot_min"]
        lots = risk / per_lot
        step = spec["lot_step"]
        return round(max(spec["lot_min"],
                         min(spec["lot_max"], round(lots/step)*step)), 2)

    def _atr(self, symbol: str) -> float:
        closes = self.io.closes(symbol, self.tf_min, self.lookback + 2)
        if len(closes) < 3:
            return 0.0
        d = [abs(b-a) for a, b in zip(closes, closes[1:])]
        return sum(d)/len(d)

    def _enter(self, source: str, strategy: str, symbol: str, side: int,
               note: str, sl_mult: float, tp_mult: float,
               lots_override: float = 0.0, sl_price: float = 0.0,
               tp_price: float = 0.0) -> EntryRecord | None:
        if not self.io.has_symbol(symbol):
            self.log(f"[entry] unknown symbol {symbol}")
            return None
        if hasattr(self.io, "market_live") and not self.io.market_live(symbol):
            self.log(f"[entry] NOTE: {symbol} market looks closed (stale tick) — "
                     f"order may be rejected or fill Monday. Proceeding as you asked.")
        atr = self._atr(symbol)
        sl_dist = sl_mult * atr
        px = self.io.price(symbol, side)
        digits = self.io.spec(symbol)["digits"]
        sl = round(sl_price, digits) if sl_price else round(px - side * sl_dist, digits)
        if sl_price:
            sl_dist = abs(px - sl_price)
        lots = lots_override or self._size(symbol, sl_dist)
        tp = round(tp_price, digits) if tp_price else 0.0
        res = self.io.market(symbol, side, lots, sl,
                             f"sklz-{source} {strategy}"[:26], tp=tp)
        if not res.get("ok"):
            code = res.get("retcode")
            try:
                from basket_engine.mt5io import RETCODES
                why = RETCODES.get(code, "")
            except Exception:
                why = ""
            self.log(f"[entry] FAIL {symbol}: {code}"
                     + (f" — {why}" if why else ""))
            return None
        st = snapshot(self.io, symbol, self.tf_min, self.lookback)
        rec = EntryRecord(
            ts=datetime.now(timezone.utc).isoformat(), source=source,
            strategy=strategy, symbol=symbol, side=side, lots=lots,
            entry_price=res["price"], note=note, state=st.__dict__,
            ticket=res.get("ticket"))
        self.journal.record_entry(rec)
        self.log(f"[{source}] {'BUY' if side>0 else 'SELL'} {lots} {symbol} "
                 f"@ {res['price']} · {strategy}"
                 + (f" · \"{note}\"" if note else ""))
        return rec

    # ---- stream 1: YOU, with a reason ----
    def forced_entry(self, symbol: str, side: int, note: str,
                     sl_mult: float = 2.0, tp_mult: float = 3.0) -> EntryRecord | None:
        """A deliberate entry you're taking to TEACH the system.
        `note` is your reasoning — the label that makes learning work."""
        return self._enter("forced", note.split()[0].lower() if note else "manual",
                            symbol, side, note, sl_mult, tp_mult)

    def forced_custom(self, symbol: str, side: int, note: str,
                      lots: float = 0.0, sl: float = 0.0,
                      tp: float = 0.0) -> EntryRecord | None:
        """Dashboard entry with optional explicit lots / SL / TP.
        Blank fields fall back to risk-based sizing and ATR stop."""
        return self._enter("forced", "dashboard", symbol, side, note,
                           2.0, 3.0, lots_override=lots,
                           sl_price=sl, tp_price=tp)

    # ---- stream 2: the bot's scanners ----
    def auto_entry(self, scanner: str, symbol: str, side: int, detail: str,
                   sl_mult: float = 2.0, tp_mult: float = 3.0) -> EntryRecord | None:
        """A scanner-triggered entry — a HYPOTHESIS being tested, not trusted."""
        return self._enter("auto", scanner, symbol, side, detail, sl_mult, tp_mult)
