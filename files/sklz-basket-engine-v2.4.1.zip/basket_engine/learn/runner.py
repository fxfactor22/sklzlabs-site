"""Learning runner — three entry streams + end-of-day review, interactive.

Commands while it runs (type + Enter):
  buy EURUSD your reason here     forced BUY, note = "your reason here"
  sell GBPUSD london sweep        forced SELL with your note
  scan                            run the famous-strategy scanners once now
  auto on / auto off              enable/disable automatic scanner entries
  review                          run the end-of-day AI review right now
  status                          positions + today's tally
  quit                            stop the runner (open trades stay in MT5)

Everything is journaled. The review PROPOSES; it never changes parameters.
"""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.request
from datetime import datetime, timezone

from basket_engine.learn.capture import Journal
from basket_engine.learn.entries import EntryController
from basket_engine.learn.review import summarize, ai_review
from basket_engine.learn.scanners import SCANNERS
from basket_engine.learn import journal_push
from basket_engine.learn import signal_publish
from basket_engine.learn import quality
from basket_engine.learn import trailing


class LearningRunner:
    def __init__(self, io, bot_label: str = "", tf_min=60, lookback=24, risk_pct=0.5,
                 auto=False, symbols=None, log=print) -> None:
        path = os.path.join(os.path.dirname(__file__), "..", "..",
                            "learning_journal.jsonl")
        self.journal = Journal(path)
        self.ec = EntryController(io, self.journal, tf_min, lookback, risk_pct, log)
        self.io = io
        self.tf_min = tf_min
        self.lookback = lookback
        self.auto = auto
        # symbols to scan — override with SKLZ_SYMBOLS="EURUSD,GBPUSD,XAUUSD,..."
        # unavailable symbols are skipped automatically (io.has_symbol check).
        env_syms = os.environ.get("SKLZ_SYMBOLS", "").strip()
        if symbols:
            self.symbols = symbols
        elif env_syms:
            self.symbols = [s.strip().upper() for s in env_syms.split(",") if s.strip()]
        else:
            self.symbols = [
                # FX majors
                "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD", "NZDUSD",
                # FX crosses
                "EURJPY", "GBPJPY", "EURGBP", "AUDJPY",
                # metals
                "XAUUSD", "XAGUSD",
                # indices
                "US30", "NAS100", "SPX500", "GER40",
                # energy + crypto
                "USOIL", "UKOIL", "BTCUSD", "ETHUSD",
            ]
        self.log = log
        self._auto_seen: set = set()
        # --- v1.4.0 remote control (dashboard START/PAUSE) ---
        self.entries_blocked = False
        self._remote_state = None   # None -> announce state on first poll
        # the poller thread reads this, so it must be set before the thread
        # starts — otherwise it falls back to the wrong bot name and silently
        # polls a queue nobody is writing to.
        self.bot_label = bot_label or os.environ.get("SKLZ_BOT_NAME", "")
        t = threading.Thread(target=self._command_loop, daemon=True)
        t.start()
        self._journaled_positions: set = set()
        from datetime import datetime as _dt, timezone as _tz
        self._journal_start = _dt.now(_tz.utc)   # only journal trades closed after this
        self._acct_no = ""
        self._server = ""
        try:
            info = self.io.mt5.account_info() if hasattr(self.io, "mt5") else None
            if info:
                self._acct_no = str(info.login)
                self._server = info.server
        except Exception:
            pass
        jt = threading.Thread(target=self._auto_journal_loop, daemon=True)
        jt.start()
        tt = threading.Thread(target=self._trail_loop, daemon=True)
        tt.start()
        st = threading.Thread(target=self._signal_track_loop, daemon=True)
        st.start()

    # ---- v1.4.0 remote control: poll dashboard command every 30s ----
    def _command_loop(self):
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("SKLZ_BOT_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        # must match the name telemetry registers under, or dashboard
        # commands and orders will never reach this runner
        bot = getattr(self, "bot_label", "") or os.environ.get("SKLZ_BOT_NAME", "")
        if not bot:
            self.log("[remote] no bot label set — dashboard orders cannot be "
                     "delivered. This is a bug; report it.")
            return
        if not (api and key):
            return                      # telemetry env not set; run local-only
        try:
            poll_secs = max(2, int(os.environ.get("SKLZ_POLL_SECONDS", "5")))
        except ValueError:
            poll_secs = 2
        consecutive_errors = 0
        # one opener reused for every poll — avoids churning through Windows
        # ephemeral ports, which starves the telemetry thread of sockets
        opener = urllib.request.build_opener()
        self.log(f"[remote] command poll every {poll_secs}s")
        while True:
            try:
                from urllib.parse import quote
                req = urllib.request.Request(
                    f"{api}/api/bot/command?bot_name={quote(bot)}",
                    headers={"Authorization": f"Bearer {key}"})
                with opener.open(req, timeout=30) as resp:
                    r_body = resp.read().decode()
                cmd = (json.loads(r_body).get("command") or "run")
                # execute any queued manual orders from the admin dashboard
                for o in (json.loads(r_body).get("orders") or []):
                    try:
                        if self.entries_blocked:
                            self.log("[REMOTE] order ignored — paused"); continue
                        side = +1 if o.get("side") == "buy" else -1
                        self.log(f"[REMOTE] dashboard order: {o.get('side','?').upper()} "
                                 f"{o.get('symbol','?')} — {o.get('note','')}")
                        rec = self.ec.forced_custom(
                            o.get("symbol", ""), side,
                            "[dashboard] " + (o.get("note") or "manual"),
                            lots=float(o.get("lots") or 0),
                            sl=float(o.get("sl") or 0),
                            tp=float(o.get("tp") or 0))
                        # only publish if the order actually filled — a signal
                        # for a trade that does not exist is worse than silence
                        if not rec:
                            self.log("[signal] not published — the entry did not fill")
                            continue
                        try:
                            signal_publish.publish(
                                self.io, o.get("symbol", ""), side,
                                "manual entry", (o.get("note") or "trader entry"),
                                self.tf_min, log=self.log, force=True)
                        except Exception as exc:
                            self.log(f"[signal] error: {exc}")
                    except Exception as exc:
                        self.log(f"[REMOTE] order failed: {exc}")
                if cmd != self._remote_state:
                    self._remote_state = cmd
                    if cmd == "pause":
                        self.auto = False
                        self.entries_blocked = True
                        self.log("[REMOTE] *** PAUSED from dashboard *** "
                                 "auto-trading OFF, no new entries; positions still managed.")
                    else:
                        self.auto = True
                        self.entries_blocked = False
                        self.log("[REMOTE] *** RUNNING from dashboard *** "
                                 "auto-trading ON - scanners may enter. "
                                 "(PAUSE on the dashboard to stop)")
            except Exception:
                consecutive_errors += 1
                # back off on repeated failures so a dead API does not hammer it
                time.sleep(min(30, 3 * consecutive_errors))
                continue
            consecutive_errors = 0
            # fast poll: dashboard orders and START/PAUSE feel immediate.
            # SKLZ_POLL_SECONDS tunes it (default 2s).
            time.sleep(poll_secs)

    # ---- signal outcome tracking: follow every published call ----
    def _signal_track_loop(self):
        import time as _t, json as _json, urllib.request as _u
        _t.sleep(25)
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("INTERNAL_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        if not (api and key):
            return
        try:
            every = max(10, int(os.environ.get("SKLZ_SIGNAL_TRACK_SECONDS", "20")))
        except ValueError:
            every = 20
        while True:
            try:
                req = _u.Request(api + "/api/signals/open",
                                 headers={"Authorization": "Bearer " + key})
                with _u.urlopen(req, timeout=25) as resp:
                    open_sigs = (_json.loads(resp.read().decode()) or {}).get("signals", [])
                for s in open_sigs:
                    sym = s.get("symbol")
                    if not sym:
                        continue
                    try:
                        px = self.io.price(sym, 1)
                    except Exception:
                        continue
                    body = {"signal_id": s.get("id"), "price": px}
                    try:
                        rq = _u.Request(api + "/api/signals/track",
                                        data=_json.dumps(body).encode(),
                                        headers={"Authorization": "Bearer " + key,
                                                 "Content-Type": "application/json"})
                        _u.urlopen(rq, timeout=20)
                    except Exception:
                        pass
            except Exception as exc:
                self.log(f"[sigtrack] {type(exc).__name__}")
            _t.sleep(every)

    # ---- trailing stops: protect and trail every open position ----
    def _trail_loop(self):
        import time as _t
        _t.sleep(15)
        every = 5
        try:
            every = max(2, int(os.environ.get("SKLZ_TRAIL_SECONDS", "5")))
        except ValueError:
            pass
        while True:
            try:
                trailing.manage(self.io, log=self.log,
                                on_update=self._report_trail)
            except Exception as exc:
                self.log(f"[trail] {type(exc).__name__}: {exc}")
            _t.sleep(every)

    def _report_trail(self, ev: dict) -> None:
        """Publish a stop move to the update board + Telegram."""
        import json as _json, urllib.request as _u
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("INTERNAL_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        if not (api and key):
            return
        secured = "secured" in ev.get("reason", "")
        body = {
            "kind": "secured" if secured else "trail",
            "symbol": ev["symbol"], "side": ev["side"],
            "ticket": str(ev.get("ticket", "")),
            "headline": (f"{ev['symbol']} secured — this trade can no longer lose"
                         if secured else f"Stop trailed on {ev['symbol']}"),
            "detail": ("Stop moved into profit. Worst case on this position is "
                       "now a win." if secured else
                       "Following price up while the move continues."),
            "old_sl": ev.get("old_sl") or None,
            "new_sl": ev.get("new_sl"),
            "locked_pips": ev.get("locked_pips"),
            "price": ev.get("price"),
            "broadcast": True,
        }
        try:
            req = _u.Request(api + "/api/updates/bot",
                             data=_json.dumps(body).encode(),
                             headers={"Authorization": "Bearer " + key,
                                      "Content-Type": "application/json"})
            _u.urlopen(req, timeout=20)
        except Exception as exc:
            self.log(f"[trail] could not publish update: {type(exc).__name__}")

    # ---- live auto-journal: push ANY closed trade on the account ----
    def _auto_journal_loop(self):
        import time as _t
        _t.sleep(20)                       # let MT5 settle after startup
        while True:
            try:
                self._push_closed_trades()
            except Exception as exc:
                self.log(f"[auto-journal] {type(exc).__name__}: {exc}")
            _t.sleep(int(os.environ.get("SKLZ_JOURNAL_SECONDS", "45")))

    def _classify_source(self, comment: str) -> str:
        c = (comment or "").lower()
        if "dashboard" in c:
            return "dashboard"
        if "sklz-forced" in c or "sklz-auto" in c or "sklz-" in c:
            return "bot"
        return "manual"                    # opened directly in MT5

    def _push_closed_trades(self):
        if not hasattr(self.io, "closed_trades_since"):
            return
        trades = self.io.closed_trades_since(minutes=1440)
        # dedup is handled permanently server-side by position_id, so we simply
        # push everything in the window; the API rejects anything already journaled.
        fresh = [t for t in trades
                 if t["position_id"] not in self._journaled_positions]
        if not fresh:
            return
        import json as _json, os as _os, urllib.request as _u
        api = _os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = _os.environ.get("BOT_INGEST_KEY", "") or _os.environ.get("SKLZ_BOT_KEY", "")
        uid = _os.environ.get("SKLZ_USER_ID", "")
        if not (api and key and uid):
            return
        payload = [{
            "symbol": t["symbol"],
            "side": "buy" if t["side"] > 0 else "sell",
            "entry_price": t["entry_price"], "exit_price": t["exit_price"],
            "lots": t["lots"], "pnl": t["pnl"],
            "opened_at": t["opened_at"], "closed_at": t["closed_at"],
            "setup": self._classify_source(t.get("comment")),
            "reason": t.get("comment") or "",
            "source": self._classify_source(t.get("comment")),
            "tags": [self._classify_source(t.get("comment")), "auto-journal"],
            "position_id": str(t.get("position_id", "")),
        } for t in fresh]
        try:
            body = _json.dumps({"user_id": uid, "trades": payload, "account_no": self._acct_no, "server": self._server}).encode()
            req = _u.Request(api + "/api/journal/ingest", data=body,
                             headers={"Content-Type": "application/json",
                                      "Authorization": "Bearer " + key})
            with _u.urlopen(req, timeout=30) as resp:
                res = _json.loads(resp.read().decode())
            for t in fresh:
                self._journaled_positions.add(t["position_id"])
            self.log(f"[auto-journal] pushed {res.get('ingested', len(fresh))} "
                     f"closed trade(s) to your journal")
        except Exception as exc:
            self.log(f"[auto-journal] push failed: {type(exc).__name__}: {exc}")

    # ---- forced ----
    def cmd_buy(self, parts):  self._forced(+1, parts)
    def cmd_sell(self, parts): self._forced(-1, parts)
    def _forced(self, side, parts):
        if len(parts) < 2:
            self.log("usage: buy SYMBOL your reason for the entry"); return
        if self.entries_blocked:
            self.log("Entries are PAUSED from the dashboard. Press START there to resume.")
            return
        symbol = parts[1].upper()
        note = " ".join(parts[2:]) or "manual"
        rec = self.ec.forced_entry(symbol, side, note)
        if not rec:
            self.log("[signal] not published — the entry did not fill")
            return
        try:
            signal_publish.publish(self.io, symbol, side, "manual entry", note,
                                   self.tf_min, log=self.log, force=True)
        except Exception as exc:
            self.log(f"[signal] error: {exc}")

    # ---- scanners ----
    def scan_once(self) -> int:
        n = 0
        for sym in self.symbols:
            if not self.io.has_symbol(sym):
                continue
            # market-open guard: never scan on frozen weekend/closed data
            if hasattr(self.io, "market_live") and not self.io.market_live(sym):
                continue
            # gather EVERY scanner hit for this symbol first, then judge quality
            hits = []
            for name, fn in SCANNERS.items():
                sig = fn(self.io, sym, self.tf_min, self.lookback)
                if sig:
                    hits.append((name, sig[0], sig[1]))
            if not hits:
                continue

            q = quality.score_setup(self.io, sym, self.tf_min, hits)
            side = q.get("side", 0)
            if not side:
                continue

            # one entry per (symbol, direction, agreeing-scanner-set) per session
            key = (sym, side, tuple(sorted(q.get("scanners", []))))
            if key in self._auto_seen:
                continue
            self._auto_seen.add(key)

            names = "+".join(q.get("scanners", []))
            self.log(f"[scan] {sym} {'BUY' if side > 0 else 'SELL'} "
                     f"score {q['score']}/100 ({names}) — "
                     + "; ".join(q.get("reasons", [])))

            if not q.get("publish"):
                self.log(f"[scan] skipped — below quality threshold "
                         f"({quality.min_score()})")
                continue

            detail = f"{q['detail']} · score {q['score']}/100 · {names}"
            taken = None
            if self.auto and not self.entries_blocked:
                taken = self.ec.auto_entry(names, sym, side, detail)
                if taken:
                    n += 1
            # when auto is on, only publish setups we actually took
            if self.auto and not taken:
                self.log("[signal] not published — the entry did not fill")
            else:
                try:
                    signal_publish.publish(self.io, sym, side, names, detail,
                                           self.tf_min, log=self.log)
                except Exception as exc:
                    self.log(f"[signal] error: {exc}")
        return n

    # ---- exits: reconcile closed positions into the journal ----
    def sync_exits(self) -> None:
        open_tickets = {p["ticket"] for p in self.io.my_positions()}
        rows = self.journal.load_day()
        entered = {r["ticket"] for r in rows if r.get("type") == "entry" and r.get("ticket")}
        exited = {r["ticket"] for r in rows if r.get("type") == "exit"}
        for tk in entered - exited - open_tickets:
            # position closed — fetch the EXACT realized P/L from deal history
            pnl = self.io.realized_pnl(tk)
            if pnl is None:
                pnl = 0.0
                self.log(f"[exit] ticket {tk} closed (P/L pending in history)")
            else:
                self.log(f"[exit] ticket {tk} closed: {pnl:+.2f} realized")
            self.journal.record_exit(tk, 0.0, pnl)

    # ---- review ----
    def review(self) -> dict:
        closed = self.journal.reconcile()
        stats = summarize(closed)
        rep = ai_review(stats, closed)
        self.log("\n" + "=" * 58)
        self.log("  END-OF-DAY REVIEW  (AI proposes — you decide)")
        self.log("=" * 58)
        self.log(f"  {rep.get('headline','')}")
        self.log(f"  forced vs auto: {rep.get('forced_vs_auto','')}")
        self.log(f"  winning pattern: {rep.get('winning_pattern','')}")
        props = rep.get("proposals", [])
        if props:
            self.log("  PROPOSED CHANGES (apply manually if you agree):")
            for i, p in enumerate(props, 1):
                self.log(f"   {i}. [{p.get('confidence','?')}] {p.get('change')}: "
                         f"{p.get('suggestion')}")
                self.log(f"      reason: {p.get('reason')}")
                self.log(f"      caution: {p.get('caution')}")
        else:
            self.log("  No proposals (small sample or no AI key).")
        self.log(f"  coach: {rep.get('note_to_trader','')}")
        self.log("=" * 58 + "\n")
        # persist the review beside the journal
        rpath = os.path.join(os.path.dirname(self.journal.path),
                             f"review-{datetime.now(timezone.utc):%Y-%m-%d}.json")
        import json
        with open(rpath, "w", encoding="utf-8") as f:
            json.dump({"stats": stats, "review": rep}, f, indent=2)
        # NOTE: journal push is handled continuously by the live auto-journal loop
        # (_push_closed_trades), which tags account + dedups by position id.
        # The old end-of-day push is intentionally disabled to prevent DUPLICATES.
        self.log("[journal] (auto-journal keeps the journal current; no separate push)")
        return rep

    def status(self):
        pos = self.io.my_positions()
        closed = self.journal.reconcile()
        s = summarize(closed)
        self.log(f"  open positions: {len(pos)} | today: {s['trades']} closed, "
                 f"{s['win_rate']:.0%} win, {s['total_pnl']:+.2f} P/L | "
                 f"auto-entries: {'ON' if self.auto else 'OFF'}")
        for p in pos:
            self.log(f"    #{p['ticket']} {'BUY' if p['side']>0 else 'SELL'} "
                     f"{p['lots']} {p['symbol']} @ {p['open_price']} "
                     f"({p['profit']:+.2f})")
