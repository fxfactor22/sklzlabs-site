"""SKLZ — market regime classification.

Answers one question per symbol per scan: WHAT KIND OF MARKET IS THIS —
so that, once enough trades carry a regime tag, the journal can answer the
question that actually matters: which models earn money in which conditions.

Deliberately simple. Three measured dimensions plus the clock:

  trend   efficiency ratio: net movement / total movement. A market that
          travels 100 pips to move 90 is trending; one that travels 100 to
          move 10 is chop. No indicator folklore, just arithmetic.
  vol     realized volatility vs its own recent history. "High" is only
          meaningful relative to what this instrument has been doing.
  shape   short ATR vs long ATR: compressed (coiling) or expanding.
  session Asian / London / New York / late-NY, plus the rollover flag —
          the thinnest, widest-spread minutes of the day.

No machine learning here on purpose. Rules are inspectable, stable, and
cannot overfit 400 trades. An HMM can replace this only after the rule
version has produced enough tagged trades to beat.
"""
from __future__ import annotations

from datetime import datetime, timezone


def _stdev(xs: list[float]) -> float:
    n = len(xs)
    if n < 2:
        return 0.0
    m = sum(xs) / n
    return (sum((x - m) ** 2 for x in xs) / (n - 1)) ** 0.5


def efficiency_ratio(closes: list[float], n: int = 20) -> float:
    if len(closes) < n + 1:
        return 0.0
    window = closes[-(n + 1):]
    net = abs(window[-1] - window[0])
    path = sum(abs(window[i] - window[i - 1]) for i in range(1, len(window)))
    return net / path if path > 0 else 0.0


def _atr(bars: list[dict], n: int) -> float:
    if len(bars) < n + 1:
        return 0.0
    trs = []
    for i in range(len(bars) - n, len(bars)):
        h, l, pc = bars[i]["high"], bars[i]["low"], bars[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    return sum(trs) / n


def classify(m15: list[dict], now_utc: float | None = None) -> dict:
    """Regime from M15 bars (needs ~120 for stable vol baselines)."""
    out = {"trend": "unknown", "vol": "unknown", "shape": "unknown",
           "session": "unknown", "rollover": False,
           "label": "unknown", "confidence": 0.0}
    if len(m15) < 60:
        return out

    closes = [b["close"] for b in m15]

    # trend — efficiency ratio
    er = efficiency_ratio(closes, 20)
    out["trend"] = ("trending" if er >= 0.35
                    else "ranging" if er <= 0.18 else "mixed")

    # vol — current realized vs its own history
    rets = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    cur = _stdev(rets[-20:])
    hist = [_stdev(rets[i - 20:i]) for i in range(20, len(rets), 5)]
    hist_s = sorted(hist)
    med = hist_s[len(hist_s) // 2] if hist_s else 0.0
    if med > 0:
        r = cur / med
        out["vol"] = "high" if r >= 1.5 else "low" if r <= 0.6 else "normal"

    # shape — short ATR vs long ATR
    a_s, a_l = _atr(m15, 10), _atr(m15, 50)
    if a_l > 0:
        k = a_s / a_l
        out["shape"] = ("compressed" if k <= 0.7
                        else "expanding" if k >= 1.4 else "normal")

    # session — UTC clock
    dt = (datetime.fromtimestamp(now_utc, tz=timezone.utc)
          if now_utc else datetime.now(timezone.utc))
    h, m = dt.hour, dt.minute
    if 7 <= h < 12:
        out["session"] = "london"
    elif 12 <= h < 17:
        out["session"] = "newyork"
    elif 17 <= h < 22:
        out["session"] = "late_ny"
    else:
        out["session"] = "asian"
    out["rollover"] = (h == 21 and m >= 45) or (h == 22 and m < 15)

    decisive = sum(1 for k in ("trend", "vol", "shape")
                   if out[k] not in ("unknown", "mixed", "normal"))
    out["confidence"] = round(decisive / 3, 2)
    out["label"] = f"{out['trend']}/{out['vol']}-vol/{out['shape']}"
    return out
