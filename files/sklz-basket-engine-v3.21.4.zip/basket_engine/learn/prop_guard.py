"""SKLZ — prop-firm circuit breaker.

A prop account is not a normal account. With a 5% daily loss limit AND a 5%
max drawdown on $10,000, the entire life of the account is a $500 budget —
and the firm counts FLOATING losses, so the breach can happen while every
position still "might come back."

The guard's job is to make the firm's rule unreachable by stopping first:

  SOFT  (default 2.5% down):  no new entries. Open trades manage themselves.
  HARD  (default 4.0% down):  flatten everything and halt. The 1% gap to the
        firm's 5% is the slippage budget — a flatten during a fast move fills
        worse than the trigger price, and being stopped by YOUR OWN rule at
        4.2% is survival; being stopped by the firm's at 5.0% is deletion.

Both checks run against BOTH anchors every scan:
  - the day anchor (equity at the configured daily reset hour)
  - the baseline (SKLZ_PROP_BASELINE — the account's initial size)

Whichever anchor is closer to breach decides. The daily reset hour MUST match
the firm's server reset (SKLZ_DAY_RESET_UTC_HOUR); a mismatch means the
engine's "new day" and the firm's disagree, and the firm's opinion is the
only one that matters.
"""
from __future__ import annotations

import os
import time
from datetime import datetime, timezone


def _f(env: str, default: float) -> float:
    try:
        return float(os.environ.get(env, str(default)))
    except (TypeError, ValueError):
        return default


class PropGuard:
    def __init__(self, log=print):
        self.log = log
        self.enabled = os.environ.get("SKLZ_PROP_GUARD", "0") == "1"
        self.baseline = _f("SKLZ_PROP_BASELINE", 0.0)
        self.soft_pct = _f("SKLZ_PROP_SOFT_PCT", 2.5)
        self.hard_pct = _f("SKLZ_PROP_HARD_PCT", 4.0)
        # the overall (baseline) drawdown may have its own, wider firm rule
        # — a 4%-daily / 7%-overall account needs the baseline anchor to
        # trip later than the day anchor, or the guard strangles runway the
        # firm actually grants. Defaults fall back to the daily numbers.
        self.total_soft = _f("SKLZ_PROP_TOTAL_SOFT_PCT", self.soft_pct)
        self.total_hard = _f("SKLZ_PROP_TOTAL_HARD_PCT", self.hard_pct)
        # profit target: reaching it FLATTENS AND LOCKS. An eval that hits
        # target and keeps trading is volunteering to fail it.
        self.target_pct = _f("SKLZ_PROP_TARGET_PCT", 0.0)
        # what reaching target means:
        #   "lock"    — flatten + stop. The withdrawal-cycle loop for funded
        #               accounts: hit +5%, bank it, withdraw, re-anchor the
        #               baseline, restart. Never donates eligibility back.
        #   "protect" — keep trading, but arm a profit floor (default
        #               target-1%). If equity ever falls to the floor,
        #               flatten and stop there — upside stays open, the
        #               withdrawal-worthy gain is defended.
        self.target_mode = os.environ.get("SKLZ_PROP_TARGET_MODE", "lock")
        self.floor_pct = _f("SKLZ_PROP_FLOOR_PCT",
                            max(self.target_pct - 1.0, 0.0))
        self.floor: float | None = None
        self.passed = False
        self.reset_hour = int(_f("SKLZ_DAY_RESET_UTC_HOUR", 0))
        self.max_open = int(_f("SKLZ_PROP_MAX_OPEN", 3))
        self.day_anchor: float | None = None
        self.day_key: str | None = None
        self.halted = False
        self._last_state = ""

    def _day_key(self, now: datetime) -> str:
        # the "prop day" starts at reset_hour UTC, not midnight
        shifted = now.timestamp() - self.reset_hour * 3600
        return datetime.fromtimestamp(shifted, tz=timezone.utc).strftime(
            "%Y-%m-%d")

    def check(self, io) -> dict:
        """Returns {"entries_ok": bool, "reason": str}. Flattens on HARD."""
        if not self.enabled:
            return {"entries_ok": True, "reason": ""}

        try:
            acct = io.account() or {}
            equity = float(acct.get("equity") or 0.0)
        except Exception:
            return {"entries_ok": False,
                    "reason": "cannot read equity — refusing entries "
                              "rather than guessing"}
        if equity <= 0:
            return {"entries_ok": False, "reason": "no equity reading"}

        now = datetime.now(timezone.utc)
        dk = self._day_key(now)
        if dk != self.day_key:
            self.day_key = dk
            self.day_anchor = equity
            self.halted = False
            self.log(f"[prop] new trading day — anchor {equity:.2f}, "
                     f"budget to soft stop "
                     f"{equity * self.soft_pct / 100:.2f}, to hard stop "
                     f"{equity * self.hard_pct / 100:.2f}")

        if self.passed:
            return {"entries_ok": False,
                    "reason": "TARGET REACHED — account locked in profit"}

        if self.floor is not None and equity <= self.floor:
            self.passed = True
            n = 0
            try:
                n = io.close_all()
            except Exception as exc:  # noqa: BLE001
                self.log(f"[prop] floor flatten failed: "
                         f"{type(exc).__name__}: {exc} — CLOSE MANUALLY")
            self.log(f"[prop] PROFIT FLOOR DEFENDED at {equity:.2f} — "
                     f"closed {n} position(s), entries locked. The gain "
                     f"above +{self.floor_pct:.1f}% was spent probing "
                     f"higher; what remains is banked. Withdraw or "
                     f"re-anchor to continue.")
            return {"entries_ok": False, "reason": "profit floor hit"}

        if (self.target_pct > 0 and self.baseline > 0 and not self.passed
                and self.floor is None
                and equity >= self.baseline * (1 + self.target_pct / 100)):
            if self.target_mode == "protect":
                self.floor = self.baseline * (1 + self.floor_pct / 100)
                self.log(f"[prop] *** WITHDRAWAL THRESHOLD REACHED *** "
                         f"equity {equity:.2f}. Mode=protect: trading "
                         f"continues, profit floor armed at "
                         f"{self.floor:.2f} (+{self.floor_pct:.1f}%). "
                         f"Falling to the floor flattens and locks.")
                return {"entries_ok": True, "reason": ""}
            self.passed = True
            n = 0
            try:
                n = io.close_all()
            except Exception as exc:  # noqa: BLE001
                self.log(f"[prop] target flatten failed: "
                         f"{type(exc).__name__}: {exc} — CLOSE MANUALLY")
            self.log(f"[prop] *** PROFIT TARGET REACHED *** equity "
                     f"{equity:.2f} >= {self.baseline * (1 + self.target_pct / 100):.2f}. "
                     f"Closed {n} position(s). Entries LOCKED — request "
                     f"the payout/next phase; do not give this back.")
            return {"entries_ok": False, "reason": "target reached"}

        if self.halted:
            return {"entries_ok": False,
                    "reason": "halted until the next trading day"}

        anchors = [("day", self.day_anchor or equity)]
        if self.baseline > 0:
            anchors.append(("baseline", self.baseline))

        # each anchor carries its own thresholds now
        worst_dd, worst_name = 0.0, "day"
        worst_soft, worst_hard = self.soft_pct, self.hard_pct
        for name, ref in anchors:
            if ref <= 0:
                continue
            dd = (ref - equity) / ref * 100
            s = self.soft_pct if name == "day" else self.total_soft
            h = self.hard_pct if name == "day" else self.total_hard
            # "closer to ITS OWN hard line" decides, not raw dd
            if h > 0 and (worst_hard <= 0 or dd / h > worst_dd / worst_hard):
                worst_dd, worst_name = dd, name
                worst_soft, worst_hard = s, h

        if worst_dd >= worst_hard:
            self.halted = True
            n = 0
            try:
                n = io.close_all()
            except Exception as exc:  # noqa: BLE001
                self.log(f"[prop] FLATTEN FAILED: {type(exc).__name__}: "
                         f"{exc} — CLOSE MANUALLY NOW")
            self.log(f"[prop] HARD STOP — {worst_dd:.2f}% down from the "
                     f"{worst_name} anchor (its hard line: "
                     f"{worst_hard:.1f}%). Closed {n} position(s). No more "
                     f"entries today. Stopping before the firm does is what "
                     f"keeps the account alive.")
            return {"entries_ok": False, "reason": "hard stop hit"}

        if worst_dd >= worst_soft:
            state = "soft"
            if self._last_state != state:
                self.log(f"[prop] SOFT STOP — {worst_dd:.2f}% down from the "
                         f"{worst_name} anchor. No new entries; open trades "
                         f"run their stops. Resumes if equity recovers or "
                         f"at the next day anchor.")
            self._last_state = state
            return {"entries_ok": False, "reason": "soft stop active"}

        self._last_state = "ok"

        # concurrency cap: three positions at 0.5% risk each is a 1.5%
        # correlated worst case — inside the soft budget, never past it
        try:
            n_open = len(io.my_positions() or [])
            if n_open >= self.max_open:
                return {"entries_ok": False,
                        "reason": f"{n_open} positions open — the prop cap "
                                  f"is {self.max_open} at once"}
        except Exception:
            pass

        return {"entries_ok": True, "reason": ""}
