"""SKLZ — high-impact news blackout.

The first minutes after a major release are spread expansion, slippage and
one-sided books. Whatever edge the models have assumes a functioning market,
and for those few minutes there isn't one.

The rule: no NEW auto entries on an affected currency from shortly before a
high-impact event until a few minutes after. Existing positions are left
alone — their stops manage them — and forced dashboard orders still work,
because the owner overriding a filter is the owner's right.

The opportunity is not lost. The M5 candle that completes after the blackout
IS the post-news structure, and every model already reads completed candles.
Straddling the release itself sounds clever and pays the spread twice at the
worst moment of the week; entering the first confirmed structure after the
dust settles is the version of "trading the news" that survives retail costs.

Feed: Forex Factory weekly JSON. Cached; a dead feed fails OPEN with a log
line (the bot trades normally) rather than silently blocking everything —
a stale calendar should never become a hidden kill switch.
"""
from __future__ import annotations

import json
import os
import time
import urllib.request
from datetime import datetime, timezone

FEED = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"

_cache: dict = {"at": 0.0, "events": []}


def _fetch() -> list[dict]:
    req = urllib.request.Request(FEED, headers={
        "User-Agent": "SKLZ-Labs/1.0 (+https://www.sklzlabs.com)"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode())


def events(log=None) -> list[dict]:
    """High-impact events, cached for 4 hours."""
    now = time.time()
    if now - _cache["at"] > 4 * 3600:
        try:
            raw = _fetch()
            out = []
            for e in raw:
                if e.get("impact") != "High":
                    continue
                try:
                    ts = datetime.fromisoformat(e["date"]).timestamp()
                except (KeyError, ValueError):
                    continue
                out.append({"ts": ts, "ccy": e.get("country", ""),
                            "title": e.get("title", "")})
            _cache["events"] = out
            _cache["at"] = now
            if log:
                log(f"[news] calendar refreshed — {len(out)} high-impact "
                    f"events this week")
        except Exception as exc:  # noqa: BLE001
            # fail OPEN: no calendar means no blackout, said out loud
            _cache["at"] = now - 3 * 3600   # retry in an hour
            if log:
                log(f"[news] calendar fetch failed ({type(exc).__name__}) — "
                    f"news filter inactive until it recovers")
    return _cache["events"]


def _currencies(symbol: str) -> set[str]:
    s = (symbol or "").upper()
    for suf in ("..", ".", "m", "c", "r", "_", "#"):
        if s.endswith(suf):
            s = s[: -len(suf)]
    if s.startswith(("XAU", "XAG", "GOLD", "SILVER")):
        return {"USD"}
    if s.startswith(("USO", "UKO", "WTI", "XTI", "BRENT", "OIL", "NGAS")):
        return {"USD"}
    if s.startswith(("US30", "US500", "USTEC", "NAS", "SPX")):
        return {"USD"}
    if s.startswith(("DE40", "DE30", "GER", "STOXX")):
        return {"EUR"}
    if s.startswith("UK100"):
        return {"GBP"}
    if s.startswith(("JP225",)):
        return {"JPY"}
    if s.startswith(("AUS200",)):
        return {"AUD"}
    if s.startswith(("BTC", "ETH", "XRP", "SOL", "LTC", "ADA", "DOGE")):
        return {"USD"}          # crypto trades the dollar leg on news
    if len(s) >= 6:
        return {s[:3], s[3:6]}
    return set()


def blackout(symbol: str, now_ts: float | None = None,
             log=None) -> tuple[bool, str]:
    """(blocked, reason). Window: BEFORE_MIN before to AFTER_MIN after."""
    try:
        before = float(os.environ.get("SKLZ_NEWS_BLOCK_BEFORE_MIN", "2"))
        after = float(os.environ.get("SKLZ_NEWS_BLOCK_AFTER_MIN", "5"))
    except ValueError:
        before, after = 2.0, 5.0
    if os.environ.get("SKLZ_NEWS_FILTER", "1") == "0":
        return False, ""

    now_ts = now_ts if now_ts is not None else time.time()
    ccys = _currencies(symbol)
    if not ccys:
        return False, ""

    for e in events(log=log):
        if e["ccy"] not in ccys:
            continue
        dt = now_ts - e["ts"]
        if -before * 60 <= dt <= after * 60:
            when = (f"in {-dt/60:.0f}min" if dt < 0
                    else f"{dt/60:.0f}min ago")
            return True, (f"{e['ccy']} {e['title']} {when} — first minutes "
                          f"after a release are spread and slippage, not "
                          f"structure. Entries resume at "
                          f"T+{after:.0f}min.")
    return False, ""
