"""SKLZ — correlated exposure limits.

THE PROBLEM THIS SOLVES
=======================
Long EURUSD, short USDCHF, long gold and short USDJPY looks like four
positions. It is one bet: the dollar falls. If the dollar rallies, all four
lose together, and a risk model that caps each trade at 2% has quietly allowed
8% on a single view.

This is how accounts die while every individual trade looks responsible. The
per-trade cap is necessary and completely insufficient on its own.

HOW EXPOSURE IS MEASURED
========================
Every FX pair is a bet on two currencies. Long EURUSD is long EUR and short
USD. Long XAUUSD is short USD with gold on the other side. Adding up the
signed exposure per currency across all open positions shows what the account
is actually betting on, rather than what the position list appears to say.

The limit is on NET CURRENCY exposure, not on position count. Ten positions
that offset each other are safer than two that align.
"""
from __future__ import annotations

import os

# what each instrument is a bet on, as (base, quote)
# gold and silver are treated as currencies in their own right against USD
SPECIALS = {
    "XAUUSD": ("XAU", "USD"),
    "XAGUSD": ("XAG", "USD"),
    "USOUSD": ("OIL", "USD"),
    "UKOUSD": ("OIL", "USD"),
    "USOIL":  ("OIL", "USD"),
    "UKOIL":  ("OIL", "USD"),
    "BTCUSD": ("BTC", "USD"),
    "ETHUSD": ("ETH", "USD"),
    "US30":   ("IDX", "USD"),
    "US500":  ("IDX", "USD"),
    "NAS100": ("IDX", "USD"),
    "DE40":   ("IDX", "EUR"),
    "UK100":  ("IDX", "GBP"),
    "JP225":  ("IDX", "JPY"),
}


def max_currency_exposure() -> float:
    """Cap on net exposure to any single currency, as a multiple of the
    per-trade risk. Default 3 means: never more than three trades' worth of
    risk pointing the same way on one currency."""
    try:
        return float(os.environ.get("SKLZ_MAX_CURRENCY_EXPOSURE", "3"))
    except (TypeError, ValueError):
        return 3.0


def split(symbol: str) -> tuple[str, str]:
    """What this instrument is actually a bet on."""
    s = (symbol or "").upper()
    # strip broker suffixes: XAUUSD.., EURUSDm, GBPUSD.r
    for ch in ("..", ".", "m", "c", "r", "_", "#"):
        if s.endswith(ch):
            s = s[: -len(ch)]
    s = s.strip(".")

    for k, v in SPECIALS.items():
        if s.startswith(k):
            return v
    if len(s) >= 6:
        return (s[:3], s[3:6])
    return (s, "USD")


def exposure_map(positions: list[dict]) -> dict:
    """Net signed exposure per currency across all open positions.

    Each position contributes +1 unit to the currency it is long and -1 to the
    currency it is short, scaled by lot size so a 0.10 position counts ten
    times a 0.01 one.
    """
    net: dict = {}
    for p in positions or []:
        sym = p.get("symbol") or ""
        side = 1 if (p.get("side") or 0) > 0 else -1
        lots = float(p.get("lots") or p.get("volume") or 0.01)
        base, quote = split(sym)
        net[base] = net.get(base, 0.0) + side * lots
        net[quote] = net.get(quote, 0.0) - side * lots
    return {k: round(v, 4) for k, v in net.items() if abs(v) > 1e-9}


def would_breach(positions: list[dict], symbol: str, side: int,
                 lots: float, unit_lot: float = 0.01) -> dict:
    """Would adding this position push any currency past the limit?

    Returns a decision with the reasoning, so a refusal can be explained
    rather than just delivered.
    """
    limit_units = max_currency_exposure()
    limit = limit_units * unit_lot

    before = exposure_map(positions)
    after = exposure_map(list(positions or []) +
                         [{"symbol": symbol, "side": side, "lots": lots}])

    for ccy, amount in after.items():
        if abs(amount) <= limit:
            continue
        # only block when this trade makes it worse — closing exposure should
        # never be refused for being large
        was = abs(before.get(ccy, 0.0))
        if abs(amount) <= was:
            continue

        direction = "long" if amount > 0 else "short"
        count = abs(amount) / unit_lot
        return {
            "ok": False,
            "currency": ccy,
            "exposure": amount,
            "reason": (
                f"this would make the account {direction} {ccy} by "
                f"{count:.1f} units — past the {limit_units:.0f} unit limit. "
                f"Positions that look separate can be one bet: adding it means "
                f"a single {ccy} move decides several trades at once."),
        }

    return {"ok": True, "exposure": after}


def describe(positions: list[dict], unit_lot: float = 0.01) -> str:
    """One line summarising what the account is actually betting on."""
    net = exposure_map(positions)
    if not net:
        return "no open exposure"
    parts = []
    for ccy, amt in sorted(net.items(), key=lambda kv: -abs(kv[1])):
        units = amt / unit_lot
        if abs(units) < 0.5:
            continue
        parts.append(f"{'+' if units > 0 else ''}{units:.0f} {ccy}")
    return " · ".join(parts[:6]) if parts else "flat"
