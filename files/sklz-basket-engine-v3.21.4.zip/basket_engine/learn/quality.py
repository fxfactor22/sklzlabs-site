"""Signal quality gate — publish fewer, better setups.

The scanners each fire on ONE condition, which is why they produce noise.
This module scores a symbol's combined scanner output and only lets
high-conviction setups through.

Scoring (0-100):
  confluence        up to 45   two or three scanners agreeing on direction
  htf_alignment     up to 25   higher timeframe agrees with the signal
  momentum          up to 15   the most recent bar moves with the signal
  volatility_ok     up to 15   ATR is in a sane band (not dead, not exploding)

Honest note: this does NOT convert a coin-flip into an edge. SKLZ's own
27M-tick research says these setups are frequently coin-flips out-of-sample.
Filtering raises conviction and cuts noise; the journal still decides whether
any of it actually works. Quality gate, not a promise.
"""
from __future__ import annotations

import os


def _f(env: str, default: float) -> float:
    try:
        return float(os.environ.get(env, default))
    except (TypeError, ValueError):
        return default


def min_score() -> float:
    """Publish threshold. Raise it to get fewer, stronger signals."""
    return _f("SKLZ_SIGNAL_MIN_SCORE", 60)


def _sma(vals: list[float]) -> float:
    return sum(vals) / len(vals) if vals else 0.0


def _htf_direction(io, symbol: str, tf_min: int, lookback: int = 20) -> int:
    """Higher-timeframe bias: compare price to its own average on a 4x timeframe."""
    htf = max(tf_min * 4, 60)
    try:
        c = io.closes(symbol, htf, lookback + 1)
    except Exception:
        return 0
    if len(c) < 5:
        return 0
    avg = _sma(c[:-1])
    if not avg:
        return 0
    if c[-1] > avg:
        return +1
    if c[-1] < avg:
        return -1
    return 0


def _atr_state(io, symbol: str, tf_min: int) -> tuple[float, str]:
    """Return (atr, state) where state is 'dead' | 'ok' | 'wild'."""
    try:
        c = io.closes(symbol, tf_min, 40)
    except Exception:
        return 0.0, "dead"
    if len(c) < 20:
        return 0.0, "dead"
    moves = [abs(c[i] - c[i - 1]) for i in range(1, len(c))]
    recent = _sma(moves[-14:])
    baseline = _sma(moves)
    if not baseline or not recent:
        return recent, "dead"
    ratio = recent / baseline
    if ratio < 0.55:
        return recent, "dead"        # chop / dead session
    if ratio > 2.2:
        return recent, "wild"        # news spike — spreads and slippage
    return recent, "ok"


def score_setup(io, symbol: str, tf_min: int,
                hits: list[tuple[str, int, str]]) -> dict:
    """hits = [(scanner_name, side, detail), ...] for ONE symbol.

    Returns a dict with the winning side, score, and human-readable reasons.
    """
    if not hits:
        return {"publish": False, "score": 0, "side": 0, "reasons": []}

    # 1) confluence — which direction do the scanners agree on?
    longs = [h for h in hits if h[1] > 0]
    shorts = [h for h in hits if h[1] < 0]
    if len(longs) == len(shorts):
        # conflicting signals cancel out — this is exactly the noise to skip
        return {"publish": False, "score": 0, "side": 0,
                "reasons": ["scanners disagree — stand aside"]}
    winners = longs if len(longs) > len(shorts) else shorts
    side = 1 if winners is longs else -1
    agree = len(winners)

    score = 0.0
    reasons: list[str] = []

    conf_pts = {1: 12.0, 2: 32.0, 3: 45.0}.get(agree, 45.0)

    # The structured models (A: M15 break-retest, B: HTF block + fib 50) carry
    # more weight than a scanner hit, because they require a SEQUENCE to have
    # occurred — a level broken, retested and held, with RSI confirming at the
    # right moment — rather than a single condition being true right now.
    #
    # This is a prior, not a finding. It comes from the owner's own trading
    # experience, which is real evidence but not measured evidence. Outcomes
    # are recorded per source, so after enough trades the journal will either
    # support the weighting or contradict it — and if it contradicts, this
    # number should come back down rather than the data being explained away.
    model_hits = [w for w in winners if w[0].startswith("model_")]
    if model_hits:
        try:
            bonus = float(os.environ.get("SKLZ_MODEL_BONUS", "22"))
        except ValueError:
            bonus = 22.0
        conf_pts += bonus
        reasons.append(
            f"{len(model_hits)} structured model fired "
            f"({', '.join(m[0] for m in model_hits)}) — a full sequence, "
            f"not a single condition")

    score += conf_pts
    names = ", ".join(w[0] for w in winners)
    reasons.append(f"{agree} signal{'s' if agree > 1 else ''} agree ({names})")

    # 2) higher timeframe alignment
    htf = _htf_direction(io, symbol, tf_min)
    if htf == side:
        score += 25
        reasons.append("higher timeframe agrees")
    elif htf == 0:
        score += 8
        reasons.append("higher timeframe flat")
    else:
        reasons.append("against the higher timeframe")

    # 3) momentum on the entry bar
    try:
        c = io.closes(symbol, tf_min, 3)
        if len(c) >= 2:
            mom = c[-1] - c[-2]
            if (mom > 0 and side > 0) or (mom < 0 and side < 0):
                score += 15
                reasons.append("momentum confirms")
            else:
                reasons.append("momentum against entry")
    except Exception:
        pass

    # 4) volatility sanity
    atr, state = _atr_state(io, symbol, tf_min)
    if state == "ok":
        score += 15
        reasons.append("volatility normal")
    elif state == "dead":
        reasons.append("low volatility / chop")
    else:
        reasons.append("volatility spike — wide spreads likely")

    score = round(min(score, 100.0), 1)
    return {
        "publish": score >= min_score(),
        "score": score,
        "side": side,
        "agree": agree,
        "atr": atr,
        "reasons": reasons,
        "detail": winners[0][2],
        "scanners": [w[0] for w in winners],
    }
