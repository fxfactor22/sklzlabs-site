"""SKLZ — structure-aware stop placement.

Stops were being set from ATR alone, which put them at arbitrary distances
with no relation to where price would actually have to trade to prove the
idea wrong. That is why trades were stopping out early: the stop sat inside
normal noise rather than beyond the level that mattered.

The rule this implements:

    find the nearest M15 swing pivot beyond entry
    place the stop just past it (a small buffer, so a wick does not clip it)
    clamp the result to between MIN_PIPS and MAX_PIPS

Worked example, AUDUSD buy at 0.69800:
    nearest pivot low   0.69200  ->  60 pips away
    60 exceeds the cap  ->  stop placed at 0.69300  (50 pips)

If the pivot is nearer than the minimum, the stop widens to MIN_PIPS instead,
because a 5-pip stop on a 15-minute structure is not a stop, it is a coin toss.
"""
from __future__ import annotations

import os


def _f(env: str, default: float) -> float:
    try:
        return float(os.environ.get(env, default))
    except (TypeError, ValueError):
        return default


# The 20-50 pip band is calibrated for FX. Gold moves $5 in an hour and
# Bitcoin far more, so the same band there would sit inside normal noise and
# stop out constantly — the exact problem this module exists to fix.
# Bands are per instrument class, in that instrument's own pips.
BANDS = {
    "fx":      (20, 50),
    "jpy":     (20, 50),
    "gold":    (50, 150),      # XAU pip is 0.1, so $5 - $15
    "silver":  (20, 60),       # XAG pip is 0.01, so $0.20 - $0.60
    "metals":  (50, 150),
    "indices": (30, 120),      # US30/NAS: 30 - 120 points
    "crypto":  (100, 400),     # BTC: $100 - $400
    "energy":  (20, 60),
}


def _klass(symbol: str) -> str:
    s = (symbol or "").upper()
    # gold and silver both quote in dollars but their pip sizes differ by 10x,
    # so one shared band gave silver stops ten times too wide in real money
    if s.startswith(("XAU", "GOLD")):
        return "gold"
    if s.startswith(("XAG", "SILVER")):
        return "silver"
    if s.startswith(("BTC", "ETH", "XRP", "LTC", "SOL")):
        return "crypto"
    if s.startswith(("US30", "NAS", "SPX", "GER", "UK100", "JP225", "AUS200",
                     "USTEC", "DE40", "US500")):
        return "indices"
    if s.startswith(("USO", "UKO", "WTI", "BRENT", "OIL")):
        return "energy"
    if "JPY" in s:
        return "jpy"
    return "fx"


def min_pips(symbol: str = "") -> float:
    override = os.environ.get("SKLZ_SL_MIN_PIPS")
    if override:
        return _f("SKLZ_SL_MIN_PIPS", 20)
    return BANDS[_klass(symbol)][0]


def max_pips(symbol: str = "") -> float:
    override = os.environ.get("SKLZ_SL_MAX_PIPS")
    if override:
        return _f("SKLZ_SL_MAX_PIPS", 50)
    return BANDS[_klass(symbol)][1]


def buffer_pips() -> float:
    """How far beyond the pivot to sit, so a wick does not take the stop."""
    return _f("SKLZ_SL_BUFFER_PIPS", 2)


def find_pivots(highs: list[float], lows: list[float],
                left: int = 2, right: int = 2) -> tuple[list[float], list[float]]:
    """Swing highs and lows. A pivot high is a bar higher than `left` bars
    before and `right` bars after it; a pivot low is the mirror.

    `right` bars must have closed for a pivot to be confirmed — an unconfirmed
    pivot is just the current bar, and building a stop on it is guesswork.
    """
    ph, pl = [], []
    n = min(len(highs), len(lows))
    for i in range(left, n - right):
        window_h = highs[i - left:i + right + 1]
        window_l = lows[i - left:i + right + 1]
        if highs[i] == max(window_h) and window_h.count(highs[i]) == 1:
            ph.append(highs[i])
        if lows[i] == min(window_l) and window_l.count(lows[i]) == 1:
            pl.append(lows[i])
    return ph, pl


def nearest_pivot(side: int, entry: float,
                  pivot_highs: list[float], pivot_lows: list[float]) -> float | None:
    """The closest pivot that sits beyond the entry in the risk direction.

    For a buy that is the nearest swing low BELOW entry; for a sell, the
    nearest swing high ABOVE it.
    """
    if side > 0:
        below = [p for p in pivot_lows if p < entry]
        return max(below) if below else None
    above = [p for p in pivot_highs if p > entry]
    return min(above) if above else None


def place_stop(side: int, entry: float, pip: float,
               pivot: float | None, digits: int = 5,
               symbol: str = "") -> dict:
    """Work out where the stop belongs. Pure function, no market calls.

    Returns the price, the distance in pips, and why it landed there — so the
    reasoning shows up in the journal rather than being invisible.
    """
    lo, hi = min_pips(symbol), max_pips(symbol)
    buf = buffer_pips()

    if pivot is None:
        dist = (lo + hi) / 2                      # no structure found: middle
        why = f"no M15 pivot found — default {dist:.0f} pips"
    else:
        raw = abs(entry - pivot) / pip + buf
        if raw < lo:
            dist, why = lo, (f"pivot only {raw - buf:.0f} pips away — widened to "
                             f"the {lo:.0f} pip minimum")
        elif raw > hi:
            dist, why = hi, (f"pivot {raw - buf:.0f} pips away — capped at the "
                             f"{hi:.0f} pip maximum")
        else:
            dist, why = raw, (f"just beyond the M15 pivot at {pivot:.{digits}f} "
                              f"({raw:.0f} pips)")

    sl = entry - dist * pip if side > 0 else entry + dist * pip
    return {"sl": round(sl, digits), "pips": round(dist, 1),
            "pivot": pivot, "reason": why}


def stop_for(io, symbol: str, side: int, entry: float,
             tf_min: int = 15, bars: int = 60, log=print) -> dict | None:
    """Read M15 structure from the broker and place the stop.

    Returns None if the data is unavailable, so the caller can fall back
    rather than guessing.
    """
    try:
        from basket_engine.learn.trailing import pip_size
        spec = io.spec(symbol)
        digits = int(spec.get("digits") or 5)
        pip = pip_size(symbol, digits)
    except Exception:
        return None

    highs = lows = None
    for getter in ("highs", "bars", "ohlc"):
        fn = getattr(io, getter, None)
        if not fn:
            continue
        try:
            data = fn(symbol, tf_min, bars)
            if isinstance(data, dict):
                highs, lows = data.get("high"), data.get("low")
            elif isinstance(data, (list, tuple)) and data and isinstance(data[0], dict):
                highs = [b.get("high") for b in data]
                lows = [b.get("low") for b in data]
            if highs and lows:
                break
        except Exception:
            continue

    # closes-only fallback: treat local extremes of the close series as pivots
    if not (highs and lows):
        try:
            c = io.closes(symbol, tf_min, bars)
            highs = lows = c
        except Exception:
            return None

    ph, pl = find_pivots(list(highs), list(lows))
    pivot = nearest_pivot(side, entry, ph, pl)
    out = place_stop(side, entry, pip, pivot, digits, symbol)
    log(f"[stop] {symbol} {'BUY' if side > 0 else 'SELL'} @ {entry} -> "
        f"SL {out['sl']} ({out['pips']:.0f} pips) — {out['reason']}")
    return out
