"""SKLZ — trade context capture.

Every trade becomes a research observation, not just a P/L line.

WHY THIS COMES FIRST
====================
A research pipeline is only as good as what it recorded at the time. You
cannot go back and ask "what was the spread when that trade failed" if nobody
wrote it down. Most of the questions worth asking later depend on data that
only exists at the moment of the trade.

So this captures wide and captures early, even for fields whose predictive
value is unknown. Storage is cheap; a lost observation is gone permanently.

WHAT THIS DELIBERATELY DOES NOT DO
==================================
It does not draw conclusions. With fewer than a few hundred trades, any
"finding" is noise — a 55% win rate over 90 trades has a confidence interval
of roughly 45-65%, which includes a coin-flip. The statistics module refuses
to report an edge until the sample can support one, and says how many more
trades are needed.

That restraint is the research discipline, not a limitation of it.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone


def _safe(fn, default=None):
    try:
        return fn()
    except Exception:
        return default


def capture_entry(io, symbol: str, side: int, strategy: str,
                  quality: dict | None = None,
                  institutional: dict | None = None,
                  orderflow: dict | None = None) -> dict:
    """Everything knowable at the moment of entry.

    Fields whose usefulness is unproven are still recorded — the point is to
    be able to test them later, not to assume they matter now.
    """
    now = datetime.now(timezone.utc)
    spec = _safe(lambda: io.spec(symbol), {}) or {}
    ctx: dict = {
        "captured_at": now.isoformat(),
        "symbol": symbol,
        "side": "buy" if side > 0 else "sell",
        "strategy": strategy,

        # ── session and timing ──
        "hour_utc": now.hour,
        "weekday": now.weekday(),                 # 0 = Monday
        "session": _session_name(now.hour),
        "minutes_into_session": _minutes_into_session(now),

        # ── price and volatility ──
        "entry_price": _safe(lambda: io.price(symbol, side)),
        "spread": _safe(lambda: _spread(io, symbol)),
        "spread_pips": None,
        "atr_m15": _safe(lambda: _atr(io, symbol, 15)),
        "atr_h1": _safe(lambda: _atr(io, symbol, 60)),
        "atr_percentile": None,                   # filled below
        "digits": spec.get("digits"),
    }

    # spread relative to the instrument, which is what actually matters
    pip = _safe(lambda: _pip_size(symbol, spec.get("digits")), 0.0001)
    if ctx["spread"] and pip:
        ctx["spread_pips"] = round(ctx["spread"] / pip, 2)
    if ctx["atr_m15"] and pip:
        ctx["atr_m15_pips"] = round(ctx["atr_m15"] / pip, 1)

    # ── where price sits in its recent range ──
    bars = _safe(lambda: io.bars(symbol, 15, 100), []) or []
    if len(bars) >= 30:
        highs = [b["high"] for b in bars]
        lows = [b["low"] for b in bars]
        closes = [b["close"] for b in bars]
        hi, lo = max(highs[-50:]), min(lows[-50:])
        px = closes[-1]
        ctx["range_position"] = round((px - lo) / (hi - lo), 3) if hi > lo else None
        ctx["bars_since_high"] = _bars_since(highs, max(highs[-50:]))
        ctx["bars_since_low"] = _bars_since(lows, min(lows[-50:]))

        # volatility regime: is current ATR unusual for this instrument?
        atrs = _rolling_atr(bars, 14)
        if atrs and ctx.get("atr_m15"):
            below = sum(1 for a in atrs if a < ctx["atr_m15"])
            ctx["atr_percentile"] = round(below / len(atrs), 3)
            ctx["volatility_regime"] = (
                "expanded" if ctx["atr_percentile"] > 0.75 else
                "compressed" if ctx["atr_percentile"] < 0.25 else "normal")

        # trend quality, not just direction
        ctx["trend_efficiency"] = _efficiency(closes[-30:])
        ctx["regime"] = _regime(ctx.get("trend_efficiency"),
                                ctx.get("atr_percentile"))

    # ── what the decision engines saw ──
    if quality:
        ctx["quality_score"] = quality.get("score")
        ctx["quality_detail"] = quality.get("detail")
        ctx["scanners_agreeing"] = quality.get("agreeing")
    if institutional:
        ctx["institutional_score"] = getattr(institutional, "score", None)
        ctx["institutional_flags"] = list(getattr(institutional, "flags", []))
        ctx["inputs_used"] = list(getattr(institutional, "inputs_used", []))
        ctx["inputs_missing"] = list(getattr(institutional, "inputs_missing", []))
    if orderflow:
        ctx["book_imbalance"] = (orderflow.get("book") or {}).get("imbalance")
        ctx["delta_imbalance"] = (orderflow.get("delta") or {}).get("imbalance")
        ctx["delta_quality"] = (orderflow.get("delta") or {}).get("quality")
        ctx["absorbed"] = orderflow.get("absorbed")
        ctx["wall_ahead"] = (orderflow.get("wall") or {}).get("found")

    # ── account state, for sizing analysis later ──
    acct = _safe(lambda: io.account(), {}) or {}
    ctx["equity_at_entry"] = acct.get("equity")
    ctx["open_positions"] = _safe(lambda: len(io.my_positions()), None)

    return ctx


def capture_exit(entry_ctx: dict, exit_price: float, pnl: float,
                 exit_reason: str = "", io=None) -> dict:
    """What happened, and how the trade behaved on the way there."""
    now = datetime.now(timezone.utc)
    entered = entry_ctx.get("captured_at")
    held_min = None
    if entered:
        try:
            t0 = datetime.fromisoformat(str(entered).replace("Z", "+00:00"))
            held_min = round((now - t0).total_seconds() / 60, 1)
        except ValueError:
            pass

    entry = entry_ctx.get("entry_price") or 0
    side = 1 if entry_ctx.get("side") == "buy" else -1
    pip = 0.0001
    try:
        from basket_engine.learn.trailing import pip_size
        pip = pip_size(entry_ctx.get("symbol", ""), entry_ctx.get("digits"))
    except Exception:
        pass

    result_pips = ((exit_price - entry) if side > 0 else (entry - exit_price)) / pip \
        if entry and exit_price else None

    out = {
        "exit_at": now.isoformat(),
        "exit_price": exit_price,
        "pnl": pnl,
        "result_pips": round(result_pips, 1) if result_pips is not None else None,
        "held_minutes": held_min,
        "exit_reason": exit_reason,
        "outcome": ("win" if pnl > 0 else "loss" if pnl < 0 else "breakeven"),
    }

    # how far did it go the right way before it ended? the gap between
    # favourable excursion and result is where exit quality lives
    if io and entry:
        bars = _safe(lambda: io.bars(entry_ctx.get("symbol", ""), 5, 200), []) or []
        if bars and entered:
            try:
                t0 = datetime.fromisoformat(str(entered).replace("Z", "+00:00"))
                during = [b for b in bars
                          if datetime.fromtimestamp(b["time"], timezone.utc) >= t0]
                if during:
                    if side > 0:
                        mfe = (max(b["high"] for b in during) - entry) / pip
                        mae = (min(b["low"] for b in during) - entry) / pip
                    else:
                        mfe = (entry - min(b["low"] for b in during)) / pip
                        mae = (entry - max(b["high"] for b in during)) / pip
                    out["max_favourable_pips"] = round(mfe, 1)
                    out["max_adverse_pips"] = round(mae, 1)
                    if result_pips is not None and mfe > 0:
                        out["capture_ratio"] = round(result_pips / mfe, 3)
            except Exception:
                pass
    return out


def classify_failure(entry_ctx: dict, exit_ctx: dict) -> dict:
    """Why did this lose? Classified from what was recorded, not guessed.

    The categories are deliberately mechanical. "Bad luck" is not a category —
    if the data cannot explain it, that is said plainly rather than invented.
    """
    if exit_ctx.get("outcome") != "loss":
        return {"category": None}

    reasons = []
    cat = "unexplained"

    mae = exit_ctx.get("max_adverse_pips")
    mfe = exit_ctx.get("max_favourable_pips")
    held = exit_ctx.get("held_minutes") or 0

    # never went the right way at all
    if mfe is not None and mfe < 3:
        cat = "wrong_direction"
        reasons.append("price never moved in favour — the read was simply wrong")

    # went well then reversed
    elif mfe is not None and mfe > 20 and (exit_ctx.get("result_pips") or 0) < 0:
        cat = "gave_back"
        reasons.append(f"reached +{mfe:.0f} pips then reversed to a loss — "
                       f"this is an exit problem, not an entry problem")

    # stopped almost immediately
    elif held < 5:
        cat = "stopped_instantly"
        reasons.append(f"closed after {held:.0f} minutes — the stop was inside "
                       f"normal noise for this instrument")

    # spread was a meaningful share of the move
    sp = entry_ctx.get("spread_pips")
    if sp and exit_ctx.get("result_pips") and abs(exit_ctx["result_pips"]) < sp * 3:
        reasons.append(f"spread was {sp} pips against a {abs(exit_ctx['result_pips']):.0f} "
                       f"pip move — costs dominated the outcome")
        if cat == "unexplained":
            cat = "cost_dominated"

    # entered into conditions the engines had flagged
    if entry_ctx.get("absorbed"):
        reasons.append("order flow showed absorption at entry — this was flagged "
                       "and taken anyway")
        cat = "ignored_warning"
    if entry_ctx.get("wall_ahead"):
        reasons.append("a resting wall sat in the path at entry")

    if entry_ctx.get("volatility_regime") == "compressed":
        reasons.append("volatility was compressed — the move may simply not have "
                       "had room")
    if entry_ctx.get("session") in ("asian", "off-hours"):
        reasons.append(f"taken during {entry_ctx['session']} — thin liquidity, "
                       f"wider spreads")

    if cat == "unexplained" and not reasons:
        reasons.append("nothing in the recorded context explains this loss. "
                       "That is itself information: it may be variance, or a "
                       "factor not yet being captured.")

    return {"category": cat, "reasons": reasons}


# ── helpers ─────────────────────────────────────────────────────────
def _session_name(hour: int) -> str:
    if 12 <= hour < 16:
        return "london_ny_overlap"
    if 7 <= hour < 12:
        return "london"
    if 16 <= hour < 21:
        return "new_york"
    if 0 <= hour < 7:
        return "asian"
    return "off-hours"


def _minutes_into_session(now: datetime) -> int:
    starts = {"london": 7, "london_ny_overlap": 12, "new_york": 16,
              "asian": 0, "off-hours": 21}
    s = starts.get(_session_name(now.hour), 0)
    return (now.hour - s) * 60 + now.minute


def _spread(io, symbol: str) -> float | None:
    try:
        return abs(io.price(symbol, 1) - io.price(symbol, -1))
    except Exception:
        return None


def _pip_size(symbol: str, digits) -> float:
    try:
        from basket_engine.learn.trailing import pip_size
        return pip_size(symbol, digits)
    except Exception:
        return 0.0001


def _atr(io, symbol: str, tf: int, period: int = 14) -> float | None:
    bars = _safe(lambda: io.bars(symbol, tf, period + 2), []) or []
    if len(bars) < period + 1:
        return None
    trs = []
    for i in range(1, len(bars)):
        h, l, pc = bars[i]["high"], bars[i]["low"], bars[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    return sum(trs[-period:]) / period if trs else None


def _rolling_atr(bars: list[dict], period: int = 14) -> list[float]:
    if len(bars) < period + 2:
        return []
    trs = []
    for i in range(1, len(bars)):
        h, l, pc = bars[i]["high"], bars[i]["low"], bars[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    return [sum(trs[i - period:i]) / period
            for i in range(period, len(trs) + 1)]


def _bars_since(series: list[float], target: float) -> int | None:
    for i in range(len(series) - 1, -1, -1):
        if series[i] == target:
            return len(series) - 1 - i
    return None


def _efficiency(closes: list[float]) -> float | None:
    """Net move divided by total path. 1.0 = a straight line, 0 = pure chop."""
    if len(closes) < 5:
        return None
    net = abs(closes[-1] - closes[0])
    path = sum(abs(closes[i] - closes[i - 1]) for i in range(1, len(closes)))
    return round(net / path, 3) if path else None


def _regime(efficiency: float | None, atr_pct: float | None) -> str:
    if efficiency is None:
        return "unknown"
    if efficiency > 0.45:
        return "trending_volatile" if (atr_pct or 0) > 0.6 else "trending_quiet"
    if efficiency < 0.2:
        return "choppy_volatile" if (atr_pct or 0) > 0.6 else "choppy_quiet"
    return "mixed"
