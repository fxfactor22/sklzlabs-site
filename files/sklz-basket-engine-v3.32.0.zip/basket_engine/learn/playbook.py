"""SKLZ — the playbook: which model is allowed to trade which pair in which session.

Built from the model_report numbers (28 Sep – 1 Oct, 170 closed trades):

    strength_extreme alone      22W/13L  -$156   PF 0.68   worst money loser
    strength_extreme in NY       5W/ 6L  -$153   PF 0.27
    model_c in Asian             2W/ 3L  -$103   PF 0.15   (but 7W/1L in NY)
    model_e in Asian             1W/ 3L            model_e on XAGUSD 0W/3L
    EURJPY                       6W/ 6L  -$128
    NZDUSD                       0W/ 2L   -$66
    XAUUSD                      35W/ 7L  +$313   the only pair that pays

The rules live in playbook.json next to this file so they can be tuned from the
report without touching code. Each rule is matched against (signals, session,
symbol); the first matching BLOCK rule stops the entry. If `allow` rules exist,
an entry must also match at least one of them.

Rule fields (all optional, all case-insensitive, lists mean "any of"):
    signals      scanner/model names that must ALL be present     ["strength_extreme"]
    only         the entry's signal set must be exactly this       ["strength_extreme"]
    not_signals  names that must be absent                         ["model_a"]
    sessions     ["Asian", "London", "NY"]
    symbols      ["XAUUSD", "EURJPY"]        (prefix match, broker suffixes ok)
    not_symbols  rule does not apply to these pairs                ["XAUUSD"]
    min_signals  integer — at least this many agreeing signals
    why          free text, logged when the rule fires

Sessions are the engine's own buckets, folded to three:
    sydney_tokyo -> Asian · london -> London · london_ny_overlap, newyork -> NY

Forced (dashboard / console) entries are never blocked — a human outranks the
playbook. Set SKLZ_PLAYBOOK=0 to disable, SKLZ_PLAYBOOK_FILE to point elsewhere.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone

_FOLD = {
    "sydney_tokyo": "Asian", "sydney": "Asian", "tokyo": "Asian", "asian": "Asian",
    "london": "London",
    "london_ny_overlap": "NY", "newyork": "NY", "new_york": "NY", "ny": "NY",
    "off": "NY",            # 21:00-22:00 UTC gap; treat as late NY
}

DEFAULT_RULES = {
    "block": [
        {"only": ["strength_extreme"],
         "why": "strength_extreme alone: 22W/13L but -$156 (PF 0.68) — needs a partner signal"},
        {"signals": ["strength_extreme"], "sessions": ["NY"], "not_symbols": ["XAUUSD"],
         "why": "strength_extreme in NY: 5W/6L, -$153 (gold exempt: XAUUSD NY 13W/1L)"},
        {"signals": ["model_c"], "sessions": ["Asian", "London"],
         "why": "model_c only pays in NY (7W/1L); Asian 2W/3L -$103"},
        {"signals": ["model_e"], "sessions": ["Asian"],
         "why": "model_e in Asian: 1W/3L"},
        {"signals": ["model_e"], "symbols": ["XAGUSD"],
         "why": "model_e on silver: 0W/3L"},
        {"symbols": ["EURJPY", "NZDUSD"],
         "why": "EURJPY -$128 (PF 0.40), NZDUSD 0W/2L — off the list until they earn it back"},
        {"symbols": ["GBPUSD"], "sessions": ["NY"],
         "why": "GBPUSD in NY: 1W/3L, -$83"},
    ],
    "allow": [],
    "min_signals": 1,
}


def fold_session(raw: str | None) -> str:
    if not raw:
        return current_session()
    return _FOLD.get(str(raw).strip().lower(), str(raw))


def current_session(now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    h = now.hour
    if 22 <= h or h < 7:
        return "Asian"
    if 7 <= h < 12:
        return "London"
    return "NY"


def _norm_sym(s: str) -> str:
    s = (s or "").upper()
    for suf in ("..", ".", "M", "C", "R", "_", "#", "-", "+"):
        if len(s) > 6 and s.endswith(suf):
            s = s[: -len(suf)]
    return s.strip(".")


class Playbook:
    def __init__(self, path: str | None = None, log=print) -> None:
        self.log = log
        self.path = path or os.environ.get(
            "SKLZ_PLAYBOOK_FILE",
            os.path.join(os.path.dirname(__file__), "..", "..", "playbook.json"))
        self.rules = dict(DEFAULT_RULES)
        self._mtime = 0.0
        self.reload()

    # hot-reload so the file can be edited while the engine runs
    def reload(self) -> None:
        try:
            m = os.path.getmtime(self.path)
        except OSError:
            return
        if m == self._mtime:
            return
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                self.rules = {"block": data.get("block", []),
                              "allow": data.get("allow", []),
                              "min_signals": int(data.get("min_signals", 1) or 1)}
                self._mtime = m
                self.log(f"[playbook] loaded {len(self.rules['block'])} block / "
                         f"{len(self.rules['allow'])} allow rule(s) from {os.path.basename(self.path)}")
        except Exception as exc:  # noqa: BLE001
            self.log(f"[playbook] could not read {self.path}: {exc} — keeping previous rules")

    @staticmethod
    def enabled() -> bool:
        return os.environ.get("SKLZ_PLAYBOOK", "1") != "0"

    @staticmethod
    def _match(rule: dict, signals: set[str], session: str, symbol: str) -> bool:
        sig_l = {s.lower() for s in signals}
        if "only" in rule and sig_l != {s.lower() for s in rule["only"]}:
            return False
        if "signals" in rule and not {s.lower() for s in rule["signals"]} <= sig_l:
            return False
        if "not_signals" in rule and {s.lower() for s in rule["not_signals"]} & sig_l:
            return False
        if "sessions" in rule and session.lower() not in {s.lower() for s in rule["sessions"]}:
            return False
        if "symbols" in rule:
            sym = _norm_sym(symbol)
            if not any(sym.startswith(_norm_sym(s)) for s in rule["symbols"]):
                return False
        if "not_symbols" in rule:
            sym = _norm_sym(symbol)
            if any(sym.startswith(_norm_sym(s)) for s in rule["not_symbols"]):
                return False
        if "min_signals" in rule and len(signals) < int(rule["min_signals"]):
            return False
        return True

    def check(self, signals, symbol: str, session: str | None = None,
              source: str = "auto") -> tuple[bool, str]:
        """(allowed, reason). Forced entries always pass."""
        if source != "auto" or not self.enabled():
            return True, ""
        self.reload()
        sigs = set(signals if isinstance(signals, (list, tuple, set)) else str(signals).split("+"))
        sigs = {s.strip() for s in sigs if s and s.strip()}
        sess = fold_session(session)
        if len(sigs) < int(self.rules.get("min_signals", 1) or 1):
            return False, f"needs at least {self.rules['min_signals']} agreeing signals"
        for r in self.rules.get("block", []):
            if self._match(r, sigs, sess, symbol):
                return False, r.get("why", "blocked by playbook")
        allow = self.rules.get("allow", [])
        if allow and not any(self._match(r, sigs, sess, symbol) for r in allow):
            return False, "not on the allow list for this session/pair"
        return True, ""


def write_default(path: str) -> None:
    """Drop the built-in rules to disk so the owner can edit them."""
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(DEFAULT_RULES, fh, indent=2)
