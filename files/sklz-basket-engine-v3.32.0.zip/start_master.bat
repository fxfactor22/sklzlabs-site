@echo off
title SKLZ MASTER - ICMarketsSC-Demo 53031572
cd /d C:\Users\Administrator
set SKLZ_MT5_PATH=C:\Program Files\MetaTrader 5 IC Markets Global\terminal64.exe
set SKLZ_EXPECT_LOGIN=53031572
set SKLZ_EXPECT_SERVER=ICMarketsSC-Demo
set SKLZ_BOT_NAME=SKLZ Master
set SKLZ_ALLOW_LIVE=I_ACCEPT_THE_RISK
set SKLZ_API_URL=https://api.sklzlabs.com
set SKLZ_BOT_KEY=
set SIGNAL_WEBHOOK_KEY=
set SKLZ_MODELS_ENABLED=a,b,c,d,e,f,g,x,h,j,k,l,m,n
set SKLZ_PUBLISH_SIGNALS=1
set SKLZ_MAX_LOTS=0.15
set SKLZ_MAX_RISK_PCT=0.5
set SKLZ_INST_MIN_SCORE=75

REM ══════════════════ v3.32.0 — from the 28 Sep–1 Oct report ══════════════════
REM Gold carried the whole book (35W/7L, +$313) while capped at 0.06; pairs that
REM lost got 0.15. Raised gold, kept silver tiny (7W/8L). Change to your comfort.
set SKLZ_MAX_LOTS_BY_SYMBOL=XAUUSD:0.12,XAGUSD:0.01

REM Exit management. OLD: break-even at +12 pips FX / +30 gold, trail 6/15 — fixed
REM pips, blind to the trade's stop, so winners were cut at ~0.2R while losers ran
REM the full 1R (68%% win rate, net flat). NEW: measured in R against each trade's
REM own stop — break-even arms at 1.0R, then trails 0.6R behind. TP stays.
REM To go back to the old behaviour:  set SKLZ_TRAIL_MODE=pips
set SKLZ_TRAIL_MODE=r
set SKLZ_TRAIL_TRIGGER_R=1.0
set SKLZ_TRAIL_DIST_R=0.6

REM Playbook: which model may trade which pair in which session (playbook.json,
REM edit while running — it hot-reloads). 0 = off.
set SKLZ_PLAYBOOK=1

REM Pairs that never earned their place: EURJPY -$128, NZDUSD 0W/2L
set SKLZ_BLOCKED_SYMBOLS=EURJPY,NZDUSD
REM ═════════════════════════════════════════════════════════════════════════════

python learn_main.py --auto
