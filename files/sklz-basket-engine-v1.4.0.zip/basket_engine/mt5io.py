"""Thin MT5 wrapper — every call the basket engine needs, nothing more.

MetaTrader5 import is guarded so the whole engine is testable on any OS;
tests inject a fake through BasketIO(client=fake).
"""
from __future__ import annotations

import time

try:
    import MetaTrader5 as _mt5
except ImportError:          # tests / macOS
    _mt5 = None


class BasketIO:
    def __init__(self, magic: int, client=None) -> None:
        self.mt5 = client or _mt5
        self.magic = magic
        if self.mt5 is None:
            raise RuntimeError("MetaTrader5 package not available")

    # ---- lifecycle ----
    def connect(self) -> dict:
        if not self.mt5.initialize():
            raise RuntimeError(f"MT5 initialize failed: {self.mt5.last_error()}")
        acct = self.mt5.account_info()
        if acct is None:
            raise RuntimeError("MT5: no account — open & log in the terminal first")
        return {"login": acct.login, "server": acct.server,
                "balance": acct.balance, "equity": acct.equity,
                "currency": acct.currency, "demo": acct.trade_mode == 0}

    def account(self) -> dict:
        a = self.mt5.account_info()
        return {"balance": a.balance, "equity": a.equity} if a else {}

    # ---- data ----
    def closes(self, symbol: str, timeframe_min: int, count: int) -> list[float]:
        tf = {5: self.mt5.TIMEFRAME_M5, 15: self.mt5.TIMEFRAME_M15,
              60: self.mt5.TIMEFRAME_H1, 240: self.mt5.TIMEFRAME_H4}[timeframe_min]
        rates = self.mt5.copy_rates_from_pos(symbol, tf, 0, count)
        return [r["close"] for r in rates] if rates is not None else []

    def has_symbol(self, symbol: str) -> bool:
        info = self.mt5.symbol_info(symbol)
        if info is None:
            return False
        if not info.visible:
            self.mt5.symbol_select(symbol, True)
        return True

    def spec(self, symbol: str) -> dict:
        s = self.mt5.symbol_info(symbol)
        return {"point": s.point, "tick_value": s.trade_tick_value,
                "tick_size": s.trade_tick_size, "lot_min": s.volume_min,
                "lot_step": s.volume_step, "lot_max": s.volume_max,
                "digits": s.digits}

    def price(self, symbol: str, side: int) -> float:
        t = self.mt5.symbol_info_tick(symbol)
        return t.ask if side > 0 else t.bid

    # ---- positions ----
    def my_positions(self) -> list[dict]:
        out = []
        for p in (self.mt5.positions_get() or []):
            if p.magic != self.magic:
                continue
            out.append({"ticket": p.ticket, "symbol": p.symbol,
                        "side": 1 if p.type == 0 else -1, "lots": p.volume,
                        "open_price": p.price_open, "profit": p.profit,
                        "comment": p.comment})
        return out

    def basket_profit(self) -> float:
        return sum(p["profit"] for p in self.my_positions())

    # ---- orders ----
    def market(self, symbol: str, side: int, lots: float, sl: float,
               comment: str) -> dict:
        req = {
            "action": self.mt5.TRADE_ACTION_DEAL, "symbol": symbol,
            "volume": lots,
            "type": self.mt5.ORDER_TYPE_BUY if side > 0 else self.mt5.ORDER_TYPE_SELL,
            "price": self.price(symbol, side), "sl": sl, "tp": 0.0,
            "magic": self.magic, "comment": comment[:26],
            "type_time": self.mt5.ORDER_TIME_GTC,
            "type_filling": self.mt5.ORDER_FILLING_IOC,
        }
        for attempt in range(3):
            res = self.mt5.order_send(req)
            if res is not None and res.retcode == self.mt5.TRADE_RETCODE_DONE:
                return {"ok": True, "ticket": res.order, "price": res.price}
            time.sleep(0.6)
            req["price"] = self.price(symbol, side)
        rc = getattr(res, "retcode", "n/a") if res is not None else "none"
        return {"ok": False, "retcode": rc}

    def close(self, pos: dict) -> bool:
        side = -pos["side"]
        req = {
            "action": self.mt5.TRADE_ACTION_DEAL, "symbol": pos["symbol"],
            "volume": pos["lots"], "position": pos["ticket"],
            "type": self.mt5.ORDER_TYPE_BUY if side > 0 else self.mt5.ORDER_TYPE_SELL,
            "price": self.price(pos["symbol"], side),
            "magic": self.magic, "comment": "basket-close",
            "type_time": self.mt5.ORDER_TIME_GTC,
            "type_filling": self.mt5.ORDER_FILLING_IOC,
        }
        res = self.mt5.order_send(req)
        return res is not None and res.retcode == self.mt5.TRADE_RETCODE_DONE

    def close_all(self) -> int:
        n = 0
        for p in self.my_positions():
            if self.close(p):
                n += 1
        return n

    def realized_pnl(self, ticket: int) -> float | None:
        """Exact realized P/L for a closed position, from deal history.
        Sums profit + swap + commission of all deals on this position."""
        try:
            import time as _t
            deals = self.mt5.history_deals_get(
                0, int(_t.time()) + 3600, position=ticket)
            if not deals:
                return None
            return round(sum(d.profit + d.swap + d.commission for d in deals), 2)
        except Exception:
            return None

    def market_live(self, symbol: str, max_age_sec: int = 120) -> bool:
        """True only if this symbol has a tick within max_age_sec — i.e. the
        market is actually open. Prevents scanners acting on frozen weekend data."""
        try:
            import time as _t
            t = self.mt5.symbol_info_tick(symbol)
            if t is None or not t.time:
                return False
            return (_t.time() - t.time) <= max_age_sec
        except Exception:
            return False
