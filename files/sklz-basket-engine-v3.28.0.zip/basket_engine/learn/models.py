"""SKLZ — structured entry models A–G.

MODEL A — M15 break and retest
    A level breaks on M15, price returns to it, and the level holds as
    support/resistance. Entry on the hold, not the break.

MODEL B — HTF order block, fib 50 entry
    Price rejects from the 50% level of a 4H or 1H order block. A 5M engulfing
    candle confirms the rejection. A fib is drawn from that rejection line to
    the extreme reached, and entry is at the 50% retracement.

BOTH confirmed by RSI(2) with a 21-period SMA on M5.

WHY THE RSI TIMING MATTERS
==========================
RSI(2) is fast and mean-reverting. At the moment a level breaks it will be
deep overbought on a bullish break — so a rule of "buy only below 30" would
block every entry if it were read at the break.

It is read at the RETEST, which is a pullback, and that is exactly when RSI(2)
falls. The rule and the model agree only because of when the measurement is
taken. Read it at the wrong moment and the model never fires.

The 21-SMA of RSI is the slower reference: RSI below its own average says the
pullback is real rather than a single noisy print.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


# ── indicators ──────────────────────────────────────────────────────
def rsi(closes: list[float], period: int = 2) -> list[float]:
    """Wilder's RSI. Returns a list aligned to the input, padded at the front.

    Period 2 is deliberately short — it is a pullback detector, not a trend
    filter, and at that length it swings the full range within a few bars.
    """
    if len(closes) < period + 1:
        return [50.0] * len(closes)

    out = [50.0] * period
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0.0)
        losses += max(-d, 0.0)
    ag, al = gains / period, losses / period
    out.append(100.0 if al == 0 else 100 - 100 / (1 + ag / al))

    for i in range(period + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        ag = (ag * (period - 1) + max(d, 0.0)) / period
        al = (al * (period - 1) + max(-d, 0.0)) / period
        out.append(100.0 if al == 0 else 100 - 100 / (1 + ag / al))
    return out


def sma(values: list[float], period: int) -> list[float]:
    out, run = [], 0.0
    for i, v in enumerate(values):
        run += v
        if i >= period:
            run -= values[i - period]
        out.append(run / min(i + 1, period))
    return out


# ── shared confirmation ─────────────────────────────────────────────
def rsi_confirms(side: int, m5_closes: list[float],
                 period: int = 2, smooth: int = 21) -> dict:
    """RSI(2) against its 21-SMA, read at the entry bar.

    Buy wants RSI oversold (the pullback is deep enough to be worth entering).
    Sell wants overbought. The SMA comparison guards against a single spike:
    RSI can print 12 on one noisy bar and mean nothing.
    """
    if len(m5_closes) < smooth + period + 2:
        return {"ok": False, "reason": "not enough M5 bars for RSI"}

    r = rsi(m5_closes, period)
    rs = sma(r, smooth)
    cur, avg = r[-1], rs[-1]

    try:
        lo = float(os.environ.get("SKLZ_RSI_BUY_BELOW", "30"))
        hi = float(os.environ.get("SKLZ_RSI_SELL_ABOVE", "70"))
    except ValueError:
        lo, hi = 30.0, 70.0

    # Look back a few bars, not only at the current one.
    #
    # The "hold" that confirms a retest is itself upward movement, and RSI(2)
    # is fast enough to leave oversold on that single bar. Demanding RSI < 30
    # AT the entry bar means the condition is almost never true at the moment
    # you actually want to enter.
    #
    # The real signal is: it REACHED oversold during the pullback, and is now
    # turning back up. That is the classic short-RSI entry and it is what the
    # rule was reaching for.
    try:
        window = int(os.environ.get("SKLZ_RSI_LOOKBACK", "4"))
    except ValueError:
        window = 4
    recent = r[-window:]

    if side > 0:
        reached = min(recent) < lo
        turning = cur > recent[-2] if len(recent) > 1 else True
        ok = reached and turning
        why = (f"RSI(2) reached {min(recent):.0f} in the pullback (under "
               f"{lo:.0f}) and is turning up at {cur:.0f}"
               if ok else
               (f"RSI(2) got to {min(recent):.0f} but is not turning up yet"
                if reached else
                f"RSI(2) low was {min(recent):.0f} over the last {window} bars; "
                f"a buy wants it under {lo:.0f}. The pullback is not deep "
                f"enough."))
    else:
        reached = max(recent) > hi
        turning = cur < recent[-2] if len(recent) > 1 else True
        ok = reached and turning
        why = (f"RSI(2) reached {max(recent):.0f} (over {hi:.0f}) and is "
               f"turning down at {cur:.0f}"
               if ok else
               (f"RSI(2) got to {max(recent):.0f} but is not turning down yet"
                if reached else
                f"RSI(2) high was {max(recent):.0f} over the last {window} "
                f"bars; a sell wants it over {hi:.0f}."))

    return {"ok": ok, "rsi": round(cur, 1), "rsi_avg": round(avg, 1),
            "reason": why}


def engulfing(bars: list[dict], side: int) -> dict:
    """A 5M engulfing candle in the intended direction."""
    if len(bars) < 2:
        return {"ok": False, "reason": "not enough bars"}
    p, c = bars[-2], bars[-1]
    if side > 0:
        ok = (p["close"] < p["open"] and c["close"] > c["open"]
              and c["close"] > p["open"] and c["open"] <= p["close"])
    else:
        ok = (p["close"] > p["open"] and c["close"] < c["open"]
              and c["close"] < p["open"] and c["open"] >= p["close"])
    return {"ok": ok,
            "reason": ("5M engulfing candle in our direction" if ok
                       else "no 5M engulfing candle at this level")}


# ── Model A: M15 break and retest ───────────────────────────────────
@dataclass
class Setup:
    ok: bool
    model: str
    side: int = 0
    entry: float = 0.0
    level: float = 0.0
    stop: float = 0.0
    reasons: list = field(default_factory=list)
    blockers: list = field(default_factory=list)


def find_m15_level(m15: list[dict], lookback: int = 40,
                   touches: int = 2, tol_frac: float = 0.0008) -> list[dict]:
    """Levels worth breaking: prices touched more than once.

    A level nobody traded twice is not a level, it is a coordinate.
    """
    if len(m15) < 12:
        return []
    window = m15[-lookback:]
    pts = []
    for i in range(2, len(window) - 2):
        h, l = window[i]["high"], window[i]["low"]
        if h >= max(window[i - 2]["high"], window[i - 1]["high"],
                    window[i + 1]["high"], window[i + 2]["high"]):
            pts.append(("high", h))
        if l <= min(window[i - 2]["low"], window[i - 1]["low"],
                    window[i + 1]["low"], window[i + 2]["low"]):
            pts.append(("low", l))

    levels = []
    for kind, price in pts:
        hit = [p for k, p in pts if k == kind
               and abs(p - price) <= price * tol_frac]
        if len(hit) >= touches:
            if not any(abs(l["price"] - price) <= price * tol_frac
                       for l in levels):
                levels.append({"kind": kind, "price": sum(hit) / len(hit),
                               "touches": len(hit)})
    return levels


def model_a(m15: list[dict], m5: list[dict], pip: float) -> Setup:
    """M15 break, then retest, then enter on the hold."""
    s = Setup(ok=False, model="A: M15 break-retest")

    levels = find_m15_level(m15)
    if not levels:
        s.blockers.append("no M15 level with two or more touches")
        return s
    if len(m15) < 6:
        s.blockers.append("not enough M15 history")
        return s

    for lv in levels:
        price, kind = lv["price"], lv["kind"]
        side = 1 if kind == "high" else -1

        # did a recent M15 bar close beyond it?
        broke_at = None
        for i in range(len(m15) - 6, len(m15)):
            if i < 1:
                continue
            b = m15[i]
            if side > 0 and b["close"] > price and m15[i - 1]["close"] <= price:
                broke_at = i
            if side < 0 and b["close"] < price and m15[i - 1]["close"] >= price:
                broke_at = i
        if broke_at is None:
            continue

        # has price come back to it and held? measured on M5 for precision
        tol = 6 * pip
        came_back = any(
            (side > 0 and b["low"] <= price + tol) or
            (side < 0 and b["high"] >= price - tol)
            for b in m5[-8:])
        if not came_back:
            s.blockers.append(f"broke {price:.5f} but has not retested it yet")
            continue

        last = m5[-1]
        held = last["close"] > price if side > 0 else last["close"] < price
        if not held:
            s.blockers.append(f"retested {price:.5f} and failed to hold")
            continue

        rsi_c = rsi_confirms(side, [b["close"] for b in m5])
        if not rsi_c["ok"]:
            s.blockers.append(rsi_c["reason"])
            continue

        s.ok = True
        s.side = side
        s.level = price
        s.entry = last["close"]
        s.stop = (min(b["low"] for b in m5[-6:]) - 2 * pip if side > 0
                  else max(b["high"] for b in m5[-6:]) + 2 * pip)
        s.reasons = [
            f"M15 level {price:.5f} touched {lv['touches']}x, then broken",
            "price returned and the level held",
            rsi_c["reason"],
        ]
        return s

    return s


# ── Model B: HTF order block, fib 50 entry ──────────────────────────
def order_block(htf: list[dict], side: int, lookback: int = 30) -> dict | None:
    """The last opposing candle before the move that broke structure.

    That candle is where the position was built — the 50% of its range is the
    level worth watching, not its extreme.
    """
    if len(htf) < 6:
        return None
    window = htf[-lookback:]
    # start at len-2 so the candle immediately before the break is reachable —
    # that is usually THE order block, and len-3 skipped it entirely
    for i in range(len(window) - 2, 0, -1):
        c = window[i]
        nxt = window[i + 1] if i + 1 < len(window) else None
        if nxt is None:
            continue
        if side > 0 and c["close"] < c["open"] and nxt["close"] > c["high"]:
            return {"high": c["high"], "low": c["low"],
                    "mid": (c["high"] + c["low"]) / 2, "index": i}
        if side < 0 and c["close"] > c["open"] and nxt["close"] < c["low"]:
            return {"high": c["high"], "low": c["low"],
                    "mid": (c["high"] + c["low"]) / 2, "index": i}
    return None


def model_b(h4: list[dict], h1: list[dict], m5: list[dict],
            pip: float) -> Setup:
    """Rejection from the 50% of an HTF order block, entered at fib 50."""
    s = Setup(ok=False, model="B: HTF block, fib 50")

    for side in (1, -1):
        blk = order_block(h4, side) or order_block(h1, side)
        if not blk:
            continue

        mid = blk["mid"]

        # has price rejected from the block's 50%?
        touched = any(
            (side > 0 and b["low"] <= mid + 4 * pip) or
            (side < 0 and b["high"] >= mid - 4 * pip)
            for b in m5[-30:])
        if not touched:
            continue

        # the extreme reached since that rejection — and it must be a REAL
        # run. A fib of a 2-pip move has levels 1 pip apart, which is spread.
        min_run = _min_pips("SKLZ_B_MIN_RUN_PIPS", 8.0) * pip
        if side > 0:
            extreme = max(b["high"] for b in m5[-30:])
            if extreme <= mid or (extreme - mid) < min_run:
                continue
            fib50 = mid + (extreme - mid) * 0.5
            at_fib = m5[-1]["low"] <= fib50 + 4 * pip
        else:
            extreme = min(b["low"] for b in m5[-30:])
            if extreme >= mid or (mid - extreme) < min_run:
                continue
            fib50 = mid - (mid - extreme) * 0.5
            at_fib = m5[-1]["high"] >= fib50 - 4 * pip

        if not at_fib:
            s.blockers.append(
                f"rejected from the block at {mid:.5f} but price is not back "
                f"at the 50% fib ({fib50:.5f}) yet")
            continue

        eng = engulfing(m5, side)
        if not eng["ok"]:
            s.blockers.append(eng["reason"])
            continue

        rsi_c = rsi_confirms(side, [b["close"] for b in m5])
        if not rsi_c["ok"]:
            s.blockers.append(rsi_c["reason"])
            continue

        s.ok = True
        s.side = side
        s.level = mid
        s.entry = m5[-1]["close"]
        s.stop = (blk["low"] - 2 * pip if side > 0 else blk["high"] + 2 * pip)
        s.reasons = [
            f"HTF order block {blk['low']:.5f}-{blk['high']:.5f}, "
            f"50% at {mid:.5f}",
            f"price rejected from it and ran to {extreme:.5f}",
            f"returned to the 50% fib at {fib50:.5f}",
            eng["reason"],
            rsi_c["reason"],
        ]
        return s

    return s




# ── Model C: 4H candle open + fair value gap ────────────────────────
def _min_pips(env: str, default: float) -> float:
    try:
        return float(os.environ.get(env, str(default)))
    except ValueError:
        return default


def fair_value_gap(bars: list[dict], side: int, lookback: int = 20,
                   min_height: float = 0.0) -> dict | None:
    """A three-candle gap: the middle candle moved so fast that the first and
    third don't overlap. That unfilled space is where the market skipped
    price levels, and it tends to get revisited.

    Bullish FVG: bar[i-2].high < bar[i].low  (gap below, price jumped up)
    Bearish FVG: bar[i-2].low  > bar[i].high (gap above, price fell through)
    """
    if len(bars) < 3:
        return None
    start = max(2, len(bars) - lookback)
    for i in range(len(bars) - 1, start - 1, -1):
        a, b = bars[i - 2], bars[i]
        if side > 0 and a["high"] < b["low"]:
            if (b["low"] - a["high"]) < min_height:
                continue                    # a gap smaller than noise is noise
            return {"top": b["low"], "bottom": a["high"],
                    "mid": (b["low"] + a["high"]) / 2, "index": i}
        if side < 0 and a["low"] > b["high"]:
            if (a["low"] - b["high"]) < min_height:
                continue
            return {"top": a["low"], "bottom": b["high"],
                    "mid": (a["low"] + b["high"]) / 2, "index": i}
    return None


def model_c(h4: list[dict], m5: list[dict], pip: float) -> Setup:
    """4H open + FVG: the drop below a bullish 4H open is the trap, the fair
    value gap left on the way back is the entry.

    Mechanics, stripped of the video's "millions" framing:
      1. HTF bias from 4H structure (three closed candles)
      2. Price must have traded the WRONG side of the current 4H open —
         below it for longs. That counter-move is the setup, not a failure.
      3. The reversal back through leaves an FVG on M5.
      4. Enter on the retracement INTO that gap, stop beyond the
         counter-move's extreme.
    """
    s = Setup(ok=False, model="C: 4H open + FVG")
    if len(h4) < 5 or len(m5) < 20:
        s.blockers.append("not enough history for the 4H model")
        return s

    # bias from closed 4H candles — the forming one's colour isn't known yet
    closed = h4[:-1]
    ups = sum(1 for b in closed[-3:] if b["close"] > b["open"])
    if ups >= 2:
        side = 1
    elif ups <= 1 and sum(1 for b in closed[-3:]
                          if b["close"] < b["open"]) >= 2:
        side = -1
    else:
        s.blockers.append("4H candles are mixed — no bias")
        return s

    h4_open = h4[-1]["open"]

    # the counter-move: price must have traded the wrong side of the open
    recent = m5[-24:]
    if side > 0:
        dipped = min(b["low"] for b in recent) < h4_open
        extreme = min(b["low"] for b in recent)
    else:
        dipped = max(b["high"] for b in recent) > h4_open
        extreme = max(b["high"] for b in recent)
    if not dipped:
        s.blockers.append(
            f"price has not traded the far side of the 4H open "
            f"({h4_open:.5f}) — no trap, no setup")
        return s

    # A GBPUSD sell fired with a 0.5-pip "trap" and a 0.2-pip "FVG" — every
    # condition technically true, all of it inside the spread. Structure
    # smaller than noise is noise: the trap must be a real excursion and the
    # gap must be wider than the ordinary cost of crossing it.
    trap_depth = abs(h4_open - extreme)
    min_trap = _min_pips("SKLZ_C_MIN_TRAP_PIPS", 5.0) * pip
    if trap_depth < min_trap:
        s.blockers.append(
            f"trap beyond the 4H open is only {trap_depth / pip:.1f} pips — "
            f"price is hovering AT the open, not trapped beyond it "
            f"(needs {min_trap / pip:.0f})")
        return s

    min_gap = _min_pips("SKLZ_MIN_FVG_PIPS", 3.0) * pip
    fvg = fair_value_gap(m5, side, min_height=min_gap)
    if not fvg:
        s.blockers.append(
            f"no fair value gap of at least {min_gap / pip:.0f} pips on the "
            f"reversal yet")
        return s

    # entry: price retracing INTO the gap
    last = m5[-1]
    if side > 0:
        in_gap = last["low"] <= fvg["top"] and last["close"] >= fvg["bottom"]
    else:
        in_gap = last["high"] >= fvg["bottom"] and last["close"] <= fvg["top"]
    if not in_gap:
        s.blockers.append(
            f"FVG at {fvg['bottom']:.5f}-{fvg['top']:.5f} exists but price "
            f"has not retraced into it")
        return s

    rsi_c = rsi_confirms(side, [b["close"] for b in m5])
    if not rsi_c["ok"]:
        s.blockers.append(rsi_c["reason"])
        return s

    s.ok = True
    s.side = side
    s.level = fvg["mid"]
    s.entry = last["close"]
    s.stop = extreme - 2 * pip if side > 0 else extreme + 2 * pip
    s.reasons = [
        f"4H bias {'bullish' if side > 0 else 'bearish'} from closed candles",
        f"price trapped the far side of the 4H open ({h4_open:.5f})",
        f"FVG {fvg['bottom']:.5f}-{fvg['top']:.5f} on the reversal, "
        f"price retraced into it",
        rsi_c["reason"],
    ]
    return s



# ── Model D: inducement sweep + change of character ─────────────────
def swing_points(bars: list[dict], k: int = 2) -> tuple[list, list]:
    """(lows, highs) as (index, price), using k-bar pivots."""
    lows, highs = [], []
    for i in range(k, len(bars) - k):
        if bars[i]["low"] <= min(b["low"] for b in bars[i-k:i+k+1]):
            lows.append((i, bars[i]["low"]))
        if bars[i]["high"] >= max(b["high"] for b in bars[i-k:i+k+1]):
            highs.append((i, bars[i]["high"]))
    return lows, highs


def model_d(m15: list[dict], m5: list[dict], pip: float) -> Setup:
    """Inducement sweep: the minor higher-low is the bait, not the target.

    Sequence (long side; mirrored for shorts):
      1. An obvious low L0, then a rally.
      2. A pullback forms a HIGHER low L1 — the inducement. Retail reads it
         as support and rests stops just beneath it.
      3. Price sweeps below L1 — collecting those stops — while holding
         above L0. The obvious low never trades.
      4. The sweep reverses with a change of character: price closes back
         above the minor high formed after L1.
      5. Entry on that close. Stop below the sweep low (the real risk point).
         If price instead takes L0 too, the read was wrong — which is exactly
         what the stop placement admits.
    """
    s = Setup(ok=False, model="D: inducement sweep")
    if len(m15) < 20 or len(m5) < 20:
        s.blockers.append("not enough history for the inducement model")
        return s

    lows, highs = swing_points(m15[-40:])
    if len(lows) < 2 or not highs:
        s.blockers.append("no clear swing structure on M15")
        return s

    for side in (1, -1):
        if side > 0:
            pts = lows
            # L0 then a HIGHER L1 after it, with a rally high between them
            for a in range(len(pts) - 1):
                i0, l0 = pts[a]
                for b in range(a + 1, len(pts)):
                    i1, l1 = pts[b]
                    if l1 <= l0:
                        continue
                    between = [h for hi, h in highs if i0 < hi < i1]
                    if not between:
                        continue
                    rally_high = max(between)
                    if (rally_high - l0) < 10 * pip:
                        continue

                    # the sweep, on M5: below L1, holding above L0
                    recent = m5[-16:]
                    swept = min(bb["low"] for bb in recent)
                    if not (swept < l1 and swept > l0 + 1 * pip):
                        continue

                    # change of character: closed back above the minor high
                    # formed after the inducement low
                    post = [h for hi, h in highs if hi > i1]
                    choch_ref = min(post) if post else l1 + 8 * pip
                    last = m5[-1]
                    if last["close"] <= choch_ref:
                        s.blockers.append(
                            f"swept the inducement at {l1:.5f} but no change "
                            f"of character yet (needs a close above "
                            f"{choch_ref:.5f})")
                        continue

                    rsi_c = rsi_confirms(side, [bb["close"] for bb in m5])
                    if not rsi_c["ok"]:
                        s.blockers.append(rsi_c["reason"])
                        continue

                    s.ok = True
                    s.side = 1
                    s.level = l1
                    s.entry = last["close"]
                    s.stop = swept - 2 * pip
                    s.reasons = [
                        f"inducement: higher-low {l1:.5f} above the real low "
                        f"{l0:.5f} — retail support with stops beneath",
                        f"swept to {swept:.5f}, collecting those stops while "
                        f"holding above {l0:.5f}",
                        f"change of character — closed back above "
                        f"{choch_ref:.5f}",
                        rsi_c["reason"],
                    ]
                    return s
        else:
            pts = highs
            for a in range(len(pts) - 1):
                i0, h0 = pts[a]
                for b in range(a + 1, len(pts)):
                    i1, h1 = pts[b]
                    if h1 >= h0:
                        continue
                    between = [l for li, l in lows if i0 < li < i1]
                    if not between:
                        continue
                    drop_low = min(between)
                    if (h0 - drop_low) < 10 * pip:
                        continue
                    recent = m5[-16:]
                    swept = max(bb["high"] for bb in recent)
                    if not (swept > h1 and swept < h0 - 1 * pip):
                        continue
                    post = [l for li, l in lows if li > i1]
                    choch_ref = max(post) if post else h1 - 8 * pip
                    last = m5[-1]
                    if last["close"] >= choch_ref:
                        s.blockers.append(
                            f"swept the inducement at {h1:.5f} but no change "
                            f"of character yet (needs a close below "
                            f"{choch_ref:.5f})")
                        continue
                    rsi_c = rsi_confirms(side, [bb["close"] for bb in m5])
                    if not rsi_c["ok"]:
                        s.blockers.append(rsi_c["reason"])
                        continue
                    s.ok = True
                    s.side = -1
                    s.level = h1
                    s.entry = last["close"]
                    s.stop = swept + 2 * pip
                    s.reasons = [
                        f"inducement: lower-high {h1:.5f} below the real high "
                        f"{h0:.5f}",
                        f"swept to {swept:.5f} while holding below {h0:.5f}",
                        f"change of character — closed back below "
                        f"{choch_ref:.5f}",
                        rsi_c["reason"],
                    ]
                    return s
    return s

# ── Model E: prior-session sweep & reclaim ──────────────────────────
# Source: owner-supplied strategy video (CallistoFx, "85% winrate").
# What the charts showed: mark the prior session's high and low, wait for
# price to SWEEP one of them, then reclaim it — trade the reclaim, target
# the opposite extreme. The clip framed it as Thursday/Friday/Monday-open
# specifically; that weekly-calendar filter is NOT encoded here because the
# frames could not confirm the direction rule, and a wrong calendar filter
# is worse than none. This is the general form: sweep of the previous
# 24h extreme, reclaimed.
def model_e(h1: list[dict], m5: list[dict], pip: float) -> Setup:
    """Sweep of the prior session's extreme, then reclaimed.

    Sequence (long; mirrored for shorts):
      1. The previous 24h block sets a low PL and a high PH.
      2. In the current session price trades BELOW PL — the sweep. Weekend
         and session stops sit exactly there, which is why it happens.
      3. Price closes back ABOVE PL — the reclaim. A sweep that does not
         reclaim is simply a downtrend, and this model must not buy it.
      4. Entry on the reclaim close. Stop below the sweep's low — the real
         invalidation. Target is the opposite extreme PH.
    """
    s = Setup(ok=False, model="E: session sweep reclaim")
    if len(h1) < 40 or len(m5) < 12:
        s.blockers.append("not enough history for the session-sweep model")
        return s

    prev = h1[-48:-24] if len(h1) >= 48 else h1[:-24]
    cur = h1[-24:]
    if len(prev) < 12 or len(cur) < 4:
        s.blockers.append("not enough session history")
        return s

    ph = max(b["high"] for b in prev)
    pl = min(b["low"] for b in prev)
    if ph - pl <= 0:
        s.blockers.append("prior session has no range")
        return s

    last = m5[-1]
    recent = cur[-8:]
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip

    for side in (1, -1):
        if side > 0:
            swept = [b for b in recent if b["low"] < pl]
            if not swept:
                continue
            sweep_low = min(b["low"] for b in swept)
            if last["close"] <= pl:
                s.blockers.append(
                    f"swept the prior low {pl:.5f} but has not reclaimed it "
                    f"— that is a downtrend, not a trap")
                continue
            entry = last["close"]
            stop = sweep_low - 2 * pip
            if entry - stop < min_stop:
                s.blockers.append("reclaim stop is too tight to be real")
                continue
            if entry >= ph:
                s.blockers.append("already at the opposite extreme — no room")
                continue
            s.reasons = [
                f"prior session low {pl:.5f} swept to {sweep_low:.5f}",
                f"price closed back above it at {entry:.5f} — reclaimed",
                f"opposite extreme {ph:.5f} is the objective"]
        else:
            swept = [b for b in recent if b["high"] > ph]
            if not swept:
                continue
            sweep_high = max(b["high"] for b in swept)
            if last["close"] >= ph:
                s.blockers.append(
                    f"swept the prior high {ph:.5f} but has not reclaimed it "
                    f"— that is an uptrend, not a trap")
                continue
            entry = last["close"]
            stop = sweep_high + 2 * pip
            if stop - entry < min_stop:
                s.blockers.append("reclaim stop is too tight to be real")
                continue
            if entry <= pl:
                s.blockers.append("already at the opposite extreme — no room")
                continue
            s.reasons = [
                f"prior session high {ph:.5f} swept to {sweep_high:.5f}",
                f"price closed back below it at {entry:.5f} — reclaimed",
                f"opposite extreme {pl:.5f} is the objective"]

        s.ok = True
        s.side = side
        s.entry = entry
        s.level = pl if side > 0 else ph
        s.stop = stop
        return s

    if not s.blockers:
        s.blockers.append("prior session extremes intact — nothing swept")
    return s


# ── Model F: accumulation, manipulation, POC retest ─────────────────
# Source: owner-supplied strategy video (volume-profile clip).
# What the charts showed: a boxed ACCUMULATION range, a MANIPULATION leg
# that sweeps out of it and closes back in, the volume-profile POC of that
# range drawn as a line, and the entry taken when price returns to the POC
# and holds. Stop beyond the manipulation wick.
def _poc(bars: list[dict], bins: int = 24) -> float:
    """Volume point of control: the price bucket that traded the most.

    Each bar's volume is spread evenly across the prices it covered — a
    coarse profile, but the POC of a coarse profile and a fine one land in
    the same place, and this needs no tick history.
    """
    if not bars:
        return 0.0
    hi = max(b["high"] for b in bars)
    lo = min(b["low"] for b in bars)
    if hi <= lo:
        return 0.0
    step = (hi - lo) / bins
    buckets = [0.0] * bins
    def _span(a: float, b2: float) -> tuple[int, int]:
        i0 = min(bins - 1, max(0, int((a - lo) / step)))
        i1 = min(bins - 1, max(0, int((b2 - lo) / step)))
        return (i0, i1) if i0 <= i1 else (i1, i0)

    for b in bars:
        vol = float(b.get("volume") or 0.0) or 1.0
        # 40% of a bar's volume spread over its whole range, 60% over its
        # body. Wicks are where price was rejected; bodies are where it was
        # accepted, and the POC is a question about acceptance.
        wick_lo, wick_hi = _span(b["low"], b["high"])
        share = vol * 0.4 / (wick_hi - wick_lo + 1)
        for i in range(wick_lo, wick_hi + 1):
            buckets[i] += share
        body_lo, body_hi = _span(b["open"], b["close"])
        share = vol * 0.6 / (body_hi - body_lo + 1)
        for i in range(body_lo, body_hi + 1):
            buckets[i] += share
    top_i = max(range(bins), key=lambda i: buckets[i])
    return lo + (top_i + 0.5) * step


def model_f(m15: list[dict], m5: list[dict], pip: float) -> Setup:
    """Range accumulation -> manipulation out of it -> POC retest.

    Sequence (long; mirrored for shorts):
      1. An accumulation window: price rotates inside a range instead of
         trending — most closes sit in the middle of it.
      2. Manipulation: price trades BELOW the range low, then closes back
         INSIDE. The stops under the range have been collected.
      3. The volume POC of the accumulation window is the fair price of
         that whole rotation. Price returns to it.
      4. Entry when price is at the POC and the last M5 close holds above
         it. Stop below the manipulation low.
    """
    s = Setup(ok=False, model="F: POC retest after manipulation")
    if len(m15) < 40 or len(m5) < 12:
        s.blockers.append("not enough history for the POC model")
        return s

    window = m15[-40:-8]
    tail = m15[-8:]
    rh = max(b["high"] for b in window)
    rl = min(b["low"] for b in window)
    height = rh - rl
    if height <= 0:
        s.blockers.append("accumulation window has no range")
        return s

    # a range ROTATES; a trend DISPLACES. A uniform trend puts exactly half
    # its closes inside the middle band, so the band test alone passes
    # trends — net displacement is the discriminator that does not.
    drift = abs(window[-1]["close"] - window[0]["close"])
    mid_lo = rl + height * 0.2
    mid_hi = rh - height * 0.2
    inside = sum(1 for b in window if mid_lo <= b["close"] <= mid_hi)
    if drift > height * 0.5 or inside < len(window) * 0.5:
        s.blockers.append(
            "the window is trending, not accumulating — no range to "
            "manipulate")
        return s

    poc = _poc(window)
    if poc <= 0:
        s.blockers.append("could not read a volume POC")
        return s

    last = m5[-1]
    tol = max(height * 0.08, 3 * pip)
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip

    for side in (1, -1):
        if side > 0:
            manip = [b for b in tail if b["low"] < rl]
            if not manip:
                continue
            manip_low = min(b["low"] for b in manip)
            if tail[-1]["close"] <= rl:
                s.blockers.append(
                    f"swept the range low {rl:.5f} and has not closed back "
                    f"inside — the range is broken, not manipulated")
                continue
            if abs(last["close"] - poc) > tol:
                s.blockers.append(
                    f"manipulated, but price is not at the POC {poc:.5f} yet "
                    f"— waiting for the retest")
                continue
            if last["close"] < poc:
                s.blockers.append(
                    f"at the POC {poc:.5f} but not holding above it")
                continue
            entry = last["close"]
            stop = manip_low - 2 * pip
            if entry - stop < min_stop:
                continue
            s.reasons = [
                f"accumulation range {rl:.5f}-{rh:.5f}, POC at {poc:.5f}",
                f"manipulation swept to {manip_low:.5f} and closed back in",
                f"price returned to the POC and is holding above it"]
        else:
            manip = [b for b in tail if b["high"] > rh]
            if not manip:
                continue
            manip_high = max(b["high"] for b in manip)
            if tail[-1]["close"] >= rh:
                s.blockers.append(
                    f"swept the range high {rh:.5f} and has not closed back "
                    f"inside — the range is broken, not manipulated")
                continue
            if abs(last["close"] - poc) > tol:
                s.blockers.append(
                    f"manipulated, but price is not at the POC {poc:.5f} yet "
                    f"— waiting for the retest")
                continue
            if last["close"] > poc:
                s.blockers.append(
                    f"at the POC {poc:.5f} but not holding below it")
                continue
            entry = last["close"]
            stop = manip_high + 2 * pip
            if stop - entry < min_stop:
                continue
            s.reasons = [
                f"accumulation range {rl:.5f}-{rh:.5f}, POC at {poc:.5f}",
                f"manipulation swept to {manip_high:.5f} and closed back in",
                f"price returned to the POC and is holding below it"]

        s.ok = True
        s.side = side
        s.entry = entry
        s.level = poc
        s.stop = stop
        return s

    if not s.blockers:
        s.blockers.append("no manipulation out of the accumulation range")
    return s


# ── Model G: liquidity sweep + FVG reversal ─────────────────────────
# Source: owner-supplied breakdowns (two NQ 1-minute trades, NY open and
# London). What the charts showed: a liquidity pool ABOVE (relative equal
# highs / the prior session high) with a higher-timeframe imbalance on the
# same shelf (H1/H4 FVG); a wick THROUGH the pool that closed back below;
# then displacement leaving a bearish FVG on the entry timeframe; stop
# above the wick, target the internal liquidity the run started from —
# and only when that pays at least 2R (the reference trade paid ~5.6R).
# Model E already trades the sweep alone and its paper record (44W/179L)
# is the argument for the three extra gates here: the pool must be real,
# the sweep must be followed by displacement, and the target must pay.
def _atr(bars: list[dict], n: int = 14) -> float:
    if len(bars) < 2:
        return 0.0
    trs = []
    for i in range(1, len(bars)):
        h, l, pc = bars[i]["high"], bars[i]["low"], bars[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    trs = trs[-n:]
    return sum(trs) / len(trs) if trs else 0.0


def _equal_levels(points: list, tol: float, high: bool) -> list:
    """Clusters of >=2 swings within tol -> (level, count). The level is the
    cluster's extreme (the price the stops actually sit beyond)."""
    out, used = [], set()
    for i, (_, pa) in enumerate(points):
        if i in used:
            continue
        grp = [pa]
        for j, (_, pb) in enumerate(points[i + 1:], i + 1):
            if abs(pb - pa) <= tol:
                grp.append(pb); used.add(j)
        if len(grp) >= 2:
            out.append((max(grp) if high else min(grp), len(grp)))
    return out


def _all_fvgs(bars: list[dict], side: int, lookback: int = 40,
              min_height: float = 0.0) -> list[dict]:
    """Every FVG in the window (fair_value_gap returns only the newest)."""
    out = []
    start = max(2, len(bars) - lookback)
    for i in range(start, len(bars)):
        a, b = bars[i - 2], bars[i]
        if side < 0 and a["low"] > b["high"] and a["low"] - b["high"] >= min_height:
            out.append({"top": a["low"], "bottom": b["high"], "index": i})
        elif side > 0 and a["high"] < b["low"] and b["low"] - a["high"] >= min_height:
            out.append({"top": b["low"], "bottom": a["high"], "index": i})
    return out


def _in_kill_zone() -> bool:
    """London 07–10 UTC, New York 12–16 UTC. SKLZ_G_KILLZONES=0 lifts it."""
    if os.environ.get("SKLZ_G_KILLZONES", "1") == "0":
        return True
    from datetime import datetime, timezone
    h = datetime.now(timezone.utc).hour + datetime.now(timezone.utc).minute / 60
    return 7 <= h <= 10 or 12 <= h <= 16


def model_g(h1: list[dict], m5: list[dict], pip: float,
            m15: list[dict] | None = None,
            h4: list[dict] | None = None) -> Setup:
    """Liquidity sweep + displacement FVG. Mirrored for longs.

    Sequence (short):
      1. POOL — relative equal highs on M15 (or M5), or the prior 24h high.
      2. SWEEP — within the last 12 M5 bars a wick trades above the pool
         and the bar closes back below. A close above is a breakout: stand
         aside (that is Model E's whole failure mode).
      3. DISPLACEMENT — after the sweep bar, a bearish M5 FVG at least
         0.15 ATR tall. No gap, no trade.
      4. HTF confluence (score only): H1/H4 bearish FVG overlapping the
         sweep zone.
      5. STOP above the sweep wick (+0.15 ATR). TARGET = nearest swing low
         below entry that pays SKLZ_G_MIN_RR (default 2.0); none pays, no
         trade. The runner's paper tracker resolves at 2R, so this is what
         its scoreboard measures.
    """
    s = Setup(ok=False, model="G: liquidity sweep + FVG")
    if len(m5) < 40 or len(h1) < 24:
        s.blockers.append("not enough history for the sweep+FVG model")
        return s
    atr = _atr(m5) or pip * 10
    try:
        min_rr = float(os.environ.get("SKLZ_G_MIN_RR", "2.0"))
    except ValueError:
        min_rr = 2.0
    min_stop = _min_pips("SKLZ_MIN_STOP_PIPS", 8.0) * pip
    pool_src = m15 if m15 and len(m15) >= 20 else m5
    lows_p, highs_p = swing_points(pool_src[-80:])
    prev24 = h1[-24:]
    ph = max(b["high"] for b in prev24)
    pl = min(b["low"] for b in prev24)
    last = m5[-1]
    recent = m5[-12:]

    for side in (-1, 1):
        # 1. pools --------------------------------------------------
        pools = []
        if side < 0:
            for lvl, n in _equal_levels(highs_p, 0.25 * atr, True):
                pools.append((lvl, f"relative equal highs ×{n} at {lvl:.5f}", 20))
            pools.append((ph, f"prior 24h high {ph:.5f}", 15))
        else:
            for lvl, n in _equal_levels(lows_p, 0.25 * atr, False):
                pools.append((lvl, f"relative equal lows ×{n} at {lvl:.5f}", 20))
            pools.append((pl, f"prior 24h low {pl:.5f}", 15))
        # 2. the sweep ----------------------------------------------
        hit = None
        for lvl, label, pts in pools:
            for i in range(len(m5) - 1, len(m5) - 13, -1):
                b = m5[i]
                if side < 0 and b["high"] > lvl and b["close"] < lvl:
                    cand = (i, b["high"], lvl, label)
                elif side > 0 and b["low"] < lvl and b["close"] > lvl:
                    cand = (i, b["low"], lvl, label)
                else:
                    continue
                if hit is None or cand[0] > hit[0]:
                    hit = cand
                break
        if hit is None:
            if side < 0 and any(b["high"] > lvl and b["close"] >= lvl
                                for lvl, _, _ in pools for b in recent):
                s.blockers.append("price closed THROUGH the pool — breakout, not a sweep")
            continue
        si, extreme, level, label = hit
        taken = [lab for lv, lab, _ in pools
                 if (extreme >= lv if side < 0 else extreme <= lv)]
        score = 25 + sum(pt for lv, _, pt in pools
                         if (extreme >= lv if side < 0 else extreme <= lv))
        reasons = [f"{label} swept to {extreme:.5f} and price closed back "
                   f"{'below' if side < 0 else 'above'} it"]
        reasons += [f"the same wick also took {lab}" for lab in taken if lab != label]
        # 3. displacement FVG after the sweep bar ---------------------
        after = m5[si:si + 8]
        gaps = _all_fvgs(after, side, lookback=len(after), min_height=0.15 * atr)
        if not gaps:
            s.blockers.append(f"{label} swept but no displacement FVG yet — "
                              f"a sweep without displacement is just a wick")
            continue
        g = gaps[-1]
        score += 20
        reasons.append(f"displacement left a {'bearish' if side < 0 else 'bullish'} "
                       f"FVG {g['bottom']:.5f}–{g['top']:.5f} on M5")
        # 4. HTF confluence ------------------------------------------
        lo, hi = (min(level, extreme) - 0.5 * atr, max(level, extreme) + 0.5 * atr)
        for name, bars_, pts in (("H1", h1, 15), ("H4", h4 or [], 10)):
            for z in _all_fvgs(bars_, side, lookback=40):
                if z["bottom"] <= hi and z["top"] >= lo:
                    score += pts
                    reasons.append(f"sweep ran into {name} FVG "
                                   f"{z['bottom']:.5f}–{z['top']:.5f} — HTF imbalance")
                    break
        # 5. stop / target / R ---------------------------------------
        entry = last["close"]
        stop = extreme + 0.15 * atr if side < 0 else extreme - 0.15 * atr
        risk = abs(entry - stop)
        if risk < min_stop:
            s.blockers.append("sweep stop is too tight to be real")
            continue
        before = m5[max(0, si - 80):si]
        lows_b, highs_b = swing_points(before)
        if side < 0:
            cands = sorted([v for _, v in lows_b if v < entry] + [pl] if pl < entry
                           else [v for _, v in lows_b if v < entry], reverse=True)
        else:
            cands = sorted([v for _, v in highs_b if v > entry] + [ph] if ph > entry
                           else [v for _, v in highs_b if v > entry])
        target = None
        for v in cands:                       # nearest pool that PAYS
            if abs(v - entry) / risk >= min_rr:
                target = v
                break
        if target is None:
            s.blockers.append(f"no internal liquidity pays {min_rr:.1f}R from here")
            continue
        rr = abs(target - entry) / risk
        score += 10
        reasons.append(f"objective is the internal liquidity at {target:.5f} — {rr:.1f}R")
        if not _in_kill_zone():
            s.blockers.append("outside London/NY kill zones (SKLZ_G_KILLZONES=0 to lift)")
            continue
        reasons.append(f"score {min(score, 100)}/100")
        s.ok, s.side, s.entry, s.level, s.stop = True, side, entry, level, stop
        s.reasons = reasons
        return s

    if not s.blockers:
        s.blockers.append("no liquidity pool has been swept")
    return s


def _enabled() -> set[str]:
    """Which models may fire. SKLZ_MODELS_ENABLED="a,b,d" runs without C.

    Exists because the V1 backtest showed Model C losing on gold even at
    ZERO spread across 33 trades while firing more than all others combined.
    That is one 3-week window, not a verdict — so this is a switch for the
    owner, not a deletion by the machine. The journal's had_model rows will
    settle it properly.
    """
    raw = os.environ.get("SKLZ_MODELS_ENABLED", "a,b,c,d")
    return {x.strip().lower() for x in raw.split(",") if x.strip()}


ALL_MODELS = ("a", "b", "c", "d", "e", "f", "g")


def evaluate(m15: list[dict], m5: list[dict], h1: list[dict],
             h4: list[dict], pip: float) -> Setup:
    """Try the enabled models; A first because it needs less to be true."""
    en = _enabled()
    off = Setup(ok=False, model="disabled")
    a = model_a(m15, m5, pip) if "a" in en else off
    if a.ok:
        return a
    b = model_b(h4, h1, m5, pip) if "b" in en else off
    if b.ok:
        return b
    cm = model_c(h4, m5, pip) if "c" in en else off
    if cm.ok:
        return cm
    d = model_d(m15, m5, pip) if "d" in en else off
    if d.ok:
        return d
    e = model_e(h1, m5, pip) if "e" in en else off
    if e.ok:
        return e
    f = model_f(m15, m5, pip) if "f" in en else off
    if f.ok:
        return f
    g = model_g(h1, m5, pip, m15, h4) if "g" in en else off
    if g.ok:
        return g
    # none fired — return whichever got furthest, so the log says why
    return min((a, b, cm, d, e, f, g), key=lambda s: len(s.blockers))


def call_model(tag: str, m15, m5, h1, h4, pip) -> Setup:
    """One dispatch for every caller (live chain and paper observer), so a
    new model's signature is declared once — G needs H1+H4 for its zones."""
    fn = globals().get(f"model_{tag}")
    if fn is None:
        return Setup(ok=False, model=f"{tag.upper()}: unknown")
    if tag == "b":
        return fn(h4, h1, m5, pip)
    if tag == "c":
        return fn(h4, m5, pip)
    if tag == "e":
        return fn(h1, m5, pip)
    if tag == "g":
        return fn(h1, m5, pip, m15, h4)
    return fn(m15, m5, pip)


# ── break-entry confirmation for scanner-led entries ────────────────
def break_entry_confirmed(m5: list[dict], level: float, side: int,
                          pip: float) -> tuple[bool, str]:
    """A confirmed break ENTRY needs more than a confirmed break.

    The candle closing beyond the level says the break is real. It does not
    say the entry is: the profitable version waits for price to come BACK to
    the broken level, hold it, and print a 5M engulfing in the break's
    direction. Without that, half of "breakouts" are entered at the far end
    of the move — maximum chase, minimum information — and the sweep that
    closes back through collects the stop.

    Sequence, from the owner's own losing-trade review:
      break (already confirmed upstream) -> retest of the line ->
      hold -> 5M engulfing in direction -> enter.
    """
    if len(m5) < 6:
        return False, "not enough M5 bars to confirm the retest"

    tol = 6 * pip
    recent = m5[-10:]
    if side > 0:
        came_back = any(b["low"] <= level + tol for b in recent)
    else:
        came_back = any(b["high"] >= level - tol for b in recent)
    if not came_back:
        return False, (f"broke {level:.5f} but has not retested it — "
                       f"entering here is chasing the far end of the move")

    last = m5[-1]
    held = last["close"] > level if side > 0 else last["close"] < level
    if not held:
        return False, (f"retested {level:.5f} and is not holding the break "
                       f"side — this is how sweeps look")

    eng = engulfing(m5, side)
    if not eng["ok"]:
        return False, (f"retest holding at {level:.5f}, waiting for a 5M "
                       f"engulfing candle to confirm direction")

    return True, (f"break of {level:.5f} retested, held, and confirmed by a "
                  f"5M engulfing — continuation, not a sweep")
