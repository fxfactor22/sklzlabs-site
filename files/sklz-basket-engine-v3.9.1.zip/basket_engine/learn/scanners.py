"""The 'famous strategies' as opportunity scanners.

Each returns (side, detail) or None. These are HYPOTHESES: your own 27M-tick
research showed them at coin-flip out-of-sample, so we log their entries to
MEASURE them against your discretionary entries — not because we trust them.
"""
from __future__ import annotations


def _closes(io, sym, tf, n):
    return io.closes(sym, tf, n)


def sweep_reversal(io, symbol, tf_min, lookback):
    """Liquidity sweep: price pokes beyond the recent extreme then reverses."""
    c = _closes(io, symbol, tf_min, lookback + 4)
    if len(c) < lookback + 4:
        return None
    # same principle as structure_break: the forming bar is not evidence.
    # c[-1] is live, so the poke and the reaction must both be COMPLETED bars
    c = c[:-1]
    # the extreme is the RANGE BEFORE the poke: exclude the last two bars
    body = c[:-2]
    hi, lo = max(body), min(body)
    prev, last = c[-2], c[-1]          # prev = the poke bar, last = the reaction
    if prev > hi and last < prev:      # swept highs, rejected down
        return (-1, f"sweep of highs {hi:.5f} then rejection")
    if prev < lo and last > prev:      # swept lows, rejected up
        return (+1, f"sweep of lows {lo:.5f} then rejection")
    return None


def structure_break(io, symbol, tf_min, lookback):
    """Market-structure shift, confirmed by a COMPLETED candle body close.

    Two mistakes this version replaces:

    1. The forming bar was included, so its "close" was just the live price.
       During a sweep, the wick-in-progress read as a close beyond the level
       and fired an entry IN THE DIRECTION OF THE SWEEP — selling the bottom
       of the trap. A wick through a level is a sweep until the candle
       actually closes beyond it; only the body close is a break.

    2. Structure was measured on closes. The swing everyone watches — and
       places stops beyond — is the actual high/low. Breaking the highest
       close while staying under the swing high breaks nothing.

    The cost is one bar of latency. That is the price of knowing the candle
    closed, and it is cheaper than being the liquidity.
    """
    bars = io.bars(symbol, tf_min, lookback + 3)
    if len(bars) < lookback + 3:
        return None
    done = bars[:-1]                    # decisions on completed candles only
    last = done[-1]
    window = done[-lookback - 1:-1]
    hi = max(b["high"] for b in window)
    lo = min(b["low"] for b in window)
    if last["close"] > hi:
        return (+1, f"break of structure — candle closed above {hi:.5f}")
    if last["close"] < lo:
        return (-1, f"break of structure — candle closed below {lo:.5f}")
    return None


def strength_extreme(io, symbol, tf_min, lookback):
    """Currency-strength: enter the strongest-vs-weakest in the symbol's legs."""
    from basket_engine.strength import currency_strength, rank, PAIRS
    if len(symbol) < 6:
        return None
    base, quote = symbol[:3], symbol[3:6]
    avail = {p for p in PAIRS if io.has_symbol(p)}
    data = {p: io.closes(p, tf_min, lookback+2) for p in avail}
    data = {p: c for p, c in data.items() if len(c) > lookback}
    if len(data) < 6:
        return None
    s = currency_strength(data, lookback)
    if base not in s or quote not in s:
        return None
    diff = s[base] - s[quote]
    if diff > 0.002:
        return (+1, f"{base} stronger than {quote} ({diff:+.4f})")
    if diff < -0.002:
        return (-1, f"{base} weaker than {quote} ({diff:+.4f})")
    return None


SCANNERS = {
    "sweep_reversal": sweep_reversal,
    "structure_break": structure_break,
    "strength_extreme": strength_extreme,
}
