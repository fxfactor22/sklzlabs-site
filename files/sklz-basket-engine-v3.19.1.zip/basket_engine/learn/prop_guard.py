"""SKLZ — prop-firm circuit breaker.

A prop account is not a normal account. With a 5% daily loss limit AND a 5%
max drawdown on $10,000, the entire life of the account is a $500 budget —
and the firm counts FLOATING losses, so the breach can happen while every
position still "might come back."

The guard's job is to make the firm's rule unreachable by stopping first:

  SOFT  (default 2.5% down):  no new entries. Open trades manage themselves.
  HARD  (default 4.0% down):  flatten everything and halt. The 1% gap to the
        firm's 5% is the slippage budget — a flatten during a fast move fills
        worse than the trigger price, and being stopped by YOUR OWN rule at
        4.2% is survival; being stopped by the firm's at 5.0% is deletion.

Both checks run against BOTH anchors every scan:
  - the day anchor (equity at the configured daily reset hour)
  - the baseline (SKLZ_PROP_BASELINE — the account's initial size)

Whichever anchor is closer to breach decides. The daily reset hour MUST match
the firm's server reset (SKLZ_DAY_RESET_UTC_HOUR); a mismatch means the
engine's "new day" and the firm's disagree, and the firm's opinion is the
only one that matters.
"""
from __future__ import annotations

import os
import time
from datetime import datetime, timezone


def _f(env: str, default: float) -> float:
    try:
        return float(os.environ.get(env, str(default)))
    except (TypeError, ValueError):
        return default


class PropGuard:
    def __init__(self, log=print):
        self.log = log
        self.enabled = os.environ.get("SKLZ_PROP_GUARD", "0") == "1"
        self.baseline = _f("SKLZ_PROP_BASELINE", 0.0)
        self.soft_pct = _f("SKLZ_PROP_SOFT_PCT", 2.5)
        self.hard_pct = _f("SKLZ_PROP_HARD_PCT", 4.0)
        self.reset_hour = int(_f("SKLZ_DAY_RESET_UTC_HOUR", 0))
        self.max_open = int(_f("SKLZ_PROP_MAX_OPEN", 3))
        self.day_anchor: float | None = None
        self.day_key: str | None = None
        self.halted = False
        self._last_state = ""

    def _day_key(self, now: datetime) -> str:
        # the "prop day" starts at reset_hour UTC, not midnight
        shifted = now.timestamp() - self.reset_hour * 3600
        return datetime.fromtimestamp(shifted, tz=timezone.utc).strftime(
            "%Y-%m-%d")

    def check(self, io) -> dict:
        """Returns {"entries_ok": bool, "reason": str}. Flattens on HARD."""
        if not self.enabled:
            return {"entries_ok": True, "reason": ""}

        try:
            acct = io.account() or {}
            equity = float(acct.get("equity") or 0.0)
        except Exception:
            return {"entries_ok": False,
                    "reason": "cannot read equity — refusing entries "
                              "rather than guessing"}
        if equity <= 0:
            return {"entries_ok": False, "reason": "no equity reading"}

        now = datetime.now(timezone.utc)
        dk = self._day_key(now)
        if dk != self.day_key:
            self.day_key = dk
            self.day_anchor = equity
            self.halted = False
            self.log(f"[prop] new trading day — anchor {equity:.2f}, "
                     f"budget to soft stop "
                     f"{equity * self.soft_pct / 100:.2f}, to hard stop "
                     f"{equity * self.hard_pct / 100:.2f}")

        if self.halted:
            return {"entries_ok": False,
                    "reason": "halted until the next trading day"}

        anchors = [("day", self.day_anchor or equity)]
        if self.baseline > 0:
            anchors.append(("baseline", self.baseline))

        worst_dd = 0.0
        worst_name = "day"
        for name, ref in anchors:
            if ref <= 0:
                continue
            dd = (ref - equity) / ref * 100
            if dd > worst_dd:
                worst_dd, worst_name = dd, name

        if worst_dd >= self.hard_pct:
            self.halted = True
            n = 0
            try:
                n = io.close_all()
            except Exception as exc:  # noqa: BLE001
                self.log(f"[prop] FLATTEN FAILED: {type(exc).__name__}: "
                         f"{exc} — CLOSE MANUALLY NOW")
            self.log(f"[prop] HARD STOP — {worst_dd:.2f}% down from the "
                     f"{worst_name} anchor. Closed {n} position(s). No more "
                     f"entries today. The firm's limit is 5%; stopping at "
                     f"{self.hard_pct:.1f}% is what keeps the account alive.")
            return {"entries_ok": False, "reason": "hard stop hit"}

        if worst_dd >= self.soft_pct:
            state = "soft"
            if self._last_state != state:
                self.log(f"[prop] SOFT STOP — {worst_dd:.2f}% down from the "
                         f"{worst_name} anchor. No new entries; open trades "
                         f"run their stops. Resumes if equity recovers or "
                         f"at the next day anchor.")
            self._last_state = state
            return {"entries_ok": False, "reason": "soft stop active"}

        self._last_state = "ok"

        # concurrency cap: three positions at 0.5% risk each is a 1.5%
        # correlated worst case — inside the soft budget, never past it
        try:
            n_open = len(io.my_positions() or [])
            if n_open >= self.max_open:
                return {"entries_ok": False,
                        "reason": f"{n_open} positions open — the prop cap "
                                  f"is {self.max_open} at once"}
        except Exception:
            pass

        return {"entries_ok": True, "reason": ""}
