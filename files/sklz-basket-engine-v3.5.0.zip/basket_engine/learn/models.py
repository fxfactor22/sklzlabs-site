"""SKLZ — two structured entry models.

MODEL A — M15 break and retest
    A level breaks on M15, price returns to it, and the level holds as
    support/resistance. Entry on the hold, not the break.

MODEL B — HTF order block, fib 50 entry
    Price rejects from the 50% level of a 4H or 1H order block. A 5M engulfing
    candle confirms the rejection. A fib is drawn from that rejection line to
    the extreme reached, and entry is at the 50% retracement.

BOTH confirmed by RSI(2) with a 21-period SMA on M5.

WHY THE RSI TIMING MATTERS
==========================
RSI(2) is fast and mean-reverting. At the moment a level breaks it will be
deep overbought on a bullish break — so a rule of "buy only below 30" would
block every entry if it were read at the break.

It is read at the RETEST, which is a pullback, and that is exactly when RSI(2)
falls. The rule and the model agree only because of when the measurement is
taken. Read it at the wrong moment and the model never fires.

The 21-SMA of RSI is the slower reference: RSI below its own average says the
pullback is real rather than a single noisy print.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


# ── indicators ──────────────────────────────────────────────────────
def rsi(closes: list[float], period: int = 2) -> list[float]:
    """Wilder's RSI. Returns a list aligned to the input, padded at the front.

    Period 2 is deliberately short — it is a pullback detector, not a trend
    filter, and at that length it swings the full range within a few bars.
    """
    if len(closes) < period + 1:
        return [50.0] * len(closes)

    out = [50.0] * period
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0.0)
        losses += max(-d, 0.0)
    ag, al = gains / period, losses / period
    out.append(100.0 if al == 0 else 100 - 100 / (1 + ag / al))

    for i in range(period + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        ag = (ag * (period - 1) + max(d, 0.0)) / period
        al = (al * (period - 1) + max(-d, 0.0)) / period
        out.append(100.0 if al == 0 else 100 - 100 / (1 + ag / al))
    return out


def sma(values: list[float], period: int) -> list[float]:
    out, run = [], 0.0
    for i, v in enumerate(values):
        run += v
        if i >= period:
            run -= values[i - period]
        out.append(run / min(i + 1, period))
    return out


# ── shared confirmation ─────────────────────────────────────────────
def rsi_confirms(side: int, m5_closes: list[float],
                 period: int = 2, smooth: int = 21) -> dict:
    """RSI(2) against its 21-SMA, read at the entry bar.

    Buy wants RSI oversold (the pullback is deep enough to be worth entering).
    Sell wants overbought. The SMA comparison guards against a single spike:
    RSI can print 12 on one noisy bar and mean nothing.
    """
    if len(m5_closes) < smooth + period + 2:
        return {"ok": False, "reason": "not enough M5 bars for RSI"}

    r = rsi(m5_closes, period)
    rs = sma(r, smooth)
    cur, avg = r[-1], rs[-1]

    try:
        lo = float(os.environ.get("SKLZ_RSI_BUY_BELOW", "30"))
        hi = float(os.environ.get("SKLZ_RSI_SELL_ABOVE", "70"))
    except ValueError:
        lo, hi = 30.0, 70.0

    # Look back a few bars, not only at the current one.
    #
    # The "hold" that confirms a retest is itself upward movement, and RSI(2)
    # is fast enough to leave oversold on that single bar. Demanding RSI < 30
    # AT the entry bar means the condition is almost never true at the moment
    # you actually want to enter.
    #
    # The real signal is: it REACHED oversold during the pullback, and is now
    # turning back up. That is the classic short-RSI entry and it is what the
    # rule was reaching for.
    try:
        window = int(os.environ.get("SKLZ_RSI_LOOKBACK", "4"))
    except ValueError:
        window = 4
    recent = r[-window:]

    if side > 0:
        reached = min(recent) < lo
        turning = cur > recent[-2] if len(recent) > 1 else True
        ok = reached and turning
        why = (f"RSI(2) reached {min(recent):.0f} in the pullback (under "
               f"{lo:.0f}) and is turning up at {cur:.0f}"
               if ok else
               (f"RSI(2) got to {min(recent):.0f} but is not turning up yet"
                if reached else
                f"RSI(2) low was {min(recent):.0f} over the last {window} bars; "
                f"a buy wants it under {lo:.0f}. The pullback is not deep "
                f"enough."))
    else:
        reached = max(recent) > hi
        turning = cur < recent[-2] if len(recent) > 1 else True
        ok = reached and turning
        why = (f"RSI(2) reached {max(recent):.0f} (over {hi:.0f}) and is "
               f"turning down at {cur:.0f}"
               if ok else
               (f"RSI(2) got to {max(recent):.0f} but is not turning down yet"
                if reached else
                f"RSI(2) high was {max(recent):.0f} over the last {window} "
                f"bars; a sell wants it over {hi:.0f}."))

    return {"ok": ok, "rsi": round(cur, 1), "rsi_avg": round(avg, 1),
            "reason": why}


def engulfing(bars: list[dict], side: int) -> dict:
    """A 5M engulfing candle in the intended direction."""
    if len(bars) < 2:
        return {"ok": False, "reason": "not enough bars"}
    p, c = bars[-2], bars[-1]
    if side > 0:
        ok = (p["close"] < p["open"] and c["close"] > c["open"]
              and c["close"] > p["open"] and c["open"] <= p["close"])
    else:
        ok = (p["close"] > p["open"] and c["close"] < c["open"]
              and c["close"] < p["open"] and c["open"] >= p["close"])
    return {"ok": ok,
            "reason": ("5M engulfing candle in our direction" if ok
                       else "no 5M engulfing candle at this level")}


# ── Model A: M15 break and retest ───────────────────────────────────
@dataclass
class Setup:
    ok: bool
    model: str
    side: int = 0
    entry: float = 0.0
    level: float = 0.0
    stop: float = 0.0
    reasons: list = field(default_factory=list)
    blockers: list = field(default_factory=list)


def find_m15_level(m15: list[dict], lookback: int = 40,
                   touches: int = 2, tol_frac: float = 0.0008) -> list[dict]:
    """Levels worth breaking: prices touched more than once.

    A level nobody traded twice is not a level, it is a coordinate.
    """
    if len(m15) < 12:
        return []
    window = m15[-lookback:]
    pts = []
    for i in range(2, len(window) - 2):
        h, l = window[i]["high"], window[i]["low"]
        if h >= max(window[i - 2]["high"], window[i - 1]["high"],
                    window[i + 1]["high"], window[i + 2]["high"]):
            pts.append(("high", h))
        if l <= min(window[i - 2]["low"], window[i - 1]["low"],
                    window[i + 1]["low"], window[i + 2]["low"]):
            pts.append(("low", l))

    levels = []
    for kind, price in pts:
        hit = [p for k, p in pts if k == kind
               and abs(p - price) <= price * tol_frac]
        if len(hit) >= touches:
            if not any(abs(l["price"] - price) <= price * tol_frac
                       for l in levels):
                levels.append({"kind": kind, "price": sum(hit) / len(hit),
                               "touches": len(hit)})
    return levels


def model_a(m15: list[dict], m5: list[dict], pip: float) -> Setup:
    """M15 break, then retest, then enter on the hold."""
    s = Setup(ok=False, model="A: M15 break-retest")

    levels = find_m15_level(m15)
    if not levels:
        s.blockers.append("no M15 level with two or more touches")
        return s
    if len(m15) < 6:
        s.blockers.append("not enough M15 history")
        return s

    for lv in levels:
        price, kind = lv["price"], lv["kind"]
        side = 1 if kind == "high" else -1

        # did a recent M15 bar close beyond it?
        broke_at = None
        for i in range(len(m15) - 6, len(m15)):
            if i < 1:
                continue
            b = m15[i]
            if side > 0 and b["close"] > price and m15[i - 1]["close"] <= price:
                broke_at = i
            if side < 0 and b["close"] < price and m15[i - 1]["close"] >= price:
                broke_at = i
        if broke_at is None:
            continue

        # has price come back to it and held? measured on M5 for precision
        tol = 6 * pip
        came_back = any(
            (side > 0 and b["low"] <= price + tol) or
            (side < 0 and b["high"] >= price - tol)
            for b in m5[-8:])
        if not came_back:
            s.blockers.append(f"broke {price:.5f} but has not retested it yet")
            continue

        last = m5[-1]
        held = last["close"] > price if side > 0 else last["close"] < price
        if not held:
            s.blockers.append(f"retested {price:.5f} and failed to hold")
            continue

        rsi_c = rsi_confirms(side, [b["close"] for b in m5])
        if not rsi_c["ok"]:
            s.blockers.append(rsi_c["reason"])
            continue

        s.ok = True
        s.side = side
        s.level = price
        s.entry = last["close"]
        s.stop = (min(b["low"] for b in m5[-6:]) - 2 * pip if side > 0
                  else max(b["high"] for b in m5[-6:]) + 2 * pip)
        s.reasons = [
            f"M15 level {price:.5f} touched {lv['touches']}x, then broken",
            "price returned and the level held",
            rsi_c["reason"],
        ]
        return s

    return s


# ── Model B: HTF order block, fib 50 entry ──────────────────────────
def order_block(htf: list[dict], side: int, lookback: int = 30) -> dict | None:
    """The last opposing candle before the move that broke structure.

    That candle is where the position was built — the 50% of its range is the
    level worth watching, not its extreme.
    """
    if len(htf) < 6:
        return None
    window = htf[-lookback:]
    # start at len-2 so the candle immediately before the break is reachable —
    # that is usually THE order block, and len-3 skipped it entirely
    for i in range(len(window) - 2, 0, -1):
        c = window[i]
        nxt = window[i + 1] if i + 1 < len(window) else None
        if nxt is None:
            continue
        if side > 0 and c["close"] < c["open"] and nxt["close"] > c["high"]:
            return {"high": c["high"], "low": c["low"],
                    "mid": (c["high"] + c["low"]) / 2, "index": i}
        if side < 0 and c["close"] > c["open"] and nxt["close"] < c["low"]:
            return {"high": c["high"], "low": c["low"],
                    "mid": (c["high"] + c["low"]) / 2, "index": i}
    return None


def model_b(h4: list[dict], h1: list[dict], m5: list[dict],
            pip: float) -> Setup:
    """Rejection from the 50% of an HTF order block, entered at fib 50."""
    s = Setup(ok=False, model="B: HTF block, fib 50")

    for side in (1, -1):
        blk = order_block(h4, side) or order_block(h1, side)
        if not blk:
            continue

        mid = blk["mid"]

        # has price rejected from the block's 50%?
        touched = any(
            (side > 0 and b["low"] <= mid + 4 * pip) or
            (side < 0 and b["high"] >= mid - 4 * pip)
            for b in m5[-30:])
        if not touched:
            continue

        # the extreme reached since that rejection
        if side > 0:
            extreme = max(b["high"] for b in m5[-30:])
            if extreme <= mid:
                continue
            fib50 = mid + (extreme - mid) * 0.5
            at_fib = m5[-1]["low"] <= fib50 + 4 * pip
        else:
            extreme = min(b["low"] for b in m5[-30:])
            if extreme >= mid:
                continue
            fib50 = mid - (mid - extreme) * 0.5
            at_fib = m5[-1]["high"] >= fib50 - 4 * pip

        if not at_fib:
            s.blockers.append(
                f"rejected from the block at {mid:.5f} but price is not back "
                f"at the 50% fib ({fib50:.5f}) yet")
            continue

        eng = engulfing(m5, side)
        if not eng["ok"]:
            s.blockers.append(eng["reason"])
            continue

        rsi_c = rsi_confirms(side, [b["close"] for b in m5])
        if not rsi_c["ok"]:
            s.blockers.append(rsi_c["reason"])
            continue

        s.ok = True
        s.side = side
        s.level = mid
        s.entry = m5[-1]["close"]
        s.stop = (blk["low"] - 2 * pip if side > 0 else blk["high"] + 2 * pip)
        s.reasons = [
            f"HTF order block {blk['low']:.5f}-{blk['high']:.5f}, "
            f"50% at {mid:.5f}",
            f"price rejected from it and ran to {extreme:.5f}",
            f"returned to the 50% fib at {fib50:.5f}",
            eng["reason"],
            rsi_c["reason"],
        ]
        return s

    return s


def evaluate(m15: list[dict], m5: list[dict], h1: list[dict],
             h4: list[dict], pip: float) -> Setup:
    """Try both models; A first because it needs less to be true."""
    a = model_a(m15, m5, pip)
    if a.ok:
        return a
    b = model_b(h4, h1, m5, pip)
    if b.ok:
        return b
    # neither fired — return whichever got further, so the log says why
    return a if len(a.blockers) <= len(b.blockers) else b
