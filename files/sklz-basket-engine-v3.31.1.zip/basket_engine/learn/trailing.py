"""SKLZ — trailing stop and break-even protection.

Applies to every open position the runner can see, whether it was opened by
a scanner, from the dashboard, or typed into the console.

The rule, using the gold example:

    entry 4024, SL 4016 (buy)
    price reaches 4028   -> +40 pips, trigger fires
    SL jumps to 4026     -> +20 pips locked in, trade can no longer lose
    price keeps rising   -> SL trails 20 pips behind, never moving backwards

Expressed generically: trigger at TRIGGER_PIPS, secure at TRAIL_PIPS profit,
then keep the stop TRAIL_PIPS behind the current price. Pip size differs per
instrument, so the same rule gives sensible distances on FX, metals, indices
and crypto.

Two properties that matter:
  - the stop only ever moves in the trader's favour, never wider
  - it is set on the BROKER, so protection survives the runner going offline
"""
from __future__ import annotations

import os

# pip size per instrument family. Gold: 0.1, so 40 pips = $4.00 — matching
# the convention most brokers and traders use for XAUUSD.
PIP_SIZE = {
    # metals
    "XAUUSD": 0.1, "GOLD": 0.1, "XAGUSD": 0.01, "SILVER": 0.01,
    # FX majors / crosses (JPY pairs use 0.01)
    "USDJPY": 0.01, "EURJPY": 0.01, "GBPJPY": 0.01, "AUDJPY": 0.01,
    "CADJPY": 0.01, "CHFJPY": 0.01, "NZDJPY": 0.01,
    # indices — 1 point. Broker aliases matter here: IC Markets calls the
    # Nasdaq USTEC and the S&P US500 — an unlisted alias fell through to
    # digits=1 -> pip 0.1, which made the 25-pip index trigger 2.5 POINTS on
    # a 29,700 index. The trail armed on noise and stopped out in seconds.
    "US30": 1.0, "NAS100": 1.0, "USTEC": 1.0, "USTECH": 1.0,
    "SPX500": 1.0, "US500": 1.0, "GER40": 1.0, "DE40": 1.0, "DE30": 1.0,
    "UK100": 1.0, "JP225": 1.0, "AUS200": 1.0, "HK50": 1.0, "STOXX50": 1.0,
    # energy
    "USOIL": 0.01, "UKOIL": 0.01, "WTI": 0.01,
    "USOUSD": 0.01, "UKOUSD": 0.01, "BRENT": 0.01,
    # crypto — 1 unit
    "BTCUSD": 1.0, "ETHUSD": 0.1, "XRPUSD": 0.0001, "LTCUSD": 0.01,
}
DEFAULT_PIP = 0.0001            # standard FX


def pip_size(symbol: str, digits: int | None = None) -> float:
    """Pip size for an instrument, falling back to broker digits."""
    s = (symbol or "").upper()
    for key, size in PIP_SIZE.items():
        if s.startswith(key):
            return size
    if digits is not None:
        if digits in (3, 5):
            return 10 ** -(digits - 1)      # 5-digit FX -> 0.0001
        if digits in (2, 4):
            return 10 ** -(digits - 1)
        if digits == 1:
            return 0.1
        if digits == 0:
            return 1.0
    return DEFAULT_PIP


def _cfg(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


# Trailing thresholds per instrument class.
#
# A single pip number cannot serve gold and EURUSD: 30 pips is $3 on gold and
# most of a day's range on EURUSD. These are what each class actually needs to
# clear its own noise, with env overrides for testing.
TRAIL_BANDS = {
    "gold":    (30, 15),      # $3.00 move -> lock $1.50
    "silver":  (20, 10),      # silver pip is 10x smaller than gold's
    "fx":      (12, 6),
    "jpy":     (12, 6),
    "index":   (25, 12),
    "crypto":  (60, 30),
    "energy":  (20, 10),
}


def _trail_class(symbol: str) -> str:
    s = (symbol or "").upper()
    for suf in ("..", ".", "m", "c", "r", "_", "#"):
        if s.endswith(suf):
            s = s[: -len(suf)]
    s = s.strip(".")
    if s.startswith(("XAU", "GOLD")):
        return "gold"
    if s.startswith(("XAG", "SILVER")):
        return "silver"
    if s.startswith(("BTC", "ETH", "XRP", "SOL", "LTC", "ADA", "DOGE")):
        return "crypto"
    if s.startswith(("US30", "US500", "NAS", "SPX", "DE40", "UK100", "JP225",
                     "GER", "USTEC", "AUS200")):
        return "index"
    if s.startswith(("USO", "UKO", "WTI", "BRENT", "OIL", "NGAS")):
        return "energy"
    if "JPY" in s:
        return "jpy"
    return "fx"


def trail_for(symbol: str) -> tuple[float, float]:
    """(trigger, lock) in pips for this instrument.

    An explicit env override wins, so a single global number can still be
    forced for testing — but the per-class defaults mean nothing has to be set
    for the behaviour to be sensible.
    """
    import os as _os
    k = _trail_class(symbol)
    trig, lock = TRAIL_BANDS.get(k, TRAIL_BANDS["fx"])

    # class-specific override, e.g. SKLZ_TRAIL_GOLD=30/15
    raw = _os.environ.get(f"SKLZ_TRAIL_{k.upper()}", "").strip()
    if raw and "/" in raw:
        try:
            a, b = raw.split("/", 1)
            trig, lock = float(a), float(b)
        except ValueError:
            pass

    # global override still wins over everything, for a single-number test
    g_t = _os.environ.get("SKLZ_TRAIL_TRIGGER_PIPS", "").strip()
    g_l = _os.environ.get("SKLZ_TRAIL_DISTANCE_PIPS", "").strip()
    if g_t:
        try:
            trig = float(g_t)
        except ValueError:
            pass
    if g_l:
        try:
            lock = float(g_l)
        except ValueError:
            pass
    return trig, lock


def trigger_pips() -> float:
    """Profit at which break-even protection kicks in."""
    return _cfg("SKLZ_TRAIL_TRIGGER_PIPS", 20)


def trail_pips() -> float:
    """Distance the stop keeps behind price once trailing."""
    return _cfg("SKLZ_TRAIL_DISTANCE_PIPS", 10)


def enabled() -> bool:
    return os.environ.get("SKLZ_TRAILING", "1") != "0"


def desired_stop(side: int, entry: float, current: float, current_sl: float,
                 pip: float, symbol: str = "") -> tuple[float | None, str]:
    """Work out where the stop should be. Returns (new_sl, reason) or (None, why not).

    Pure function — no broker calls — so the rule is unit-testable.
    """
    if symbol:
        t_p, d_p = trail_for(symbol)
    else:
        t_p, d_p = trigger_pips(), trail_pips()
    trig = t_p * pip
    dist = d_p * pip

    profit = (current - entry) if side > 0 else (entry - current)
    if profit < trig:
        return None, "not yet at trigger"

    if side > 0:
        target = current - dist
        secured = entry + dist
        target = max(target, secured)          # never below the secure level
        if current_sl and target <= current_sl + (pip * 0.5):
            return None, "stop already at or beyond target"
        moved_to_be = current_sl < entry or not current_sl
        return target, ("secured at break-even + profit" if moved_to_be
                        else "trailing stop up")
    else:
        target = current + dist
        secured = entry - dist
        target = min(target, secured)
        if current_sl and target >= current_sl - (pip * 0.5):
            return None, "stop already at or beyond target"
        moved_to_be = current_sl > entry or not current_sl
        return target, ("secured at break-even + profit" if moved_to_be
                        else "trailing stop down")


def manage(io, log=print, on_update=None) -> list[dict]:
    """Check every open position and move stops where the rule says to.

    `on_update(event)` is called for each change so the caller can broadcast it.
    Returns the list of updates made.
    """
    if not enabled():
        return []
    updates = []
    try:
        positions = io.my_positions()
    except Exception as exc:  # noqa: BLE001
        log(f"[trail] could not read positions: {exc}")
        return []

    for p in positions:
        symbol = p.get("symbol", "")
        side = p.get("side", 0)
        entry = float(p.get("open_price") or 0)
        cur_sl = float(p.get("sl") or 0)
        if not symbol or not side or not entry:
            continue
        # sanity: an entry price that is zero, or wildly far from the market,
        # means the broker did not report the fill properly. Acting on it
        # produced instant closes, so skip and say so.
        try:
            mkt = io.price(symbol, -side)
        except Exception:
            continue
        if entry <= 0 or mkt <= 0 or abs(entry - mkt) / mkt > 0.25:
            log(f"[trail] {symbol} skipped — entry price {entry} looks wrong "
                f"against market {mkt}; not moving the stop")
            continue
        try:
            digits = io.spec(symbol).get("digits")
        except Exception:
            digits = None
        pip = pip_size(symbol, digits)
        current = mkt                              # exit side price, already read

        new_sl, reason = desired_stop(side, entry, current, cur_sl, pip,
                                      symbol=symbol)
        if new_sl is None:
            continue

        ok = False
        try:
            ok = io.modify_sl(p["ticket"], new_sl)
        except Exception as exc:  # noqa: BLE001
            log(f"[trail] modify failed on {symbol}: {exc}")
        if not ok:
            continue

        locked = ((new_sl - entry) if side > 0 else (entry - new_sl)) / pip
        ev = {
            "ticket": p["ticket"], "symbol": symbol,
            "side": "buy" if side > 0 else "sell",
            "entry": entry, "price": current,
            "old_sl": cur_sl, "new_sl": round(new_sl, 6),
            "locked_pips": round(locked, 1),
            "reason": reason,
        }
        updates.append(ev)
        log(f"[trail] {symbol} {ev['side'].upper()} — {reason}: "
            f"SL {cur_sl or 'none'} -> {new_sl:.5f} "
            f"({locked:+.0f} pips locked)")
        if on_update:
            try:
                on_update(ev)
            except Exception:
                pass
    return updates
