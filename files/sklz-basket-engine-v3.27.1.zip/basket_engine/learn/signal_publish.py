"""Publish REAL scanner findings to the SKLZ signals pipeline.

Everything here comes from live market data via MT5:
  - the setup is a genuine scanner hit (sweep / structure break / strength)
  - entry is the live price, SL/TP are computed from live ATR
  - nothing is invented; if there is no setup, nothing is sent

Honest framing is enforced in the note: these scanners are HYPOTHESES per
SKLZ's own 27M-tick research (often coin-flip out-of-sample), so signals are
published as PLANS with levels, never as promises.

Env:
  SKLZ_API_URL           https://api.sklzlabs.com
  SIGNAL_WEBHOOK_KEY     the webhook key from the signals pipeline
  SKLZ_PUBLISH_SIGNALS   "1" to enable publishing (default off)
  SKLZ_SIGNAL_MIN_GAP    minutes between signals per symbol (default 60)
"""
from __future__ import annotations

import json
import os
import time
import urllib.request

_LAST_SENT: dict = {}


def _enabled() -> bool:
    return os.environ.get("SKLZ_PUBLISH_SIGNALS", "") == "1"


def _min_gap_min() -> int:
    try:
        return int(os.environ.get("SKLZ_SIGNAL_MIN_GAP", "60"))
    except ValueError:
        return 60


def _atr(io, symbol: str, tf_min: int, n: int = 14) -> float:
    """Simple ATR proxy from close-to-close moves on live bars."""
    c = io.closes(symbol, tf_min, n + 1)
    if len(c) < 3:
        return 0.0
    moves = [abs(c[i] - c[i - 1]) for i in range(1, len(c))]
    return sum(moves) / len(moves) if moves else 0.0


def publish(io, symbol: str, side: int, strategy: str, detail: str,
            tf_min: int, log=print, force: bool = False,
            actual_price: float | None = None,
            actual_sl: float | None = None,
            actual_tp: float | None = None) -> bool:
    """Send ONE real signal. force=True for deliberate trader entries
    (skips the per-symbol rate limit, since you meant to take this one).

    When the bot has already placed a trade, pass its REAL fill and levels.
    Recomputing them here produced a signal whose stop differed from the one
    actually being traded — subscribers were told a level the bot was not
    using. Anything passed in wins over a fresh calculation."""
    if not _enabled():
        return False
    api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
    key = os.environ.get("SIGNAL_WEBHOOK_KEY", "")
    if not (api and key):
        return False

    # rate limit per symbol so the channel isn't spammed
    gap = _min_gap_min() * 60
    now = time.time()
    if not force and now - _LAST_SENT.get(symbol, 0) < gap:
        return False

    # LIVE data — price and ATR straight from the terminal, unless the caller
    # already has the real numbers from the executed trade
    try:
        price = actual_price if actual_price else io.price(symbol, side)
        atr = _atr(io, symbol, tf_min)
    except Exception as exc:  # noqa: BLE001
        log(f"[signal] could not read live data for {symbol}: {exc}")
        return False
    if not price or not atr:
        return False

    payload = {
        "symbol": symbol,
        "side": "buy" if side > 0 else "sell",
        "price": round(price, 5),
        "atr": round(atr, 5),
        "timeframe": f"M{tf_min}" if tf_min < 60 else f"H{tf_min // 60}",
        "note": (f"SKLZ trader entry — {detail}. "
                 f"Plan, not a promise — manage your own risk."
                 if strategy == "manual entry" else
                 f"SKLZ bot scan — {strategy}: {detail}. "
                 f"Plan, not a promise — manage your own risk."),
    }
    # if the bot already traded this, publish the levels it ACTUALLY used —
    # the API honours explicit entry/sl/tp and only computes them otherwise
    # The API only honours explicit levels when entry, sl AND tp are all
    # present. Requiring actual_tp here meant any entry without a take-profit
    # — which is every auto entry, since those trail instead — silently fell
    # back to recomputing, and subscribers were told a stop the bot was not
    # using. Derive a target from the real stop rather than dropping both.
    if actual_sl:
        d = 1 if side > 0 else -1
        sl_v = float(actual_sl)
        tp_v = float(actual_tp) if actual_tp else None
        if tp_v is None:
            risk = abs(price - sl_v)
            tp_v = price + d * risk * 2      # 2R, matching the stop actually set
        payload["entry"] = round(price, 6)
        payload["sl"] = round(sl_v, 6)
        payload["tp"] = round(tp_v, 6)
    try:
        req = urllib.request.Request(
            f"{api}/api/signals/webhook/{key}",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as r:
            res = json.loads(r.read().decode())
        if res.get("ok"):
            _LAST_SENT[symbol] = now
            lv = res.get("levels", {})
            log(f"[signal] PUBLISHED {payload['side'].upper()} {symbol} "
                f"@ {lv.get('entry')} SL {lv.get('sl')} TP {lv.get('tp')} "
                f"-> {res.get('category')} channel")
            return True
        log(f"[signal] rejected: {res}")
    except Exception as exc:  # noqa: BLE001
        log(f"[signal] publish failed: {type(exc).__name__}: {exc}")
    return False


def update_status(symbol: str, side: int, new_status: str,
                  pips: float | None = None,
                  money: float | None = None, log=print) -> bool:
    """Tell the API a published signal changed state.

    "secured" when the trail arms (profit locked), "closed" on exit. Fire and
    forget — a failed status update must never interfere with trading, so
    every failure path is a return, not a raise.
    """
    api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
    key = os.environ.get("SIGNAL_WEBHOOK_KEY", "")
    if not (api and key):
        return False
    body = {"symbol": symbol, "side": "buy" if side > 0 else "sell",
            "status": new_status}
    if pips is not None:
        body["pips"] = round(pips, 1)
    if money is not None:
        body["money"] = round(money, 2)
    try:
        req = urllib.request.Request(
            api + "/api/signals/status",
            data=json.dumps(body).encode(),
            headers={"Authorization": "Bearer " + key,
                     "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as r:
            ok = json.loads(r.read().decode()).get("ok", False)
        if ok:
            log(f"[signal] {symbol} marked {new_status}"
                + (f" ({pips:+.1f} pips)" if pips is not None else ""))
        return ok
    except Exception:  # noqa: BLE001
        return False


def copy_event(event: str, ticket, symbol: str, side: int,
               lots: float | None = None, price: float | None = None,
               sl: float | None = None, tp: float | None = None,
               log=print) -> bool:
    """Feed the SKLZ COPY queue: opens and closes, as they happen.

    Fire-and-forget like every publisher in this file — a copy-network
    hiccup must never touch the trading loop. Off-switch:
    SKLZ_COPY_PUBLISH=0. Harmless when nobody subscribes: events with no
    enabled slave configs fan out to zero rows.
    """
    if os.environ.get("SKLZ_COPY_PUBLISH", "1") == "0":
        return False
    api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
    key = os.environ.get("SIGNAL_WEBHOOK_KEY", "")
    if not (api and key and ticket):
        log(f"[copy] not sent — missing "
            f"{'API url ' if not api else ''}"
            f"{'key ' if not key else ''}{'ticket' if not ticket else ''}")
        return False
    # The master's broker dresses its symbols — EURJPY.., XAUUSD.., US30.cash
    # — and those names mean nothing to a follower on a different broker.
    # Publishing the raw name made every FX copy fail with "symbol not
    # found" and every subsequent close fail with "no position matched".
    # The queue carries the CANONICAL name; per-slave symbol_map handles
    # followers whose own broker needs a suffix.
    canon = symbol.split(".")[0].rstrip("_-# ").upper()
    if canon != symbol.upper():
        log(f"[copy] symbol {symbol} published as {canon} "
            f"(broker suffix stripped)")
    body = {"event": event, "master_ticket": int(ticket), "symbol": canon,
            "side": int(side)}
    if lots is not None:
        body["lots"] = round(float(lots), 2)
    if price is not None:
        body["price"] = float(price)
    if sl:
        body["sl"] = float(sl)
    if tp:
        body["tp"] = float(tp)
    # A CLOSE that fails to publish leaves every follower holding a
    # position the master has already exited — nobody managing it, no
    # alarm anywhere. That happened on a single API timeout. Opens are
    # cheap to lose (a missed entry); closes are not. So closes get
    # retried hard and, if they still fail, they scream.
    attempts = 4 if event == "close" else 2
    last = "no attempt"
    for i in range(attempts):
        try:
            req = urllib.request.Request(
                api + "/api/mt5copy/event",
                data=json.dumps(body).encode(),
                headers={"Authorization": "Bearer " + key,
                         "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=10) as r:
                d = json.loads(r.read().decode())
            q = d.get("queued", 0)
            # ALWAYS say what happened. An hour of debugging was lost to
            # this function's silence: zero followers, a dead API and a
            # wrong engine version all looked identical — like nothing.
            log(f"[copy] {event} {canon} -> {q} follower(s)"
                + ("" if q else " (no enabled subscriber configs)")
                + (f" (on attempt {i + 1})" if i else ""))
            return bool(d.get("ok"))
        except Exception as exc:  # noqa: BLE001
            last = type(exc).__name__
            if i + 1 < attempts:
                time.sleep(1.5 * (i + 1))
    if event == "close":
        log(f"[copy] *** CLOSE NOT PUBLISHED *** {canon} ticket {ticket} "
            f"after {attempts} attempts ({last}). FOLLOWERS MAY STILL BE "
            f"IN THIS TRADE — check their terminals and close manually.")
    else:
        log(f"[copy] publish FAILED: {last} — the trade is fine, the copy "
            f"network did not hear about this entry")
    return False
