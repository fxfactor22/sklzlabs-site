"""Push the day's reconciled trades into the SKLZ Journal.

Maps each journaled entry (with your note + market-state) to a journal trade
so your bot's demo trades land in the SAME honest journal as your manual
entries — one timeline, discretionary + automated.

Gated by BOT_INGEST_KEY; files under SKLZ_USER_ID (your account).
"""
from __future__ import annotations

import json
import os
import urllib.request


def _session_from_state(state: dict) -> str:
    return (state or {}).get("session", "")


def build_trades(closed: list[dict]) -> list[dict]:
    """EntryRecord dicts (reconciled, with outcomes) -> journal trade payloads."""
    out = []
    for e in closed:
        st = e.get("state") or {}
        out.append({
            "symbol": e.get("symbol", ""),
            "side": "buy" if e.get("side", 1) > 0 else "sell",
            "entry_price": e.get("entry_price"),
            "exit_price": e.get("exit_price"),
            "lots": e.get("lots"),
            "pnl": e.get("pnl"),
            "opened_at": e.get("ts"),
            "closed_at": e.get("exit_ts"),
            # the intent-capture that makes SKLZ's journal unique:
            "setup": e.get("strategy", ""),
            "reason": e.get("note", ""),
            "session": _session_from_state(st),
            "source": "bot" if e.get("source") == "auto" else "manual",
            "tags": [e.get("source", "")],
        })
    return out


def push(closed: list[dict], log=print, account_no: str = "", server: str = "") -> dict:
    api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
    key = os.environ.get("BOT_INGEST_KEY", "")
    uid = os.environ.get("SKLZ_USER_ID", "")
    if not (api and key and uid):
        log("[journal] skip — set SKLZ_API_URL, BOT_INGEST_KEY, SKLZ_USER_ID to push")
        return {"pushed": 0, "skipped": True}
    trades = build_trades([e for e in closed if e.get("outcome")])
    if not trades:
        log("[journal] nothing to push (no closed trades today)")
        return {"pushed": 0}
    body = json.dumps({"user_id": uid, "trades": trades, "account_no": account_no, "server": server}).encode()
    req = urllib.request.Request(
        api + "/api/journal/ingest", data=body,
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {key}"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            res = json.loads(r.read().decode())
        log(f"[journal] pushed {res.get('ingested', 0)} trades to your journal")
        return res
    except Exception as exc:  # noqa: BLE001
        # The server puts the REAL reason in the response body; logging only
        # "HTTP Error 500" turned a one-line diagnosis into an evening.
        detail = ""
        try:
            detail = exc.read().decode()[:400]      # type: ignore[attr-defined]
        except Exception:
            pass
        log(f"[journal] push failed: {type(exc).__name__}: {exc}"
            + (f" — server said: {detail}" if detail else ""))
        return {"pushed": 0, "error": str(exc), "detail": detail}
