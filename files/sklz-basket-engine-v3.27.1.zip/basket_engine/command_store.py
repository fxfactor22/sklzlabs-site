"""Durable record of what this Runner has already executed.

WHY THIS EXISTS
===============
Acknowledgement is not idempotency. Consider:

    API delivers command X
      → Runner executes it
        → broker fills, money moves
          → Runner POSTs the result
            → the POST is lost
              → API still shows X as un-acknowledged
                → API delivers X again

Without a durable local record, the Runner cannot tell that second
delivery apart from a new order, and the trade happens twice. An
in-memory set does not survive the restart that often caused the lost
acknowledgement in the first place, so the record has to reach disk
before the order reaches the broker.

THE RULE
========
    write intent  →  execute  →  write result

If the process dies between the first write and the second, the command
is marked `attempted` with no result. On the next delivery it is NOT
re-executed: an order whose outcome we cannot establish is reported back
as `unknown` for a human to reconcile. Re-running it might double a
filled position; refusing it might miss a trade. Between silently
doubling someone's exposure and visibly missing an entry, missing is the
one you can recover from.

SQLite is used because it is in the standard library, survives restarts,
and does not need another service on a Windows VPS.
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from typing import Any

_DEFAULT_PATH = os.environ.get("SKLZ_COMMAND_DB", "sklz_commands.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS executed_commands (
    command_id   TEXT PRIMARY KEY,
    command_type TEXT,
    state        TEXT NOT NULL,      -- attempted | done | refused
    result_json  TEXT,
    attempted_at REAL NOT NULL,
    finished_at  REAL
);
CREATE INDEX IF NOT EXISTS idx_cmd_state ON executed_commands (state);
CREATE TABLE IF NOT EXISTS runner_identity (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    created_at REAL NOT NULL
);
"""


class CommandStore:
    """Small durable key-value log of command outcomes."""

    def __init__(self, path: str = "") -> None:
        self.path = path or _DEFAULT_PATH
        self._conn = sqlite3.connect(self.path, timeout=10,
                                     check_same_thread=False)
        self._conn.executescript(_SCHEMA)
        # Durability matters more than speed here: a few commands a minute,
        # but each one can move money.
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.commit()

    def installation_id(self) -> str:
        """A durable identifier for THIS Runner installation.

        Not a provider, not a user, not an email, not the bot_name — those
        are all shared or reassignable. This exists so the server can tell
        two Runners apart when they share a bot_name, which is the
        difference between a lease being safely reclaimed and a command
        being executed twice on two machines.

        Generated once, stored beside the command log, survives restarts.
        """
        cur = self._conn.execute(
            "SELECT value FROM runner_identity WHERE key='installation_id'")
        row = cur.fetchone()
        if row and row[0]:
            return row[0]
        import uuid
        rid = "rn_" + uuid.uuid4().hex[:20]
        self._conn.execute(
            "INSERT OR REPLACE INTO runner_identity (key, value, created_at) "
            "VALUES ('installation_id', ?, ?)", (rid, time.time()))
        self._conn.commit()
        return rid

    # ---- the three writes ----
    def begin(self, command_id: str, command_type: str = "") -> bool:
        """Record the INTENT to execute, before touching the broker.

        Returns True if this Runner may proceed. False means the command
        is already known — it was executed, is being executed, or was
        refused — and must not be sent to the broker again.
        """
        try:
            self._conn.execute(
                "INSERT INTO executed_commands "
                "(command_id, command_type, state, attempted_at) "
                "VALUES (?, ?, 'attempted', ?)",
                (str(command_id), command_type, time.time()))
            self._conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False          # already present: do not execute again

    def finish(self, command_id: str, result: dict[str, Any]) -> None:
        """Record the outcome. Safe to call more than once."""
        self._conn.execute(
            "UPDATE executed_commands SET state='done', result_json=?, "
            "finished_at=? WHERE command_id=?",
            (json.dumps(result), time.time(), str(command_id)))
        self._conn.commit()

    def refuse(self, command_id: str, reason: str,
               command_type: str = "") -> None:
        """Record a command we deliberately did not execute (expired, etc)."""
        self._conn.execute(
            "INSERT OR REPLACE INTO executed_commands "
            "(command_id, command_type, state, result_json, attempted_at, "
            " finished_at) VALUES (?, ?, 'refused', ?, ?, ?)",
            (str(command_id), command_type,
             json.dumps({"ok": False, "refused": reason}),
             time.time(), time.time()))
        self._conn.commit()

    # ---- reads ----
    def known(self, command_id: str) -> bool:
        cur = self._conn.execute(
            "SELECT 1 FROM executed_commands WHERE command_id=?",
            (str(command_id),))
        return cur.fetchone() is not None

    def result_for(self, command_id: str) -> dict[str, Any] | None:
        """The stored result, so a lost acknowledgement can be re-sent."""
        cur = self._conn.execute(
            "SELECT state, result_json FROM executed_commands "
            "WHERE command_id=?", (str(command_id),))
        row = cur.fetchone()
        if not row:
            return None
        state, blob = row
        if state == "attempted":
            # Executed or not — we cannot tell. Never re-run it; say so.
            return {"ok": False, "state": "unknown",
                    "error": "execution was interrupted before the result "
                             "was recorded; this command will not be "
                             "retried automatically"}
        try:
            return json.loads(blob) if blob else None
        except (TypeError, ValueError):
            return None

    def pending_results(self, limit: int = 20) -> list[tuple[str, dict]]:
        """Finished commands whose result may never have reached the API.

        The Runner re-posts these on reconnect, which is what makes a lost
        acknowledgement a delay rather than a permanent gap.
        """
        cur = self._conn.execute(
            "SELECT command_id, result_json FROM executed_commands "
            "WHERE state='done' AND result_json IS NOT NULL "
            "ORDER BY finished_at DESC LIMIT ?", (limit,))
        out = []
        for cid, blob in cur.fetchall():
            try:
                out.append((cid, json.loads(blob)))
            except (TypeError, ValueError):
                continue
        return out

    def mark_reported(self, command_id: str) -> None:
        """The API has the result; stop re-sending it."""
        self._conn.execute(
            "UPDATE executed_commands SET state='done', "
            "result_json=json_patch(COALESCE(result_json,'{}'), "
            "'{\"reported\":true}') WHERE command_id=?", (str(command_id),))
        self._conn.commit()

    def prune(self, older_than_days: int = 30) -> int:
        cutoff = time.time() - older_than_days * 86400
        cur = self._conn.execute(
            "DELETE FROM executed_commands WHERE attempted_at < ?", (cutoff,))
        self._conn.commit()
        return cur.rowcount or 0

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:  # noqa: BLE001
            pass
