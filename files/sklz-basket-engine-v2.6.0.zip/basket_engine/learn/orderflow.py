"""SKLZ — order flow analysis.

WHAT THIS IS, PRECISELY
=======================
True cluster delta requires knowing whether each executed contract was
buyer-aggressed or seller-aggressed. That comes from a central exchange feed.
Forex has no central exchange, so MT5 gives us neither traded size nor an
aggressor flag.

What we can do is INFER aggression from raw ticks: a tick that prints at or
above the prevailing ask is treated as buyer-initiated, at or below the bid as
seller-initiated. This is the same approximation retail footprint tools use.
It is directionally informative and genuinely useful for spotting absorption.
It is not measured delta, and nothing here pretends otherwise.

Every result carries a `quality` field saying which inputs were real, so a
signal built on inference is never mistaken for one built on exchange data.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class DeltaResult:
    buy_volume: float = 0.0
    sell_volume: float = 0.0
    delta: float = 0.0
    cumulative: list[float] = field(default_factory=list)
    ticks_seen: int = 0
    quality: str = "none"          # none | inferred | measured
    note: str = ""


def classify_ticks(ticks: list[dict]) -> DeltaResult:
    """Split ticks into buyer- and seller-initiated.

    A print at the ask means someone crossed the spread to buy; at the bid,
    to sell. Ticks in between are unclassifiable and are ignored rather than
    split arbitrarily — guessing them would manufacture delta that is not there.
    """
    res = DeltaResult()
    if not ticks:
        res.note = "no ticks available"
        return res

    buy = sell = 0.0
    cum, running = [], 0.0
    measured = False

    for t in ticks:
        bid, ask = t.get("bid", 0), t.get("ask", 0)
        last, vol = t.get("last", 0), t.get("volume", 0) or 1.0
        if vol > 1.0:
            measured = True          # broker reported real size
        price = last if last else (ask if ask else bid)
        if not price or not bid or not ask:
            continue
        if price >= ask:
            buy += vol
            running += vol
        elif price <= bid:
            sell += vol
            running -= vol
        else:
            continue                 # inside the spread: unknowable
        cum.append(running)

    res.buy_volume = round(buy, 2)
    res.sell_volume = round(sell, 2)
    res.delta = round(buy - sell, 2)
    res.cumulative = cum[-500:]
    res.ticks_seen = len(ticks)
    res.quality = "measured" if measured else "inferred"
    res.note = ("volume reported by the broker" if measured else
                "delta inferred from tick side — not exchange data")
    return res


def absorption(delta: DeltaResult, price_move_pips: float,
               threshold_delta: float = 0.0) -> dict:
    """Detect the case where aggression is heavy but price will not move.

    Strong positive delta with price going nowhere means someone large is
    selling into every buy — the breakout is being absorbed and is likely to
    fail. The mirror applies for negative delta.
    """
    if delta.quality == "none" or not delta.cumulative:
        return {"absorbed": False, "side": None,
                "reason": "no order flow data"}

    d = delta.delta
    total = delta.buy_volume + delta.sell_volume
    if total <= 0:
        return {"absorbed": False, "side": None, "reason": "no classified flow"}

    imbalance = d / total                      # -1 .. +1
    thr = threshold_delta or 0.25
    moved = abs(price_move_pips)

    # heavy one-sided aggression, price barely responding
    if imbalance > thr and moved < 3:
        return {"absorbed": True, "side": "seller",
                "imbalance": round(imbalance, 3),
                "reason": (f"buyers aggressive ({imbalance:+.0%} imbalance) but "
                           f"price moved only {moved:.0f} pips — sellers absorbing")}
    if imbalance < -thr and moved < 3:
        return {"absorbed": True, "side": "buyer",
                "imbalance": round(imbalance, 3),
                "reason": (f"sellers aggressive ({imbalance:+.0%} imbalance) but "
                           f"price held within {moved:.0f} pips — buyers absorbing")}

    return {"absorbed": False, "side": None,
            "imbalance": round(imbalance, 3),
            "reason": "no absorption signature"}


def delta_divergence(closes: list[float], cumulative: list[float],
                     side: int) -> dict:
    """Price making a new extreme while cumulative delta fails to confirm.

    A higher high on weakening delta means the move is being driven by fewer
    aggressive buyers than the last push — institutional distribution rather
    than accumulation.
    """
    if len(closes) < 20 or len(cumulative) < 20:
        return {"divergent": False, "reason": "not enough data"}

    n = min(len(closes), len(cumulative))
    c, d = closes[-n:], cumulative[-n:]
    half = n // 2
    prev_c, last_c = c[:half], c[half:]
    prev_d, last_d = d[:half], d[half:]

    if side > 0:
        made_hh = max(last_c) > max(prev_c)
        delta_weaker = max(last_d) < max(prev_d)
        if made_hh and delta_weaker:
            return {"divergent": True, "kind": "bearish",
                    "reason": ("price made a higher high while cumulative delta "
                               "weakened — buying pressure is fading")}
    else:
        made_ll = min(last_c) < min(prev_c)
        delta_stronger = min(last_d) > min(prev_d)
        if made_ll and delta_stronger:
            return {"divergent": True, "kind": "bullish",
                    "reason": ("price made a lower low while cumulative delta "
                               "strengthened — selling pressure is fading")}

    return {"divergent": False, "reason": "delta confirms price"}


def read_depth(book: list[dict], side: int) -> dict:
    """Summarise the order book, where one exists.

    NOT detectable from retail depth, and deliberately not claimed:
      - iceberg orders (hidden by definition)
      - spoofing (needs per-order lifecycle, not aggregated snapshots)
    What is readable: resting size on each side and how lopsided it is.
    """
    if not book:
        return {"available": False,
                "reason": ("no order book from this broker — normal for retail "
                           "forex, which has no central exchange")}

    bids = sum(b["volume"] for b in book if b["type"] in (1, 2))
    asks = sum(b["volume"] for b in book if b["type"] in (0, 3))
    total = bids + asks
    if total <= 0:
        return {"available": False, "reason": "empty book"}

    lean = (bids - asks) / total
    supportive = (lean > 0.15) if side > 0 else (lean < -0.15)
    return {"available": True, "bid_volume": round(bids, 2),
            "ask_volume": round(asks, 2), "lean": round(lean, 3),
            "supportive": supportive,
            "reason": (f"book leans {'bid' if lean > 0 else 'ask'} "
                       f"{abs(lean):.0%} — {'supports' if supportive else 'against'} "
                       f"this direction")}


# ── ClusterDelta bridge ─────────────────────────────────────────────
# SKLZ_DeltaBridge.mq5 reads ClusterDelta's indicator buffers and writes them
# to MQL5/Files/sklz_delta_<SYMBOL>.csv. That is REAL bid/ask volume from the
# ClusterDelta feed, not tick inference — so when this file is present the
# delta quality is "measured" and the confidence score can rely on it.

import csv
import os
import time as _time


def _terminal_files_dir(io=None) -> str:
    """Where MT5 keeps MQL5/Files for this terminal."""
    env = os.environ.get("SKLZ_MT5_FILES_DIR", "")
    if env:
        return env
    try:
        if io is not None and hasattr(io, "mt5"):
            info = io.mt5.terminal_info()
            base = getattr(info, "data_path", "")
            if base:
                return os.path.join(base, "MQL5", "Files")
    except Exception:
        pass
    return ""


def read_bridge(symbol: str, io=None, max_age_sec: int = 180) -> DeltaResult:
    """Load ClusterDelta volumes exported by the bridge EA.

    Returns quality="none" if the file is missing or stale — a stale file is
    worse than none, because it would score a fresh breakout on old flow.
    """
    res = DeltaResult()
    d = _terminal_files_dir(io)
    if not d:
        res.note = "MT5 files directory unknown"
        return res

    # the EA names files by the broker symbol, e.g. sklz_delta_AUDUSD...csv
    candidates = [symbol, symbol.rstrip("."), symbol.split(".")[0]]
    path = ""
    for name in candidates:
        p = os.path.join(d, f"sklz_delta_{name}.csv")
        if os.path.exists(p):
            path = p
            break
    if not path:
        res.note = f"no bridge file for {symbol} — is SKLZ_DeltaBridge attached?"
        return res

    age = _time.time() - os.path.getmtime(path)
    if age > max_age_sec:
        res.note = (f"bridge file is {age/60:.0f} min old — the EA may have "
                    f"stopped; ignoring rather than scoring stale flow")
        return res

    try:
        with open(path, newline="", encoding="ascii", errors="ignore") as f:
            rows = list(csv.DictReader(f))
    except Exception as exc:  # noqa: BLE001
        res.note = f"could not read bridge file: {exc}"
        return res
    if not rows:
        res.note = "bridge file is empty"
        return res

    buy = sell = 0.0
    cum, running = [], 0.0
    used = 0
    for r in rows[-200:]:
        try:
            a = float(r.get("ask_volume") or 0)
            b = float(r.get("bid_volume") or 0)
        except (TypeError, ValueError):
            continue
        if a == 0 and b == 0:
            continue
        buy += a
        sell += b
        running += (a - b)
        cum.append(running)
        used += 1

    if not used:
        res.note = ("bridge file has no non-zero volumes — the buffer indices "
                    "in the EA are probably wrong; check DemoVolumes.mq5")
        return res

    res.buy_volume = round(buy, 2)
    res.sell_volume = round(sell, 2)
    res.delta = round(buy - sell, 2)
    res.cumulative = cum[-500:]
    res.ticks_seen = used
    res.quality = "measured"
    res.note = f"ClusterDelta volumes via bridge ({used} bars, {age:.0f}s old)"
    return res
