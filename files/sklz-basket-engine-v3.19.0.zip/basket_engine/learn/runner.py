"""Learning runner — three entry streams + end-of-day review, interactive.

Commands while it runs (type + Enter):
  buy EURUSD your reason here     forced BUY, note = "your reason here"
  sell GBPUSD london sweep        forced SELL with your note
  scan                            run the famous-strategy scanners once now
  auto on / auto off              enable/disable automatic scanner entries
  review                          run the end-of-day AI review right now
  status                          positions + today's tally
  quit                            stop the runner (open trades stay in MT5)

Everything is journaled. The review PROPOSES; it never changes parameters.
"""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.request
from datetime import datetime, timezone

from basket_engine.learn.capture import Journal
from basket_engine.learn.entries import EntryController
from basket_engine.learn.review import summarize, ai_review
from basket_engine.learn.scanners import SCANNERS
from basket_engine.learn import journal_push
from basket_engine.learn import signal_publish
from basket_engine.learn import quality
from basket_engine.learn import trailing


class LearningRunner:
    def __init__(self, io, bot_label: str = "", tf_min=60, lookback=24, risk_pct=0.5,
                 auto=False, symbols=None, log=print) -> None:
        path = os.path.join(os.path.dirname(__file__), "..", "..",
                            "learning_journal.jsonl")
        self.journal = Journal(path)
        self.ec = EntryController(io, self.journal, tf_min, lookback, risk_pct, log)
        self.io = io
        self.tf_min = tf_min
        self.lookback = lookback
        self.auto = auto
        self._sprd: dict = {}      # per-symbol rolling spread baseline
        self._shadows: list = []   # vetoed model setups being followed
        self.prop = None           # built on first use, once log exists
        self._shadow_tally: dict = {}   # veto -> [would_have_won, would_have_lost]
        # symbols to scan — override with SKLZ_SYMBOLS="EURUSD,GBPUSD,XAUUSD,..."
        # unavailable symbols are skipped automatically (io.has_symbol check).
        env_syms = os.environ.get("SKLZ_SYMBOLS", "").strip()
        if symbols:
            self.symbols = symbols
        elif env_syms:
            self.symbols = [s.strip().upper() for s in env_syms.split(",") if s.strip()]
        else:
            self.symbols = [
                # FX majors
                "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD", "NZDUSD",
                # FX crosses
                "EURJPY", "GBPJPY", "EURGBP", "AUDJPY",
                # metals
                "XAUUSD", "XAGUSD",
                # indices
                "US30", "NAS100", "SPX500", "GER40",
                # energy + crypto
                "USOIL", "UKOIL", "BTCUSD", "ETHUSD",
            ]
        self.log = log
        # when each background loop last completed a pass, so the heartbeat
        # can say what is actually running rather than just "alive"
        import time as _time
        self._started_at = _time.time()
        self._last_scan_at = None
        self._last_poll_at = None
        self._last_trail_at = None
        self._scans_done = 0
        self._auto_seen: set = set()
        # --- v1.4.0 remote control (dashboard START/PAUSE) ---
        self.entries_blocked = False
        self._remote_state = None   # None -> announce state on first poll
        # the poller thread reads this, so it must be set before the thread
        # starts — otherwise it falls back to the wrong bot name and silently
        # polls a queue nobody is writing to.
        self.bot_label = bot_label or os.environ.get("SKLZ_BOT_NAME", "")
        t = threading.Thread(target=self._command_loop, daemon=True)
        t.start()
        hb = threading.Thread(target=self._heartbeat_loop, daemon=True)
        hb.start()
        self._journaled_positions: set = set()
        from datetime import datetime as _dt, timezone as _tz
        self._journal_start = _dt.now(_tz.utc)   # only journal trades closed after this
        self._acct_no = ""
        self._server = ""
        try:
            info = self.io.mt5.account_info() if hasattr(self.io, "mt5") else None
            if info:
                self._acct_no = str(info.login)
                self._server = info.server
        except Exception:
            pass
        jt = threading.Thread(target=self._auto_journal_loop, daemon=True)
        jt.start()
        tt = threading.Thread(target=self._trail_loop, daemon=True)
        tt.start()
        st = threading.Thread(target=self._signal_track_loop, daemon=True)
        st.start()

    # ---- v1.4.0 remote control: poll dashboard command every 30s ----
    def _command_loop(self):
        import time as _time
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("SKLZ_BOT_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        # must match the name telemetry registers under, or dashboard
        # commands and orders will never reach this runner
        bot = getattr(self, "bot_label", "") or os.environ.get("SKLZ_BOT_NAME", "")
        if not bot:
            self.log("[remote] no bot label set — dashboard orders cannot be "
                     "delivered. This is a bug; report it.")
            return
        if not (api and key):
            return                      # telemetry env not set; run local-only
        try:
            poll_secs = max(2, int(os.environ.get("SKLZ_POLL_SECONDS", "5")))
        except ValueError:
            poll_secs = 2
        consecutive_errors = 0
        # one opener reused for every poll — avoids churning through Windows
        # ephemeral ports, which starves the telemetry thread of sockets
        opener = urllib.request.build_opener()
        self.log(f"[remote] command poll every {poll_secs}s")
        while True:
            try:
                from urllib.parse import quote
                req = urllib.request.Request(
                    f"{api}/api/bot/command?bot_name={quote(bot)}",
                    headers={"Authorization": f"Bearer {key}"})
                with opener.open(req, timeout=30) as resp:
                    r_body = resp.read().decode()
                cmd = (json.loads(r_body).get("command") or "run")
                self._last_poll_at = _time.time()
                # execute any queued manual orders from the admin dashboard
                for o in (json.loads(r_body).get("orders") or []):
                    try:
                        if self.entries_blocked:
                            self.log("[REMOTE] order ignored — paused"); continue
                        side = +1 if o.get("side") == "buy" else -1
                        self.log(f"[REMOTE] dashboard order: {o.get('side','?').upper()} "
                                 f"{o.get('symbol','?')} — {o.get('note','')}")
                        rec = self.ec.forced_custom(
                            o.get("symbol", ""), side,
                            "[dashboard] " + (o.get("note") or "manual"),
                            lots=float(o.get("lots") or 0),
                            sl=float(o.get("sl") or 0),
                            tp=float(o.get("tp") or 0))
                        # only publish if the order actually filled — a signal
                        # for a trade that does not exist is worse than silence
                        if not rec:
                            self.log("[signal] not published — the entry did not fill")
                            continue
                        try:
                            signal_publish.publish(
                                self.io, o.get("symbol", ""), side,
                                "manual entry", (o.get("note") or "trader entry"),
                                self.tf_min, log=self.log, force=True)
                        except Exception as exc:
                            self.log(f"[signal] error: {exc}")
                    except Exception as exc:
                        self.log(f"[REMOTE] order failed: {exc}")
                if cmd != self._remote_state:
                    self._remote_state = cmd
                    if cmd == "pause":
                        self.auto = False
                        self.entries_blocked = True
                        self.log("[REMOTE] *** PAUSED from dashboard *** "
                                 "auto-trading OFF, no new entries; positions still managed.")
                    else:
                        self.auto = True
                        self.entries_blocked = False
                        self.log("[REMOTE] *** RUNNING from dashboard *** "
                                 "auto-trading ON - scanners may enter. "
                                 "(PAUSE on the dashboard to stop)")
            except Exception:
                consecutive_errors += 1
                # back off on repeated failures so a dead API does not hammer it
                time.sleep(min(30, 3 * consecutive_errors))
                continue
            consecutive_errors = 0
            # fast poll: dashboard orders and START/PAUSE feel immediate.
            # SKLZ_POLL_SECONDS tunes it (default 2s).
            time.sleep(poll_secs)

    # ---- heartbeat: prove the process is alive when nothing is happening ----
    def _heartbeat_loop(self):
        """Print a line every few minutes even when there is nothing to report.

        A trading console that goes quiet is ambiguous — no setups looks the
        same as a frozen process, and the difference matters at 3am with a
        live position open. This makes silence impossible: if the heartbeat
        stops, something is wrong.
        """
        import time as _time
        try:
            every = max(60, int(os.environ.get("SKLZ_HEARTBEAT_SECONDS", "300")))
        except (TypeError, ValueError):
            every = 300

        while True:
            _time.sleep(every)
            try:
                now = _time.time()
                up = now - self._started_at
                hrs, rem = divmod(int(up), 3600)
                mins = rem // 60

                def ago(t):
                    if not t:
                        return "never"
                    s = int(now - t)
                    return f"{s}s ago" if s < 90 else f"{s // 60}m ago"

                try:
                    pos = len(self.io.my_positions())
                except Exception:
                    pos = "?"

                state = "paused" if getattr(self, "entries_blocked", False) else "running"
                self.log(f"[alive] up {hrs}h{mins:02d}m · {state} · "
                         f"{pos} open · scans {self._scans_done} "
                         f"(last {ago(self._last_scan_at)}) · "
                         f"commands {ago(self._last_poll_at)}")
            except Exception:
                # a heartbeat that can crash the process defeats its purpose
                pass

    # ---- research: record every completed trade ----
    def _push_observation(self, rec, exit_price: float, pnl: float,
                          exit_reason: str = "") -> None:
        """Write one finished trade to the research store.

        Failures here are logged and swallowed — losing an observation is bad,
        but blocking the trading loop over it would be worse.
        """
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("INTERNAL_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        if not (api and key):
            return
        ctx = getattr(rec, "context", None) or {}
        if not ctx:
            return
        try:
            from basket_engine.learn import trade_context as TC
            exit_ctx = TC.capture_exit(ctx, exit_price, pnl, exit_reason, self.io)
            failure = TC.classify_failure(ctx, exit_ctx)
            body = {**ctx, **exit_ctx,
                    "failure_category": failure.get("category"),
                    "failure_reasons": failure.get("reasons") or []}
            if failure.get("reasons"):
                self.log(f"[research] {ctx.get('symbol')} "
                         f"{exit_ctx.get('outcome')}: {failure['reasons'][0][:90]}")
            import json as _json, urllib.request as _u
            req = _u.Request(api + "/api/research/observation",
                             data=_json.dumps(body, default=str).encode(),
                             headers={"Authorization": "Bearer " + key,
                                      "Content-Type": "application/json"})
            _u.urlopen(req, timeout=20)
        except Exception as exc:  # noqa: BLE001
            self.log(f"[research] could not store observation: {type(exc).__name__}")

    # ---- institutional order-flow confirmation ----
    def _institutional(self, symbol: str, side: int):
        """Gather what the broker actually provides, then score the breakout.

        Missing inputs are passed through as absent rather than faked — the
        scorer normalises over what it can genuinely see.
        """
        from basket_engine.learn import institutional as INST
        from basket_engine.learn.trailing import pip_size

        spec = self.io.spec(symbol)
        pip = pip_size(symbol, int(spec.get("digits") or 5))

        m15 = self.io.bars(symbol, 15, 150)
        h1 = self.io.bars(symbol, 60, 220)
        d1 = self.io.bars(symbol, 1440, 25)

        # real ClusterDelta volumes if the bridge EA is running, otherwise
        # fall back to inferring delta from tick side
        bridge = None
        try:
            from basket_engine.learn import orderflow as _OF
            b = _OF.read_bridge(symbol, self.io)
            if b.quality == "measured":
                bridge = b
                self.log(f"[inst] delta: {b.note}")
        except Exception:
            pass

        ticks = []
        if bridge is None:
            try:
                ticks = self.io.ticks(symbol, minutes=20)
            except Exception:
                pass
        book = []
        try:
            book = self.io.depth(symbol)
        except Exception:
            pass

        # peer moves for the basket correlation check
        peers = {}
        for peer in INST.CORRELATION.get(symbol.upper()[:6], {}):
            try:
                c = self.io.closes(peer, 15, 8)
                if len(c) >= 2 and c[0]:
                    peers[peer] = (c[-1] - c[0]) / c[0] * 100
            except Exception:
                continue

        return INST.assess(side, symbol, pip, m15, h1, d1,
                           ticks=ticks, book=book, peer_moves=peers,
                           delta_override=bridge)

    # ---- signal outcome tracking: follow every published call ----
    def _signal_track_loop(self):
        import time as _t, json as _json, urllib.request as _u
        _t.sleep(25)
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("INTERNAL_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        if not (api and key):
            return
        try:
            every = max(10, int(os.environ.get("SKLZ_SIGNAL_TRACK_SECONDS", "20")))
        except ValueError:
            every = 20
        while True:
            try:
                req = _u.Request(api + "/api/signals/open",
                                 headers={"Authorization": "Bearer " + key})
                with _u.urlopen(req, timeout=25) as resp:
                    open_sigs = (_json.loads(resp.read().decode()) or {}).get("signals", [])
                for s in open_sigs:
                    sym = s.get("symbol")
                    if not sym:
                        continue
                    try:
                        px = self.io.price(sym, 1)
                    except Exception:
                        continue
                    body = {"signal_id": s.get("id"), "price": px}
                    try:
                        rq = _u.Request(api + "/api/signals/track",
                                        data=_json.dumps(body).encode(),
                                        headers={"Authorization": "Bearer " + key,
                                                 "Content-Type": "application/json"})
                        _u.urlopen(rq, timeout=20)
                    except Exception:
                        pass
            except Exception as exc:
                self.log(f"[sigtrack] {type(exc).__name__}")
            _t.sleep(every)

    # ---- trailing stops: protect and trail every open position ----
    def _trail_loop(self):
        import time as _t
        _t.sleep(15)
        every = 5
        try:
            every = max(2, int(os.environ.get("SKLZ_TRAIL_SECONDS", "5")))
        except ValueError:
            pass
        while True:
            try:
                trailing.manage(self.io, log=self.log,
                                on_update=self._report_trail)
            except Exception as exc:
                self.log(f"[trail] {type(exc).__name__}: {exc}")
            _t.sleep(every)

    def _report_trail(self, ev: dict) -> None:
        """Publish a stop move to the update board + Telegram."""
        import json as _json, urllib.request as _u
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("INTERNAL_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        if not (api and key):
            return
        secured = "secured" in ev.get("reason", "")

        # the published signal follows the position: once the stop is in
        # profit, subscribers see "secured" on the site next to their entry
        if secured:
            try:
                side_n = 1 if str(ev.get("side", "")).lower() in ("buy", "1") else -1
                signal_publish.update_status(
                    ev["symbol"], side_n, "secured",
                    pips=ev.get("locked_pips"), log=self.log)
            except Exception:
                pass

        body = {
            "kind": "secured" if secured else "trail",
            "symbol": ev["symbol"], "side": ev["side"],
            "ticket": str(ev.get("ticket", "")),
            "headline": (f"{ev['symbol']} secured — this trade can no longer lose"
                         if secured else f"Stop trailed on {ev['symbol']}"),
            "detail": ("Stop moved into profit. Worst case on this position is "
                       "now a win." if secured else
                       "Following price up while the move continues."),
            "old_sl": ev.get("old_sl") or None,
            "new_sl": ev.get("new_sl"),
            "locked_pips": ev.get("locked_pips"),
            "price": ev.get("price"),
            "broadcast": True,
        }
        try:
            req = _u.Request(api + "/api/updates/bot",
                             data=_json.dumps(body).encode(),
                             headers={"Authorization": "Bearer " + key,
                                      "Content-Type": "application/json"})
            _u.urlopen(req, timeout=20)
        except Exception as exc:
            self.log(f"[trail] could not publish update: {type(exc).__name__}")

    # ---- live auto-journal: push ANY closed trade on the account ----
    def _auto_journal_loop(self):
        import time as _t
        _t.sleep(20)                       # let MT5 settle after startup
        while True:
            try:
                self._push_closed_trades()
            except Exception as exc:
                self.log(f"[auto-journal] {type(exc).__name__}: {exc}")
            _t.sleep(int(os.environ.get("SKLZ_JOURNAL_SECONDS", "45")))

    def _classify_source(self, comment: str) -> str:
        c = (comment or "").lower()
        if "dashboard" in c:
            return "dashboard"
        if "sklz-forced" in c or "sklz-auto" in c or "sklz-" in c:
            return "bot"
        return "manual"                    # opened directly in MT5

    def _push_closed_trades(self):
        if not hasattr(self.io, "closed_trades_since"):
            return
        trades = self.io.closed_trades_since(minutes=1440)
        # dedup is handled permanently server-side by position_id, so we simply
        # push everything in the window; the API rejects anything already journaled.
        fresh = [t for t in trades
                 if t["position_id"] not in self._journaled_positions]
        if not fresh:
            return
        import json as _json, os as _os, urllib.request as _u
        api = _os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = _os.environ.get("BOT_INGEST_KEY", "") or _os.environ.get("SKLZ_BOT_KEY", "")
        uid = _os.environ.get("SKLZ_USER_ID", "")
        if not (api and key and uid):
            return
        payload = [{
            "symbol": t["symbol"],
            "side": "buy" if t["side"] > 0 else "sell",
            "entry_price": t["entry_price"], "exit_price": t["exit_price"],
            "lots": t["lots"], "pnl": t["pnl"],
            "opened_at": t["opened_at"], "closed_at": t["closed_at"],
            "setup": self._classify_source(t.get("comment")),
            "reason": t.get("comment") or "",
            "source": self._classify_source(t.get("comment")),
            "tags": [self._classify_source(t.get("comment")), "auto-journal"],
            "position_id": str(t.get("position_id", "")),
        } for t in fresh]
        try:
            body = _json.dumps({"user_id": uid, "trades": payload, "account_no": self._acct_no, "server": self._server}).encode()
            req = _u.Request(api + "/api/journal/ingest", data=body,
                             headers={"Content-Type": "application/json",
                                      "Authorization": "Bearer " + key})
            with _u.urlopen(req, timeout=30) as resp:
                res = _json.loads(resp.read().decode())
            for t in fresh:
                self._journaled_positions.add(t["position_id"])
            self.log(f"[auto-journal] pushed {res.get('ingested', len(fresh))} "
                     f"closed trade(s) to your journal")
        except Exception as exc:
            self.log(f"[auto-journal] push failed: {type(exc).__name__}: {exc}")

    # ---- forced ----
    def cmd_buy(self, parts):  self._forced(+1, parts)
    def cmd_sell(self, parts): self._forced(-1, parts)
    def _forced(self, side, parts):
        if len(parts) < 2:
            self.log("usage: buy SYMBOL your reason for the entry"); return
        if self.entries_blocked:
            self.log("Entries are PAUSED from the dashboard. Press START there to resume.")
            return
        symbol = parts[1].upper()
        note = " ".join(parts[2:]) or "manual"
        rec = self.ec.forced_entry(symbol, side, note)
        if not rec:
            self.log("[signal] not published — the entry did not fill")
            return
        try:
            signal_publish.publish(self.io, symbol, side, "manual entry", note,
                                   self.tf_min, log=self.log, force=True)
        except Exception as exc:
            self.log(f"[signal] error: {exc}")



    def _resolve_shadows(self) -> None:
        """Follow each vetoed setup to its stop (-1R) or 2R target.

        Deliberately coarse: current price only, first-touch wins, expiry
        after 12 hours. The question is not exact P&L — it is whether a veto
        class is blocking winners or losers, and at that granularity this is
        enough.
        """
        if not self._shadows:
            return
        import time as _t
        keep = []
        for s in self._shadows:
            try:
                px = self.io.price(s["sym"], -s["side"])   # exit side price
            except Exception:
                px = 0.0
            if not px:
                keep.append(s)
                continue
            won = (px >= s["target"] if s["side"] > 0 else px <= s["target"])
            lost = (px <= s["stop"] if s["side"] > 0 else px >= s["stop"])
            expired = _t.time() - s["t"] > 12 * 3600
            if won or lost or expired:
                key = s["veto"]
                w, l = self._shadow_tally.get(key, [0, 0])
                if won:
                    w += 1
                elif lost:
                    l += 1
                # expiry with neither touched counts as neither
                self._shadow_tally[key] = [w, l]
                verdict = ("would have hit 2R" if won
                           else "would have hit the stop" if lost
                           else "expired unresolved")
                self.log(f"[shadow] {s['sym']} model_{s['model']} vetoed by "
                         f"{key} — {verdict}. Tally for this veto: "
                         f"{self._shadow_tally[key][0]}W blocked / "
                         f"{self._shadow_tally[key][1]}L saved")
            else:
                keep.append(s)
        self._shadows = keep

    # ---- structured entry models ----
    def _run_models(self, sym: str):
        """Model A (M15 break-retest) and Model B (HTF block, fib 50).

        Both need several timeframes at once, so this pulls them together and
        hands them over. Failures are swallowed deliberately: a model that
        cannot get its data should not stop the scanners that can.
        """
        if os.environ.get("SKLZ_MODELS", "1") == "0":
            return None
        try:
            from basket_engine.learn import models as MD
            from basket_engine.learn.trailing import pip_size

            def bars(tf, n):
                rows = self.io.bars(sym, tf, n) or []
                return [{"open": r["open"], "high": r["high"],
                         "low": r["low"], "close": r["close"],
                         "volume": r.get("tick_volume", 0)} for r in rows]

            m5 = bars(5, 80)
            m15 = bars(15, 60)
            h1 = bars(60, 40)
            h4 = bars(240, 30)
            if len(m5) < 40 or len(m15) < 20:
                return None

            pip = pip_size(sym, self.io.spec(sym).get("digits"))
            s = MD.evaluate(m15, m5, h1, h4, pip)

            if s.ok:
                self.log(f"[model] {sym} {s.model} — "
                         f"{'BUY' if s.side > 0 else 'SELL'} @ {s.entry:.5f}")
                for r in s.reasons:
                    self.log(f"[model]   + {r}")
            elif s.blockers and os.environ.get("SKLZ_MODEL_VERBOSE", "0") == "1":
                self.log(f"[model] {sym} {s.model} not ready — {s.blockers[0]}")
            return s
        except Exception as exc:  # noqa: BLE001
            if os.environ.get("SKLZ_MODEL_VERBOSE", "0") == "1":
                self.log(f"[model] {sym} error: {type(exc).__name__}: {exc}")
            return None

    # ---- scanners ----
    def scan_once(self) -> int:
        import time as _t
        self._scans_done += 1
        self._last_scan_at = _t.time()
        n = 0
        for sym in self.symbols:
            if not self.io.has_symbol(sym):
                continue
            # market-open guard: never scan on frozen weekend/closed data
            if hasattr(self.io, "market_live") and not self.io.market_live(sym):
                continue
            # gather EVERY scanner hit for this symbol first, then judge quality
            self._resolve_shadows()

            # the prop circuit breaker outranks every other opinion in this
            # loop — a perfect setup on a breached account is worth nothing
            if self.prop is None:
                from basket_engine.learn.prop_guard import PropGuard
                self.prop = PropGuard(log=self.log)
            _pg = self.prop.check(self.io)
            if not _pg["entries_ok"]:
                if _pg["reason"] not in ("soft stop active",
                                         "halted until the next trading day"):
                    self.log(f"[prop] entries blocked — {_pg['reason']}")
                hits = []
                continue

            hits = []
            for name, fn in SCANNERS.items():
                sig = fn(self.io, sym, self.tf_min, self.lookback)
                if sig:
                    hits.append((name, sig[0], sig[1]))

            # The two structured models run alongside the scanners rather than
            # replacing them. They are stricter — a specific sequence must
            # occur — so when one fires it carries more information than a
            # scanner hit, and it is added as its own vote.
            model_setup = self._run_models(sym)
            if model_setup and model_setup.ok:
                hits.append((f"model_{model_setup.model[0].lower()}",
                             model_setup.side, model_setup.reasons[0][:70]))

            if not hits:
                continue

            q = quality.score_setup(self.io, sym, self.tf_min, hits)
            side = q.get("side", 0)
            if not side:
                continue

            # one entry per (symbol, direction, agreeing-scanner-set) per session
            key = (sym, side, tuple(sorted(q.get("scanners", []))))
            if key in self._auto_seen:
                continue
            self._auto_seen.add(key)

            names = "+".join(q.get("scanners", []))
            self.log(f"[scan] {sym} {'BUY' if side > 0 else 'SELL'} "
                     f"score {q['score']}/100 ({names}) — "
                     + "; ".join(q.get("reasons", [])))

            if not q.get("publish"):
                self.log(f"[scan] skipped — below quality threshold "
                         f"({quality.min_score()})")
                continue

            # ── institutional confirmation ──────────────────────────
            # The scanners say a level broke. This asks whether the break
            # has participation behind it, or is a stop hunt wearing a
            # breakout's clothes.
            # stash for the research capture — entries.py reads these so the
            # observation records what the engines actually saw at the time
            self.ec._last_quality = q
            inst = None
            if os.environ.get("SKLZ_INSTITUTIONAL", "1") != "0":
                try:
                    inst = self._institutional(sym, side)
                except Exception as exc:
                    self.log(f"[inst] check failed — {type(exc).__name__}: {exc}")
                    self.log("[inst] falling back to the scanner score. "
                             "This is a bug; report the line above.")
            self.ec._last_institutional = inst
            if inst is not None:
                self.log(f"[inst] {sym} {inst.verdict}")
                for f in inst.flags[:3]:
                    self.log(f"[inst]   ! {f}")
                # THE SWEEP VETO DOES NOT APPLY TO THE SWEEP MODEL.
                # Model D's entire thesis IS the liquidity sweep: it waits
                # for the sweep and enters the reversal. The "this is a
                # liquidity sweep, not a breakout" check was written for
                # BREAKOUT entries, where a sweep means the break is fake.
                # Applied to D it rejects the model for doing its job — a
                # US30 inducement entry was vetoed for being a sweep and
                # then ran 20 points without us. Waived ONLY when the sweep
                # flag is the sole blocker and the score still clears.
                if (not inst.passed and model_setup and model_setup.ok
                        and model_setup.model.startswith("D")):
                    try:
                        from basket_engine.learn.institutional import                             threshold as _ithr
                        _prefixes = ("LIQUIDITY SWEEP", "ABSORPTION",
                                     "DELTA AGAINST", "price is sitting ON",
                                     "INTO HTF BLOCK")
                        _blocking = [f for f in inst.flags
                                     if f.startswith(_prefixes)]
                        _only_sweep = (_blocking and all(
                            f.startswith("LIQUIDITY SWEEP")
                            for f in _blocking))
                        if (_only_sweep and not inst.veto
                                and inst.score >= _ithr()):
                            inst.passed = True
                            self.log(f"[inst] {sym} sweep veto waived — the "
                                     f"sweep IS the inducement model's "
                                     f"setup, not a warning against it")
                    except Exception:
                        pass

                if not inst.passed:
                    # SHADOW TRACKING. The walk-forward validated the models
                    # WITHOUT this veto layer — so every veto of a completed
                    # model sequence is an unmeasured decision. Follow the
                    # phantom trade to its stop or a 2R target, and in two
                    # weeks each veto has a P&L: kept money, or cost it.
                    try:
                        if (model_setup and model_setup.ok
                                and len(self._shadows) < 60):
                            _e = model_setup.entry
                            _st = model_setup.stop
                            _r = abs(_e - _st)
                            if _r > 0:
                                self._shadows.append({
                                    "sym": sym, "side": model_setup.side,
                                    "entry": _e, "stop": _st,
                                    "target": _e + model_setup.side * 2 * _r,
                                    "veto": (inst.flags[0].split(" — ")[0]
                                             if inst.flags else "unknown"),
                                    "model": model_setup.model[0],
                                    "t": time.time()})
                    except Exception:
                        pass
                    continue

            detail = f"{q['detail']} · score {q['score']}/100 · {names}"
            if inst is not None:
                detail += f" · institutional {inst.score:.0f}/100"
            taken = None
            skipped_but_valid = False

            if self.auto and not self.entries_blocked:
                # ONE POSITION PER SYMBOL. Model A on a break and Model D on
                # the sweep of the same pair are not two opportunities — they
                # are one market view held twice, and when it is wrong it
                # loses twice. The second signal still counts as confluence
                # in the score; it does not get its own ticket.
                try:
                    open_syms = {p.get("symbol", "") for p in
                                 (self.io.my_positions() or [])}
                except Exception:
                    open_syms = set()
                if sym in open_syms:
                    self.log(f"[entry] {sym} skipped — a position is already "
                             f"open on this pair. One idea, one ticket.")
                    continue

                # SPREAD-EXPANSION COST GATE (V1). The single most
                # expensive moments to trade are when the spread is not its
                # usual self — news, rollover, thin sessions. The engine keeps
                # a rolling baseline per symbol; when the current spread is a
                # multiple of it, the entry waits. This encodes the V1
                # finding a third time: cost decides marginal trades.
                try:
                    cur_sp = (self.io.price(sym, 1) or 0) -                              (self.io.price(sym, -1) or 0)
                    hist = self._sprd.setdefault(sym, [])
                    if cur_sp > 0:
                        hist.append(cur_sp)
                        if len(hist) > 500:
                            del hist[:100]
                    if len(hist) >= 30 and cur_sp > 0:
                        import statistics as _st
                        base = _st.median(hist)
                        mult = float(os.environ.get(
                            "SKLZ_SPREAD_EXPANSION_MULT", "2.0"))
                        if base > 0 and cur_sp > base * mult:
                            from basket_engine.learn.trailing import pip_size                                 as _ps
                            _pp = _ps(sym, self.io.spec(sym).get("digits"))
                            self.log(
                                f"[cost] {sym} entry held back — spread "
                                f"{cur_sp/_pp:.1f}p is {cur_sp/base:.1f}x its "
                                f"usual {base/_pp:.1f}p. Paying an expanded "
                                f"spread is how marginal trades become "
                                f"losers.")
                            continue
                except Exception:
                    pass

                # NEWS BLACKOUT: no fresh entries into the first minutes of a
                # high-impact release on this symbol's currencies. The M5
                # candle that completes after the window IS the post-news
                # entry — nothing is lost except the slippage.
                try:
                    from basket_engine.learn import news as _news
                    blocked, why = _news.blackout(sym, log=self.log)
                except Exception:
                    blocked, why = False, ""
                if blocked:
                    self.log(f"[news] {sym} entry skipped — {why}")
                    continue

                # Can this account carry it? Heavy instruments on a small
                # balance crowd out everything else, but the SETUP is still
                # real — someone with a larger account should hear about it.
                afford = {"ok": True}
                try:
                    afford = self.ec.affordable(sym, 0.01, side)
                except Exception:
                    pass

                # SCANNER-LED BREAKOUTS MUST EARN THE ENTRY. structure_break
                # alone confirms the break, not the trade: without a retest,
                # a hold, and a 5M engulfing, the entry is a chase — and the
                # journal showed exactly those entries losing. Models skip
                # this gate because each already enforces its own sequence.
                break_led = ("structure_break" in names
                             and not any(h[0].startswith("model_")
                                         for h in hits))
                confirm_ok = True
                if break_led:
                    try:
                        import re as _re
                        from basket_engine.learn import models as _MD
                        from basket_engine.learn.trailing import pip_size
                        m = _re.search(r"closed (?:above|below) "
                                       r"([0-9]+\.?[0-9]*)", detail)
                        level = float(m.group(1)) if m else 0.0
                        if level:
                            raw = self.io.bars(sym, 5, 40) or []
                            m5b = [{"open": r["open"], "high": r["high"],
                                    "low": r["low"], "close": r["close"]}
                                   for r in raw[:-1]]   # completed bars only
                            pip = pip_size(sym, self.io.spec(sym).get("digits"))
                            confirm_ok, why = _MD.break_entry_confirmed(
                                m5b, level, side, pip)
                            if not confirm_ok:
                                self.log(f"[entry] {sym} structure_break "
                                         f"held back — {why}")
                    except Exception:
                        confirm_ok = True   # a broken gate must not block

                # tag the decision with the market regime — measurement
                # first: no gating on regime until tagged trades say which
                # regimes deserve gates
                try:
                    from basket_engine.learn import regime as _rg
                    raw15 = self.io.bars(sym, 15, 130) or []
                    rg = _rg.classify(
                        [{"open": r["open"], "high": r["high"],
                          "low": r["low"], "close": r["close"]}
                         for r in raw15[:-1]])
                    if rg["label"] != "unknown":
                        detail += f" · regime {rg['label']}/{rg['session']}"
                        if rg["rollover"]:
                            detail += " (rollover)"
                except Exception:
                    pass

                if not afford.get("ok"):
                    self.log(f"[size] {afford.get('reason', '')}")
                    skipped_but_valid = bool(afford.get("signal_anyway"))
                elif not confirm_ok:
                    pass                    # wait for the sequence, no entry
                else:
                    taken = self.ec.auto_entry(names, sym, side, detail)
                    if taken:
                        n += 1
                        # the copy network hears about the fill immediately
                        try:
                            signal_publish.copy_event(
                                "open", taken.ticket, sym, side,
                                lots=taken.lots, price=taken.entry_price,
                                sl=taken.sl_price, tp=taken.tp_price,
                                log=self.log)
                        except Exception:
                            pass

            # publish when we took it, when auto is off, or when the setup was
            # sound but this account could not carry it
            if self.auto and not taken and not skipped_but_valid:
                self.log("[signal] not published — the entry did not fill")
            else:
                if skipped_but_valid:
                    detail += " · signal only (account too small for this instrument)"
                try:
                    # publish the levels the trade actually used, not a
                    # fresh guess — subscribers must see the same numbers
                    signal_publish.publish(
                        self.io, sym, side, names, detail, self.tf_min,
                        log=self.log,
                        actual_price=getattr(taken, "entry_price", None),
                        actual_sl=getattr(taken, "sl_price", None),
                        actual_tp=getattr(taken, "tp_price", None))
                except Exception as exc:
                    self.log(f"[signal] error: {exc}")
        return n

    # ---- exits: reconcile closed positions into the journal ----
    def sync_exits(self) -> None:
        open_tickets = {p["ticket"] for p in self.io.my_positions()}
        rows = self.journal.load_day()
        entered = {r["ticket"] for r in rows if r.get("type") == "entry" and r.get("ticket")}
        exited = {r["ticket"] for r in rows if r.get("type") == "exit"}
        for tk in entered - exited - open_tickets:
            # position closed — fetch the EXACT realized P/L from deal history
            pnl = self.io.realized_pnl(tk)
            if pnl is None:
                # Deal history lags the position closing by a moment. Writing
                # 0.0 here was recording the trade as breakeven FOREVER — the
                # real number arrives seconds later but the journal already
                # says flat. Nine trades in a row reading exactly $0.00 is not
                # a quiet day, it is this bug.
                #
                # So: leave it unrecorded and try again on the next pass.
                pending = getattr(self, "_pending_exits", None)
                if pending is None:
                    pending = self._pending_exits = {}
                tries = pending.get(tk, 0) + 1
                pending[tk] = tries
                if tries <= 20:
                    # first attempt, then occasionally — three tickets retrying
                    # every five seconds buries everything else in the console
                    if tries == 1 or tries % 8 == 0:
                        self.log(f"[exit] ticket {tk} closed — P/L not in "
                                 f"history yet, retrying (attempt {tries})")
                    continue
                # after ~20 passes something is genuinely wrong; record it as
                # unknown rather than as breakeven, so it is visible
                self.log(f"[exit] ticket {tk}: P/L never appeared in history "
                         f"after {tries} attempts. Recording as UNKNOWN rather "
                         f"than as flat — check this trade manually.")
                self.journal.record_exit(tk, 0.0, None)
                pending.pop(tk, None)
                continue

            self.log(f"[exit] ticket {tk} closed: {pnl:+.2f} realized")

            # close the published signal too. Pips from entry vs the last
            # known price when available; otherwise outcome from the sign of
            # the money, which is what subscribers actually care about
            try:
                _er = next((r for r in rows if r.get("ticket") == tk), None)
                _sym = (_er or {}).get("symbol", "")
                _side = 1 if (_er or {}).get("side", 1) in (1, "1", "buy") else -1
                if _sym:
                    _pips = None
                    try:
                        from basket_engine.learn.trailing import pip_size
                        _entry = float((_er or {}).get("entry") or 0)
                        _px = self.io.price(_sym, _side)
                        if _entry and _px:
                            _pips = ((_px - _entry) if _side > 0
                                     else (_entry - _px)) / pip_size(_sym)
                    except Exception:
                        _pips = None
                    signal_publish.update_status(_sym, _side, "closed",
                                                 pips=_pips, money=pnl,
                                                 log=self.log)
                    signal_publish.copy_event("close", tk, _sym, _side,
                                              log=self.log)
            except Exception:
                pass
            if getattr(self, "_pending_exits", None):
                self._pending_exits.pop(tk, None)
            self.journal.record_exit(tk, 0.0, pnl)

            # write the research observation, using the entry context stored
            # when the position was opened
            try:
                entry_row = next((r for r in rows
                                  if r.get("ticket") == tk
                                  and r.get("type") == "entry"), None)
                ctx = (entry_row or {}).get("context") or {}
                if ctx:
                    class _Rec:
                        pass
                    rec = _Rec()
                    rec.context = ctx
                    exit_px = 0.0
                    try:
                        exit_px = float(self.io.price(ctx.get("symbol", ""), 1))
                    except Exception:
                        pass
                    self._push_observation(rec, exit_px, pnl, "position closed")
            except Exception as exc:  # noqa: BLE001
                self.log(f"[research] exit capture skipped: {type(exc).__name__}")

    # ---- review ----
    def review(self) -> dict:
        closed = self.journal.reconcile()
        stats = summarize(closed)
        rep = ai_review(stats, closed)
        self.log("\n" + "=" * 58)
        self.log("  END-OF-DAY REVIEW  (AI proposes — you decide)")
        self.log("=" * 58)
        self.log(f"  {rep.get('headline','')}")
        self.log(f"  forced vs auto: {rep.get('forced_vs_auto','')}")
        self.log(f"  winning pattern: {rep.get('winning_pattern','')}")
        props = rep.get("proposals", [])
        if props:
            self.log("  PROPOSED CHANGES (apply manually if you agree):")
            for i, p in enumerate(props, 1):
                self.log(f"   {i}. [{p.get('confidence','?')}] {p.get('change')}: "
                         f"{p.get('suggestion')}")
                self.log(f"      reason: {p.get('reason')}")
                self.log(f"      caution: {p.get('caution')}")
        else:
            self.log("  No proposals (small sample or no AI key).")
        self.log(f"  coach: {rep.get('note_to_trader','')}")
        self.log("=" * 58 + "\n")
        # persist the review beside the journal
        rpath = os.path.join(os.path.dirname(self.journal.path),
                             f"review-{datetime.now(timezone.utc):%Y-%m-%d}.json")
        import json
        with open(rpath, "w", encoding="utf-8") as f:
            json.dump({"stats": stats, "review": rep}, f, indent=2)
        # NOTE: journal push is handled continuously by the live auto-journal loop
        # (_push_closed_trades), which tags account + dedups by position id.
        # The old end-of-day push is intentionally disabled to prevent DUPLICATES.
        self.log("[journal] (auto-journal keeps the journal current; no separate push)")
        return rep

    def status(self):
        pos = self.io.my_positions()
        closed = self.journal.reconcile()
        s = summarize(closed)
        self.log(f"  open positions: {len(pos)} | today: {s['trades']} closed, "
                 f"{s['win_rate']:.0%} win, {s['total_pnl']:+.2f} P/L | "
                 f"auto-entries: {'ON' if self.auto else 'OFF'}")
        for p in pos:
            self.log(f"    #{p['ticket']} {'BUY' if p['side']>0 else 'SELL'} "
                     f"{p['lots']} {p['symbol']} @ {p['open_price']} "
                     f"({p['profit']:+.2f})")
