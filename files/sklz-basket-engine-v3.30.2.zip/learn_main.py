"""SKLZ Learning Runner — entry point.

    set SKLZ_API_URL=https://api.sklzlabs.com
    set SKLZ_BOT_KEY=...
    set ANTHROPIC_API_KEY=...            (for AI review; optional)
    python learn_main.py

Trades are placed on whatever MT5 terminal is open & logged in.
The AI review PROPOSES parameter changes; it never applies them.
"""
from __future__ import annotations

import os
import threading
import time
from datetime import datetime, timezone

from basket_engine import MAGIC
from basket_engine.mt5io import BasketIO
from basket_engine.telemetry import Telemetry
from basket_engine.learn.runner import LearningRunner

BANNER = """
╔══════════════════════════════════════════════════════════════╗
║  SKLZ LEARNING RUNNER                                        ║
║  Learns from YOUR entries (with notes) + scanner hypotheses. ║
║  End-of-day AI PROPOSES changes — you decide. Never auto-set.║
╚══════════════════════════════════════════════════════════════╝
Commands:
  buy  EURUSD  <your reason>      forced BUY with a note the AI will learn from
  sell GBPUSD  <your reason>      forced SELL with a note
  scan                            run famous-strategy scanners once
  auto on | auto off              toggle automatic scanner entries
  review                          run the end-of-day AI review now
  journal                         push today's trades to your SKLZ Journal
  status                          positions + today's tally
  quit
"""


def _stamp(msg: str = "") -> None:
    """Every line carries the time.

    Without it a quiet console is ambiguous: it looks identical whether the
    scanner found nothing or the process froze twenty minutes ago. A timestamp
    on each line, plus the heartbeat, makes the difference obvious at a glance.
    """
    from datetime import datetime
    if msg:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)
    else:
        print(flush=True)


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--auto", action="store_true",
                    help="scanners place entries automatically")
    ap.add_argument("--headless", action="store_true",
                    help="no interactive prompt (for the auto-restart wrapper)")
    args = ap.parse_args()

    print(BANNER)
    io = BasketIO(MAGIC)
    acct = io.connect()
    live = not acct.get("demo", True)
    if live and os.environ.get("SKLZ_ALLOW_LIVE", "") != "I_ACCEPT_THE_RISK":
        print("!! LIVE ACCOUNT DETECTED.")
        print("   This runner takes entries from scanners that SKLZ's own")
        print("   research finds are frequently coin-flips out of sample.")
        print("   Its current record: 49% win rate, 0.78 profit factor.")
        print()
        print("   To run it on real money anyway, set:")
        print("     set SKLZ_ALLOW_LIVE=I_ACCEPT_THE_RISK")
        print("   and consider starting with auto OFF so only YOUR entries")
        print("   are taken, and halving the lot size.")
        return
    mode = "LIVE" if live else "DEMO"
    print(f"connected: {acct['login']} @ {acct['server']} "
          f"(equity {acct['equity']:.2f} {acct['currency']}, {mode})")
    if live:
        print("*** REAL MONEY. Every entry below is a real position. ***")

    # the label must exist before the runner is created — the command
    # poller reads it, and telemetry registers under the same name
    tag = "live" if live else "demo"
    bot_label = os.environ.get("SKLZ_BOT_NAME") or f"Learning Runner [{tag}]"

    # label passed IN, not assigned after — the poller thread starts during
    # construction and needs it immediately
    runner = LearningRunner(io, bot_label=bot_label, auto=args.auto,
                            log=_stamp)
    # show which broker symbols the requested instruments mapped to
    try:
        rep = io.resolution_report(runner.symbols)
        ok = {k: v for k, v in rep.items() if v}
        missing = [k for k, v in rep.items() if not v]
        renamed = {k: v for k, v in ok.items() if k != v}
        print(f"symbols: {len(ok)}/{len(rep)} available on this broker")
        if renamed:
            print("  matched: " + ", ".join(f"{k}->{v}" for k, v in list(renamed.items())[:8]))
        if missing:
            print("  not offered: " + ", ".join(missing[:10]))
        runner.symbols = [v for v in ok.values()]
    except Exception as exc:
        print(f"  (symbol check skipped: {exc})")
    if args.auto:
        print(f"AUTO mode: scanners will place {'REAL' if live else 'demo'} entries.")
    tel = Telemetry(bot_label, "MULTI", tag)
    if tel.enabled:
        print(f"telemetry: SKLZ dashboard connected as \"{bot_label}\"")

    # what order-flow data does this broker actually give us? The confidence
    # score weights only what is genuinely available, so this matters.
    if os.environ.get("SKLZ_INSTITUTIONAL", "1") != "0":
        try:
            probe = runner.symbols[0] if runner.symbols else "EURUSD"
            caps = io.capabilities(probe)
            have = [k for k, v in caps.items() if v]
            lack = [k for k, v in caps.items() if not v]
            print(f"order flow ({probe}): {', '.join(have) or 'nothing'} available"
                  + (f" | missing: {', '.join(lack)}" if lack else ""))
            if not caps.get("depth"):
                print("  no order book from this broker — normal for retail FX.")
                print("  DOM's 15% is redistributed across the checks that do have data.")
            if caps.get("ticks") and not caps.get("real_volume"):
                print("  delta will be INFERRED from tick side, not measured volume.")
        except Exception as exc:
            print(f"  (capability probe skipped: {type(exc).__name__})")

    stop = threading.Event()

    def background():
        last_hb = last_scan = 0.0
        while not stop.is_set():
            now = time.time()
            try:
                runner.sync_exits()
                if now - last_scan > 60:
                    runner.scan_once()
                    last_scan = now
                if now - last_hb > 30 and tel.enabled:
                    a = io.account()
                    from basket_engine.learn.review import summarize
                    s = summarize(runner.journal.reconcile())
                    # count today's entries + scanner detections for the monitor
                    try:
                        rows = runner.journal.load_day()
                        opened = sum(1 for r in rows if r.get("type") == "entry")
                    except Exception:
                        opened = 0
                    # what is open, with the broker's CURRENT stop — the
                    # dashboard's position controls read this, so a stop
                    # the trailing engine moved is shown as it really is
                    try:
                        open_pos = [{
                            "ticket": int(p.get("ticket") or 0),
                            "symbol": p.get("symbol", ""),
                            "side": "buy" if int(p.get("side", 0)) > 0 else "sell",
                            "volume": float(p.get("lots") or 0),
                            "entry": float(p.get("open_price") or 0),
                            "sl": float(p.get("sl") or 0),
                            "tp": float(p.get("tp") or 0),
                            "profit": float(p.get("profit") or 0),
                        } for p in (io.my_positions() or [])][:40]
                    except Exception:  # noqa: BLE001
                        open_pos = []
                    tel.heartbeat(a.get("equity", 0), a.get("balance", 0),
                                  {# names the Bot Monitor reads
                                   "signals": len(runner._auto_seen),
                                   "positions_opened": opened,
                                   "positions_closed": s["trades"],
                                   "realized_pl": s["total_pnl"],
                                   "open_now": len(open_pos),
                                   "open_positions": open_pos,
                                   # extra context
                                   "win_rate": s["win_rate"],
                                   "auto": runner.auto})
                    last_hb = now
            except Exception as exc:  # noqa: BLE001
                print(f"[bg] {type(exc).__name__}: {exc}")
            stop.wait(5)

    t = threading.Thread(target=background, daemon=True)
    t.start()

    if args.headless:
        # unattended: run until killed, auto-review once per day at ~21:00 UTC
        print("headless mode — Ctrl+C to stop. Daily review at ~21:00 UTC.\n")
        last_review_day = None
        try:
            while True:
                now = datetime.now(timezone.utc)
                if now.hour == 21 and now.strftime("%Y-%m-%d") != last_review_day:
                    runner.review()
                    last_review_day = now.strftime("%Y-%m-%d")
                time.sleep(30)
        except (KeyboardInterrupt, EOFError):
            stop.set()
            runner.review()
            print("stopped.")
        return

    print("ready. Type commands (or 'quit'). Background scan + telemetry running.\n")

    try:
        while True:
            line = input("> ").strip()
            if not line:
                continue
            parts = line.split()
            cmd = parts[0].lower()
            if cmd == "quit":
                break
            elif cmd == "buy":
                runner.cmd_buy(parts)
            elif cmd == "sell":
                runner.cmd_sell(parts)
            elif cmd == "scan":
                n = runner.scan_once()
                print(f"  scan complete ({n} auto-entries)" if runner.auto
                      else "  scan complete (auto OFF — signals logged, not traded)")
            elif cmd == "auto" and len(parts) > 1:
                runner.auto = parts[1].lower() == "on"
                print(f"  auto-entries {'ON' if runner.auto else 'OFF'}")
            elif cmd == "review":
                runner.review()
            elif cmd == "journal":
                from basket_engine.learn import journal_push
                closed = runner.journal.reconcile()
                journal_push.push(closed, log=print)
            elif cmd == "models":
                runner.model_scoreboard()
            elif cmd == "shadows":
                t = getattr(runner, "_shadow_tally", {}) or {}
                live = len(getattr(runner, "_shadows", []) or [])
                if not t and not live:
                    print("no shadows resolved yet — no vetoed model "
                          "setups have reached stop/target/expiry")
                else:
                    print(f"VETO SCOREBOARD ({live} shadow(s) still "
                          f"running):")
                    for veto, (w, l) in sorted(t.items()):
                        n = w + l
                        verdict = ("EARNING ITS KEEP" if l > w
                                   else "COSTING MONEY — review it"
                                   if w > l else "split")
                        print(f"  {veto}: blocked {w} winner(s) / saved "
                              f"{l} loss(es) of {n} resolved — {verdict}")
            elif cmd == "status":
                runner.status()
            else:
                print("  unknown command — buy/sell/scan/auto/review/status/shadows/models/quit")
    except (KeyboardInterrupt, EOFError):
        pass
    finally:
        stop.set()
        print("\nrunning end-of-day review before exit...")
        try:
            runner.review()
        except Exception as exc:  # noqa: BLE001
            print(f"review skipped: {exc}")
        print("stopped. Open trades remain in MT5.")


if __name__ == "__main__":
    main()
