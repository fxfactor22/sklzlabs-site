"""Model X — the fake structure shift. Lettered cases name the rule."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest
from basket_engine.learn import models as MD

PIP = 0.01


@pytest.fixture(autouse=True)
def _env(monkeypatch):
    monkeypatch.delenv("SKLZ_X_MIN_RR", raising=False)
    monkeypatch.setenv("SKLZ_MIN_STOP_PIPS", "0")


def bar(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c, "volume": 100}


def flat(n, px, w=0.15):
    return [(px, px + w, px - w, px)] * n


def setup(sweep_close=101.8, reclaim=True, level=True, last_close=102.15, sweep_low=101.6):
    rows = []
    rows += flat(4, 100.5)
    rows += [(100.5, 100.7, 100.0, 100.4)]            # prior swing low 100.0
    rows += flat(3, 100.8)
    rows += [(100.8, 104.0, 100.7, 103.6)]            # prior high 104.0
    rows += flat(3, 103.4)
    if level:
        rows += [(100.8, 102.1, 100.7, 102.0),        # big bullish candle
                 (101.7, 101.9, 101.2, 101.3)]        # bearish after it -> wick level 101.7
    else:
        rows += [(101.4, 101.6, 101.2, 101.5), (101.5, 101.6, 101.3, 101.4)]
    rows += [(101.3, 102.7, 101.3, 102.6), (102.6, 103.0, 102.5, 102.9),
             (102.9, 103.0, 102.2, 102.3)]
    rows += [(102.3, 102.5, 102.0, 102.4)]            # swing low 102.0 (the low)
    rows += [(102.4, 102.9, 102.3, 102.8), (102.8, 103.1, 102.7, 103.0)]
    rows += [(102.9, 104.5, 102.8, 104.4), (104.4, 105.2, 104.3, 105.0),
             (105.0, 106.0, 104.9, 105.8)]            # break of structure up to 106.0
    rows += [(105.8, 105.9, 104.6, 104.8), (104.8, 104.9, 103.6, 103.8),
             (103.8, 103.9, 102.6, 102.8), (102.8, 102.9, 102.2, 102.4)]   # pullback
    rows += [(102.4, 102.5, sweep_low, sweep_close)]  # THE SWEEP below 102.0
    if reclaim:
        rows += [(101.8, 102.6, 101.7, 102.4)]        # close back above 102.0 (valid BOS)
        if last_close > 102.6:
            rows += [(102.9, 103.4, 102.8, last_close)]
        else:
            rows += [(102.4, 102.5, 102.0, last_close)]   # retrace into the 50%
    else:
        rows += [(101.8, 101.9, 101.5, 101.7), (101.7, 101.8, 101.4, 101.6)]
    return [bar(*r) for r in rows]


def test_a_trap_sequence_fires_buy():
    s = MD.model_x(setup(), None, PIP)
    assert s.ok and s.side == 1
    assert s.stop < 101.6 and s.level == pytest.approx(102.0)
    txt = " ".join(s.reasons)
    assert "CLOSED below it" in txt and "wick level" in txt
    assert "VALID break of structure" in txt and "50% of the leg" in txt
    assert "106.00000" in txt                          # the objective is the BOS high
    assert s.model.startswith("X:")


def test_b_no_level_no_trade():
    s = MD.model_x(setup(level=False), None, PIP)
    assert not s.ok and any("reacted off nothing" in b for b in s.blockers)


def test_c_no_reclaim_no_trade():
    s = MD.model_x(setup(reclaim=False), None, PIP)
    assert not s.ok and any("not reclaimed" in b for b in s.blockers)


def test_d_major_low_taken_stands_aside():
    assert not MD.model_x(setup(sweep_low=99.5, sweep_close=99.8), None, PIP).ok


def test_e_waits_for_the_retracement():
    s = MD.model_x(setup(last_close=103.2), None, PIP)
    assert not s.ok and any("retracement into the 50%" in b for b in s.blockers)


def test_e_min_rr_gate(monkeypatch):
    monkeypatch.setenv("SKLZ_X_MIN_RR", "9.0")
    s = MD.model_x(setup(), None, PIP)
    assert not s.ok and any("pays only" in b for b in s.blockers)


def test_f_sell_is_the_mirror():
    m = [bar(210 - b["open"], 210 - b["low"], 210 - b["high"], 210 - b["close"]) for b in setup()]
    s = MD.model_x(m, None, PIP)
    assert s.ok and s.side == -1
    assert s.stop > 210 - 101.6


def test_g_too_few_bars_is_silent():
    s = MD.model_x([bar(*r) for r in flat(10, 100)], None, PIP)
    assert not s.ok and "not enough" in s.blockers[0]


def test_h_min_stop_pips_applies(monkeypatch):
    monkeypatch.setenv("SKLZ_MIN_STOP_PIPS", "500")   # 5.00 — wider than this stop
    s = MD.model_x(setup(), None, PIP)
    assert not s.ok and any("too tight" in b for b in s.blockers)


def test_i_wired_into_chain_and_dispatcher(monkeypatch):
    assert "x" in MD.ALL_MODELS
    m5 = setup()
    monkeypatch.setenv("SKLZ_MODELS_ENABLED", "x")
    assert MD.evaluate(m5[-40:], m5, m5, m5, PIP).ok
    assert MD.call_model("x", m5, m5, None, None, PIP).ok
    monkeypatch.setenv("SKLZ_MODELS_ENABLED", "a")
    assert not MD.evaluate(m5[-40:], m5, m5, m5, PIP).model.startswith("X")


# ── dashboard modify: 0 keeps the current level, never removes the stop ──
def test_j_modify_zero_sl_keeps_the_current_stop():
    from basket_engine.learn.runner import LearningRunner
    calls = []

    class IO:
        def modify_sl(self, tk, sl, tp=None):
            calls.append((tk, sl, tp)); return True
        def account(self): return {}

    r = LearningRunner.__new__(LearningRunner)
    r.io = IO(); r.log = lambda *a, **k: None
    r._position_by_ticket = lambda tk: {"ticket": tk, "symbol": "XAUUSD",
                                        "sl": 2390.0, "tp": 0, "side": 1}
    out = LearningRunner._cmd_modify(r, {"ticket": 5, "sl": 0, "tp": 2430.0})
    assert out["ok"] and calls == [(5, 2390.0, 2430.0)]
    out = LearningRunner._cmd_modify(r, {"ticket": 5, "sl": 2395.0, "tp": 0})
    assert calls[-1] == (5, 2395.0, None)
    r._position_by_ticket = lambda tk: {"ticket": tk, "symbol": "XAUUSD",
                                        "sl": 0, "tp": 0, "side": 1}
    out = LearningRunner._cmd_modify(r, {"ticket": 5, "sl": 0, "tp": 2430.0})
    assert not out["ok"] and "naked" in out["broker_comment"]
