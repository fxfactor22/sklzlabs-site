"""Model G — liquidity sweep + displacement FVG. Every rule from the
breakdown is a case, lettered so a failure names the rule it broke."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest
from basket_engine.learn import models as MD

PIP = 0.01          # index-like symbol; ATR of the synthetic path ≈ 1.0


@pytest.fixture(autouse=True)
def _env(monkeypatch):
    monkeypatch.setenv("SKLZ_G_KILLZONES", "0")
    monkeypatch.setenv("SKLZ_MIN_STOP_PIPS", "8")
    monkeypatch.delenv("SKLZ_G_MIN_RR", raising=False)


def bar(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c, "volume": 100}


def flat(n, px, w=0.2):
    return [bar(px, px + w, px - w, px)] * n


def m5_setup(sweep_close=109.4, disp=True, last_close=106.8, low=98.0):
    rows = []
    rows += flat(10, 104)
    rows += [bar(104, 110.0, 103.5, 105)]              # equal high #1
    rows += flat(6, 104)
    rows += [bar(104, 100.5, low, 102)]                # the swing low / target
    rows += flat(6, 103)
    rows += [bar(103, 110.05, 102.5, 105)]             # equal high #2
    rows += flat(6, 105)
    rows += [bar(105, 107, 104.8, 107), bar(107, 109, 106.8, 109)]
    rows += [bar(109, 110.6, 108.9, sweep_close)]      # SWEEP
    if disp:
        rows += [bar(109.4, 109.6, 108.2, 108.3), bar(108.3, 108.4, 107.0, 107.1),
                 bar(107.1, 107.6, 106.5, last_close)]  # bearish FVG 107.6–108.2
    else:
        rows += [bar(109.4, 109.6, 108.9, 109.0), bar(109.0, 109.5, 108.7, 109.1),
                 bar(109.1, 109.6, 108.9, last_close)]
    return flat(10, 104) + rows                        # >=40 bars


def h1_prev(high=111.5, low=99.0):
    return flat(24, 105) + [bar(105, high, low, 105)] * 24


# ── A. the reference trade fires a SELL with the right geometry ──────
def test_a_sell_after_equal_highs_sweep_with_displacement():
    s = MD.model_g(h1_prev(), m5_setup(), PIP)
    assert s.ok and s.side == -1
    assert s.stop > 110.6                      # above the wick
    assert s.entry == pytest.approx(106.8)
    txt = " ".join(s.reasons)
    assert "relative equal highs" in txt and "swept" in txt
    assert "displacement" in txt and "bearish FVG" in txt
    assert "internal liquidity at 98.00000" in txt
    assert s.model.startswith("G:")


# ── B. no displacement → not a trade (Model E's mistake) ─────────────
def test_b_sweep_without_displacement_is_blocked_and_named():
    s = MD.model_g(h1_prev(), m5_setup(disp=False), PIP)
    assert not s.ok
    assert any("without displacement" in b for b in s.blockers)


# ── C. a close through the pool is a breakout ────────────────────────
def test_c_close_above_pool_is_not_a_sweep():
    s = MD.model_g(h1_prev(), m5_setup(sweep_close=110.3), PIP)
    assert not s.ok


# ── D. HTF FVG on the shelf is named; far away it is not ─────────────
def test_d_h1_fvg_on_the_shelf_is_named():
    h1 = h1_prev() + [bar(111.5, 112.0, 111.0, 111.2), bar(111.2, 111.4, 110.9, 111.0),
                      bar(111.0, 110.4, 110.0, 110.2)]     # bearish H1 FVG 110.4–111.0
    s = MD.model_g(h1, m5_setup(), PIP)
    assert s.ok and "H1 FVG" in " ".join(s.reasons)


def test_d_far_fvg_is_not_confluence():
    h1 = h1_prev() + [bar(120, 121, 119.5, 120.5), bar(120.5, 120.8, 120.2, 120.4),
                      bar(120.4, 119.4, 119.0, 119.2)]
    s = MD.model_g(h1, m5_setup(), PIP)
    assert s.ok and "H1 FVG" not in " ".join(s.reasons)


# ── E. the target must pay ───────────────────────────────────────────
def test_e_no_pool_pays_2r_stands_aside():
    s = MD.model_g(h1_prev(low=104.6), m5_setup(low=104.5), PIP)
    assert not s.ok
    assert any("pays" in b for b in s.blockers)


def test_e_min_rr_env_is_honoured(monkeypatch):
    m5 = m5_setup(low=102.0)                    # 4.8 reward vs ~3.95 risk
    assert not MD.model_g(h1_prev(low=104.6), m5, PIP).ok
    monkeypatch.setenv("SKLZ_G_MIN_RR", "1.0")
    assert MD.model_g(h1_prev(low=104.6), m5, PIP).ok


# ── F. mirrored for a BUY ────────────────────────────────────────────
def test_f_buy_is_the_mirror():
    m5 = [bar(220 - b["open"], 220 - b["low"], 220 - b["high"], 220 - b["close"])
          for b in m5_setup()]
    h1 = [bar(220 - b["open"], 220 - b["low"], 220 - b["high"], 220 - b["close"])
          for b in h1_prev()]
    s = MD.model_g(h1, m5, PIP)
    assert s.ok and s.side == 1
    assert s.stop < 220 - 110.6
    assert "relative equal lows" in " ".join(s.reasons)


# ── G. kill zones gate the live signal ───────────────────────────────
def test_g_outside_kill_zone_is_a_named_blocker(monkeypatch):
    monkeypatch.setenv("SKLZ_G_KILLZONES", "1")
    monkeypatch.setattr(MD, "_in_kill_zone", lambda: False)
    s = MD.model_g(h1_prev(), m5_setup(), PIP)
    assert not s.ok and any("kill zones" in b for b in s.blockers)


# ── H. wiring: evaluate() reaches G, call_model dispatches it ────────
def test_h_evaluate_reaches_g_when_enabled(monkeypatch):
    monkeypatch.setenv("SKLZ_MODELS_ENABLED", "g")
    s = MD.evaluate(m15=[], m5=m5_setup(), h1=h1_prev(), h4=[], pip=PIP)
    assert s.ok and s.model.startswith("G:")


def test_h_evaluate_skips_g_when_disabled(monkeypatch):
    monkeypatch.setenv("SKLZ_MODELS_ENABLED", "a,b,c,d")
    s = MD.evaluate(m15=[], m5=m5_setup(), h1=h1_prev(), h4=[], pip=PIP)
    assert not (s.ok and s.model.startswith("G:"))


def test_h_call_model_dispatch():
    s = MD.call_model("g", [], m5_setup(), h1_prev(), [], PIP)
    assert s.ok and s.model.startswith("G:")
    assert MD.call_model("zz", [], [], [], [], PIP).model.endswith("unknown")
    assert "g" in MD.ALL_MODELS
