"""Tests for the signal quality gate."""
from basket_engine.learn import quality


class FakeIO:
    """Deterministic price series with a controllable trend."""

    def __init__(self, trend: int = 1):
        self.trend = trend

    def closes(self, sym, tf, n):
        base = 100.0
        step = 0.5 * self.trend
        return [base + step * i for i in range(n)]


def test_conflicting_scanners_stand_aside():
    io = FakeIO()
    r = quality.score_setup(io, "EURUSD", 60,
                            [("sweep_reversal", 1, "a"),
                             ("structure_break", -1, "b")])
    assert r["publish"] is False
    assert r["side"] == 0


def test_single_scanner_against_trend_is_filtered():
    io = FakeIO(trend=1)                       # uptrend
    r = quality.score_setup(io, "EURUSD", 60,
                            [("structure_break", -1, "broke low")])
    assert r["side"] == -1
    assert r["publish"] is False               # 1 scanner + against HTF


def test_full_confluence_with_trend_publishes():
    io = FakeIO(trend=1)
    r = quality.score_setup(io, "EURUSD", 60,
                            [("sweep_reversal", 1, "a"),
                             ("structure_break", 1, "b"),
                             ("strength_extreme", 1, "c")])
    assert r["side"] == 1
    assert r["agree"] == 3
    assert r["publish"] is True
    assert r["score"] >= quality.min_score()


def test_majority_direction_wins():
    io = FakeIO(trend=1)
    r = quality.score_setup(io, "EURUSD", 60,
                            [("sweep_reversal", 1, "a"),
                             ("structure_break", 1, "b"),
                             ("strength_extreme", -1, "c")])
    assert r["side"] == 1
    assert r["agree"] == 2


def test_no_hits_returns_no_signal():
    io = FakeIO()
    r = quality.score_setup(io, "EURUSD", 60, [])
    assert r["publish"] is False
    assert r["score"] == 0


def test_model_outranks_one_opposing_scanner():
    """A sweep model fires on the very candle a breakout scanner reads the
    other way. 1 vs 1 used to cancel silently; the model's sequence wins."""
    io = FakeIO(trend=1)
    r = quality.score_setup(io, "EURUSD", 60,
                            [("model_x", 1, "fake structure shift"),
                             ("structure_break", -1, "broke low")])
    assert r["side"] == 1
    assert r["agree"] == 1
    assert any("outranked" in x for x in r["reasons"])
    assert r["scanners"] == ["model_x"]


def test_model_vs_model_still_stands_aside():
    io = FakeIO()
    r = quality.score_setup(io, "EURUSD", 60,
                            [("model_x", 1, "a"), ("model_c", -1, "b")])
    assert r["side"] == 0 and r["publish"] is False


def test_two_scanners_still_outvote_one_model():
    io = FakeIO(trend=1)
    r = quality.score_setup(io, "EURUSD", 60,
                            [("model_e", 1, "a"),
                             ("structure_break", -1, "b"),
                             ("strength_extreme", -1, "c")])
    assert r["side"] == -1
