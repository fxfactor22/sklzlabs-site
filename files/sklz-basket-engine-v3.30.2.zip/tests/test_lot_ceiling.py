"""Per-symbol lot caps: gold/silver at 0.06, everything else on the global cap."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from basket_engine.learn.entries import lot_ceiling, EntryController


def test_global_cap_when_no_per_symbol(monkeypatch):
    monkeypatch.setenv("SKLZ_MAX_LOTS", "0.15")
    monkeypatch.delenv("SKLZ_MAX_LOTS_BY_SYMBOL", raising=False)
    assert lot_ceiling("EURUSD") == (0.15, "SKLZ_MAX_LOTS")
    assert lot_ceiling("XAUUSD")[0] == 0.15


def test_per_symbol_overrides_and_ignores_broker_suffix(monkeypatch):
    monkeypatch.setenv("SKLZ_MAX_LOTS", "0.15")
    monkeypatch.setenv("SKLZ_MAX_LOTS_BY_SYMBOL", "XAUUSD:0.06, XAGUSD:0.06")
    assert lot_ceiling("XAUUSD")[0] == 0.06
    assert lot_ceiling("XAUUSD.c")[0] == 0.06
    assert lot_ceiling("xagusdm")[0] == 0.06
    assert lot_ceiling("EURUSD")[0] == 0.15          # untouched
    assert lot_ceiling("US30")[0] == 0.15


def test_longest_prefix_wins_and_garbage_is_ignored(monkeypatch):
    monkeypatch.setenv("SKLZ_MAX_LOTS", "0")
    monkeypatch.setenv("SKLZ_MAX_LOTS_BY_SYMBOL", "XAU:0.10,XAUUSD:0.06,bad,EUR:x")
    assert lot_ceiling("XAUUSD")[0] == 0.06
    assert lot_ceiling("XAUEUR")[0] == 0.10
    assert lot_ceiling("EURUSD")[0] == 0.0           # unparsable -> no cap


def test_size_applies_the_symbol_cap(monkeypatch):
    monkeypatch.setenv("SKLZ_MAX_LOTS", "0.15")
    monkeypatch.setenv("SKLZ_MAX_LOTS_BY_SYMBOL", "XAUUSD:0.06")
    logs = []

    class IO:
        def spec(self, s): return {"lot_min": 0.01}

    ec = EntryController.__new__(EntryController)
    ec.io = IO(); ec.log = logs.append
    ec._size_raw = lambda sym, sl: 0.15
    assert ec._size("XAUUSD", 10.0) == 0.06
    assert ec._size("EURUSD", 10.0) == 0.15
    assert ec._size("XAUUSD", 10.0, apply_ceiling=False) == 0.15   # dashboard: human decision
    assert any("SKLZ_MAX_LOTS_BY_SYMBOL (XAUUSD)" in l for l in logs)
