"""Per-model overrides read from the bat — v3.36.

Model R (order flow) needs a few things the global switches deny every
other model: its own stop (the bat runs SKLZ_MODEL_SL=0 so that the 15-40
pip structure band governs the rest), a wider lot ceiling on gold, and an
exemption from the M5 confirmation gate. Rather than special-casing "r" in
three files, each of those places asks here with the entry's strategy
string, and the answer comes from a `letter:value` list:

    SKLZ_MODEL_SL_BY_MODEL=r:1          r keeps the stop its model computed
    SKLZ_MAX_LOTS_BY_MODEL=r:0.04       r may size up to 0.04 (overrides the
                                        symbol / global lot ceiling for r)

Everything is additive: with these variables unset every function returns
"no override" and the engine behaves exactly as v3.35.2.
"""
from __future__ import annotations

import os


def model_tag(strategy: str) -> str:
    """'strength_extreme+model_r_trend' -> 'r'; 'model_e_tl' -> 'e'; '' -> ''."""
    for name in str(strategy or "").split("+"):
        name = name.strip().lower()
        if name.startswith("model_") and len(name) > 6:
            return name[6:].split("_", 1)[0]
    return ""


def _lookup(env: str, tag: str) -> str | None:
    tag = (tag or "").strip().lower()
    if not tag:
        return None
    raw = os.environ.get(env, "")
    for part in raw.split(","):
        if ":" not in part:
            continue
        k, v = part.split(":", 1)
        if k.strip().lower() == tag:
            return v.strip()
    return None


def flag(env: str, tag: str) -> bool | None:
    """True/False when the list names this model, None when it does not."""
    v = _lookup(env, tag)
    if v is None:
        return None
    return v not in ("0", "off", "false", "no", "")


def number(env: str, tag: str) -> float | None:
    v = _lookup(env, tag)
    if v is None:
        return None
    try:
        return float(v)
    except ValueError:
        return None


def model_sl_allowed(tag: str, global_default: str = "1") -> bool:
    """Does this entry keep the stop its model computed?"""
    f = flag("SKLZ_MODEL_SL_BY_MODEL", tag)
    if f is not None:
        return f
    return os.environ.get("SKLZ_MODEL_SL", global_default) != "0"


def lot_cap(tag: str) -> float | None:
    """Per-model lot ceiling, or None to fall back to the symbol / global cap."""
    v = number("SKLZ_MAX_LOTS_BY_MODEL", tag)
    return v if v and v > 0 else None


def confirm_exempt(tag_full: str) -> bool:
    """SKLZ_ENTRY_CONFIRM_EXEMPT lists full tags (p_open) or letters (r).
    v3.35 compared the full tag only, so a letter never matched its
    variants; this accepts both without changing the p_open behaviour."""
    raw = os.environ.get("SKLZ_ENTRY_CONFIRM_EXEMPT", "p_open")
    ex = {x.strip().lower() for x in raw.split(",") if x.strip()}
    t = (tag_full or "").strip().lower()
    if not t:
        return False
    return t in ex or t.split("_", 1)[0] in ex
