"""LLM context note for Model R — v3.36. Default OFF.

Fabio reads the tape with a story in his head: what the day is about, what
the overnight did, which side the big players are leaning. The footprint
tells you WHERE and WHEN; the context tells you WHETHER the day is one to
press or one to sit out. This module writes that story once every
SKLZ_LLM_EVERY_MIN minutes (default 30) from numbers the engine already has
— yesterday's value area, where the session opened against it, the H1
trend, session CVD, basis — and asks the model for a one-line read with a
lean (-1 / 0 / +1) and a confidence.

    SKLZ_LLM_CONTEXT=off     nothing is called, nothing is logged (default)
    SKLZ_LLM_CONTEXT=score   the lean adjusts R's quality score ±SKLZ_LLM_PTS
    SKLZ_LLM_CONTEXT=gate    an R setup against a confident lean is skipped

The call never decides a trade on its own: the three mandatory steps
(state, location, aggression) are code. With no ANTHROPIC_API_KEY the
module returns a deterministic note built from the same numbers, so the log
line still reads the same.
"""
from __future__ import annotations

import json
import os
import time

_cache: dict[str, tuple[float, dict]] = {}


def mode() -> str:
    m = os.environ.get("SKLZ_LLM_CONTEXT", "off").strip().lower()
    return m if m in ("off", "score", "gate") else "off"


def _every() -> float:
    try:
        return float(os.environ.get("SKLZ_LLM_EVERY_MIN", "30") or 30) * 60
    except ValueError:
        return 1800.0


def _facts(symbol: str, px: float, pdva: dict | None, h1: list[dict], of_state: dict | None) -> dict:
    d: dict = {"symbol": symbol, "price": round(px, 2)}
    if pdva:
        d["prev_day_value"] = {k: round(float(pdva[k]), 2) for k in ("val", "poc", "vah") if k in pdva}
        d["state"] = "above value" if px > pdva["vah"] else "below value" if px < pdva["val"] else "inside value"
    if len(h1) >= 12:
        c = [float(b["close"]) for b in h1[-12:]]
        d["h1_12bar_change_pct"] = round((c[-1] - c[0]) / c[0] * 100, 2)
        d["h1_higher_highs"] = sum(1 for i in range(1, 6) if float(h1[-i]["high"]) > float(h1[-i - 1]["high"]))
        d["h1_lower_lows"] = sum(1 for i in range(1, 6) if float(h1[-i]["low"]) < float(h1[-i - 1]["low"]))
    if of_state:
        bars = of_state.get("bars") or []
        if bars:
            d["session_cvd"] = round(float(bars[-1].get("cvd", 0) or 0), 2)
            d["cvd_last10"] = round(sum(float(b.get("d", 0) or 0) for b in bars[-10:]), 2)
            d["big_prints_last10"] = {"buy": sum(int(b.get("big_buy", 0) or 0) for b in bars[-10:]),
                                      "sell": sum(int(b.get("big_sell", 0) or 0) for b in bars[-10:])}
        mt = of_state.get("mt5") or {}
        if mt:
            d["paxg_basis_pct"] = mt.get("basis_pct")
            d["paxg_corr60"] = mt.get("corr60")
    return d


def _deterministic(f: dict) -> dict:
    lean, why = 0, []
    st = f.get("state", "")
    chg = float(f.get("h1_12bar_change_pct", 0) or 0)
    cvd = float(f.get("cvd_last10", 0) or 0)
    if st == "above value" and chg > 0:
        lean += 1; why.append("holding above value with H1 momentum up")
    if st == "below value" and chg < 0:
        lean -= 1; why.append("holding below value with H1 momentum down")
    if cvd > 0:
        lean += 1; why.append("recent delta positive")
    elif cvd < 0:
        lean -= 1; why.append("recent delta negative")
    lean = max(-1, min(1, lean))
    return {"lean": lean, "confidence": 0.4 if lean else 0.2,
            "note": ("; ".join(why) or "balanced — no edge from context") + " (deterministic)",
            "source": "rules"}


def _llm(f: dict) -> dict | None:
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        return None
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)
        prompt = (
            "You are a gold futures order-flow trader in the Auction Market Theory school "
            "(Fabio Valentini). Given these facts about XAUUSD right now, write ONE sentence of "
            "context (max 30 words) and a lean. Reply as JSON only: "
            '{"lean": -1|0|1, "confidence": 0..1, "note": "..."}\n\n' + json.dumps(f)
        )
        msg = client.messages.create(
            model=os.environ.get("SKLZ_LLM_MODEL", "claude-sonnet-4-6"), max_tokens=200,
            messages=[{"role": "user", "content": prompt}])
        txt = "".join(getattr(b, "text", "") for b in msg.content).strip()
        txt = txt[txt.find("{"): txt.rfind("}") + 1]
        out = json.loads(txt)
        return {"lean": int(max(-1, min(1, int(out.get("lean", 0))))),
                "confidence": float(max(0.0, min(1.0, float(out.get("confidence", 0.5))))),
                "note": str(out.get("note", ""))[:160], "source": "llm"}
    except Exception as exc:  # noqa: BLE001
        return {"lean": 0, "confidence": 0.0, "note": f"LLM unavailable ({type(exc).__name__})", "source": "error"}


def note(symbol: str, px: float, pdva: dict | None, h1: list[dict],
         of_state: dict | None, now: float | None = None) -> dict | None:
    """Cached context read, or None when SKLZ_LLM_CONTEXT=off."""
    if mode() == "off":
        return None
    now = now or time.time()
    hit = _cache.get(symbol)
    if hit and now - hit[0] < _every():
        return hit[1]
    f = _facts(symbol, px, pdva, h1, of_state)
    out = _llm(f) or _deterministic(f)
    out["ts"] = now
    _cache[symbol] = (now, out)
    return out


def apply(ctx: dict | None, side: int, score: float) -> tuple[float, bool, str]:
    """(new_score, veto, log_text). score mode nudges, gate mode vetoes a
    confident opposite lean; both leave a neutral note alone."""
    if not ctx:
        return score, False, ""
    lean, conf = int(ctx.get("lean", 0)), float(ctx.get("confidence", 0))
    try:
        pts = float(os.environ.get("SKLZ_LLM_PTS", "8") or 8)
    except ValueError:
        pts = 8.0
    try:
        min_conf = float(os.environ.get("SKLZ_LLM_MIN_CONF", "0.6") or 0.6)
    except ValueError:
        min_conf = 0.6
    txt = f"[ctx] {ctx.get('note', '')} · lean {lean:+d} ({conf:.1f})"
    if lean == 0:
        return score, False, txt + " · neutral"
    agrees = (lean > 0) == (side > 0)
    if mode() == "gate" and not agrees and conf >= min_conf:
        return score, True, txt + " · VETO (against a confident read)"
    if agrees:
        return score + pts, False, txt + f" · +{pts:g}"
    return max(0.0, score - pts), False, txt + f" · -{pts:g}"
