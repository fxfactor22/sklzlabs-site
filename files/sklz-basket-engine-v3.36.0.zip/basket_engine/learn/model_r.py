"""Model R — order-flow gold model (v3.36). Fabio Valentini's Auction
Market Theory playbook, adapted to XAUUSD with measured flow from PAXG.

Three steps, every one mandatory — miss one and there is no trade:

  STATE      where price sits against yesterday's value area (balance)
  LOCATION   a low-volume node of the leg price is retracing into
  AGGRESSION measured flow in the trade's direction at that node
             (stacked imbalances / big prints / absorption of the other side)

Two sub-models, each its own report tag:

  r_trend   out of balance, displaced beyond yesterday's VA with a real
            impulse; price returns to an LVN of the impulse leg; aggression
            in the trend direction; stop beyond the print; target the next
            opposing liquidity that pays SKLZ_MIN_TARGET_RR.
  r_mr      balance: a push outside yesterday's VA FAILED and price has
            reclaimed value (not the first move back); pullback into an LVN
            of the reclaim leg or the VA edge; aggression in the snap-back
            direction; stop beyond the failed extreme; target yesterday's POC.

What is NOT here, on purpose: price levels from PAXG. Every level comes
from the broker's own XAUUSD bars (levels.py). PAXG supplies only who was
hitting what, mapped onto broker prices by the feed's rolling basis — and
of_feed.guards() stands the model aside the moment PAXG stops tracking.

R is exempt from the universal M5 confirmation gate
(SKLZ_ENTRY_CONFIRM_EXEMPT=p_open,r): the aggression print IS the
confirmation, and by the time an M5 retest closes the node is gone.
"""
from __future__ import annotations

import os
import time
from datetime import datetime, timezone

from basket_engine.learn import of_feed as OF


def _f(env: str, default: float) -> float:
    try:
        return float(os.environ.get(env, "") or default)
    except ValueError:
        return default


def _i(env: str, default: int) -> int:
    try:
        return int(float(os.environ.get(env, "") or default))
    except ValueError:
        return default


def _modes() -> set[str]:
    return {x.strip().lower() for x in os.environ.get("SKLZ_R_MODES", "trend,mr").split(",") if x.strip()}


_SESSION_HOURS = {"london": "7-11", "ny": "13-16", "asia": "0-4", "asian": "0-4"}


def in_hours(now_utc: datetime | None = None) -> tuple[bool, str]:
    """SKLZ_R_HOURS="7-11,13-16" (UTC) wins; else SKLZ_R_SESSIONS=london,ny."""
    now = now_utc or datetime.now(timezone.utc)
    h = now.hour + now.minute / 60.0
    raw = os.environ.get("SKLZ_R_HOURS", "").strip()
    if not raw:
        parts = [_SESSION_HOURS.get(s.strip().lower(), "") for s in
                 os.environ.get("SKLZ_R_SESSIONS", "london,ny").split(",")]
        raw = ",".join(p for p in parts if p)
    for part in raw.split(","):
        try:
            a, b = part.split("-")
            if float(a) <= h < float(b):
                return True, part
        except ValueError:
            continue
    return False, f"{h:.1f} UTC is outside R hours ({raw})"


def _atr(bars: list[dict], n: int = 14) -> float:
    xs = [float(b["high"]) - float(b["low"]) for b in bars[-n - 1:-1]]
    xs = [x for x in xs if x > 0]
    return sum(xs) / len(xs) if xs else 0.0


# ───────────────────────── daily loss limit ───────────────────────────
def losses_today(journal_path: str | None = None) -> int:
    """Closed R trades today that lost — Fabio's 'three stops and done'."""
    try:
        from basket_engine.learn.capture import Journal
        path = journal_path or os.environ.get("SKLZ_JOURNAL_PATH", "").strip() or os.path.join(
            os.path.dirname(__file__), "..", "..", "learning_journal.jsonl")
        rows = Journal(path).reconcile()
    except Exception:  # noqa: BLE001
        return 0
    n = 0
    for r in rows:
        if "model_r" in str(r.get("strategy", "")) and r.get("outcome") == "loss":
            n += 1
    return n


# ───────────────────────── the model ──────────────────────────────────
def model_r(h1: list[dict], m5: list[dict], pip: float, extra=None):
    from basket_engine.learn import levels as LV
    from basket_engine.learn.models import Setup

    s = Setup(ok=False, model="R: order flow (LVN + aggression)")
    ex = extra or {}
    sym = str(ex.get("symbol", "") or "")
    want = os.environ.get("SKLZ_OF_MAP_TO", "XAUUSD").strip().upper()
    if not sym.upper().startswith(want):
        s.blockers.append(f"R trades {want} only")
        return s
    ok_h, why_h = in_hours(ex.get("now_utc"))
    if not ok_h:
        s.blockers.append(why_h)
        return s
    if len(m5) < 60 or len(h1) < 30:
        s.blockers.append("not enough history for the order-flow model")
        return s

    # the feed, and the guards that keep PAXG honest
    st, why = OF.load_state(now=ex.get("now_epoch"))
    g_ok, g_why = OF.guards(st, why)
    if not g_ok:
        s.blockers.append(g_why)
        return s

    max_l = _i("SKLZ_R_MAX_LOSSES", 3)
    if max_l > 0:
        nl = ex.get("r_losses_today")
        nl = losses_today() if nl is None else int(nl)
        if nl >= max_l:
            s.blockers.append(f"R has taken {nl} stops today (SKLZ_R_MAX_LOSSES={max_l}) — done for the day")
            return s

    m15 = ex.get("m15") or []
    pdva = LV.prev_day_value_area(m15, bins=40) if m15 else None
    if not pdva:
        s.blockers.append("yesterday's value area unavailable (M15 bars need timestamps)")
        return s
    vah, val, poc = float(pdva["vah"]), float(pdva["val"]), float(pdva["poc"])

    px = float(m5[-1]["close"])
    atr5, atr60 = _atr(m5), _atr(h1)
    if atr5 <= 0 or atr60 <= 0:
        s.blockers.append("no volatility reading")
        return s
    buffer = _f("SKLZ_SL_BUFFER_PIPS", 2.0) * pip
    cap = _f("SKLZ_R_SL_MAX_PIPS", 120.0) * pip
    floor = _f("SKLZ_SL_MIN_PIPS", 15.0) * pip
    tol = _f("SKLZ_R_LVN_TOL_ATR", 0.25) * atr5
    modes = _modes()
    state_txt = ("above value" if px > vah else "below value" if px < val else "inside value")
    s.reasons.append(f"yesterday's value {val:.2f}–{vah:.2f} (POC {poc:.2f}); price {px:.2f} is {state_txt}")

    # ── R_TREND ────────────────────────────────────────────────────────
    if "trend" in modes and (px > vah or px < val):
        side = 1 if px > vah else -1
        need = _f("SKLZ_R_IMPULSE_ATR", 1.5) * atr60
        # The leg out of balance: from the last bar that still touched value
        # (the origin of the break) to the extreme printed since. A generic
        # "last swing" would hand back the pullback itself on a trend day.
        win = m5[-_i("SKLZ_R_LOOKBACK", 80):]
        idx = 0
        for i in range(len(win) - 1, -1, -1):
            if (side > 0 and float(win[i]["low"]) <= vah) or (side < 0 and float(win[i]["high"]) >= val):
                idx = i
                break
        leg_bars = win[idx:]
        if side > 0:
            origin = float(win[idx]["low"])
            ext = max(float(b["high"]) for b in leg_bars)
        else:
            origin = float(win[idx]["high"])
            ext = min(float(b["low"]) for b in leg_bars)
        height = abs(ext - origin)
        leg = {"lo": min(origin, ext), "hi": max(origin, ext), "dir": side}
        if len(leg_bars) < 6:
            s.blockers.append("just left value — no leg to measure yet")
        elif height < need:
            s.blockers.append(f"impulse {height / pip:.0f} pips is under {need / pip:.0f} ({_f('SKLZ_R_IMPULSE_ATR', 1.5):g} H1 ATR) — rotation, not displacement")
        else:
            retr = (ext - px) * side / height if height else 0.0
            if retr < _f("SKLZ_R_MIN_RETRACE", 0.15):
                s.blockers.append(f"no pullback yet ({retr * 100:.0f}% of the leg) — never chase the extreme")
            elif retr > _f("SKLZ_R_MAX_RETRACE", 0.70):
                s.blockers.append(f"retraced {retr * 100:.0f}% of the leg — the impulse is failing, not pulling back")
            else:
                va_leg = LV.value_area(leg_bars, bins=24, source="volume")
                lvns = LV.low_volume_nodes(va_leg) if va_leg else []
                hit = [(lo, hi) for lo, hi in lvns if lo - tol <= px <= hi + tol]
                if not hit:
                    near = min(lvns, key=lambda b: abs((b[0] + b[1]) / 2 - px)) if lvns else None
                    s.blockers.append("price is not at a low-volume node of the leg"
                                      + (f" (nearest {near[0]:.2f}–{near[1]:.2f})" if near else ""))
                else:
                    lo, hi = hit[0]
                    ag = OF.aggression(st, side)
                    if not ag.get("ok"):
                        s.blockers.append(f"at LVN {lo:.2f}–{hi:.2f} but {ag.get('why', 'no aggression')}")
                    else:
                        print_px = OF.map_price(ag.get("print_px") or 0, st) or px
                        if abs(print_px - px) > 3 * atr5:
                            print_px = px        # a print mapped far from here is a feed artefact — use the node edge
                        stop = (min(print_px, lo) - buffer) if side > 0 else (max(print_px, hi) + buffer)
                        dist = abs(px - stop)
                        if dist < floor:
                            stop = px - side * floor
                            dist = floor
                        if dist > cap:
                            s.blockers.append(f"stop beyond the print would be {dist / pip:.0f} pips, over SKLZ_R_SL_MAX_PIPS={cap / pip:.0f}")
                        else:
                            ex_lv = [ext]
                            try:
                                sl_ = LV.session_levels(m15)
                                ex_lv += [p for p, _ in (sl_["untested_highs"] if side > 0 else sl_["untested_lows"])]
                                pdr = LV.prev_day_range(m15)
                                if pdr:
                                    ex_lv.append(float(pdr["high"] if side > 0 else pdr["low"]))
                            except Exception:  # noqa: BLE001
                                pass
                            tgt, tw = LV.structural_target(m5, side, px, stop, extra_levels=ex_lv)
                            if not tgt:
                                s.blockers.append(tw)
                            else:
                                s.ok, s.side, s.entry, s.level = True, side, px, (lo + hi) / 2
                                s.stop, s.target, s.tag = round(stop, 5), float(tgt), "r_trend"
                                cv = OF.cvd_agrees(st, side)
                                s.reasons += [
                                    f"out of balance: impulse {height / pip:.0f} pips ({height / atr60:.1f} H1 ATR), pullback {retr * 100:.0f}%",
                                    f"at low-volume node {lo:.2f}–{hi:.2f} of the leg",
                                    f"aggression: {ag['why']} ({ag['kind']})",
                                    f"session CVD {'agrees' if cv else 'neutral' if cv is None else 'disagrees'} · PAXG basis {((st.get('mt5') or {}).get('basis_pct') or 0):+.2f}%",
                                    f"stop {stop:.2f} beyond the print ({dist / pip:.0f} pips) · {tw}",
                                ]
                                return s

    # ── R_MR ───────────────────────────────────────────────────────────
    if "mr" in modes:
        look = _i("SKLZ_R_MR_LOOKBACK", 36)
        closed = m5[-look - 1:-1]
        inside_now = val < px < vah
        attempt = None
        for i in range(len(closed) - 1, -1, -1):
            b = closed[i]
            if float(b["high"]) > vah and float(b["close"]) > vah:
                attempt = ("up", i); break
            if float(b["low"]) < val and float(b["close"]) < val:
                attempt = ("down", i); break
        if not attempt:
            s.blockers.append(f"no failed break of value in the last {look} bars")
        elif not inside_now:
            s.blockers.append("price still outside value — the break has not failed yet")
        else:
            kind, i_out = attempt
            side = -1 if kind == "up" else 1
            after = closed[i_out + 1:]
            back = [b for b in after if val < float(b["close"]) < vah]
            need_back = _i("SKLZ_R_RECLAIM_BARS", 3)
            if len(back) < need_back:
                s.blockers.append(f"only {len(back)} closes back inside value — not the first move back (need {need_back})")
            else:
                i_ext = max(range(len(closed)), key=lambda j: float(closed[j]["high"])) if kind == "up" \
                    else min(range(len(closed)), key=lambda j: float(closed[j]["low"]))
                extreme = float(closed[i_ext]["high"] if kind == "up" else closed[i_ext]["low"])
                leg_bars = closed[i_ext:] + [m5[-1]]
                va_leg = LV.value_area(leg_bars, bins=24, source="volume") if len(leg_bars) >= 4 else None
                lvns = LV.low_volume_nodes(va_leg) if va_leg else []
                edge = vah if side < 0 else val
                at_lvn = [(lo, hi) for lo, hi in lvns if lo - tol <= px <= hi + tol]
                near_edge = abs(px - edge) <= _f("SKLZ_R_EDGE_TOL_ATR", 0.3) * atr5
                if not at_lvn and not near_edge:
                    s.blockers.append(f"reclaimed value but price is neither at a reclaim-leg LVN nor at the VA edge {edge:.2f}")
                else:
                    ag = OF.aggression(st, side)
                    if not ag.get("ok"):
                        s.blockers.append(f"failed break of {extreme:.2f} reclaimed, but {ag.get('why', 'no aggression')}")
                    else:
                        stop = (extreme + buffer) if side < 0 else (extreme - buffer)
                        dist = abs(px - stop)
                        if dist < floor:
                            stop = px - side * floor
                            dist = floor
                        if dist > cap:
                            s.blockers.append(f"stop beyond the failed extreme would be {dist / pip:.0f} pips, over SKLZ_R_SL_MAX_PIPS={cap / pip:.0f}")
                        else:
                            rr = abs(poc - px) / dist if dist else 0.0
                            if (poc - px) * side <= 0 or rr < LV.min_target_rr():
                                s.blockers.append(f"POC {poc:.2f} pays only {rr:.1f}R from here")
                            else:
                                where = (f"LVN {at_lvn[0][0]:.2f}–{at_lvn[0][1]:.2f}" if at_lvn else f"VA edge {edge:.2f}")
                                s.ok, s.side, s.entry = True, side, px
                                s.level = (at_lvn[0][0] + at_lvn[0][1]) / 2 if at_lvn else edge
                                s.stop, s.target, s.tag = round(stop, 5), poc, "r_mr"
                                cv = OF.cvd_agrees(st, side)
                                s.reasons += [
                                    f"failed {'upside' if kind == 'up' else 'downside'} break to {extreme:.2f}, {len(back)} closes back inside value",
                                    f"pullback into the reclaim leg at {where}",
                                    f"aggression: {ag['why']} ({ag['kind']})",
                                    f"session CVD {'agrees' if cv else 'neutral' if cv is None else 'disagrees'}",
                                    f"stop {stop:.2f} beyond the failed extreme ({dist / pip:.0f} pips) · target POC {poc:.2f} ({rr:.1f}R)",
                                ]
                                return s
    if not s.blockers:
        s.blockers.append("inside value with no failed break, or R modes off")
    return s


# ───────────────────────── scratch rule (trailing hook) ───────────────
_first_seen: dict[int, float] = {}


def scratch_check(io, pos: dict, side: int, entry: float, current: float,
                  risk: float, log=print) -> bool:
    """Fabio: if the footprint loses pressure within 2–3 bars of entry,
    scratch. Only R tickets (order comment 'sklz-a R…'), only inside the
    first SKLZ_R_SCRATCH_BARS+1 minutes, only while the trade has not
    already earned SKLZ_R_SCRATCH_MAX_R (0.3R). Returns True when closed."""
    if os.environ.get("SKLZ_R_SCRATCH", "1") == "0":
        return False
    comment = str(pos.get("comment") or "")
    rest = comment.split(" ", 1)[1] if " " in comment else ""
    if not (comment.startswith("sklz-a")
            and any(t == "R" or t.startswith("R_") for t in rest.upper().split("+"))):
        return False
    tk = int(pos.get("ticket") or 0)
    now = time.time()
    first = _first_seen.setdefault(tk, now)
    bars = _i("SKLZ_R_SCRATCH_BARS", 3)
    if now - first > (bars + 1) * 60:
        return False
    if risk and (current - entry) * side / risk >= _f("SKLZ_R_SCRATCH_MAX_R", 0.3):
        return False
    st, why = OF.load_state()
    if not st:
        return False
    fading, fw = OF.pressure_fading(st, side, bars)
    if not fading:
        return False
    try:
        ok = io.close(pos)
    except Exception as exc:  # noqa: BLE001
        log(f"[r-scratch] {pos.get('symbol')} close failed: {type(exc).__name__}: {exc}")
        return False
    log(f"[r-scratch] {pos.get('symbol')} #{tk} scratched — {fw}")
    return bool(ok)
