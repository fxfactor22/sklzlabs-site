"""SKLZ — cross-market confirmation for gold (v3.33).

From the review: gold and the dollar index move opposite most of the time,
so a gold short wants DXY *reacting from demand*, a gold long wants DXY
*rejecting supply*. When the correlation is not negative the check is
neutral — it never invents a view from an uncorrelated pair.

    SKLZ_XAU_DXY=score|gate|off   (default score)
        score: logs the verdict and adds/subtracts in the quality score
        gate : a gold entry that fails is kept out
    SKLZ_XAU_DXY_SYMBOL           broker name of the dollar index; blank =
                                  auto-detect (USDX, DXY, USDOLLAR, DX ...),
                                  falling back to a synthetic basket of the
                                  majors the engine already trades
    SKLZ_XAU_DXY_MAX_CORR  -0.3   correlation must be at or below this
    SKLZ_XAU_DXY_ATR        0.5   DXY must be within this many H1 ATRs of a
                                  pivot/equal-level in the needed direction

Pure functions take bar lists so they are testable; `check()` does the
terminal reads.
"""
from __future__ import annotations

import math
import os

_CANDIDATES = ("USDX", "DXY", "USDOLLAR", "DX", "USDIDX", "USDINDEX", "DOLLAR")


def mode() -> str:
    return os.environ.get("SKLZ_XAU_DXY", "score").strip().lower() or "score"


def is_gold(symbol: str) -> bool:
    return str(symbol or "").upper().startswith(("XAU", "GOLD"))


def correlation(a: list[float], b: list[float]) -> float | None:
    """Pearson correlation of bar-to-bar returns."""
    n = min(len(a), len(b))
    if n < 12:
        return None
    ra = [(a[i] - a[i - 1]) / a[i - 1] for i in range(len(a) - n + 1, len(a)) if a[i - 1]]
    rb = [(b[i] - b[i - 1]) / b[i - 1] for i in range(len(b) - n + 1, len(b)) if b[i - 1]]
    n = min(len(ra), len(rb))
    if n < 10:
        return None
    ra, rb = ra[-n:], rb[-n:]
    ma, mb = sum(ra) / n, sum(rb) / n
    cov = sum((x - ma) * (y - mb) for x, y in zip(ra, rb))
    va = math.sqrt(sum((x - ma) ** 2 for x in ra))
    vb = math.sqrt(sum((y - mb) ** 2 for y in rb))
    if va == 0 or vb == 0:
        return None
    return cov / (va * vb)


def synthetic_dxy(closes: dict[str, list[float]]) -> list[float] | None:
    """Geometric basket in the ICE weights from whatever majors are present.
    EURUSD 57.6%, USDJPY 13.6%, GBPUSD 11.9%, USDCAD 9.1%, USDSEK 4.2%,
    USDCHF 3.6%. Inverted pairs (XXXUSD) enter with a negative exponent."""
    w = {"EURUSD": -0.576, "USDJPY": 0.136, "GBPUSD": -0.119,
         "USDCAD": 0.091, "USDSEK": 0.042, "USDCHF": 0.036}
    avail = {k: v for k, v in closes.items() if k in w and len(v) >= 20}
    if not avail or "EURUSD" not in avail:
        return None
    n = min(len(v) for v in avail.values())
    tot = sum(abs(w[k]) for k in avail)
    out = []
    for i in range(-n, 0):
        acc = 0.0
        for k, v in avail.items():
            if v[i] <= 0:
                return None
            acc += (w[k] / tot) * math.log(v[i])
        out.append(50.0 * math.exp(acc))
    return out


def level_reaction(h1: list[dict], want: int, atr_mult: float) -> tuple[bool, str]:
    """want=+1: DXY at/near demand with a bullish reaction (for a gold short).
    want=-1: DXY at/near supply with a bearish reaction (for a gold long)."""
    if len(h1) < 30:
        return False, "not enough DXY history"
    from basket_engine.learn.models import _atr, swing_points, _equal_levels
    atr = _atr(h1) or 1e-9
    lows, highs = swing_points(h1[:-1], 2)
    last = h1[-1]
    tol = atr_mult * atr
    if want > 0:
        lv = [p for _, p in lows] + [l for l, _ in _equal_levels(lows, 0.3 * atr, False)]
        near = [l for l in lv if abs(last["low"] - l) <= tol or (last["low"] <= l <= last["high"])]
        bullish = last["close"] > last["open"] and (last["close"] - last["low"]) >= 0.6 * (last["high"] - last["low"] or 1e-9)
        if near and bullish:
            return True, f"DXY reacting from demand at {min(near, key=lambda l: abs(l - last['low'])):.3f}"
        if near:
            return False, "DXY at demand but no bullish reaction yet"
        return False, "DXY is not at a demand level"
    lv = [p for _, p in highs] + [l for l, _ in _equal_levels(highs, 0.3 * atr, True)]
    near = [l for l in lv if abs(last["high"] - l) <= tol or (last["low"] <= l <= last["high"])]
    bearish = last["close"] < last["open"] and (last["high"] - last["close"]) >= 0.6 * (last["high"] - last["low"] or 1e-9)
    if near and bearish:
        return True, f"DXY rejecting supply at {min(near, key=lambda l: abs(l - last['high'])):.3f}"
    if near:
        return False, "DXY at supply but no bearish reaction yet"
    return False, "DXY is not at a supply level"


def judge(gold_closes: list[float], dxy_closes: list[float], dxy_h1: list[dict],
          side: int) -> dict:
    """{ok, score, why, corr}. ok=None means neutral (no opinion)."""
    try:
        max_corr = float(os.environ.get("SKLZ_XAU_DXY_MAX_CORR", "-0.3"))
        atr_mult = float(os.environ.get("SKLZ_XAU_DXY_ATR", "0.5"))
    except ValueError:
        max_corr, atr_mult = -0.3, 0.5
    corr = correlation(gold_closes, dxy_closes)
    if corr is None:
        return {"ok": None, "score": 0, "why": "no correlation sample", "corr": None}
    if corr > max_corr:
        return {"ok": None, "score": 0, "corr": corr,
                "why": f"gold/DXY correlation {corr:+.2f} is not negative enough — no opinion"}
    ok, why = level_reaction(dxy_h1, -side, atr_mult)
    return {"ok": ok, "corr": corr, "score": 10 if ok else -10,
            "why": f"{why} (corr {corr:+.2f})"}


def _resolve_dxy(io, log) -> str | None:
    env = os.environ.get("SKLZ_XAU_DXY_SYMBOL", "").strip()
    cands = [env] if env else list(_CANDIDATES)
    for c in cands:
        try:
            name = io.resolve_symbol(c)
        except Exception:  # noqa: BLE001
            name = None
        if name and io.has_symbol(name):
            return name
    return None


_CACHE: dict = {}


def check(io, symbol: str, side: int, log=print) -> dict | None:
    """Terminal-reading wrapper. None when the module is off or the symbol
    is not gold."""
    if mode() == "off" or not is_gold(symbol):
        return None
    try:
        gold = [b["close"] for b in (io.bars(symbol, 15, 60) or [])]
        dxy_sym = _CACHE.get("sym")
        if "sym" not in _CACHE:
            dxy_sym = _CACHE["sym"] = _resolve_dxy(io, log)
            log(f"[xmkt] dollar index source: {dxy_sym or 'synthetic basket of majors'}")
        if dxy_sym:
            h1 = [{"open": b["open"], "high": b["high"], "low": b["low"], "close": b["close"]}
                  for b in (io.bars(dxy_sym, 60, 60) or [])]
            dxy = [b["close"] for b in (io.bars(dxy_sym, 15, 60) or [])]
        else:
            majors = {}
            h1_majors = {}
            for p in ("EURUSD", "USDJPY", "GBPUSD", "USDCAD", "USDCHF"):
                name = io.resolve_symbol(p) if hasattr(io, "resolve_symbol") else p
                if not name or not io.has_symbol(name):
                    continue
                majors[p] = [b["close"] for b in (io.bars(name, 15, 60) or [])]
                h1_majors[p] = io.bars(name, 60, 60) or []
            dxy = synthetic_dxy(majors)
            if not dxy:
                return None
            # synthetic H1 bars from the basket's H1 closes (OHLC collapsed)
            h1c = synthetic_dxy({k: [b["close"] for b in v] for k, v in h1_majors.items()}) or []
            h1h = synthetic_dxy({k: [b["high"] if k.startswith("USD") else b["low"] for b in v] for k, v in h1_majors.items()}) or h1c
            h1l = synthetic_dxy({k: [b["low"] if k.startswith("USD") else b["high"] for b in v] for k, v in h1_majors.items()}) or h1c
            n = min(len(h1c), len(h1h), len(h1l))
            h1 = [{"open": h1c[i - 1] if i else h1c[i], "high": max(h1h[i], h1c[i]),
                   "low": min(h1l[i], h1c[i]), "close": h1c[i]} for i in range(-n, 0)]
        return judge(gold, dxy, h1, side)
    except Exception as exc:  # noqa: BLE001
        log(f"[xmkt] check failed — {type(exc).__name__}: {exc}")
        return None


# ── v3.35: generic SMT / lead-lag cache (silver -> gold) ─────────────
# A sweep model firing on a LEADER symbol is remembered for SKLZ_XAG_TTL_MIN
# (60). A later setup on the FOLLOWER in the same direction gets +10
# (SKLZ_SMT_SCORE) and model E's `xag` source can trade the follower
# outright. SKLZ_SMT_PAIRS="XAUUSD:XAGUSD" = follower:leader, comma list;
# the 13 Oct MGC-vs-CFD clip is the same mechanism with another pair, if a
# second gold feed ever exists on the terminal.
_SMT: dict[str, dict] = {}
_SWEEP_TAGS = ("d", "e", "g", "k", "l", "x", "p", "c")


def smt_pairs() -> dict[str, str]:
    raw = os.environ.get("SKLZ_SMT_PAIRS", "XAUUSD:XAGUSD")
    out = {}
    for part in raw.split(","):
        if ":" in part:
            f, l = part.split(":", 1)
            if f.strip() and l.strip():
                out[f.strip().upper()] = l.strip().upper()
    return out


def _base(sym: str) -> str:
    return str(sym or "").upper()


def leader_of(symbol: str) -> str | None:
    s = _base(symbol)
    for f, l in smt_pairs().items():
        if s.startswith(f):
            return l
    return None


def is_leader(symbol: str) -> bool:
    s = _base(symbol)
    return any(s.startswith(l) for l in smt_pairs().values())


def note_fire(symbol: str, side: int, tag: str, now: float | None = None) -> None:
    """Remember a sweep-model fire on a leader symbol."""
    import time as _t
    if not is_leader(symbol):
        return
    t = (tag or "").lower()
    if not any(t == x or t.startswith(x + "_") for x in _SWEEP_TAGS):
        return
    _SMT[_base(symbol)[:6]] = {"side": int(side), "tag": t, "t": now if now is not None else _t.time()}


def lead_for(symbol: str, now: float | None = None) -> dict | None:
    """The leader's recent fire for a follower symbol, or None when stale."""
    import time as _t
    l = leader_of(symbol)
    if not l:
        return None
    rec = _SMT.get(l[:6])
    if not rec:
        return None
    try:
        ttl = float(os.environ.get("SKLZ_XAG_TTL_MIN", "60"))
    except ValueError:
        ttl = 60.0
    age = ((now if now is not None else _t.time()) - rec["t"]) / 60.0
    if age > ttl:
        return None
    out = dict(rec)
    out["age_min"] = age
    out["leader"] = l
    return out


def smt_check(io, symbol: str, side: int, log=print) -> dict | None:
    """Score pass for the runner: +SKLZ_SMT_SCORE when the leader swept the
    same way recently and the pair is positively correlated, -score when it
    swept the other way. None when there is nothing to say."""
    lead = lead_for(symbol)
    if not lead:
        return None
    try:
        pts = float(os.environ.get("SKLZ_SMT_SCORE", "10"))
        min_corr = float(os.environ.get("SKLZ_XAG_MIN_CORR", "0.5"))
    except ValueError:
        pts, min_corr = 10.0, 0.5
    corr = None
    try:
        name = io.resolve_symbol(lead["leader"]) if hasattr(io, "resolve_symbol") else lead["leader"]
        a = [b["close"] for b in (io.bars(symbol, 15, 60) or [])]
        b = [b["close"] for b in (io.bars(name, 15, 60) or [])] if name else []
        corr = correlation(a, b)
    except Exception:  # noqa: BLE001
        corr = None
    lead["corr"] = corr
    if corr is not None and corr < min_corr:
        return {"ok": None, "score": 0, "lead": lead,
                "why": f"{lead['leader']} swept but correlation {corr:+.2f} < {min_corr:g} — no opinion"}
    agree = int(lead["side"]) == int(side)
    return {"ok": agree, "score": pts if agree else -pts, "lead": lead,
            "why": f"{lead['leader']} {lead['tag']} fired {'long' if lead['side'] > 0 else 'short'} "
                   f"{lead['age_min']:.0f} min ago" + (f" (corr {corr:+.2f})" if corr is not None else "")
                   + ("" if agree else " — against this entry")}
