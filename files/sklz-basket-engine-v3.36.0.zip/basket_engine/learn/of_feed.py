"""SKLZ — measured order flow for Model R (v3.36).

WHAT THIS IS
============
`orderflow.py` INFERS aggression from MT5 ticks because retail FX has no
aggressor flag. This module works from a feed that HAS one: Binance's
PAXG/USDT spot trade stream carries `m` ("buyer is the market maker"), so
every print is known to be buyer- or seller-initiated. PAXG is tokenised
gold (Paxos, LBMA vaults) and tracks spot gold closely most of the time —
closely enough to read *who is pushing*, not closely enough to copy prices.
So the engine's levels still come from the broker's XAUUSD bars; this feed
supplies only the flow, and a basis / correlation guard stands the model
aside whenever PAXG stops behaving like gold.

Two halves live here so the tests can cover the arithmetic without a socket:

  Footprint   accumulates trades into 1-minute bars of price bins
              (buy volume / sell volume per bin), big prints, stacked
              imbalances, absorption, session CVD — the feed process
              (tools/orderflow_feed.py) owns one and dumps its snapshot to
              SKLZ_OF_STATE every second.
  metrics     pure functions over that snapshot: guards(), aggression(),
              pressure_fading(), cvd_agrees(), map_price() — what model_r
              and the scratch rule call.

Nothing here touches MT5 or the network.
"""
from __future__ import annotations

import json
import math
import os
import statistics
import time
from collections import deque
from dataclasses import dataclass, field

SCHEMA = 1


# ────────────────────────────── settings ──────────────────────────────
def _f(env: str, default: float) -> float:
    try:
        return float(os.environ.get(env, "") or default)
    except ValueError:
        return default


def _i(env: str, default: int) -> int:
    try:
        return int(float(os.environ.get(env, "") or default))
    except ValueError:
        return default


def state_path() -> str:
    return os.environ.get("SKLZ_OF_STATE", "").strip() or "orderflow_state.json"


def bin_size() -> float:
    return _f("SKLZ_OF_BIN", 1.0)


# ────────────────────────────── footprint ─────────────────────────────
@dataclass
class Bar:
    t: int                                    # minute epoch (UTC)
    o: float = 0.0
    h: float = 0.0
    l: float = 0.0
    c: float = 0.0
    v: float = 0.0
    bv: float = 0.0
    sv: float = 0.0
    n: int = 0
    bins: dict = field(default_factory=dict)  # bin_price -> [buy, sell]
    big_buy: int = 0
    big_sell: int = 0
    big_buy_px: float = 0.0                   # price of the LAST big buy print
    big_sell_px: float = 0.0

    @property
    def d(self) -> float:
        return self.bv - self.sv

    def to_dict(self) -> dict:
        return {"t": self.t, "o": self.o, "h": self.h, "l": self.l, "c": self.c,
                "v": round(self.v, 4), "bv": round(self.bv, 4), "sv": round(self.sv, 4),
                "d": round(self.d, 4), "n": self.n,
                "bins": {f"{k:.4f}": [round(a, 4), round(b, 4)] for k, (a, b) in self.bins.items()},
                "big_buy": self.big_buy, "big_sell": self.big_sell,
                "big_buy_px": self.big_buy_px, "big_sell_px": self.big_sell_px}


class Footprint:
    """Trades in, 1-minute footprint bars out. Keep `keep` bars."""

    def __init__(self, bin_sz: float | None = None, keep: int = 180,
                 big_x: float | None = None, median_window: int = 500,
                 session_reset_utc_hour: int | None = None) -> None:
        self.bin = float(bin_sz or bin_size())
        self.keep = keep
        self.big_x = float(big_x if big_x is not None else _f("SKLZ_OF_BIGPRINT_X", 5.0))
        self.bars: deque[Bar] = deque(maxlen=keep)
        self.sizes: deque[float] = deque(maxlen=median_window)
        self.cvd = 0.0
        self.cvd_series: deque[float] = deque(maxlen=120)
        self.reset_hour = int(session_reset_utc_hour if session_reset_utc_hour is not None
                              else _i("SKLZ_DAY_RESET_UTC_HOUR", 21))
        self.session_start = 0
        self.last_trade_ts = 0.0
        self.price = 0.0
        self.trades = 0

    # -- helpers
    def _bin(self, price: float) -> float:
        return math.floor(price / self.bin) * self.bin

    def _session_anchor(self, ts: float) -> int:
        day = int(ts // 86400) * 86400
        anchor = day + self.reset_hour * 3600
        if ts < anchor:
            anchor -= 86400
        return anchor

    def _bar_for(self, ts: float) -> Bar:
        minute = int(ts // 60) * 60
        if self.bars and self.bars[-1].t == minute:
            return self.bars[-1]
        if self.bars and self.bars[-1].t > minute:
            return self.bars[-1]                  # late print: fold into the open bar
        # close the previous bar into the CVD series
        if self.bars:
            self.cvd_series.append(round(self.cvd, 4))
        b = Bar(t=minute)
        self.bars.append(b)
        return b

    # -- input
    def add_trade(self, price: float, qty: float, is_buy: bool, ts: float) -> None:
        """One print. `is_buy` = the aggressor bought (Binance: m == False)."""
        if price <= 0 or qty <= 0:
            return
        anchor = self._session_anchor(ts)
        if anchor != self.session_start:
            self.session_start = anchor
            self.cvd = 0.0
            self.cvd_series.clear()
        b = self._bar_for(ts)
        if b.n == 0:
            b.o = b.h = b.l = price
        b.h = max(b.h, price)
        b.l = min(b.l, price)
        b.c = price
        b.v += qty
        b.n += 1
        slot = b.bins.setdefault(self._bin(price), [0.0, 0.0])
        if is_buy:
            b.bv += qty; slot[0] += qty; self.cvd += qty
        else:
            b.sv += qty; slot[1] += qty; self.cvd -= qty
        # big print against the rolling median size
        if len(self.sizes) >= 50:
            med = statistics.median(self.sizes)
            if med > 0 and qty >= self.big_x * med:
                if is_buy:
                    b.big_buy += 1; b.big_buy_px = price
                else:
                    b.big_sell += 1; b.big_sell_px = price
        self.sizes.append(qty)
        self.last_trade_ts = ts
        self.price = price
        self.trades += 1

    # -- output
    def snapshot(self, mt5: dict | None = None, extra: dict | None = None) -> dict:
        med = statistics.median(self.sizes) if len(self.sizes) >= 10 else 0.0
        out = {"v": SCHEMA, "ts": time.time(), "last_trade_ts": self.last_trade_ts,
               "price": self.price, "bin": self.bin, "trades": self.trades,
               "session_start": self.session_start,
               "cvd": round(self.cvd, 4), "cvd_series": list(self.cvd_series),
               "median_trade": med,
               "bars": [b.to_dict() for b in self.bars]}
        if mt5:
            out["mt5"] = mt5
        if extra:
            out.update(extra)
        return out


# ────────────────────────────── state file ────────────────────────────
def write_state(state: dict, path: str | None = None) -> None:
    """Atomic: write beside, then replace, so a reader never sees half a file."""
    p = path or state_path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(state, fh, separators=(",", ":"))
    os.replace(tmp, p)


def load_state(path: str | None = None, max_age: float | None = None,
               now: float | None = None) -> tuple[dict | None, str]:
    """(state, why). why is '' when fresh, else the reason it is unusable."""
    p = path or state_path()
    age_max = float(max_age if max_age is not None else _f("SKLZ_OF_MAX_AGE_SEC", 5.0))
    try:
        with open(p, encoding="utf-8") as fh:
            st = json.load(fh)
    except FileNotFoundError:
        return None, f"no order-flow state at {p} — is orderflow_feed.py running?"
    except Exception as exc:  # noqa: BLE001
        return None, f"order-flow state unreadable ({type(exc).__name__})"
    if not isinstance(st, dict) or st.get("v") != SCHEMA:
        return None, "order-flow state has the wrong schema"
    t = float(now if now is not None else time.time())
    age = t - float(st.get("ts") or 0)
    if age > age_max:
        return None, f"order-flow state is {age:.0f}s old (max {age_max:g}s)"
    return st, ""


# ────────────────────────────── guards ────────────────────────────────
def guards(state: dict | None, why: str = "") -> tuple[bool, str]:
    """Fail closed: no fresh feed, or a feed that has stopped being gold."""
    if state is None:
        return False, why or "no order-flow state"
    if not state.get("bars"):
        return False, "order-flow feed has no bars yet"
    m = state.get("mt5") or {}
    max_basis = _f("SKLZ_OF_MAX_BASIS_PCT", 0.5)
    min_corr = _f("SKLZ_OF_MIN_CORR", 0.6)
    if m:
        bp = m.get("basis_pct")
        if bp is not None and abs(float(bp)) > max_basis:
            return False, (f"PAXG is {float(bp):+.2f}% from {m.get('symbol', 'XAUUSD')} — "
                           f"beyond the {max_basis:g}% basis guard, flow is not gold's")
        c, n = m.get("corr60"), int(m.get("n") or 0)
        if c is not None and n >= 30 and float(c) < min_corr:
            return False, (f"PAXG/XAUUSD 60-min correlation {float(c):.2f} below "
                           f"{min_corr:g} — proxy decoupled")
    elif os.environ.get("SKLZ_OF_REQUIRE_MT5", "1") != "0":
        return False, "feed has no MT5 reference yet (basis/correlation unknown)"
    return True, ""


def map_price(p: float, state: dict) -> float:
    """PAXG price -> broker XAUUSD price via the rolling basis."""
    m = (state or {}).get("mt5") or {}
    try:
        return float(p) - float(m.get("basis") or 0.0)
    except (TypeError, ValueError):
        return float(p)


# ────────────────────────────── metrics ───────────────────────────────
def _bins(bar: dict) -> list[tuple[float, float, float]]:
    out = []
    for k, (b, s) in (bar.get("bins") or {}).items():
        try:
            out.append((float(k), float(b), float(s)))
        except (TypeError, ValueError):
            continue
    return sorted(out)


def stacked_imbalances(bar: dict, side: int, ratio: float | None = None,
                       stack: int | None = None, bin_sz: float | None = None) -> dict:
    """Footprint diagonal imbalance.

    Long side: buy volume at price p against sell volume one bin LOWER
    (buyers lifting offers vs sellers hitting the bid below). Short side:
    sell volume at p against buy volume one bin HIGHER. An imbalance is a
    ratio >= `ratio` (3.0); `stack` (3) consecutive bins make it stacked.
    """
    r = float(ratio if ratio is not None else _f("SKLZ_OF_IMBALANCE", 3.0))
    need = int(stack if stack is not None else _i("SKLZ_OF_STACK", 3))
    bins = _bins(bar)
    if len(bins) < 2:
        return {"ok": False, "count": 0, "best": 0, "levels": []}
    width = float(bin_sz or bar.get("bin") or (bins[1][0] - bins[0][0]) or 1.0)
    by_px = {round(p / width): (b, s) for p, b, s in bins}
    flags = []
    for p, b, s in bins:
        k = round(p / width)
        if side > 0:
            other = by_px.get(k - 1)
            if other is None:
                continue
            ob = other[1]                          # sells one bin lower
            imb = (b >= r * max(ob, 1e-9)) and b > 0
        else:
            other = by_px.get(k + 1)
            if other is None:
                continue
            ob = other[0]                          # buys one bin higher
            imb = (s >= r * max(ob, 1e-9)) and s > 0
        flags.append((p, imb))
    best = run = 0
    levels = []
    cur = []
    for p, f in flags:
        if f:
            run += 1; cur.append(p)
        else:
            run = 0; cur = []
        if run > best:
            best = run; levels = list(cur)
    return {"ok": best >= need, "count": sum(1 for _, f in flags if f),
            "best": best, "levels": levels}


def absorption(bar: dict, avg_vol: float, atr: float, side: int,
               vol_x: float | None = None, range_atr: float | None = None) -> dict:
    """High volume, small range, delta AGAINST the side that then holds —
    the other side's orders being absorbed. For a long: heavy selling
    (delta < 0) that could not push the close below the open."""
    vx = float(vol_x if vol_x is not None else _f("SKLZ_OF_ABSORB_VOL_X", 2.0))
    ra = float(range_atr if range_atr is not None else _f("SKLZ_OF_ABSORB_RANGE_ATR", 0.3))
    v, d = float(bar.get("v") or 0), float(bar.get("d") or 0)
    rng = float(bar.get("h") or 0) - float(bar.get("l") or 0)
    o, c = float(bar.get("o") or 0), float(bar.get("c") or 0)
    if avg_vol <= 0 or atr <= 0 or v <= 0:
        return {"ok": False}
    heavy = v >= vx * avg_vol
    tight = rng <= ra * atr
    if side > 0:
        held = c >= o and d < 0
    else:
        held = c <= o and d > 0
    return {"ok": heavy and tight and held, "vol_x": round(v / avg_vol, 2),
            "range_atr": round(rng / atr, 2), "delta": d}


def _avg_vol(bars: list[dict], n: int = 20) -> float:
    xs = [float(b.get("v") or 0) for b in bars[-n - 1:-1]]
    return sum(xs) / len(xs) if xs else 0.0


def _atr(bars: list[dict], n: int = 14) -> float:
    xs = [float(b.get("h") or 0) - float(b.get("l") or 0) for b in bars[-n - 1:-1]]
    xs = [x for x in xs if x > 0]
    return sum(xs) / len(xs) if xs else 0.0


def aggression(state: dict, side: int, lookback: int | None = None) -> dict:
    """Is the feed showing aggression in `side`'s direction right now?

    Looks at the open bar and the last `lookback` closed bars (default 3).
    Any ONE of: stacked imbalances in direction; >= 2 big prints in
    direction inside a bar whose delta agrees; absorption of the other
    side. Returns {ok, kind, why, print_px (PAXG), bar_t}.
    """
    lb = int(lookback if lookback is not None else _i("SKLZ_OF_AGGR_BARS", 3))
    bars = state.get("bars") or []
    if not bars:
        return {"ok": False, "why": "no footprint bars"}
    recent = bars[-(lb + 1):]
    avg_v, atr = _avg_vol(bars), _atr(bars)
    for bar in reversed(recent):
        imb = stacked_imbalances(bar, side, bin_sz=state.get("bin"))
        if imb["ok"]:
            px = imb["levels"][-1] if side > 0 else imb["levels"][0]
            return {"ok": True, "kind": "stacked_imbalance",
                    "why": f"{imb['best']} stacked {'buy' if side > 0 else 'sell'} imbalances "
                           f"({'≥' if imb['best'] >= 3 else ''}{imb['best']}x) at {px:.2f}",
                    "print_px": px, "bar_t": bar.get("t")}
        big = int(bar.get("big_buy" if side > 0 else "big_sell") or 0)
        d = float(bar.get("d") or 0)
        if big >= 2 and d * side > 0:
            px = float(bar.get("big_buy_px" if side > 0 else "big_sell_px") or bar.get("c") or 0)
            return {"ok": True, "kind": "big_print",
                    "why": f"{big} big {'buy' if side > 0 else 'sell'} prints, bar delta {d:+.2f}",
                    "print_px": px, "bar_t": bar.get("t")}
        ab = absorption(bar, avg_v, atr, side)
        if ab.get("ok"):
            px = float(bar.get("l" if side > 0 else "h") or 0)
            return {"ok": True, "kind": "absorption",
                    "why": f"absorption: {ab['vol_x']}x volume in {ab['range_atr']}x ATR range, "
                           f"delta {ab['delta']:+.2f} could not move price",
                    "print_px": px, "bar_t": bar.get("t")}
    return {"ok": False, "why": f"no aggression in the last {lb} bars — no trade"}


def cvd_agrees(state: dict, side: int, bars: int = 10) -> bool | None:
    s = state.get("cvd_series") or []
    if len(s) < bars + 1:
        return None
    return (s[-1] - s[-1 - bars]) * side > 0


def pressure_fading(state: dict, side: int, bars: int | None = None) -> tuple[bool, str]:
    """Scratch rule: after entry, the last `bars` CLOSED bars all carry
    delta against the position and show no imbalance in its favour."""
    n = int(bars if bars is not None else _i("SKLZ_R_SCRATCH_BARS", 3))
    closed = (state.get("bars") or [])[:-1]
    if len(closed) < n:
        return False, "not enough bars"
    tail = closed[-n:]
    against = all(float(b.get("d") or 0) * side < 0 for b in tail)
    if not against:
        return False, "flow still mixed"
    for b in tail:
        if stacked_imbalances(b, side, bin_sz=state.get("bin"))["ok"]:
            return False, "an imbalance in our favour is still printing"
    tot = sum(float(b.get("d") or 0) for b in tail)
    return True, f"{n} bars of delta against the position ({tot:+.2f}), no imbalance in our favour"


def leg_profile(state: dict, lo_px: float, hi_px: float, bins: int = 24) -> dict | None:
    """Volume profile of the PAXG prints between two (PAXG) prices, from
    the footprint bins — {buckets, lo, step, poc, lvns}."""
    if hi_px <= lo_px:
        return None
    step = (hi_px - lo_px) / bins
    buckets = [0.0] * bins
    for bar in state.get("bars") or []:
        for p, b, s in _bins(bar):
            if lo_px <= p < hi_px:
                buckets[min(bins - 1, int((p - lo_px) / step))] += b + s
    tot = sum(buckets)
    if tot <= 0:
        return None
    poc_i = max(range(bins), key=lambda i: buckets[i])
    mean = tot / bins
    lvns, run = [], None
    for i, v in enumerate(buckets):
        if v < mean * 0.35:
            if run is None:
                run = [lo_px + i * step, lo_px + (i + 1) * step]
            else:
                run[1] = lo_px + (i + 1) * step
        elif run is not None:
            lvns.append(tuple(run)); run = None
    if run is not None:
        lvns.append(tuple(run))
    return {"buckets": buckets, "lo": lo_px, "step": step,
            "poc": lo_px + (poc_i + 0.5) * step, "lvns": lvns}


# ────────────────────────────── reference (MT5) ───────────────────────
class Reference:
    """Rolling PAXG-vs-XAUUSD basis and 1-minute return correlation,
    fed by the feed process from the broker's mid every few seconds."""

    def __init__(self, symbol: str = "", window_min: int = 60, alpha: float = 0.1) -> None:
        self.symbol = symbol
        self.alpha = alpha
        self.basis: float | None = None
        self.paxg: deque[tuple[int, float]] = deque(maxlen=window_min + 2)
        self.xau: deque[tuple[int, float]] = deque(maxlen=window_min + 2)
        self.last_mid = 0.0
        self.last_ts = 0.0

    def update(self, paxg_px: float, xau_mid: float, ts: float) -> None:
        if paxg_px <= 0 or xau_mid <= 0:
            return
        b = paxg_px - xau_mid
        self.basis = b if self.basis is None else (1 - self.alpha) * self.basis + self.alpha * b
        self.last_mid, self.last_ts = xau_mid, ts
        minute = int(ts // 60) * 60
        for dq, px in ((self.paxg, paxg_px), (self.xau, xau_mid)):
            if dq and dq[-1][0] == minute:
                dq[-1] = (minute, px)
            else:
                dq.append((minute, px))

    def corr(self) -> tuple[float | None, int]:
        n = min(len(self.paxg), len(self.xau))
        if n < 3:
            return None, n
        a = [p for _, p in list(self.paxg)[-n:]]
        b = [p for _, p in list(self.xau)[-n:]]
        ra = [(a[i] - a[i - 1]) / a[i - 1] for i in range(1, n) if a[i - 1]]
        rb = [(b[i] - b[i - 1]) / b[i - 1] for i in range(1, n) if b[i - 1]]
        m = min(len(ra), len(rb))
        if m < 3:
            return None, m
        ra, rb = ra[-m:], rb[-m:]
        ma, mb = sum(ra) / m, sum(rb) / m
        cov = sum((x - ma) * (y - mb) for x, y in zip(ra, rb))
        va = math.sqrt(sum((x - ma) ** 2 for x in ra))
        vb = math.sqrt(sum((y - mb) ** 2 for y in rb))
        if va == 0 or vb == 0:
            return None, m
        return cov / (va * vb), m

    def to_dict(self) -> dict:
        c, n = self.corr()
        mid = self.last_mid
        return {"symbol": self.symbol, "mid": mid, "ts": self.last_ts,
                "basis": round(self.basis, 4) if self.basis is not None else None,
                "basis_pct": round(self.basis / mid * 100, 4) if (self.basis is not None and mid) else None,
                "corr60": round(c, 4) if c is not None else None, "n": n}
