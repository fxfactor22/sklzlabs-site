"""Learning runner — three entry streams + end-of-day review, interactive.

Commands while it runs (type + Enter):
  buy EURUSD your reason here     forced BUY, note = "your reason here"
  sell GBPUSD london sweep        forced SELL with your note
  scan                            run the famous-strategy scanners once now
  auto on / auto off              enable/disable automatic scanner entries
  review                          run the end-of-day AI review right now
  status                          positions + today's tally
  quit                            stop the runner (open trades stay in MT5)

Everything is journaled. The review PROPOSES; it never changes parameters.
"""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.request
from datetime import datetime, timezone

from basket_engine.learn.capture import Journal

# models whose thesis is the liquidity sweep itself — the institutional
# "this is a sweep, not a breakout" flag is not a warning against them
_SWEEP_MODELS = ("D", "E", "G", "K", "L", "X", "P")
from basket_engine.learn.entries import EntryController
from basket_engine.learn.review import summarize, ai_review
from basket_engine.learn.scanners import SCANNERS
from basket_engine.learn import journal_push
from basket_engine.learn import signal_publish
from basket_engine.learn import quality
from basket_engine.learn import trailing


class LearningRunner:
    def __init__(self, io, bot_label: str = "", tf_min=60, lookback=24, risk_pct=0.5,
                 auto=False, symbols=None, log=print) -> None:
        # v3.35.1: SKLZ_JOURNAL_PATH overrides the package-relative default.
        # The tests used to write their fake tickets into the real journal,
        # and that journal shipped inside every release zip.
        path = os.environ.get("SKLZ_JOURNAL_PATH", "").strip() or os.path.join(
            os.path.dirname(__file__), "..", "..", "learning_journal.jsonl")
        self.journal = Journal(path)
        # v3.35: SKLZ_RISK_PCT sets the per-trade risk of the default (risk-
        # based) sizing. Until now it was the constructor default, 0.5, and
        # SKLZ_MAX_RISK_PCT in the bat only capped the equity-proportional
        # mode — so the bat's risk line did nothing on the prop account.
        try:
            risk_pct = float(os.environ.get("SKLZ_RISK_PCT", "") or risk_pct)
        except ValueError:
            pass
        self.ec = EntryController(io, self.journal, tf_min, lookback, risk_pct, log)
        self.io = io
        self.tf_min = tf_min
        self.lookback = lookback
        self.auto = auto
        self._sprd: dict = {}      # per-symbol rolling spread baseline
        self._shadows: list = []   # vetoed model setups being followed
        self.prop = None           # built on first use, once log exists
        self._shadow_tally: dict = {}   # veto -> [would_have_won, would_have_lost]
        self._model_tally: dict = {}    # observed model -> [won, lost, expired]
        # A weeks-long paper trial cannot live in RAM: the VPS restarts for
        # every engine update, and an evaluation that forgets itself on each
        # deploy proves nothing. Record and open paper trades go to disk.
        self._obs_path = os.environ.get("SKLZ_OBSERVE_FILE",
                                        "observe_record.json")
        self._load_observations()
        # symbols to scan — override with SKLZ_SYMBOLS="EURUSD,GBPUSD,XAUUSD,..."
        # unavailable symbols are skipped automatically (io.has_symbol check).
        env_syms = os.environ.get("SKLZ_SYMBOLS", "").strip()
        if symbols:
            self.symbols = symbols
        elif env_syms:
            self.symbols = [s.strip().upper() for s in env_syms.split(",") if s.strip()]
        else:
            self.symbols = [
                # FX majors
                "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD", "NZDUSD",
                # FX crosses
                "EURJPY", "GBPJPY", "EURGBP", "AUDJPY",
                # metals
                "XAUUSD", "XAGUSD",
                # indices
                "US30", "NAS100", "SPX500", "GER40",
                # energy + crypto
                "USOIL", "UKOIL", "BTCUSD", "ETHUSD",
            ]
        self.log = log
        try:
            self.io.log = log      # the order door speaks into the main log
        except Exception:
            pass
        # when each background loop last completed a pass, so the heartbeat
        # can say what is actually running rather than just "alive"
        import time as _time
        self._started_at = _time.time()
        self._last_scan_at = None
        self._last_poll_at = None
        self._last_trail_at = None
        self._scans_done = 0
        # (symbol, side, scanner-set) -> when it last fired. A key is quiet
        # for SKLZ_REENTRY_HOURS (default 4) and then may fire again — v3.29.0
        # and earlier kept a set that never emptied, so on a runner that stays
        # up for days each combination could trade exactly once per restart.
        self._auto_seen: dict = {}
        # why scans did not become entries, since start — `status` prints it
        self._gate_hits: dict = {}
        # --- v1.4.0 remote control (dashboard START/PAUSE) ---
        self.entries_blocked = False
        self._remote_state = None   # None -> announce state on first poll
        # the poller thread reads this, so it must be set before the thread
        # starts — otherwise it falls back to the wrong bot name and silently
        # polls a queue nobody is writing to.
        self.bot_label = bot_label or os.environ.get("SKLZ_BOT_NAME", "")
        t = threading.Thread(target=self._command_loop, daemon=True)
        t.start()
        hb = threading.Thread(target=self._heartbeat_loop, daemon=True)
        hb.start()
        self._journaled_positions: set = set()
        from datetime import datetime as _dt, timezone as _tz
        self._journal_start = _dt.now(_tz.utc)   # only journal trades closed after this
        self._acct_no = ""
        self._server = ""
        try:
            info = self.io.mt5.account_info() if hasattr(self.io, "mt5") else None
            if info:
                self._acct_no = str(info.login)
                self._server = info.server
        except Exception:
            pass
        jt = threading.Thread(target=self._auto_journal_loop, daemon=True)
        jt.start()
        tt = threading.Thread(target=self._trail_loop, daemon=True)
        tt.start()
        st = threading.Thread(target=self._signal_track_loop, daemon=True)
        st.start()
        ow = threading.Thread(target=self._open_watch_loop, daemon=True)
        ow.start()

    # ---- v1.4.0 remote control: poll dashboard command every 30s ----
    def _command_loop(self):
        import time as _time
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("SKLZ_BOT_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        # must match the name telemetry registers under, or dashboard
        # commands and orders will never reach this runner
        bot = getattr(self, "bot_label", "") or os.environ.get("SKLZ_BOT_NAME", "")
        if not bot:
            self.log("[remote] no bot label set — dashboard orders cannot be "
                     "delivered. This is a bug; report it.")
            return
        if not (api and key):
            return                      # telemetry env not set; run local-only
        try:
            poll_secs = max(2, int(os.environ.get("SKLZ_POLL_SECONDS", "5")))
        except ValueError:
            poll_secs = 2
        consecutive_errors = 0
        # one opener reused for every poll — avoids churning through Windows
        # ephemeral ports, which starves the telemetry thread of sockets
        opener = urllib.request.build_opener()
        self.log(f"[remote] command poll every {poll_secs}s")
        while True:
            try:
                from urllib.parse import quote
                acct = {}
                try:
                    acct = self.io.account() or {}
                except Exception:  # noqa: BLE001
                    pass
                req = urllib.request.Request(
                    f"{api}/api/bot/command?bot_name={quote(bot)}"
                    f"&account={quote(str(acct.get('login', '')))}"
                    f"&server={quote(str(acct.get('server', '')))}"
                    f"&runner_id={quote(self._cmd_store().installation_id())}",
                    headers={"Authorization": f"Bearer {key}"})
                with opener.open(req, timeout=30) as resp:
                    r_body = resp.read().decode()
                cmd = (json.loads(r_body).get("command") or "run")
                self._last_poll_at = _time.time()
                for o in (json.loads(r_body).get("orders") or []):
                    self._handle_command(o, api, key)
                if cmd != self._remote_state:
                    self._remote_state = cmd
                    if cmd == "pause":
                        self.auto = False
                        self.entries_blocked = True
                        self.log("[REMOTE] *** PAUSED from dashboard *** "
                                 "auto-trading OFF, no new entries; positions still managed.")
                    else:
                        self.auto = True
                        self.entries_blocked = False
                        self.log("[REMOTE] *** RUNNING from dashboard *** "
                                 "auto-trading ON - scanners may enter. "
                                 "(PAUSE on the dashboard to stop)")
            except Exception:
                consecutive_errors += 1
                # back off on repeated failures so a dead API does not hammer it
                time.sleep(min(30, 3 * consecutive_errors))
                continue
            consecutive_errors = 0
            # fast poll: dashboard orders and START/PAUSE feel immediate.
            # SKLZ_POLL_SECONDS tunes it (default 2s).
            time.sleep(poll_secs)

    # ---- heartbeat: prove the process is alive when nothing is happening ----
    def _heartbeat_loop(self):
        """Print a line every few minutes even when there is nothing to report.

        A trading console that goes quiet is ambiguous — no setups looks the
        same as a frozen process, and the difference matters at 3am with a
        live position open. This makes silence impossible: if the heartbeat
        stops, something is wrong.
        """
        import time as _time
        try:
            every = max(60, int(os.environ.get("SKLZ_HEARTBEAT_SECONDS", "300")))
        except (TypeError, ValueError):
            every = 300

        while True:
            _time.sleep(every)
            try:
                now = _time.time()
                up = now - self._started_at
                hrs, rem = divmod(int(up), 3600)
                mins = rem // 60

                def ago(t):
                    if not t:
                        return "never"
                    s = int(now - t)
                    return f"{s}s ago" if s < 90 else f"{s // 60}m ago"

                try:
                    pos = len(self.io.my_positions())
                except Exception:
                    pos = "?"

                state = "paused" if getattr(self, "entries_blocked", False) else "running"
                self.log(f"[alive] up {hrs}h{mins:02d}m · {state} · "
                         f"{pos} open · scans {self._scans_done} "
                         f"(last {ago(self._last_scan_at)}) · "
                         f"commands {ago(self._last_poll_at)}")
            except Exception:
                # a heartbeat that can crash the process defeats its purpose
                pass

    # ---- research: record every completed trade ----
    def _push_observation(self, rec, exit_price: float, pnl: float,
                          exit_reason: str = "") -> None:
        """Write one finished trade to the research store.

        Failures here are logged and swallowed — losing an observation is bad,
        but blocking the trading loop over it would be worse.
        """
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("INTERNAL_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        if not (api and key):
            return
        ctx = getattr(rec, "context", None) or {}
        if not ctx:
            return
        try:
            from basket_engine.learn import trade_context as TC
            exit_ctx = TC.capture_exit(ctx, exit_price, pnl, exit_reason, self.io)
            failure = TC.classify_failure(ctx, exit_ctx)
            body = {**ctx, **exit_ctx,
                    "failure_category": failure.get("category"),
                    "failure_reasons": failure.get("reasons") or []}
            if failure.get("reasons"):
                self.log(f"[research] {ctx.get('symbol')} "
                         f"{exit_ctx.get('outcome')}: {failure['reasons'][0][:90]}")
            import json as _json, urllib.request as _u
            req = _u.Request(api + "/api/research/observation",
                             data=_json.dumps(body, default=str).encode(),
                             headers={"Authorization": "Bearer " + key,
                                      "Content-Type": "application/json"})
            _u.urlopen(req, timeout=20)
        except Exception as exc:  # noqa: BLE001
            self.log(f"[research] could not store observation: {type(exc).__name__}")

    # ---- institutional order-flow confirmation ----
    def _institutional(self, symbol: str, side: int):
        """Gather what the broker actually provides, then score the breakout.

        Missing inputs are passed through as absent rather than faked — the
        scorer normalises over what it can genuinely see.
        """
        from basket_engine.learn import institutional as INST
        from basket_engine.learn.trailing import pip_size

        spec = self.io.spec(symbol)
        pip = pip_size(symbol, int(spec.get("digits") or 5))

        m15 = self.io.bars(symbol, 15, 150)
        h1 = self.io.bars(symbol, 60, 220)
        d1 = self.io.bars(symbol, 1440, 25)

        # real ClusterDelta volumes if the bridge EA is running, otherwise
        # fall back to inferring delta from tick side
        bridge = None
        try:
            from basket_engine.learn import orderflow as _OF
            b = _OF.read_bridge(symbol, self.io)
            if b.quality == "measured":
                bridge = b
                self.log(f"[inst] delta: {b.note}")
        except Exception:
            pass

        ticks = []
        if bridge is None:
            try:
                ticks = self.io.ticks(symbol, minutes=20)
            except Exception:
                pass
        book = []
        try:
            book = self.io.depth(symbol)
        except Exception:
            pass

        # peer moves for the basket correlation check
        peers = {}
        for peer in INST.CORRELATION.get(symbol.upper()[:6], {}):
            try:
                c = self.io.closes(peer, 15, 8)
                if len(c) >= 2 and c[0]:
                    peers[peer] = (c[-1] - c[0]) / c[0] * 100
            except Exception:
                continue

        return INST.assess(side, symbol, pip, m15, h1, d1,
                           ticks=ticks, book=book, peer_moves=peers,
                           delta_override=bridge)

    # ---- signal outcome tracking: follow every published call ----
    def _signal_track_loop(self):
        import time as _t, json as _json, urllib.request as _u
        _t.sleep(25)
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("INTERNAL_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        if not (api and key):
            return
        try:
            every = max(10, int(os.environ.get("SKLZ_SIGNAL_TRACK_SECONDS", "20")))
        except ValueError:
            every = 20
        while True:
            try:
                req = _u.Request(api + "/api/signals/open",
                                 headers={"Authorization": "Bearer " + key})
                with _u.urlopen(req, timeout=25) as resp:
                    open_sigs = (_json.loads(resp.read().decode()) or {}).get("signals", [])
                for s in open_sigs:
                    sym = s.get("symbol")
                    if not sym:
                        continue
                    try:
                        px = self.io.price(sym, 1)
                    except Exception:
                        continue
                    body = {"signal_id": s.get("id"), "price": px}
                    try:
                        rq = _u.Request(api + "/api/signals/track",
                                        data=_json.dumps(body).encode(),
                                        headers={"Authorization": "Bearer " + key,
                                                 "Content-Type": "application/json"})
                        _u.urlopen(rq, timeout=20)
                    except Exception:
                        pass
            except Exception as exc:
                self.log(f"[sigtrack] {type(exc).__name__}")
            _t.sleep(every)

    # ---- trailing stops: protect and trail every open position ----
    def _trail_loop(self):
        import time as _t
        _t.sleep(15)
        every = 5
        try:
            every = max(2, int(os.environ.get("SKLZ_TRAIL_SECONDS", "5")))
        except ValueError:
            pass
        def _risk_from_journal(ticket):
            # the trade's original stop distance, from its entry row — this
            # survives a restart, which the in-memory cache in trailing.py
            # does not. R-mode trailing measures against it.
            try:
                rows = (self.journal.load_recent(5) if hasattr(self.journal, "load_recent")
                        else self.journal.load_day())
                for r in rows:
                    if r.get("type") == "entry" and r.get("ticket") == ticket:
                        e = float(r.get("entry_price") or 0)
                        sl = float(r.get("sl_price") or 0)
                        return abs(e - sl) if e and sl else None
            except Exception:
                return None
            return None

        while True:
            try:
                trailing.manage(self.io, log=self.log,
                                on_update=self._report_trail,
                                risk_lookup=_risk_from_journal)
            except Exception as exc:
                self.log(f"[trail] {type(exc).__name__}: {exc}")
            _t.sleep(every)

    # ---- v3.33 open-candle straddle (Model O) ----------------------
    def _open_watch_loop(self):
        """Model O: at 09:29:50 America/New_York place a buy-stop above the
        last M1 swing high and a sell-stop below the last swing low on each
        SKLZ_O_SYMBOLS pair; whichever fills during the 09:30 candle is the
        trade (fixed SL/TP, no trailing), the other is cancelled; anything
        unfilled at 09:31:00 is cancelled. One trade per symbol per day."""
        import time as _t
        from datetime import datetime, timezone, timedelta
        try:
            from zoneinfo import ZoneInfo
            ny_tz = ZoneInfo("America/New_York")
        except Exception:  # noqa: BLE001
            if not getattr(self, "_tz_warned", False):
                self._tz_warned = True
                self.log("[open] zoneinfo unavailable — Model O disabled")
                self.log("[open] *** no timezone database: Model O, M orb/london/pre8/aorb and the "
                         "midnight-open check are all OFF. On the VPS run:  pip install tzdata  "
                         "then restart. ***")
            return
        self._pending = getattr(self, "_pending", [])
        done_days: dict[str, str] = {}
        while True:
            try:
                enabled = {x.strip().lower() for x in
                           os.environ.get("SKLZ_MODELS_ENABLED", "a,b,c,d").split(",")}
                if "o" not in enabled or not self.auto or self.entries_blocked:
                    _t.sleep(5); continue
                now = datetime.now(timezone.utc)
                ny = now.astimezone(ny_tz)
                try:
                    hh, mm = [int(x) for x in os.environ.get("SKLZ_O_OPEN_NY", "9:30").split(":")]
                except ValueError:
                    hh, mm = 9, 30
                open_at = ny.replace(hour=hh, minute=mm, second=0, microsecond=0)
                arm_at = open_at - timedelta(seconds=10)
                cancel_at = open_at + timedelta(seconds=int(os.environ.get("SKLZ_O_WINDOW_SEC", "60")))
                # --- tend live pendings ---------------------------------
                if self._pending:
                    self._tend_pending(ny >= cancel_at)
                if ny.weekday() >= 5:
                    _t.sleep(30); continue
                if arm_at <= ny < open_at:
                    syms = [x.strip().upper() for x in
                            os.environ.get("SKLZ_O_SYMBOLS", "US30").split(",") if x.strip()]
                    for sym in syms:
                        key = f"{sym}:{ny.date()}"
                        if done_days.get(sym) == str(ny.date()):
                            continue
                        done_days[sym] = str(ny.date())
                        self._arm_straddle(sym, int(cancel_at.timestamp()))
                    _t.sleep(1); continue
                # sleep smarter: long naps far from the open
                gap = (arm_at - ny).total_seconds()
                if gap < 0:
                    gap = (arm_at + timedelta(days=1) - ny).total_seconds()
                _t.sleep(1 if gap < 90 or self._pending else min(60, max(1, gap - 60)))
            except Exception as exc:  # noqa: BLE001
                self.log(f"[open] {type(exc).__name__}: {exc}")
                _t.sleep(5)

    def _arm_straddle(self, sym: str, expire_epoch: int) -> None:
        from basket_engine.learn import models as MD
        from basket_engine.learn.trailing import pip_size
        name = self.io.resolve_symbol(sym) if hasattr(self.io, "resolve_symbol") else sym
        if not name or not self.io.has_symbol(name):
            self.log(f"[open] {sym}: symbol not available on this broker")
            return
        if self.prop is not None:
            try:
                if not self.prop.check(self.io)["entries_ok"]:
                    self.log(f"[open] {sym}: prop guard has entries blocked — no straddle today")
                    return
            except Exception:  # noqa: BLE001
                pass
        raw = self.io.bars(name, 1, 60) or []
        m1 = [{"open": r["open"], "high": r["high"], "low": r["low"], "close": r["close"],
               "volume": r.get("volume", 0), "time": r.get("time")} for r in raw]
        pip = pip_size(name, self.io.spec(name).get("digits"))
        spread = self.io.spread(name) if hasattr(self.io, "spread") else 0.0
        plan = MD.model_o_plan(m1, pip, spread)
        if not plan.get("ok"):
            self.log(f"[open] {sym}: no straddle — {plan.get('why')}")
            return
        buf = float(os.environ.get("SKLZ_O_BUFFER_PTS", "1")) * pip
        hi, lo = plan["high"] + buf, plan["low"] - buf
        sl_d, tp_d = plan["sl_dist"], plan["tp_dist"]
        self.log(f"[open] {sym}: {plan['why']} (spread {spread / pip:.1f} pts)")
        legs = []
        for side, px in ((1, hi), (-1, lo)):
            res = self.ec.place_pending("model_o", name, side, px,
                                        px - side * sl_d, px + side * tp_d,
                                        "open-candle straddle", expire_epoch)
            if res:
                res.update({"group": f"{name}:{expire_epoch}", "expire": expire_epoch,
                            "fixed_tp": True})
                legs.append(res)
        self._pending.extend(legs)
        if len(legs) == 2:
            self.log(f"[open] {sym}: straddle armed #{legs[0]['ticket']} / #{legs[1]['ticket']} "
                     f"— valid for the opening candle only")

    def _tend_pending(self, window_closed: bool) -> None:
        """Fill -> journal + cancel sibling; expiry -> cancel."""
        from basket_engine.learn import trailing as _tr
        still = []
        for pend in self._pending:
            tk = pend["ticket"]
            pos = self.io.position_for_order(tk) if hasattr(self.io, "position_for_order") else None
            if pos:
                if not pend.get("filled"):
                    pend["filled"] = True
                    rec = self.ec.record_fill(pend, pos)
                    if pend.get("fixed_tp"):
                        _tr.mark_fixed(pos.get("ticket") or tk)
                    try:
                        self._recent_entries[pos.get("symbol", pend["symbol"])] = time.time()
                    except AttributeError:
                        self._recent_entries = {pos.get("symbol", pend["symbol"]): time.time()}
                    # OCO: the sibling leg goes
                    for other in self._pending:
                        if other is not pend and other.get("group") == pend.get("group") \
                                and not other.get("filled"):
                            if self.io.cancel_order(other["ticket"]):
                                other["cancelled"] = True
                                self.log(f"[open] cancelled the other leg #{other['ticket']}")
                continue                       # filled legs leave the list
            if pend.get("cancelled"):
                continue
            alive = self.io.order_alive(tk) if hasattr(self.io, "order_alive") else True
            if not alive:
                continue                       # expired or removed by the broker
            if window_closed or time.time() >= pend.get("expire", 0):
                if self.io.cancel_order(tk):
                    self.log(f"[open] {pend['symbol']}: opening candle passed — cancelled #{tk}")
                    continue
            still.append(pend)
        self._pending = still

    def _cmd_store(self):
        """Durable local record of executed commands. Opened once."""
        st = getattr(self, "_command_store", None)
        if st is None:
            from basket_engine.command_store import CommandStore
            st = self._command_store = CommandStore()
        return st

    def _post_result(self, api: str, key: str, result: dict) -> bool:
        try:
            req = urllib.request.Request(
                f"{api}/api/bot/result",
                data=json.dumps(result).encode(),
                headers={"Authorization": f"Bearer {key}",
                         "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                json.loads(resp.read().decode())
            return True
        except Exception as exc:  # noqa: BLE001
            self.log(f"[REMOTE] result not delivered ({type(exc).__name__}) "
                     f"— stored locally, will resend")
            return False

    def _handle_command(self, o: dict, api: str, key: str) -> None:
        """Execute one command exactly once, whatever the network does.

        The order is deliberate: record the INTENT durably, then touch the
        broker, then record the RESULT. A command already in the store is
        never executed again — its stored result is re-sent instead. That
        is what stops a lost acknowledgement from becoming a second trade.
        """
        import time as _t
        cid = str(o.get("command_id") or "")
        ctype = (o.get("type") or "market").lower()
        received_at = datetime.now(timezone.utc).isoformat()
        store = self._cmd_store()

        if not cid:
            self.log("[REMOTE] command without an id — refusing to execute "
                     "something we cannot deduplicate")
            return

        # already seen? re-send what we recorded; never execute twice
        if store.known(cid):
            prev = store.result_for(cid) or {}
            prev.setdefault("command_id", cid)
            prev.setdefault("runner_id", store.installation_id())
            if prev.get("state") == "unknown":
                # We wrote the intent and never proved the outcome. Saying
                # "failed" would assert the broker did nothing, which we
                # cannot know. It needs a human and the account.
                self.log(f"[REMOTE] command {cid[:8]} OUTCOME UNKNOWN — "
                         f"execution was interrupted. NOT retrying. "
                         f"Check the account before re-issuing.")
            else:
                self.log(f"[REMOTE] command {cid[:8]} already handled — "
                         f"resending stored result, not executing again")
            self._post_result(api, key, prev)
            return

        # TTL: an old market order must not reach a broker at today's price
        exp = o.get("expires_at")
        if exp:
            try:
                if datetime.fromisoformat(
                        str(exp).replace("Z", "+00:00")) < datetime.now(
                            timezone.utc):
                    store.refuse(cid, "expired", ctype)
                    self.log(f"[REMOTE] command {cid[:8]} EXPIRED before "
                             f"execution — not sent to the broker")
                    self._post_result(api, key, {
                        "command_id": cid, "ok": False, "state": "expired",
                        "broker_comment": "expired before execution",
                        "runner_received_at": received_at})
                    return
            except (TypeError, ValueError):
                pass

        if self.entries_blocked and ctype == "market":
            store.refuse(cid, "paused", ctype)
            self.log("[REMOTE] order ignored — paused")
            self._post_result(api, key, {
                "command_id": cid, "ok": False, "state": "failed",
                "broker_comment": "runner paused from the dashboard",
                "runner_received_at": received_at})
            return

        # INTENT lands on disk before anything reaches the broker
        if not store.begin(cid, ctype):
            self.log(f"[REMOTE] command {cid[:8]} claimed by another "
                     f"attempt — not executing")
            return

        acct = {}
        try:
            acct = self.io.account() or {}
        except Exception:  # noqa: BLE001
            pass
        result = {"command_id": cid, "ok": False, "state": "failed",
                  "runner_received_at": received_at,
                  "runner_id": store.installation_id(),
                  "account": str(acct.get("login", "")),
                  "server": str(acct.get("server", "")),
                  "mt5_requested_at": datetime.now(timezone.utc).isoformat()}

        try:
            if ctype == "market":
                result.update(self._cmd_market(o))
            elif ctype == "close":
                result.update(self._cmd_close(o))
            elif ctype == "modify":
                result.update(self._cmd_modify(o))
            elif ctype == "positions":
                result.update(self._cmd_positions(o))
            elif ctype == "breakeven":
                result.update(self._cmd_breakeven(o))
            else:
                result["broker_comment"] = f"unknown command type {ctype}"
        except Exception as exc:  # noqa: BLE001
            result["broker_comment"] = f"{type(exc).__name__}: {exc}"[:300]
            self.log(f"[REMOTE] command {cid[:8]} raised: {exc}")

        result["broker_confirmed_at"] = datetime.now(timezone.utc).isoformat()
        store.finish(cid, result)          # RESULT lands on disk
        self._post_result(api, key, result)

    def _cmd_market(self, o: dict) -> dict:
        """Place the order, falling back when the primary market is shut.

        A cold lead is most likely to open a demo link at a weekend, when
        forex is closed. The Runner is the only place that knows what is
        tradable right now, so the fallback decision lives here rather
        than in a server guessing from the clock.
        """
        side = +1 if o.get("side") == "buy" else -1
        sym = o.get("symbol", "")
        fallback = os.environ.get("SKLZ_DEMO_FALLBACK_SYMBOL", "").strip()
        if fallback and sym and not self._tradable(sym):
            self.log(f"[REMOTE] {sym} is not tradable now — falling back "
                     f"to {fallback}")
            sym = fallback
            o = dict(o, symbol=sym)
        self.log(f"[REMOTE] dashboard order: {o.get('side','?').upper()} "
                 f"{sym} — {o.get('note','')}")
        rec = self.ec.forced_custom(
            sym, side, "[dashboard] " + (o.get("note") or "manual"),
            lots=float(o.get("lots") or 0),
            sl=float(o.get("sl") or 0), tp=float(o.get("tp") or 0))
        if not rec:
            self.log("[signal] not published — the entry did not fill")
            return {"ok": False, "state": "failed",
                    "broker_comment": "entry did not fill"}

        # EntryRecord's price field is `entry_price`, not `price`. Reading
        # the wrong name returned 0, so every dashboard order reported a
        # ticket with no fill price — the one number a trader looks for.
        fill = {}
        try:
            fill = (getattr(rec, "state", {}) or {}).get("fill", {}) or {}
        except Exception:  # noqa: BLE001
            fill = {}
        price = float(getattr(rec, "entry_price", 0) or 0) or None
        out = {"ok": True, "state": "succeeded",
               "ticket": int(getattr(rec, "ticket", 0) or 0) or None,
               "fill_price": price or (fill.get("price") or None),
               "filled_volume": float(fill.get("volume")
                                      or getattr(rec, "lots", 0) or 0) or None,
               "retcode": fill.get("retcode"),
               "broker_comment": (fill.get("comment") or "")[:300],
               "resolved_symbol": getattr(rec, "symbol", sym)}

        # mode governs what else happens. The default preserves exactly
        # today's behaviour for every existing caller.
        mode = (o.get("mode") or "execute_signal_copy").lower()
        if mode in ("execute_signal", "execute_signal_copy"):
            try:
                signal_publish.publish(
                    self.io, sym, side, "manual entry",
                    (o.get("note") or "trader entry"),
                    self.tf_min, log=self.log, force=True)
            except Exception as exc:  # noqa: BLE001
                self.log(f"[signal] error: {exc}")
        return out

    def _tradable(self, symbol: str) -> bool:
        """Can this symbol be bought right now, on this account?

        Checks the broker's own answer — selectable, full trade mode, and
        a live tick — rather than inferring from the time of day.
        """
        try:
            spec = self.io.spec(symbol)
            if not spec:
                return False
            if not self.io.market_live(symbol):
                return False
            mode = spec.get("trade_mode")
            if mode is not None and int(mode) not in (4,):
                return False
        except Exception:  # noqa: BLE001
            return False
        return True

    def _position_by_ticket(self, ticket: int) -> dict | None:
        for p in (self.io.my_positions() or []):
            if int(p.get("ticket", 0)) == int(ticket):
                return p
        return None

    def _cmd_close(self, o: dict) -> dict:
        tk = int(o.get("ticket") or 0)
        pos = self._position_by_ticket(tk) if tk else None
        if not pos:
            return {"ok": False, "state": "failed",
                    "broker_comment": f"no open position with ticket {tk}"}
        ok = self.io.close(pos)
        self.log(f"[REMOTE] close {pos.get('symbol')} ticket {tk} -> "
                 f"{'OK' if ok else 'FAILED'}")
        return {"ok": bool(ok), "state": "succeeded" if ok else "failed",
                "ticket": tk, "resolved_symbol": pos.get("symbol", ""),
                "broker_comment": "" if ok else "broker refused the close"}

    def _cmd_positions(self, o: dict) -> dict:
        """Read-only. What the broker currently holds.

        Needed so the desk can show a stop the TRAILING engine moved.
        Trailing sets the stop at the broker, so the only honest source
        for its current value is the broker itself — not a number the
        API remembers from when the order was placed.
        """
        want = int(o.get("ticket") or 0)
        rows = []
        try:
            for p in (self.io.my_positions() or []):
                if want and int(p.get("ticket") or 0) != want:
                    continue
                # my_positions() returns side/lots/open_price — NOT the
                # raw MT5 field names. Reading type/volume/price_open gave
                # zeros for every field, the same way rec.price did.
                rows.append({
                    "ticket": int(p.get("ticket") or 0),
                    "symbol": p.get("symbol", ""),
                    "side": "buy" if int(p.get("side", 0)) > 0 else "sell",
                    "volume": float(p.get("lots") or 0),
                    "entry": float(p.get("open_price") or 0),
                    "sl": float(p.get("sl") or 0),
                    "tp": float(p.get("tp") or 0),
                    "profit": float(p.get("profit") or 0)})
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "state": "failed",
                    "broker_comment": f"could not read positions: {exc}"[:200]}
        return {"ok": True, "state": "succeeded", "positions": rows,
                "resolved_symbol": rows[0]["symbol"] if rows else ""}

    def _cmd_modify(self, o: dict) -> dict:
        tk = int(o.get("ticket") or 0)
        pos = self._position_by_ticket(tk) if tk else None
        if not pos:
            return {"ok": False, "state": "failed",
                    "broker_comment": f"no open position with ticket {tk}"}
        # 0 means LEAVE UNCHANGED for both levels. modify_sl() sends the
        # stop verbatim, so a dashboard "set TP only" arriving as sl=0
        # would have REMOVED the stop from a live position.
        sl = float(o.get("sl") or 0) or float(pos.get("sl") or 0)
        tp = float(o.get("tp") or 0)
        if not sl:
            return {"ok": False, "state": "failed",
                    "broker_comment": "no stop given and the position has "
                                      "none — refusing to leave it naked"}
        ok = self.io.modify_sl(tk, sl, tp or None)
        self.log(f"[REMOTE] modify ticket {tk} SL={sl} TP={tp} -> "
                 f"{'OK' if ok else 'FAILED'}")
        return {"ok": bool(ok), "state": "succeeded" if ok else "failed",
                "ticket": tk, "resolved_symbol": pos.get("symbol", ""),
                "broker_comment": "" if ok else "broker refused the change"}

    def _cmd_breakeven(self, o: dict) -> dict:
        """Stop to the position's ACTUAL entry, never a client-supplied one."""
        tk = int(o.get("ticket") or 0)
        pos = self._position_by_ticket(tk) if tk else None
        if not pos:
            return {"ok": False, "state": "failed",
                    "broker_comment": f"no open position with ticket {tk}"}
        entry = float(pos.get("open_price") or 0)
        if entry <= 0:
            return {"ok": False, "state": "failed",
                    "broker_comment": "broker did not report an entry price"}
        side = int(pos.get("side", 0))
        from basket_engine.learn.trailing import pip_size
        pip = pip_size(pos.get("symbol", ""),
                       self.io.spec(pos.get("symbol", "")).get("digits"))
        offset = float(o.get("offset_pips") or 0) * pip
        new_sl = entry + offset if side > 0 else entry - offset
        ok = self.io.modify_sl(tk, round(new_sl, 6), None)
        self.log(f"[REMOTE] breakeven ticket {tk} -> SL {new_sl:.6f} "
                 f"{'OK' if ok else 'FAILED'}")
        return {"ok": bool(ok), "state": "succeeded" if ok else "failed",
                "ticket": tk, "resolved_symbol": pos.get("symbol", ""),
                "fill_price": entry,
                "broker_comment": "" if ok else "broker refused the stop"}

    def _report_trail(self, ev: dict) -> None:
        """Publish a stop move to the update board + Telegram."""
        import json as _json, urllib.request as _u
        api = os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = os.environ.get("INTERNAL_KEY", "") or os.environ.get("BOT_INGEST_KEY", "")
        if not (api and key):
            return
        secured = "secured" in ev.get("reason", "")

        # the published signal follows the position: once the stop is in
        # profit, subscribers see "secured" on the site next to their entry
        if secured:
            try:
                side_n = 1 if str(ev.get("side", "")).lower() in ("buy", "1") else -1
                signal_publish.update_status(
                    ev["symbol"], side_n, "secured",
                    pips=ev.get("locked_pips"), log=self.log)
            except Exception:
                pass

        body = {
            "kind": "secured" if secured else "trail",
            "symbol": ev["symbol"], "side": ev["side"],
            "ticket": str(ev.get("ticket", "")),
            "headline": (f"{ev['symbol']} secured — this trade can no longer lose"
                         if secured else f"Stop trailed on {ev['symbol']}"),
            "detail": ("Stop moved into profit. Worst case on this position is "
                       "now a win." if secured else
                       "Following price up while the move continues."),
            "old_sl": ev.get("old_sl") or None,
            "new_sl": ev.get("new_sl"),
            "locked_pips": ev.get("locked_pips"),
            "price": ev.get("price"),
            "broadcast": True,
        }
        try:
            req = _u.Request(api + "/api/updates/bot",
                             data=_json.dumps(body).encode(),
                             headers={"Authorization": "Bearer " + key,
                                      "Content-Type": "application/json"})
            _u.urlopen(req, timeout=20)
        except Exception as exc:
            self.log(f"[trail] could not publish update: {type(exc).__name__}")

    # ---- live auto-journal: push ANY closed trade on the account ----
    def _auto_journal_loop(self):
        import time as _t
        _t.sleep(20)                       # let MT5 settle after startup
        while True:
            try:
                self._push_closed_trades()
            except Exception as exc:
                self.log(f"[auto-journal] {type(exc).__name__}: {exc}")
            _t.sleep(int(os.environ.get("SKLZ_JOURNAL_SECONDS", "45")))

    def _classify_source(self, comment: str) -> str:
        c = (comment or "").lower()
        if "dashboard" in c:
            return "dashboard"
        if "sklz-forced" in c or "sklz-auto" in c or "sklz-" in c:
            return "bot"
        return "manual"                    # opened directly in MT5

    def _push_closed_trades(self):
        if not hasattr(self.io, "closed_trades_since"):
            return
        trades = self.io.closed_trades_since(minutes=1440)
        # dedup is handled permanently server-side by position_id, so we simply
        # push everything in the window; the API rejects anything already journaled.
        fresh = [t for t in trades
                 if t["position_id"] not in self._journaled_positions]
        if not fresh:
            return
        import json as _json, os as _os, urllib.request as _u
        api = _os.environ.get("SKLZ_API_URL", "").rstrip("/")
        key = _os.environ.get("BOT_INGEST_KEY", "") or _os.environ.get("SKLZ_BOT_KEY", "")
        uid = _os.environ.get("SKLZ_USER_ID", "")
        if not (api and key and uid):
            return
        payload = [{
            "symbol": t["symbol"],
            "side": "buy" if t["side"] > 0 else "sell",
            "entry_price": t["entry_price"], "exit_price": t["exit_price"],
            "lots": t["lots"], "pnl": t["pnl"],
            "opened_at": t["opened_at"], "closed_at": t["closed_at"],
            "setup": self._classify_source(t.get("comment")),
            "reason": t.get("comment") or "",
            "source": self._classify_source(t.get("comment")),
            "tags": [self._classify_source(t.get("comment")), "auto-journal"],
            "position_id": str(t.get("position_id", "")),
        } for t in fresh]
        try:
            body = _json.dumps({"user_id": uid, "trades": payload, "account_no": self._acct_no, "server": self._server}).encode()
            req = _u.Request(api + "/api/journal/ingest", data=body,
                             headers={"Content-Type": "application/json",
                                      "Authorization": "Bearer " + key})
            with _u.urlopen(req, timeout=30) as resp:
                res = _json.loads(resp.read().decode())
            for t in fresh:
                self._journaled_positions.add(t["position_id"])
            self.log(f"[auto-journal] pushed {res.get('ingested', len(fresh))} "
                     f"closed trade(s) to your journal")
        except Exception as exc:
            # The server's real reason lives in the response BODY. Logging
            # only "HTTP Error 500" is why this took a night: two different
            # call sites push to the same endpoint and only one of them
            # was ever taught to read the answer.
            detail = ""
            try:
                detail = exc.read().decode()[:400]  # type: ignore[attr-defined]
            except Exception:
                pass
            self.log(f"[auto-journal] push failed: {type(exc).__name__}: {exc}"
                     + (f" — server said: {detail}" if detail else ""))

    # ---- forced ----
    def cmd_buy(self, parts):  self._forced(+1, parts)
    def cmd_sell(self, parts): self._forced(-1, parts)
    def _forced(self, side, parts):
        if len(parts) < 2:
            self.log("usage: buy SYMBOL your reason for the entry"); return
        if self.entries_blocked:
            self.log("Entries are PAUSED from the dashboard. Press START there to resume.")
            return
        symbol = parts[1].upper()
        note = " ".join(parts[2:]) or "manual"
        rec = self.ec.forced_entry(symbol, side, note)
        if not rec:
            self.log("[signal] not published — the entry did not fill")
            return
        try:
            signal_publish.publish(self.io, symbol, side, "manual entry", note,
                                   self.tf_min, log=self.log, force=True)
        except Exception as exc:
            self.log(f"[signal] error: {exc}")



    def _resolve_shadows(self) -> None:
        """Follow each vetoed setup to its stop (-1R) or 2R target.

        Deliberately coarse: current price only, first-touch wins, expiry
        after 12 hours. The question is not exact P&L — it is whether a veto
        class is blocking winners or losers, and at that granularity this is
        enough.
        """
        if not self._shadows:
            return
        import time as _t
        keep = []
        for s in self._shadows:
            try:
                px = self.io.price(s["sym"], -s["side"])   # exit side price
            except Exception:
                px = 0.0
            if not px:
                keep.append(s)
                continue
            won = (px >= s["target"] if s["side"] > 0 else px <= s["target"])
            lost = (px <= s["stop"] if s["side"] > 0 else px >= s["stop"])
            expired = _t.time() - s["t"] > 12 * 3600
            if won or lost or expired:
                if s.get("kind") == "observe":
                    tag = s["model"]
                    w, l, x = self._model_tally.get(tag, [0, 0, 0])
                    if won:
                        w += 1
                    elif lost:
                        l += 1
                    else:
                        x += 1
                    self._model_tally[tag] = [w, l, x]
                    n = w + l
                    verdict = ("hit 2R" if won else "hit the stop" if lost
                               else "expired unresolved")
                    self.log(f"[observe] {s['sym']} model_{tag} paper trade "
                             f"{verdict}. Record: {w}W / {l}L of {n} "
                             f"resolved" + (f" ({w / n * 100:.0f}%)"
                                            if n else ""))
                    self._save_observations()
                    continue
                # The veto text carries live prices and percentages, so
                # "high-volume node (1.38311)" and "(112.33556)" tallied as
                # two different vetoes — every row read n=1 and no veto
                # could ever accumulate evidence. Strip the specifics and
                # the same veto finally counts as itself.
                import re as _re
                key = _re.sub(r"\s*\([^)]*\)", "", s["veto"])
                key = _re.sub(r"\b\d+(\.\d+)?%?", "N", key).strip()
                w, l = self._shadow_tally.get(key, [0, 0])
                if won:
                    w += 1
                elif lost:
                    l += 1
                # expiry with neither touched counts as neither
                self._shadow_tally[key] = [w, l]
                verdict = ("would have hit 2R" if won
                           else "would have hit the stop" if lost
                           else "expired unresolved")
                self.log(f"[shadow] {s['sym']} model_{s['model']} vetoed by "
                         f"{key} — {verdict}. Tally for this veto: "
                         f"{self._shadow_tally[key][0]}W blocked / "
                         f"{self._shadow_tally[key][1]}L saved")
            else:
                keep.append(s)
        self._shadows = keep

    # ---- structured entry models ----
    def _gate(self, why: str) -> None:
        self._gate_hits[why] = self._gate_hits.get(why, 0) + 1

    def _run_models(self, sym: str):
        """Model A (M15 break-retest) and Model B (HTF block, fib 50).

        Both need several timeframes at once, so this pulls them together and
        hands them over. Failures are swallowed deliberately: a model that
        cannot get its data should not stop the scanners that can.
        """
        if os.environ.get("SKLZ_MODELS", "1") == "0":
            return None
        try:
            from basket_engine.learn import models as MD
            from basket_engine.learn.trailing import pip_size

            def bars(tf, n):
                rows = self.io.bars(sym, tf, n) or []
                # mt5io returns "volume"; asking for "tick_volume" here
                # silently fed every model a flat zero — which the POC
                # model would have read as a featureless profile.
                return [{"open": r["open"], "high": r["high"],
                         "low": r["low"], "close": r["close"],
                         "volume": r.get("volume", r.get("tick_volume", 0)),
                         "time": r.get("time")}
                        for r in rows]

            m5 = bars(5, 120)
            m15 = bars(15, 120)    # H needs EMA50 to settle
            h1 = bars(60, 160)     # J needs EMA100; E needs two sessions
            h4 = bars(240, 30)
            if len(m5) < 40 or len(m15) < 20:
                return None

            # frames only the newer models want — fetched when one of them
            # is switched on, so the default scan costs nothing extra
            want = {x.strip().lower() for x in (
                os.environ.get("SKLZ_MODELS_ENABLED", "a,b,c,d") + ","
                + os.environ.get("SKLZ_MODELS_OBSERVE", "e,f")).split(",")}
            extra = {"symbol": sym}
            if ("l" in want and os.environ.get("SKLZ_L_TF", "1") == "1") or "p" in want:
                extra["m1"] = bars(1, 300)
            if "m" in want:
                extra["m10"] = bars(10, 160)
                extra["m2"] = bars(2, 60)
                extra["m5"] = bars(5, 200)        # orb / london boxes need the open
            if "n" in want:
                extra["m5_long"] = bars(5, 700)
            if "q" in want or os.environ.get("SKLZ_C_TRIGGER", "fvg") != "fvg":
                extra["m30"] = bars(30, 260)       # Q needs EMA200; C's ob trigger needs the range bar
            if "m" in want:
                extra["h4"] = h4
                if "aorb" in os.environ.get("SKLZ_M_BOX", "day").lower() or \
                        os.environ.get("SKLZ_M_BOX", "day").strip().lower() in ("all", "*"):
                    extra["m3"] = bars(3, 80)         # v3.35 aorb: Hull MA bias
            # v3.35: silver-led gold (model E `xag`) — the leader's recent fire
            try:
                from basket_engine.learn import xmarket as _xmk
                _lead = _xmk.lead_for(sym)
                if _lead:
                    _sc = _xmk.smt_check(self.io, sym, _lead["side"], log=self.log)
                    extra["xag_lead"] = (_sc or {}).get("lead") or _lead
            except Exception:  # noqa: BLE001
                pass

            pip = pip_size(sym, self.io.spec(sym).get("digits"))
            s = MD.evaluate(m15, m5, h1, h4, pip, extra)

            # ARMED SETUPS (v3.34.1). A model's own trigger is a moment —
            # "price is in the gap now", "RSI turning now" — while the
            # entry rule (body close -> retest -> engulfing) completes
            # minutes later. Without a memory the two almost never
            # coincide, and v3.34.0 placed no trades. So a model that
            # fired stays ARMED for SKLZ_ARM_MINUTES (90) as long as price
            # is still on the right side of its line and within the
            # no-chase distance; the entry rule then completes against it.
            cache = getattr(self, "_armed", None)
            if cache is None:
                cache = self._armed = {}
            try:
                arm_min = float(os.environ.get("SKLZ_ARM_MINUTES", "180"))
            except ValueError:
                arm_min = 90.0
            if s.ok:
                cache[sym] = {"setup": s, "t": time.time(), "entry": s.entry}
                self.log(f"[model] {sym} {s.model} — "
                         f"{'BUY' if s.side > 0 else 'SELL'} @ {s.entry:.5f}")
                try:                                   # v3.35: leader fires feed the SMT cache
                    from basket_engine.learn import xmarket as _xmk
                    _xmk.note_fire(sym, s.side, (getattr(s, "tag", "") or s.model[0]).lower())
                except Exception:  # noqa: BLE001
                    pass
                for r in s.reasons:
                    self.log(f"[model]   + {r}")
            else:
                arm = cache.get(sym)
                if arm and arm_min > 0 and time.time() - arm["t"] <= arm_min * 60:
                    a = arm["setup"]
                    last_close = m5[-1]["close"]
                    atr5 = MD._atr(m5[-40:]) or pip
                    try:
                        chase = float(os.environ.get("SKLZ_NO_CHASE_ATR", "1.5"))
                    except ValueError:
                        chase = 1.5
                    right_side = (last_close > a.level) if a.side > 0 else (last_close < a.level) if a.level else True
                    stopped = (last_close <= a.stop) if a.side > 0 else (last_close >= a.stop) if a.stop else False
                    near = abs(last_close - (a.level or a.entry)) <= chase * atr5 * 1.5
                    if right_side and not stopped and near:
                        if not getattr(a, "_armed_note", False):
                            a._armed_note = True
                        s = a                       # keep the armed setup alive for the gate
                        if os.environ.get("SKLZ_MODEL_VERBOSE", "0") == "1":
                            self.log(f"[model] {sym} {a.model} armed "
                                     f"{(time.time() - arm['t']) / 60:.0f} min — waiting for the entry rule")
                    else:
                        cache.pop(sym, None)
                        why = "stopped out" if stopped else "price left the line" if not near else "wrong side of the line"
                        self.log(f"[model] {sym} {a.model} disarmed — {why}")
                        if s.blockers and os.environ.get("SKLZ_MODEL_VERBOSE", "0") == "1":
                            self.log(f"[model] {sym} {s.model} not ready — {s.blockers[0]}")
                elif arm:
                    cache.pop(sym, None)
                    self.log(f"[model] {sym} {arm['setup'].model} disarmed — {arm_min:.0f} min passed")
                elif s.blockers and os.environ.get("SKLZ_MODEL_VERBOSE", "0") == "1":
                    self.log(f"[model] {sym} {s.model} not ready — {s.blockers[0]}")

            # OBSERVED MODELS. New strategies enter the engine on paper
            # first: they fire, they are logged, they are followed to 2R or
            # their stop — and they never touch an account until their own
            # record earns it. A claimed 85% win rate is a marketing number
            # until this tally disagrees with it.
            self._observe_models(sym, MD, m15, m5, h1, h4, pip, extra)
            return s
        except Exception as exc:  # noqa: BLE001
            if os.environ.get("SKLZ_MODEL_VERBOSE", "0") == "1":
                self.log(f"[model] {sym} error: {type(exc).__name__}: {exc}")
            return None

    def _observe_models(self, sym, MD, m15, m5, h1, h4, pip, extra=None) -> None:
        """Run tagged models in paper mode and register their trades."""
        raw = os.environ.get("SKLZ_MODELS_OBSERVE", "e,f")
        watch = {x.strip().lower() for x in raw.split(",") if x.strip()}
        if not watch:
            return
        traded = {x.strip().lower() for x in
                  os.environ.get("SKLZ_MODELS_ENABLED", "a,b,c,d").split(",")}
        for tag in sorted(watch - traded):
            fn = getattr(MD, f"model_{tag}", None)
            if fn is None:
                continue
            try:
                st = MD.call_model(tag, m15, m5, h1, h4, pip, extra)
            except Exception:
                continue
            if not st.ok:
                continue
            # one open paper trade per symbol per model — the same setup
            # narrates on every scan and must not be counted twice
            key = f"{sym}:{tag}"
            if any(x.get("pkey") == key for x in self._shadows):
                continue
            rr = abs(st.entry - st.stop)
            if rr <= 0 or len(self._shadows) >= 80:
                continue
            self._shadows.append({
                "sym": sym, "side": st.side, "entry": st.entry,
                "stop": st.stop, "target": st.entry + st.side * 2 * rr,
                "veto": f"OBSERVE model_{tag.upper()}",
                "model": tag.upper(), "kind": "observe", "pkey": key,
                "t": time.time()})
            self.log(f"[observe] {sym} {st.model} — "
                     f"{'BUY' if st.side > 0 else 'SELL'} @ {st.entry:.5f} "
                     f"SL {st.stop:.5f} · PAPER ONLY, tracked to 2R or stop")
            for rsn in st.reasons:
                self.log(f"[observe]   + {rsn}")
            self._save_observations()

    def _load_observations(self) -> None:
        try:
            import json
            with open(self._obs_path, encoding="utf-8") as fh:
                d = json.load(fh)
            self._model_tally = {k: list(v) for k, v in
                                 (d.get("tally") or {}).items()}
            live = [x for x in (d.get("open") or [])
                    if isinstance(x, dict) and x.get("kind") == "observe"]
            self._shadows.extend(live)
            if self._model_tally or live:
                self.log(f"[observe] record restored — "
                         f"{len(self._model_tally)} model(s) tracked, "
                         f"{len(live)} paper trade(s) still open")
        except Exception:
            pass

    def _save_observations(self) -> None:
        try:
            import json
            live = [x for x in self._shadows if x.get("kind") == "observe"]
            tmp = self._obs_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"tally": self._model_tally, "open": live}, fh)
            os.replace(tmp, self._obs_path)
        except Exception:
            pass

    def model_scoreboard(self) -> None:
        """Print the paper record of every observed model."""
        live = [x for x in self._shadows if x.get("kind") == "observe"]
        if not self._model_tally and not live:
            print("no observed model has resolved a paper trade yet")
            return
        print(f"OBSERVED MODEL SCOREBOARD ({len(live)} paper trade(s) open):")
        for tag, (w, l, x) in sorted(self._model_tally.items()):
            n = w + l
            rate = f"{w / n * 100:.0f}%" if n else "n/a"
            print(f"  model_{tag}: {w}W / {l}L of {n} resolved "
                  f"({rate} at 2R) · {x} expired unresolved")
        if not self._model_tally:
            print("  (none resolved yet — paper trades still running)")

    # ---- scanners ----
    def scan_once(self) -> int:
        import time as _t
        self._scans_done += 1
        self._last_scan_at = _t.time()
        n = 0
        # owner's blocklist: symbols here never scan, never model, never
        # enter automatically. Forced entries stay possible — an explicit
        # human command outranks the list. Silver earned the first seat
        # after its risk profile kept reading hot on the funded account.
        _blocked = {s.strip().upper() for s in
                    os.environ.get("SKLZ_BLOCKED_SYMBOLS", "").split(",")
                    if s.strip()}
        for sym in self.symbols:
            if sym.upper() in _blocked or any(
                    sym.upper().startswith(b) for b in _blocked):
                continue
            if not self.io.has_symbol(sym):
                continue
            # market-open guard: never scan on frozen weekend/closed data
            if hasattr(self.io, "market_live") and not self.io.market_live(sym):
                continue
            # gather EVERY scanner hit for this symbol first, then judge quality
            self._resolve_shadows()

            # the prop circuit breaker outranks every other opinion in this
            # loop — a perfect setup on a breached account is worth nothing
            if self.prop is None:
                from basket_engine.learn.prop_guard import PropGuard
                self.prop = PropGuard(log=self.log)
            _pg = self.prop.check(self.io)
            if not _pg["entries_ok"]:
                # This runs per symbol, so one blocked scan wrote the same
                # sentence fifteen times and buried everything else in the
                # log. Say it once, and again only when the reason changes
                # or five minutes have passed.
                if _pg["reason"] not in ("soft stop active",
                                         "halted until the next trading day"):
                    last = getattr(self, "_last_prop_msg", ("", 0.0))
                    now_ts = time.time()
                    if last[0] != _pg["reason"] or now_ts - last[1] > 300:
                        self.log(f"[prop] entries blocked — {_pg['reason']}")
                        self._last_prop_msg = (_pg["reason"], now_ts)
                hits = []
                continue

            hits = []
            for name, fn in SCANNERS.items():
                sig = fn(self.io, sym, self.tf_min, self.lookback)
                if sig:
                    hits.append((name, sig[0], sig[1]))

            # The two structured models run alongside the scanners rather than
            # replacing them. They are stricter — a specific sequence must
            # occur — so when one fires it carries more information than a
            # scanner hit, and it is added as its own vote.
            model_setup = self._run_models(sym)
            if model_setup and model_setup.ok:
                _mtag = (getattr(model_setup, "tag", "") or model_setup.model[0]).lower()
                hits.append((f"model_{_mtag}",
                             model_setup.side, model_setup.reasons[0][:70]))

            if not hits:
                continue

            q = quality.score_setup(self.io, sym, self.tf_min, hits)
            side = q.get("side", 0)
            if not side:
                self._gate("no direction")
                self.log(f"[scan] {sym} stood aside — "
                         f"{'; '.join(q.get('reasons') or ['no direction'])} "
                         f"({', '.join(h[0] for h in hits)})")
                continue

            # one entry per (symbol, direction, agreeing-scanner-set) per
            # SKLZ_REENTRY_HOURS window — the same setup narrates on every
            # scan and must not be entered on each one
            key = (sym, side, tuple(sorted(q.get("scanners", []))))
            now_k = time.time()
            reentry = float(os.environ.get("SKLZ_REENTRY_HOURS", "4")) * 3600
            for k, ts in list(self._auto_seen.items()):
                if now_k - ts > reentry:
                    self._auto_seen.pop(k, None)
            if key in self._auto_seen:
                self._gate("already entered this setup")
                continue
            # The key is marked ENTERED only when an order is actually sent
            # (below). v3.31.0 and earlier marked it here, on first sight —
            # so a setup that the institutional gate vetoed once was never
            # looked at again for four hours, even after the picture
            # changed, and "already entered" counted thousands of scans that
            # had entered nothing. The log is kept quiet instead: the same
            # setup narrates once per 10 minutes, but is judged every scan.
            narrated = getattr(self, "_narrated", None)
            if narrated is None:
                narrated = self._narrated = {}
            quiet = (now_k - narrated.get(key, 0)) < 600
            narrated[key] = now_k
            log_q = (lambda *a, **k: None) if quiet else self.log

            names = "+".join(q.get("scanners", []))
            log_q(f"[scan] {sym} {'BUY' if side > 0 else 'SELL'} "
                  f"score {q['score']}/100 ({names}) — "
                  + "; ".join(q.get("reasons", [])))

            # ── cross-market: gold vs the dollar index (v3.33) ──────
            try:
                from basket_engine.learn import xmarket as _xm
                xm = _xm.check(self.io, sym, side, log=self.log)
            except Exception:  # noqa: BLE001
                xm = None
            if xm is not None:
                mark = "✓" if xm.get("ok") else ("·" if xm.get("ok") is None else "✗")
                log_q(f"[xmkt] {sym} {'BUY' if side > 0 else 'SELL'} {mark} {xm.get('why')}")
                detail_xm = f" · dxy {mark}"
                if xm.get("ok") is False and _xm.mode() == "gate":
                    self._gate("dxy")
                    continue
                if xm.get("score"):
                    q["score"] = max(0, min(100, q["score"] + xm["score"]))
            else:
                detail_xm = ""

            # ── v3.35 confluence scores (all before the quality bar so a
            # -10 can actually keep a marginal setup out) ─────────────
            model_led = bool(model_setup and model_setup.ok)
            _mtag0 = ((getattr(model_setup, "tag", "") or model_setup.model[0]).lower()
                      if model_led else "")
            try:
                _raw5 = self.io.bars(sym, 5, 120) or []
                _m5c = [{"open": r["open"], "high": r["high"], "low": r["low"],
                         "close": r["close"], "time": r.get("time")} for r in _raw5[:-1]]
            except Exception:  # noqa: BLE001
                _m5c = []
            _conf_veto = False
            try:
                from basket_engine.learn import levels as _LV2
                from basket_engine.learn import models as _MD2
                from basket_engine.learn import xmarket as _xm2
                _skip_conf = {x.strip().lower() for x in
                              os.environ.get("SKLZ_CONFLUENCE_EXEMPT", "o,p_open").split(",") if x.strip()}
                try:        # weight of each rsidiv / pd / mo verdict (SMT and KZ have their own)
                    _cw = float(os.environ.get("SKLZ_CONFLUENCE_PTS", "10")) / 10.0
                except ValueError:
                    _cw = 1.0
                if _mtag0 in _skip_conf:
                    pass
                else:
                    # silver -> gold SMT (+/-10)
                    smt = _xm2.smt_check(self.io, sym, side, log=self.log)
                    if smt is not None:
                        mark = "✓" if smt.get("ok") else ("·" if smt.get("ok") is None else "✗")
                        log_q(f"[smt] {sym} {mark} {smt['why']}")
                        if smt.get("score"):
                            q["score"] = max(0, min(100, q["score"] + smt["score"]))
                            detail_xm += f" · smt {mark}"
                    # RSI divergence on bodies (SKLZ_RSI_DIV=off|score|gate)
                    rdm = _MD2.rsi_div_mode()
                    if rdm != "off" and _m5c:
                        rd = _MD2.rsi_div_judge(_m5c, side)
                        if rd.get("ok") is not None:
                            mark = "✓" if rd["ok"] else "✗"
                            log_q(f"[rsidiv] {sym} {mark} {rd['why']}")
                            q["score"] = max(0, min(100, q["score"] + rd["score"] * _cw))
                            detail_xm += f" · rsidiv {mark}"
                            if rdm == "gate" and not rd["ok"] and _mtag0[:1] in ("c", "d", "e", "g", "x", "p"):
                                self._gate("rsi divergence")
                                _conf_veto = True
                    # premium / discount of the last impulse (SKLZ_PD_FILTER)
                    pdm = os.environ.get("SKLZ_PD_FILTER", "score").strip().lower()
                    if pdm != "off" and _m5c and not _conf_veto:
                        _pxn = float(self.io.price(sym, side) or _m5c[-1]["close"])
                        pdv = _LV2.premium_discount(_m5c, _pxn, side)
                        if pdv.get("ok") is not None:
                            mark = "✓" if pdv["ok"] else "✗"
                            log_q(f"[pd] {sym} {mark} {pdv['why']}")
                            q["score"] = max(0, min(100, q["score"] + pdv["score"] * _cw))
                            detail_xm += f" · pd {mark}"
                            if pdm == "gate" and not pdv["ok"]:
                                self._gate("premium/discount")
                                _conf_veto = True
                    # ICT midnight open positioning (SKLZ_MO_MODE)
                    mom = os.environ.get("SKLZ_MO_MODE", "score").strip().lower()
                    if mom != "off" and _m5c and not _conf_veto:
                        mo = _LV2.midnight_open(_m5c)
                        if mo:
                            _raw60 = self.io.bars(sym, 60, 40) or []
                            _atr60 = _LV2._atr_simple([{"high": r["high"], "low": r["low"], "close": r["close"]} for r in _raw60]) or 0.0
                            _pxn = float(self.io.price(sym, side) or _m5c[-1]["close"])
                            mob = _LV2.midnight_open_bias(_pxn, mo, side, _atr60)
                            if mob.get("ok") is not None:
                                mark = "✓" if mob["ok"] else "✗"
                                log_q(f"[mo] {sym} {mark} {mob['why']}")
                                q["score"] = max(0, min(100, q["score"] + mob["score"] * _cw))
                                detail_xm += f" · mo {mark}"
                                if mom == "gate" and not mob["ok"]:
                                    self._gate("midnight open")
                                    _conf_veto = True
                    # kill-zone weighting for sweep / raid models
                    try:
                        kz_pts = float(os.environ.get("SKLZ_KZ_SCORE", "10"))
                    except ValueError:
                        kz_pts = 10.0
                    if kz_pts > 0 and _mtag0[:1] in ("c", "d", "e", "g", "k", "l", "x", "p"):
                        from datetime import datetime as _dt, timezone as _tz
                        _h = _dt.now(_tz.utc).hour + _dt.now(_tz.utc).minute / 60
                        _in = False
                        for part in os.environ.get("SKLZ_KZ_HOURS", "7-11,12-16").split(","):
                            try:
                                a_, b_ = part.split("-")
                                if float(a_) <= _h < float(b_):
                                    _in = True
                            except ValueError:
                                continue
                        if not _in:
                            q["score"] = max(0, q["score"] - kz_pts)
                            log_q(f"[kz] {sym} raid outside the kill zones ({_h:.1f} UTC) — -{kz_pts:g}")
                            detail_xm += " · kz ✗"
                    # v3.36 Model R only: LLM context note (SKLZ_LLM_CONTEXT, default off)
                    if _mtag0[:1] == "r":
                        from basket_engine.learn import context_note as _CN
                        if _CN.mode() != "off":
                            from basket_engine.learn import of_feed as _OF
                            _st_r, _ = _OF.load_state()
                            _raw1 = self.io.bars(sym, 60, 60) or []
                            _b1 = [{"open": r["open"], "high": r["high"], "low": r["low"],
                                    "close": r["close"], "time": r.get("time")} for r in _raw1]
                            _raw15 = self.io.bars(sym, 15, 300) or []
                            _b15 = [{"open": r["open"], "high": r["high"], "low": r["low"],
                                     "close": r["close"], "time": r.get("time")} for r in _raw15]
                            _pdva = _LV2.prev_day_value_area(_b15, bins=40) if _b15 else None
                            _px_r = float(_m5c[-1]["close"]) if _m5c else 0.0
                            _ctx = _CN.note(sym, _px_r, _pdva, _b1, _st_r)
                            _sc, _veto, _txt = _CN.apply(_ctx, side, q["score"])
                            if _txt:
                                log_q(f"{_txt}  {sym}")
                            q["score"] = _sc
                            if _veto:
                                _conf_veto = True
            except Exception as exc:  # noqa: BLE001
                self.log(f"[confluence] {type(exc).__name__}: {exc} — scores left as they were")
            if _conf_veto:
                continue

            # A reversal model trades AGAINST the higher timeframe by design
            # — that is what a sweep reclaim is — so the quality score's
            # 25-point HTF bonus is structurally out of reach for it. A
            # model-led setup therefore has its own bar,
            # SKLZ_SIGNAL_MIN_SCORE_MODEL (default 50); scanner-led setups
            # keep SKLZ_SIGNAL_MIN_SCORE (60).
            model_led = bool(model_setup and model_setup.ok)
            try:
                q_bar = (float(os.environ.get("SKLZ_SIGNAL_MIN_SCORE_MODEL", "50"))
                         if model_led else quality.min_score())
            except ValueError:
                q_bar = quality.min_score()
            if q["score"] < q_bar:
                log_q(f"[scan] skipped — below quality threshold "
                      f"({q_bar:g}{' for a model-led setup' if model_led else ''})")
                self._gate("quality score")
                continue

            # ── playbook ────────────────────────────────────────────
            # Which model may trade which pair in which session, from the
            # measured record (tools\model_report.py). A setup the numbers
            # say loses money is not an opportunity, however clean it looks.
            # Rules live in playbook.json (hot-reloaded); SKLZ_PLAYBOOK=0 off.
            if self.auto:
                try:
                    pb = getattr(self, "_playbook", None)
                    if pb is None:
                        from basket_engine.learn.playbook import Playbook
                        pb = self._playbook = Playbook(log=self.log)
                    ok_pb, why_pb = pb.check(q.get("scanners", []), sym)
                except Exception as exc:  # noqa: BLE001
                    ok_pb, why_pb = True, ""
                    self.log(f"[playbook] check failed — {type(exc).__name__}: {exc}; letting it through")
                if not ok_pb:
                    log_q(f"[playbook] {sym} {names} kept out — {why_pb}")
                    self._gate("playbook")
                    continue

            # ── institutional confirmation ──────────────────────────
            # The scanners say a level broke. This asks whether the break
            # has participation behind it, or is a stop hunt wearing a
            # breakout's clothes.
            # stash for the research capture — entries.py reads these so the
            # observation records what the engines actually saw at the time
            self.ec._last_quality = q
            inst = None
            if os.environ.get("SKLZ_INSTITUTIONAL", "1") != "0":
                try:
                    inst = self._institutional(sym, side)
                except Exception as exc:
                    self.log(f"[inst] check failed — {type(exc).__name__}: {exc}")
                    self.log("[inst] falling back to the scanner score. "
                             "This is a bug; report the line above.")
            self.ec._last_institutional = inst
            if inst is not None:
                log_q(f"[inst] {sym} {inst.verdict}")
                for f in inst.flags[:3]:
                    log_q(f"[inst]   ! {f}")
                # THE INSTITUTIONAL FRAMEWORK JUDGES BREAKOUTS. Its hard
                # flags — "this is a liquidity sweep, not a breakout",
                # "breaking into a high-volume node", "into an opposing HTF
                # block" — are the right questions for a scanner-led break
                # and the WRONG questions for a model whose thesis is the
                # sweep or the retest. Applied to D/E/G/K/L/X they rejected
                # the models for doing their job (47 of 64 gate stops in one
                # session were this). SKLZ_INST_MODELS decides what a
                # model-led setup still has to pass:
                #   score (default) — the score threshold for models,
                #                     SKLZ_INST_MIN_SCORE_MODEL (default 50),
                #                     plus the one universal hard veto:
                #                     order flow running the other way
                #   full            — everything, as for scanner breakouts
                #   off             — institutional is logged, not enforced
                # Scanner-led entries always face the full gate.
                if model_setup and model_setup.ok and not inst.passed:
                    mode = os.environ.get("SKLZ_INST_MODELS", "score").lower()
                    try:
                        thr_m = float(os.environ.get(
                            "SKLZ_INST_MIN_SCORE_MODEL", "50"))
                    except ValueError:
                        thr_m = 50.0
                    flow_against = any(f.startswith("DELTA AGAINST")
                                       for f in inst.flags)
                    if mode == "off":
                        inst.passed = True
                        log_q(f"[inst] {sym} model-led — institutional "
                              f"not enforced (SKLZ_INST_MODELS=off)")
                    elif mode == "score":
                        # v3.35.2: only measured order flow the other way
                        # vetoes a model-led entry. inst.veto is ALSO set by
                        # "price on a high-volume node" and "into an HTF
                        # block" — breakout questions that rejected every
                        # sweep model on 13 Oct under the misleading
                        # "order flow is against the entry".
                        if flow_against:
                            log_q(f"[inst] {sym} model-led — kept out: "
                                  f"order flow is against the entry")
                        elif inst.veto and os.environ.get("SKLZ_INST_MODEL_HARD_VETO", "0") == "1":
                            log_q(f"[inst] {sym} model-led — kept out by a hard flag "
                                  f"(SKLZ_INST_MODEL_HARD_VETO=1)")
                        elif inst.score >= thr_m:
                            inst.passed = True
                            log_q(f"[inst] {sym} model-led — breakout flags "
                                  f"waived; {inst.score:.0f}/100 clears the "
                                  f"model bar {thr_m:.0f}")
                        else:
                            log_q(f"[inst] {sym} model-led — "
                                  f"{inst.score:.0f}/100 is below the model "
                                  f"bar {thr_m:.0f} (SKLZ_INST_MIN_SCORE_MODEL)")
                    else:
                        # full: the original D-only sweep waiver, extended
                        # to every sweep model in v3.29.1
                        if model_setup.model[:1].upper() in _SWEEP_MODELS:
                            try:
                                from basket_engine.learn.institutional import \
                                    threshold as _ithr
                                _prefixes = ("LIQUIDITY SWEEP", "ABSORPTION",
                                             "DELTA AGAINST", "price is sitting ON",
                                             "INTO HTF BLOCK")
                                _blocking = [f for f in inst.flags
                                             if f.startswith(_prefixes)]
                                _only_sweep = (_blocking and all(
                                    f.startswith("LIQUIDITY SWEEP")
                                    for f in _blocking))
                                if (_only_sweep and not inst.veto
                                        and inst.score >= _ithr()):
                                    inst.passed = True
                                    log_q(f"[inst] {sym} sweep veto waived — the "
                                          f"sweep IS model {model_setup.model[:1]}'s "
                                          f"setup, not a warning against it")
                            except Exception:
                                pass

                if not inst.passed:
                    # SHADOW TRACKING. The walk-forward validated the models
                    # WITHOUT this veto layer — so every veto of a completed
                    # model sequence is an unmeasured decision. Follow the
                    # phantom trade to its stop or a 2R target, and in two
                    # weeks each veto has a P&L: kept money, or cost it.
                    try:
                        if (model_setup and model_setup.ok
                                and len(self._shadows) < 60
                                and not any(x.get("pkey") == key
                                            for x in self._shadows)):
                            _e = model_setup.entry
                            _st = model_setup.stop
                            _r = abs(_e - _st)
                            if _r > 0:
                                self._shadows.append({
                                    "sym": sym, "side": model_setup.side,
                                    "entry": _e, "stop": _st,
                                    "target": _e + model_setup.side * 2 * _r,
                                    "veto": (inst.flags[0].split(" — ")[0]
                                             if inst.flags else "unknown"),
                                    "model": model_setup.model[0],
                                    "pkey": key,
                                    "t": time.time()})
                    except Exception:
                        pass
                    self._gate("institutional")
                    continue

            detail = f"{q['detail']} · score {q['score']}/100 · {names}{detail_xm}"
            if inst is not None:
                detail += f" · institutional {inst.score:.0f}/100"
            taken = None
            skipped_but_valid = False

            if self.auto and not self.entries_blocked:
                # ONE POSITION PER SYMBOL. Model A on a break and Model D on
                # the sweep of the same pair are not two opportunities — they
                # are one market view held twice, and when it is wrong it
                # loses twice. The second signal still counts as confluence
                # in the score; it does not get its own ticket.
                try:
                    open_syms = {p.get("symbol", "") for p in
                                 (self.io.my_positions() or [])}
                except Exception:
                    open_syms = set()
                # A position that was ordered seconds ago may not be in
                # my_positions() yet — the broker confirms, MT5 catches up,
                # and a scan in between sees an empty book. That gap put two
                # UKOIL tickets on a funded account three seconds apart, and
                # both fanned out to every follower. So remember what we just
                # entered and treat it as open until MT5 agrees.
                recent = getattr(self, "_recent_entries", None)
                if recent is None:
                    recent = self._recent_entries = {}
                now_ts = time.time()
                for k, ts in list(recent.items()):
                    if now_ts - ts > 90:
                        recent.pop(k, None)
                if sym in open_syms or sym in recent:
                    why = ("a position is already open on this pair"
                           if sym in open_syms else
                           "an entry on this pair was just placed and MT5 "
                           "has not registered it yet")
                    log_q(f"[entry] {sym} skipped — {why}. "
                          f"One idea, one ticket.")
                    continue

                # SPREAD-EXPANSION COST GATE (V1). The single most
                # expensive moments to trade are when the spread is not its
                # usual self — news, rollover, thin sessions. The engine keeps
                # a rolling baseline per symbol; when the current spread is a
                # multiple of it, the entry waits. This encodes the V1
                # finding a third time: cost decides marginal trades.
                try:
                    cur_sp = (self.io.price(sym, 1) or 0) -                              (self.io.price(sym, -1) or 0)
                    hist = self._sprd.setdefault(sym, [])
                    if cur_sp > 0:
                        hist.append(cur_sp)
                        if len(hist) > 500:
                            del hist[:100]
                    if len(hist) >= 30 and cur_sp > 0:
                        import statistics as _st
                        base = _st.median(hist)
                        mult = float(os.environ.get(
                            "SKLZ_SPREAD_EXPANSION_MULT", "2.0"))
                        if base > 0 and cur_sp > base * mult:
                            from basket_engine.learn.trailing import pip_size                                 as _ps
                            _pp = _ps(sym, self.io.spec(sym).get("digits"))
                            log_q(
                                f"[cost] {sym} entry held back — spread "
                                f"{cur_sp/_pp:.1f}p is {cur_sp/base:.1f}x its "
                                f"usual {base/_pp:.1f}p. Paying an expanded "
                                f"spread is how marginal trades become "
                                f"losers.")
                            continue
                except Exception:
                    pass

                # NEWS BLACKOUT: no fresh entries into the first minutes of a
                # high-impact release on this symbol's currencies. The M5
                # candle that completes after the window IS the post-news
                # entry — nothing is lost except the slippage.
                try:
                    from basket_engine.learn import news as _news
                    blocked, why = _news.blackout(sym, log=self.log)
                except Exception:
                    blocked, why = False, ""
                if blocked:
                    log_q(f"[news] {sym} entry skipped — {why}")
                    continue

                # Can this account carry it? Heavy instruments on a small
                # balance crowd out everything else, but the SETUP is still
                # real — someone with a larger account should hear about it.
                afford = {"ok": True}
                try:
                    afford = self.ec.affordable(sym, 0.01, side)
                except Exception:
                    pass

                # SCANNER-LED BREAKOUTS MUST EARN THE ENTRY. structure_break
                # alone confirms the break, not the trade: without a retest,
                # a hold, and a 5M engulfing, the entry is a chase — and the
                # journal showed exactly those entries losing. Models skip
                # this gate because each already enforces its own sequence.
                break_led = ("structure_break" in names
                             and not any(h[0].startswith("model_")
                                         for h in hits))
                confirm_ok = True
                if break_led:
                    try:
                        import re as _re
                        from basket_engine.learn import models as _MD
                        from basket_engine.learn.trailing import pip_size
                        m = _re.search(r"closed (?:above|below) "
                                       r"([0-9]+\.?[0-9]*)", detail)
                        level = float(m.group(1)) if m else 0.0
                        if level:
                            raw = self.io.bars(sym, 5, 40) or []
                            m5b = [{"open": r["open"], "high": r["high"],
                                    "low": r["low"], "close": r["close"]}
                                   for r in raw[:-1]]   # completed bars only
                            pip = pip_size(sym, self.io.spec(sym).get("digits"))
                            confirm_ok, why = _MD.break_entry_confirmed(
                                m5b, level, side, pip)
                            if not confirm_ok:
                                log_q(f"[entry] {sym} structure_break "
                                      f"held back — {why}")
                    except Exception:
                        confirm_ok = True   # a broken gate must not block

                # UNIVERSAL ENTRY CONFIRMATION (v3.33.1, owner's rule):
                # every auto entry — model-led or scanner-led — waits for an
                # M5 BODY close beyond its line, a retest of the line, and a
                # 5M engulfing in direction, and must sit near the line
                # rather than at the extreme. SKLZ_ENTRY_CONFIRM=0 lifts it.
                _mtag = (getattr(model_setup, "tag", "") or "") if model_led else ""
                from basket_engine.learn import permodel as _PM
                if _mtag and _PM.confirm_exempt(_mtag) and confirm_ok:
                    log_q(f"[confirm] {sym} model_{_mtag} is exempt from the M5 confirmation gate")
                elif confirm_ok and os.environ.get("SKLZ_ENTRY_CONFIRM", "1") != "0":
                    try:
                        import re as _re
                        from basket_engine.learn import models as _MD
                        from basket_engine.learn.trailing import pip_size
                        _lvl = 0.0
                        if model_led and getattr(model_setup, "level", 0):
                            _lvl = float(model_setup.level)
                        else:
                            _m = _re.search(r"(?:closed (?:above|below)|sweep of (?:highs|lows)) "
                                            r"([0-9]+\.?[0-9]*)", detail)
                            _lvl = float(_m.group(1)) if _m else 0.0
                        if not _lvl:
                            confirm_ok = False
                            log_q(f"[confirm] {sym} {names} held back — no level to "
                                  f"confirm the entry against")
                        else:
                            raw = self.io.bars(sym, 5, 60) or []
                            m5c = [{"open": r["open"], "high": r["high"],
                                    "low": r["low"], "close": r["close"]}
                                   for r in raw[:-1]]
                            pip = pip_size(sym, self.io.spec(sym).get("digits"))
                            confirm_ok, why = _MD.entry_confirmed(m5c, _lvl, side, pip)
                            if confirm_ok:
                                log_q(f"[confirm] {sym} {names} — {why}")
                                detail += " · confirmed"
                            else:
                                log_q(f"[confirm] {sym} {names} held back — {why}")
                                self._gate("entry confirmation")
                    except Exception as exc:  # noqa: BLE001
                        self.log(f"[confirm] check failed ({type(exc).__name__}: {exc}) — "
                                 f"holding the entry back rather than guessing")
                        confirm_ok = False

                # tag the decision with the market regime — measurement
                # first: no gating on regime until tagged trades say which
                # regimes deserve gates
                try:
                    from basket_engine.learn import regime as _rg
                    raw15 = self.io.bars(sym, 15, 130) or []
                    rg = _rg.classify(
                        [{"open": r["open"], "high": r["high"],
                          "low": r["low"], "close": r["close"]}
                         for r in raw15[:-1]])
                    if rg["label"] != "unknown":
                        detail += f" · regime {rg['label']}/{rg['session']}"
                        if rg["rollover"]:
                            detail += " (rollover)"
                except Exception:
                    pass

                if not afford.get("ok"):
                    log_q(f"[size] {afford.get('reason', '')}")
                    skipped_but_valid = bool(afford.get("signal_anyway"))
                elif not confirm_ok:
                    pass                    # wait for the sequence, no entry
                else:
                    self._auto_seen[key] = now_k      # ENTERED — now it counts
                    # v3.33: a model-led entry carries its own structural
                    # stop and target when the switches allow it
                    _sl = _tp = _t1 = 0.0
                    if model_led and model_setup.side == side:
                        from basket_engine.learn import permodel as _PM2
                        if _PM2.model_sl_allowed(_mtag0[:1]) and model_setup.stop:
                            _sl = float(model_setup.stop)
                        if os.environ.get("SKLZ_MODEL_TP", "1") != "0" and getattr(model_setup, "target", 0):
                            _tp = float(model_setup.target)
                        try:
                            _px = float(self.io.price(sym, side) or 0)
                        except Exception:  # noqa: BLE001
                            _px = 0.0
                        if _px:
                            if _sl and (_px - _sl) * side <= 0:
                                _sl = 0.0            # price already through it — let stops.py decide
                            if _tp and (_tp - _px) * side <= 0:
                                _tp = 0.0
                        # v3.34: a model without a target of its own aims at the
                        # nearest untested session extreme / swing that pays
                        if not _tp and _sl and os.environ.get("SKLZ_TARGET_SESSIONS", "1") != "0":
                            try:
                                from basket_engine.learn import levels as _LV
                                raw15 = self.io.bars(sym, 15, 300) or []
                                b15 = [{"open": r["open"], "high": r["high"], "low": r["low"],
                                        "close": r["close"], "time": r.get("time")} for r in raw15]
                                raw5 = self.io.bars(sym, 5, 120) or []
                                b5 = [{"open": r["open"], "high": r["high"], "low": r["low"],
                                       "close": r["close"]} for r in raw5[:-1]]
                                sl_ = _LV.session_levels(b15)
                                ex_lv = [p for p, _ in (sl_["untested_highs"] if side > 0 else sl_["untested_lows"])]
                                pd_ = _LV.prev_day_range(b15)
                                if pd_:
                                    ex_lv.append(pd_["high"] if side > 0 else pd_["low"])
                                if os.environ.get("SKLZ_TARGET_FRESH", "1") != "0":
                                    # v3.35: a PDH / session high already taken today is spent
                                    _d0, _ = _LV._server_day(b15)
                                    _today = [b for b in b15 if _d0 and int(b.get("time") or 0) >= _d0]
                                    _before = len(ex_lv)
                                    ex_lv = _LV.fresh_targets(ex_lv, _today, side)
                                    if len(ex_lv) < _before:
                                        log_q(f"[target] {sym} {_before - len(ex_lv)} level(s) already hit today — skipped")
                                t2, _w = _LV.structural_target(b5, side, _px, _sl, extra_levels=ex_lv)
                                if t2:
                                    _tp = float(t2)
                            except Exception:  # noqa: BLE001
                                pass
                        # v3.35: SKLZ_TARGET_PREFER_HTF — a 4H/H1 level held >= 3
                        # times within 4R becomes the target; the nearer swing is
                        # remembered as target1 for SKLZ_PARTIAL_AT=target1
                        _t1 = _tp
                        if _sl and os.environ.get("SKLZ_TARGET_PREFER_HTF", "1") != "0":
                            try:
                                from basket_engine.learn import levels as _LV
                                _px2 = float(self.io.price(sym, side) or 0)
                                _risk = abs(_px2 - _sl) if _px2 else 0.0
                                _best, _holds = None, 0
                                for _tf in (240, 60):
                                    _rawh = self.io.bars(sym, _tf, 200) or []
                                    _bh = [{"open": r["open"], "high": r["high"], "low": r["low"], "close": r["close"]} for r in _rawh[:-1]]
                                    _lv, _n = _LV.htf_held_level(_bh, side, _px2, _risk)
                                    if _lv and (_best is None or abs(_lv - _px2) < abs(_best - _px2)):
                                        _best, _holds = _lv, _n
                                if _best and _risk and abs(_best - _px2) / _risk >= _LV.min_target_rr():
                                    if _tp and (abs(_best - _px2) > abs(_tp - _px2)):
                                        _t1 = _tp
                                    log_q(f"[target] {sym} HTF level {_best:.5f} held {_holds}x within "
                                          f"{abs(_best - _px2) / _risk:.1f}R — preferred target")
                                    _tp = float(_best)
                            except Exception:  # noqa: BLE001
                                pass
                        if _tp:
                            log_q(f"[target] {sym} structural TP {_tp:.5f}"
                                  + (f" · SL {_sl:.5f}" if _sl else "")
                                  + (f" · partial at {_t1:.5f}" if _t1 and _t1 != _tp else ""))
                    taken = self.ec.auto_entry(names, sym, side, detail,
                                               sl_price=_sl, tp_price=_tp)
                    if taken:
                        n += 1
                        try:                       # v3.35: first M15 S/R for PARTIAL_AT=target1
                            from basket_engine.learn import trailing as _TRm
                            if _t1 and _t1 != _tp:
                                _TRm.remember_target1(taken.ticket, float(_t1))
                            elif _tp:
                                _TRm.remember_target1(taken.ticket, float(_tp))
                        except Exception:  # noqa: BLE001
                            pass
                        try:
                            self._armed.pop(sym, None)
                        except AttributeError:
                            pass
                        # Mark it in flight IMMEDIATELY. my_positions() can
                        # lag the broker by seconds and the next scan is only
                        # a minute away — this is the write the duplicate
                        # guard above reads.
                        try:
                            self._recent_entries[sym] = time.time()
                        except AttributeError:
                            self._recent_entries = {sym: time.time()}

            # publish when we took it, when auto is off, or when the setup was
            # sound but this account could not carry it
            if self.auto and not taken and not skipped_but_valid:
                self.log("[signal] not published — the entry did not fill")
            else:
                if skipped_but_valid:
                    detail += " · signal only (account too small for this instrument)"
                try:
                    # publish the levels the trade actually used, not a
                    # fresh guess — subscribers must see the same numbers
                    signal_publish.publish(
                        self.io, sym, side, names, detail, self.tf_min,
                        log=self.log,
                        actual_price=getattr(taken, "entry_price", None),
                        actual_sl=getattr(taken, "sl_price", None),
                        actual_tp=getattr(taken, "tp_price", None))
                except Exception as exc:
                    self.log(f"[signal] error: {exc}")
        return n

    # ---- exits: reconcile closed positions into the journal ----
    def sync_exits(self) -> None:
        open_tickets = {p["ticket"] for p in self.io.my_positions()}
        # last 3 days, not today: an entry from 23:34 UTC that closes at 00:12
        # was invisible to a today-only load, so its exit was never written —
        # every broker-side close that straddled midnight vanished
        rows = (self.journal.load_recent(3) if hasattr(self.journal, "load_recent")
                else self.journal.load_day())
        entered = {r["ticket"] for r in rows if r.get("type") == "entry" and r.get("ticket")}
        exited = {r["ticket"] for r in rows if r.get("type") == "exit"}
        for tk in entered - exited - open_tickets:
            # position closed — fetch the EXACT realized P/L from deal history
            _deal = self.io.closing_deal(tk) if hasattr(self.io, "closing_deal") else None
            pnl = _deal["pnl"] if _deal else self.io.realized_pnl(tk)
            _exit_px = _deal["price"] if _deal else 0.0
            _reason = _deal["reason"] if _deal else None
            if pnl is None:
                # Deal history lags the position closing by a moment. Writing
                # 0.0 here was recording the trade as breakeven FOREVER — the
                # real number arrives seconds later but the journal already
                # says flat. Nine trades in a row reading exactly $0.00 is not
                # a quiet day, it is this bug.
                #
                # So: leave it unrecorded and try again on the next pass.
                pending = getattr(self, "_pending_exits", None)
                if pending is None:
                    pending = self._pending_exits = {}
                tries = pending.get(tk, 0) + 1
                pending[tk] = tries
                if tries <= 20:
                    # first attempt, then occasionally — three tickets retrying
                    # every five seconds buries everything else in the console
                    if tries == 1 or tries % 8 == 0:
                        self.log(f"[exit] ticket {tk} closed — P/L not in "
                                 f"history yet, retrying (attempt {tries})")
                    continue
                # after ~20 passes something is genuinely wrong; record it as
                # unknown rather than as breakeven, so it is visible
                self.log(f"[exit] ticket {tk}: P/L never appeared in history "
                         f"after {tries} attempts. Recording as UNKNOWN rather "
                         f"than as flat — check this trade manually.")
                self.journal.record_exit(tk, 0.0, None)
                pending.pop(tk, None)
                continue

            self.log(f"[exit] ticket {tk} closed by {_reason or '?'} @ {_exit_px}: {pnl:+.2f} realized")

            # close the published signal too. Pips from entry vs the last
            # known price when available; otherwise outcome from the sign of
            # the money, which is what subscribers actually care about
            try:
                _er = next((r for r in rows if r.get("ticket") == tk), None)
                _sym = (_er or {}).get("symbol", "")
                _side = 1 if (_er or {}).get("side", 1) in (1, "1", "buy") else -1
                if _sym:
                    _pips = None
                    try:
                        from basket_engine.learn.trailing import pip_size
                        _entry = float((_er or {}).get("entry") or 0)
                        _px = self.io.price(_sym, _side)
                        if _entry and _px:
                            _pips = ((_px - _entry) if _side > 0
                                     else (_entry - _px)) / pip_size(_sym)
                    except Exception:
                        _pips = None
                    signal_publish.update_status(_sym, _side, "closed",
                                                 pips=_pips, money=pnl,
                                                 log=self.log)
                    signal_publish.copy_event("close", tk, _sym, _side,
                                              log=self.log)
            except Exception:
                pass
            if getattr(self, "_pending_exits", None):
                self._pending_exits.pop(tk, None)
            self.journal.record_exit(tk, _exit_px, pnl, _reason)

            # write the research observation, using the entry context stored
            # when the position was opened
            try:
                entry_row = next((r for r in rows
                                  if r.get("ticket") == tk
                                  and r.get("type") == "entry"), None)
                ctx = (entry_row or {}).get("context") or {}
                if ctx:
                    class _Rec:
                        pass
                    rec = _Rec()
                    rec.context = ctx
                    exit_px = 0.0
                    try:
                        exit_px = float(self.io.price(ctx.get("symbol", ""), 1))
                    except Exception:
                        pass
                    self._push_observation(rec, exit_px, pnl, "position closed")
            except Exception as exc:  # noqa: BLE001
                self.log(f"[research] exit capture skipped: {type(exc).__name__}")

    # ---- review ----
    def review(self) -> dict:
        closed = self.journal.reconcile()
        stats = summarize(closed)
        rep = ai_review(stats, closed)
        self.log("\n" + "=" * 58)
        self.log("  END-OF-DAY REVIEW  (AI proposes — you decide)")
        self.log("=" * 58)
        self.log(f"  {rep.get('headline','')}")
        self.log(f"  forced vs auto: {rep.get('forced_vs_auto','')}")
        self.log(f"  winning pattern: {rep.get('winning_pattern','')}")
        props = rep.get("proposals", [])
        if props:
            self.log("  PROPOSED CHANGES (apply manually if you agree):")
            for i, p in enumerate(props, 1):
                self.log(f"   {i}. [{p.get('confidence','?')}] {p.get('change')}: "
                         f"{p.get('suggestion')}")
                self.log(f"      reason: {p.get('reason')}")
                self.log(f"      caution: {p.get('caution')}")
        else:
            self.log("  No proposals (small sample or no AI key).")
        self.log(f"  coach: {rep.get('note_to_trader','')}")
        self.log("=" * 58 + "\n")
        # persist the review beside the journal
        rpath = os.path.join(os.path.dirname(self.journal.path),
                             f"review-{datetime.now(timezone.utc):%Y-%m-%d}.json")
        import json
        with open(rpath, "w", encoding="utf-8") as f:
            json.dump({"stats": stats, "review": rep}, f, indent=2)
        # NOTE: journal push is handled continuously by the live auto-journal loop
        # (_push_closed_trades), which tags account + dedups by position id.
        # The old end-of-day push is intentionally disabled to prevent DUPLICATES.
        self.log("[journal] (auto-journal keeps the journal current; no separate push)")
        return rep

    def status(self):
        pos = self.io.my_positions()
        closed = self.journal.reconcile()
        s = summarize(closed)
        self.log(f"  open positions: {len(pos)} | today: {s['trades']} closed, "
                 f"{s['win_rate']:.0%} win, {s['total_pnl']:+.2f} P/L | "
                 f"auto-entries: {'ON' if self.auto else 'OFF'}")
        _live = {x.strip().lower() for x in
                 os.environ.get("SKLZ_MODELS_ENABLED", "a,b,c,d").split(",") if x.strip()}
        _obs = {x.strip().lower() for x in
                os.environ.get("SKLZ_MODELS_OBSERVE", "e,f").split(",") if x.strip()}
        live = ",".join(sorted(_live)).upper()
        obs = ",".join(sorted(_obs - _live)).upper() or "none"
        self.log(f"  gates: quality {quality.min_score():g} (models "
                 f"{os.environ.get('SKLZ_SIGNAL_MIN_SCORE_MODEL', '50')}) | "
                 f"institutional {os.environ.get('SKLZ_INST_MIN_SCORE', '80')} "
                 f"(models: {os.environ.get('SKLZ_INST_MODELS', 'score')}"
                 f"≥{os.environ.get('SKLZ_INST_MIN_SCORE_MODEL', '50')})")
        self.log(f"  models live: {live} | observe: {obs} | "
                 f"max lots: {os.environ.get('SKLZ_MAX_LOTS', '0') or 'unlimited'}"
                 + (f" (by symbol: {os.environ.get('SKLZ_MAX_LOTS_BY_SYMBOL')})"
                    if os.environ.get('SKLZ_MAX_LOTS_BY_SYMBOL') else "") + " | "
                 f"re-entry: {os.environ.get('SKLZ_REENTRY_HOURS', '4')}h")
        if self._gate_hits:
            parts = ", ".join(f"{k}: {v}" for k, v in
                              sorted(self._gate_hits.items(), key=lambda kv: -kv[1]))
            self.log(f"  scans stopped by — {parts}")
        for p in pos:
            self.log(f"    #{p['ticket']} {'BUY' if p['side']>0 else 'SELL'} "
                     f"{p['lots']} {p['symbol']} @ {p['open_price']} "
                     f"({p['profit']:+.2f})")
