"""SKLZ order-flow feed — Binance PAXG/USDT -> orderflow_state.json (v3.36).

Runs as its OWN process next to the engine (start_orderflow.bat). It never
places orders and never touches the engine's files except the one state
file it owns.

    python tools\\orderflow_feed.py                 live feed -> state file
    python tools\\orderflow_feed.py --record of.jsonl   same, plus a raw recording
    python tools\\orderflow_feed.py --report of.jsonl   offline: basis / correlation /
                                                      trigger counts by session

What it does every second: keep a websocket to Binance's public market
stream (no API key), fold every PAXG trade into 1-minute footprint bars
(buy vs sell volume per $-bin, big prints, session CVD), read the broker's
XAUUSD mid from the running MT5 terminal every 5 s for the basis and the
60-minute correlation, and write the whole picture atomically to
SKLZ_OF_STATE for model_r to read.

Settings (all optional, same names as the bat):
    SKLZ_OF_SYMBOL=PAXGUSDT   SKLZ_OF_MAP_TO=XAUUSD   SKLZ_OF_STATE=orderflow_state.json
    SKLZ_OF_BIN=1.0  SKLZ_OF_BIGPRINT_X=5  SKLZ_OF_MT5=1  SKLZ_OF_WS=wss://stream.binance.com:9443
    SKLZ_DAY_RESET_UTC_HOUR=21 (session CVD reset, same clock as the engine)
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from basket_engine.learn import of_feed as OF  # noqa: E402


def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] [of] {msg}", flush=True)


# ─────────────────────────── MT5 reference ────────────────────────────
class Mt5Ref:
    """Reads the broker's XAUUSD mid. Attaches to the running terminal;
    read-only. Silently absent when MetaTrader5 is not installed (Mac/Linux
    dev boxes) — the state then carries no `mt5` block and the guard holds
    model_r back unless SKLZ_OF_REQUIRE_MT5=0."""

    def __init__(self, want: str) -> None:
        self.want = (want or "XAUUSD").upper()
        self.mt5 = None
        self.symbol = ""
        try:
            import MetaTrader5 as mt5  # type: ignore
            path = os.environ.get("SKLZ_MT5_PATH", "").strip()
            ok = mt5.initialize(path=path) if path else mt5.initialize()
            if not ok:
                log(f"MT5 initialize failed: {mt5.last_error()} — running without the broker reference")
                return
            self.mt5 = mt5
            for s in (mt5.symbols_get() or []):
                if s.name.upper().startswith(self.want):
                    if not self.symbol or len(s.name) < len(self.symbol):
                        self.symbol = s.name
            if self.symbol:
                mt5.symbol_select(self.symbol, True)
                log(f"MT5 reference: {self.symbol} on {getattr(mt5.account_info(), 'server', '?')}")
            else:
                log(f"MT5: no symbol starting with {self.want} — reference disabled")
        except ImportError:
            log("MetaTrader5 package not installed — no broker reference (dev mode)")
        except Exception as exc:  # noqa: BLE001
            log(f"MT5 reference unavailable: {type(exc).__name__}: {exc}")

    def mid(self) -> float:
        if not self.mt5 or not self.symbol:
            return 0.0
        try:
            t = self.mt5.symbol_info_tick(self.symbol)
            if t and t.bid and t.ask:
                return (float(t.bid) + float(t.ask)) / 2.0
        except Exception:  # noqa: BLE001
            pass
        return 0.0


# ─────────────────────────── the feed ─────────────────────────────────
class Feed:
    def __init__(self, record: str | None = None) -> None:
        self.symbol = os.environ.get("SKLZ_OF_SYMBOL", "PAXGUSDT").strip().lower()
        self.map_to = os.environ.get("SKLZ_OF_MAP_TO", "XAUUSD").strip().upper()
        self.ws_base = os.environ.get("SKLZ_OF_WS", "wss://stream.binance.com:9443").rstrip("/")
        self.fp = OF.Footprint()
        self.ref = OF.Reference(symbol="")
        self.mt5 = Mt5Ref(self.map_to) if os.environ.get("SKLZ_OF_MT5", "1") != "0" else None
        if self.mt5 and self.mt5.symbol:
            self.ref.symbol = self.mt5.symbol
        self.record = open(record, "a", encoding="utf-8") if record else None
        self.connected_at = 0.0
        self.msgs = 0
        self.depth = {}
        self.stop = False

    # -- binance
    def _url(self) -> str:
        streams = [f"{self.symbol}@aggTrade"]
        if os.environ.get("SKLZ_OF_DEPTH", "1") != "0":
            streams.append(f"{self.symbol}@depth20@100ms")
        return f"{self.ws_base}/stream?streams={'/'.join(streams)}"

    def _on_msg(self, raw: str) -> None:
        try:
            env = json.loads(raw)
        except json.JSONDecodeError:
            return
        data = env.get("data", env)
        et = data.get("e")
        if et == "aggTrade":
            price, qty = float(data["p"]), float(data["q"])
            is_buy = not bool(data.get("m"))          # m: buyer is maker -> seller aggressed
            ts = float(data.get("T") or data.get("E") or time.time() * 1000) / 1000.0
            self.fp.add_trade(price, qty, is_buy, ts)
            if self.record:
                self.record.write(json.dumps({"k": "t", "ts": round(ts, 3), "p": price,
                                              "q": qty, "b": int(is_buy)}, separators=(",", ":")) + "\n")
        elif "bids" in data and "asks" in data:
            try:
                bids = [(float(p), float(q)) for p, q in data["bids"][:20]]
                asks = [(float(p), float(q)) for p, q in data["asks"][:20]]
                bw = max(bids, key=lambda x: x[1]) if bids else None
                aw = max(asks, key=lambda x: x[1]) if asks else None
                self.depth = {"bid_wall": list(bw) if bw else None, "ask_wall": list(aw) if aw else None,
                              "bid_qty": round(sum(q for _, q in bids), 4),
                              "ask_qty": round(sum(q for _, q in asks), 4), "ts": time.time()}
            except (TypeError, ValueError, KeyError):
                pass
        self.msgs += 1

    async def _ws_loop(self) -> None:
        import websockets
        backoff = 2
        while not self.stop:
            url = self._url()
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=20,
                                              max_size=2**22) as ws:
                    self.connected_at = time.time()
                    backoff = 2
                    log(f"connected {url}")
                    async for raw in ws:
                        self._on_msg(raw)
                        # Binance closes every connection at 24 h; leave at 23 h on our terms
                        if time.time() - self.connected_at > 23 * 3600:
                            log("23 h on this socket — reconnecting proactively")
                            break
            except Exception as exc:  # noqa: BLE001
                log(f"socket: {type(exc).__name__}: {exc} — retry in {backoff}s")
            if self.stop:
                break
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60)

    # -- broker reference
    async def _ref_loop(self) -> None:
        while not self.stop:
            if self.mt5 and self.fp.price:
                mid = self.mt5.mid()
                if mid:
                    now = time.time()
                    self.ref.update(self.fp.price, mid, now)
                    if self.record:
                        self.record.write(json.dumps({"k": "x", "ts": round(now, 3), "mid": mid,
                                                      "p": self.fp.price}, separators=(",", ":")) + "\n")
            await asyncio.sleep(5)

    # -- state writer
    async def _write_loop(self) -> None:
        last_report = 0.0
        while not self.stop:
            try:
                mt5 = self.ref.to_dict() if (self.mt5 and self.mt5.symbol and self.ref.last_ts) else None
                extra = {"source": "binance", "symbol": self.symbol.upper(), "map_to": self.map_to,
                         "connected_at": self.connected_at, "msgs": self.msgs, "depth": self.depth}
                OF.write_state(self.fp.snapshot(mt5=mt5, extra=extra))
                if self.record:
                    self.record.flush()
            except Exception as exc:  # noqa: BLE001
                log(f"state write failed: {type(exc).__name__}: {exc}")
            now = time.time()
            if now - last_report >= 300:
                last_report = now
                m = self.ref.to_dict() if self.ref.last_ts else {}
                bars = self.fp.bars
                b = bars[-1] if bars else None
                log(f"alive · {self.fp.trades} trades · last {self.fp.price:.2f} · "
                    f"bar Δ {b.d:+.3f} v {b.v:.2f}" if b else "alive · waiting for trades"
                    + (f" · basis {m.get('basis_pct', 0):+.3f}% corr60 {m.get('corr60')}"
                       f" (n={m.get('n')})" if m else " · no broker reference"))
            await asyncio.sleep(1)

    async def run(self) -> None:
        log(f"feed starting · {self.symbol.upper()} -> {self.map_to} · bin ${self.fp.bin:g} · "
            f"state {OF.state_path()}")
        await asyncio.gather(self._ws_loop(), self._ref_loop(), self._write_loop())


# ─────────────────────────── offline report ───────────────────────────
def report(path: str) -> None:
    """Replay a recording: basis and 1-min correlation by session, and how
    often each aggression trigger would have fired. Decides whether PAXG is
    a good enough proxy before a single live R trade."""
    fp = OF.Footprint()
    ref = OF.Reference(symbol="XAUUSD")
    per_min_paxg: dict[int, float] = {}
    per_min_xau: dict[int, float] = {}
    trig = {"stacked_imbalance": 0, "big_print": 0, "absorption": 0}
    checked = 0
    last_bar_t = None
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                continue
            if r.get("k") == "t":
                fp.add_trade(r["p"], r["q"], bool(r["b"]), r["ts"])
                per_min_paxg[int(r["ts"] // 60)] = r["p"]
                # count triggers once per closed bar
                if fp.bars and len(fp.bars) >= 2 and fp.bars[-2].t != last_bar_t:
                    last_bar_t = fp.bars[-2].t
                    st = fp.snapshot()
                    st["bars"] = st["bars"][:-1]
                    for side in (1, -1):
                        a = OF.aggression(st, side, lookback=0)
                        if a.get("ok"):
                            trig[a["kind"]] += 1
                    checked += 1
            elif r.get("k") == "x":
                ref.update(r["p"], r["mid"], r["ts"])
                per_min_xau[int(r["ts"] // 60)] = r["mid"]

    def sess(h):
        return "Asian" if h < 7 or h >= 21 else ("London" if h < 13 else "NY")

    buckets: dict[str, list[tuple[float, float]]] = {"Asian": [], "London": [], "NY": []}
    mins = sorted(set(per_min_paxg) & set(per_min_xau))
    for i in range(1, len(mins)):
        a0, a1 = per_min_paxg[mins[i - 1]], per_min_paxg[mins[i]]
        b0, b1 = per_min_xau[mins[i - 1]], per_min_xau[mins[i]]
        if a0 and b0:
            h = datetime.fromtimestamp(mins[i] * 60, timezone.utc).hour
            buckets[sess(h)].append(((a1 - a0) / a0, (b1 - b0) / b0))

    def pearson(pairs):
        n = len(pairs)
        if n < 10:
            return None
        ma = sum(a for a, _ in pairs) / n
        mb = sum(b for _, b in pairs) / n
        cov = sum((a - ma) * (b - mb) for a, b in pairs)
        va = sum((a - ma) ** 2 for a, _ in pairs) ** 0.5
        vb = sum((b - mb) ** 2 for _, b in pairs) ** 0.5
        return cov / (va * vb) if va and vb else None

    print(f"recording: {path}")
    print(f"trades: {fp.trades}   footprint bars: {len(fp.bars)} (last {fp.keep} kept)   "
          f"minutes with both prices: {len(mins)}")
    bases = [per_min_paxg[m] - per_min_xau[m] for m in mins if per_min_xau[m]]
    if bases:
        bases.sort()
        mid = per_min_xau[mins[-1]]
        print(f"basis PAXG-XAU: median {bases[len(bases)//2]:+.2f}  "
              f"p5 {bases[int(len(bases)*0.05)]:+.2f}  p95 {bases[int(len(bases)*0.95)]:+.2f}  "
              f"(≈ {bases[len(bases)//2]/mid*100:+.3f}% of price)")
    print("1-min return correlation by session (need ≥ ~0.8 in London/NY to trust the proxy):")
    for k, v in buckets.items():
        c = pearson(v)
        print(f"  {k:7s} n={len(v):4d}  r={'n/a' if c is None else f'{c:.2f}'}")
    print(f"aggression triggers over {checked} closed bars (either side): "
          f"stacked imbalance {trig['stacked_imbalance']}, big prints {trig['big_print']}, "
          f"absorption {trig['absorption']}")
    if checked:
        rate = sum(trig.values()) / checked
        print(f"  = {rate:.2f} triggers per bar"
              + ("  — too many: raise SKLZ_OF_IMBALANCE / SKLZ_OF_BIGPRINT_X" if rate > 0.5 else
                 "  — too few: lower SKLZ_OF_STACK or SKLZ_OF_IMBALANCE" if rate < 0.02 else ""))


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--record", metavar="FILE", help="also append raw trades + broker mids to FILE")
    ap.add_argument("--report", metavar="FILE", help="offline report over a recording, then exit")
    ap.add_argument("--no-mt5", action="store_true", help="do not read the broker reference")
    args = ap.parse_args()
    if args.report:
        report(args.report)
        return
    if args.no_mt5:
        os.environ["SKLZ_OF_MT5"] = "0"
    feed = Feed(record=args.record)
    try:
        asyncio.run(feed.run())
    except KeyboardInterrupt:
        log("stopped")


if __name__ == "__main__":
    main()
