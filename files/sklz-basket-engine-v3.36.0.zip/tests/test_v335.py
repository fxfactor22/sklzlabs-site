"""v3.35.0 — confirm modes (normal / ema), RSI divergence, trendlines and
channel projection, premium/discount, midnight open, fresh / HTF targets,
silver->gold SMT cache + E xag, A trendline break, C fail precondition,
M aorb, partial at target1, runner extend."""
import os
from datetime import datetime, timezone

import pytest

from basket_engine.learn import levels as LV
from basket_engine.learn import models as MD
from basket_engine.learn import trailing as TR
from basket_engine.learn import xmarket as XM


def _bar(o, h, l, c, t=None, v=10):
    return {"open": o, "high": h, "low": l, "close": c, "time": t, "volume": v}


# ── confirmation modes ───────────────────────────────────────────────
def _retest_series():
    b = [_bar(99.0, 99.6, 98.8, 99.4)] * 6
    b += [_bar(99.4, 100.9, 99.3, 100.7)]            # body close above 100
    b += [_bar(100.7, 101.2, 100.6, 101.0)]
    b += [_bar(101.0, 101.1, 100.0, 100.3)]          # retest
    b += [_bar(100.3, 100.4, 99.95, 100.05)]         # red bar at the line
    b += [_bar(100.1, 100.3, 100.0, 100.25)]         # small green close — NOT engulfing
    return b


def test_strict_mode_still_needs_engulfing(monkeypatch):
    monkeypatch.setenv("SKLZ_CONFIRM_LEVEL", "strict")
    ok, why = MD.entry_confirmed(_retest_series(), 100.0, 1, 0.1)
    assert not ok and "engulfing" in why


def test_normal_mode_accepts_any_close_in_direction(monkeypatch):
    monkeypatch.setenv("SKLZ_CONFIRM_LEVEL", "normal")
    ok, why = MD.entry_confirmed(_retest_series(), 100.0, 1, 0.1)
    assert ok and "normal" in why


def test_normal_mode_rejects_red_close(monkeypatch):
    monkeypatch.setenv("SKLZ_CONFIRM_LEVEL", "normal")
    b = _retest_series()
    b[-1] = _bar(100.4, 100.5, 100.0, 100.1)          # red, still above the line
    ok, why = MD.entry_confirmed(b, 100.0, 1, 0.1)
    assert not ok


def test_ema_cross_detects_fresh_cross():
    closes = [100.0] * 30 + [100 + i * 0.3 for i in range(1, 8)]
    x = MD.ema_cross(closes, 1, bars=8, fast=3, slow=9)
    assert x["ok"], x["why"]
    y = MD.ema_cross(closes, -1, bars=8, fast=3, slow=9)
    assert not y["ok"]


def test_ema_mode_confirms_on_cross(monkeypatch):
    monkeypatch.setenv("SKLZ_CONFIRM_LEVEL", "ema")
    monkeypatch.setenv("SKLZ_CONFIRM_EMA_FAST", "3")
    monkeypatch.setenv("SKLZ_CONFIRM_EMA_SLOW", "9")
    b = [_bar(99.0, 99.6, 98.8, 99.4)] * 20
    b += [_bar(99.4, 100.9, 99.3, 100.7), _bar(100.7, 101.2, 100.6, 101.0)]
    b += [_bar(101.0, 101.05, 100.3, 100.35), _bar(100.35, 100.4, 99.95, 100.0),
          _bar(100.0, 100.05, 99.8, 99.85), _bar(99.85, 99.95, 99.8, 99.9), _bar(99.9, 99.95, 99.8, 99.88)]
    b += [_bar(99.88, 100.2, 99.85, 100.15), _bar(100.15, 100.45, 100.1, 100.4), _bar(100.4, 100.7, 100.35, 100.65)]
    ok, why = MD.entry_confirmed(b, 100.0, 1, 0.1)
    assert ok and "EMA3 crossed above EMA9" in why


# ── RSI divergence ───────────────────────────────────────────────────
def _div_series():
    """Price makes a lower low on the second dip, but the second dip is
    shallow in momentum terms (RSI higher low)."""
    c = [100.0]
    for d in [-1.5, -1.5, -1.5, -1.5, -1.5, -1.5, 1, 1, 1, 1, 1, 1, 1, 1,
              -0.6, -0.6, -0.6, -0.6, -0.6, -0.6, -0.6, -0.6, -0.6, -0.6, -0.6, -0.6, -0.6, -0.6, -0.3,
              0.5, 0.5, 0.5]:
        c.append(c[-1] + d)
    return [_bar(a, max(a, b) + 0.1, min(a, b) - 0.1, b) for a, b in zip(c, c[1:])]


def test_rsi_divergence_bull():
    d = MD.rsi_divergence(_div_series(), period=5, lookback=40)
    assert d["kind"] == "bull", d


def test_rsi_div_judge_scores_direction():
    bars = _div_series()
    # patch period via a wrapper: judge uses defaults (14) — build a longer series
    j = MD.rsi_div_judge(bars, 1)
    assert j["ok"] in (True, None)
    k = MD.rsi_div_judge(bars, -1)
    assert k["ok"] in (False, None)
    if j["ok"] is not None:
        assert j["score"] == 10 and k["score"] == -10


# ── trendlines / channel ─────────────────────────────────────────────
def _uptrend():
    bars = []
    for i in range(60):
        base = 100 + i * 0.2
        # pivot lows exactly on the line every 6 bars, noise elsewhere
        lo = base if i % 6 == 3 else base + 0.6
        hi = base + 1.5 if i % 6 == 0 else base + 1.0
        bars.append(_bar(lo + 0.2, hi, lo, lo + 0.5))
    return bars


def test_trendline_finds_support_line():
    tl = LV.trendline(_uptrend(), 1, min_touches=3, tol_atr=0.3)
    assert tl and tl["touches"] >= 3
    assert abs(tl["slope"] - 0.2) < 0.05


def test_trendline_none_without_touches():
    flat = [_bar(100, 100.2 + (i % 7) * 0.3, 99.5 - (i % 5) * 0.4, 100) for i in range(40)]
    assert LV.trendline(flat, 1, min_touches=9) is None


def test_channel_projection_ahead_moves_with_slope():
    ch = LV.channel_projection(_uptrend())
    assert ch and ch["resistance"] > ch["support"]
    assert ch["ahead"][6][0] > ch["support"]


def test_line_value_projects():
    tl = {"now": 100.0, "slope": 0.5}
    assert LV.line_value(tl, 4) == 102.0


# ── premium / discount, midnight open ────────────────────────────────
def test_premium_discount_long_wants_lower_half():
    bars = [_bar(100, 100.5, 99.5, 100)] * 5
    bars += [_bar(100 + i, 100.5 + i, 99.5 + i, 101 + i) for i in range(10)]   # rising leg 100 -> ~110
    bars += [_bar(110, 110.2, 109.5, 109.8)] * 3
    lo = LV.premium_discount(bars, 102.0, 1)
    hi = LV.premium_discount(bars, 109.0, 1)
    assert lo["ok"] is True and hi["ok"] is False
    assert LV.premium_discount(bars, 109.0, -1)["ok"] is True


def test_midnight_open_bias():
    r = LV.midnight_open_bias(100.0, 100.3, 1, 1.0)          # long just below MO
    assert r["ok"] and r["score"] == 10
    r2 = LV.midnight_open_bias(102.0, 100.0, 1, 1.0)         # long 2 ATR above MO
    assert r2["ok"] is False
    r3 = LV.midnight_open_bias(102.0, 100.0, -1, 1.0)        # short above MO
    assert r3["ok"]


def test_midnight_open_reads_first_bar_after_local_midnight():
    # server clock = UTC; "now" = 14:00 UTC on a day in January (NY = UTC-5)
    now = datetime(2026, 1, 20, 14, 0, tzinfo=timezone.utc)
    t0 = int(now.timestamp()) - 299 * 300
    bars = [_bar(100 + i * 0.01, 100.1 + i * 0.01, 99.9 + i * 0.01, 100 + i * 0.01, t0 + i * 300)
            for i in range(300)]
    mo = LV.midnight_open(bars, now)
    t_mid = int(datetime(2026, 1, 20, 5, 0, tzinfo=timezone.utc).timestamp())
    expect = next(b["open"] for b in bars if b["time"] >= t_mid)
    assert mo == expect


# ── fresh / HTF targets ──────────────────────────────────────────────
def test_fresh_targets_drops_hit_levels():
    today = [_bar(100, 101.5, 99.8, 101), _bar(101, 101.2, 100.5, 100.8)]
    assert LV.fresh_targets([101.2, 103.0], today, 1) == [103.0]
    assert LV.fresh_targets([99.9, 98.0], today, -1) == [98.0]


def test_htf_held_level_needs_three_holds():
    bars = []
    for i in range(60):
        r = i % 10
        hi = 110.0 if r == 5 else (105 + r * 0.1 if r < 5 else 104.0)
        bars.append(_bar(104, hi, 100 + (i % 4), 104))
    lv, n = LV.htf_held_level(bars, 1, 104.0, 1.0, min_holds=3, max_r=10)
    assert lv == 110.0 and n >= 3
    lv2, _ = LV.htf_held_level(bars, 1, 104.0, 1.0, min_holds=3, max_r=4)
    assert lv2 is None                                        # 6R away, outside 4R


# ── SMT cache ────────────────────────────────────────────────────────
def test_smt_cache_follows_leader(monkeypatch):
    monkeypatch.setenv("SKLZ_SMT_PAIRS", "XAUUSD:XAGUSD")
    monkeypatch.setenv("SKLZ_XAG_TTL_MIN", "60")
    XM._SMT.clear()
    XM.note_fire("XAGUSD", -1, "e_ss", now=1000.0)
    lead = XM.lead_for("XAUUSD", now=1000.0 + 30 * 60)
    assert lead and lead["side"] == -1 and lead["tag"] == "e_ss"
    assert XM.lead_for("XAUUSD", now=1000.0 + 61 * 60) is None
    assert XM.lead_for("EURUSD", now=1000.0) is None


def test_smt_ignores_non_sweep_models(monkeypatch):
    monkeypatch.setenv("SKLZ_SMT_PAIRS", "XAUUSD:XAGUSD")
    XM._SMT.clear()
    XM.note_fire("XAGUSD", 1, "q", now=5.0)
    assert XM.lead_for("XAUUSD", now=5.0) is None


class _IO:
    def __init__(self, a, b):
        self.a, self.b = a, b

    def resolve_symbol(self, s):
        return s

    def bars(self, sym, tf, n):
        src = self.a if sym.startswith("XAU") else self.b
        return [{"close": c} for c in src[-n:]]


def test_smt_check_scores_and_corr_guard(monkeypatch):
    monkeypatch.setenv("SKLZ_SMT_PAIRS", "XAUUSD:XAGUSD")
    XM._SMT.clear()
    XM.note_fire("XAGUSD", 1, "d")
    up = [100 + i + (i % 3) * 0.1 for i in range(40)]
    r = XM.smt_check(_IO(up, up), "XAUUSD", 1)
    assert r and r["ok"] is True and r["score"] == 10
    r2 = XM.smt_check(_IO(up, up), "XAUUSD", -1)
    assert r2["ok"] is False and r2["score"] == -10
    noise = [100 + ((i * 7919) % 13) * 0.3 for i in range(40)]      # uncorrelated
    r3 = XM.smt_check(_IO(up, noise), "XAUUSD", 1)
    assert r3["ok"] is None and r3["score"] == 0


# ── E xag ────────────────────────────────────────────────────────────
def test_model_e_xag_fires_at_range_edge(monkeypatch):
    monkeypatch.setenv("SKLZ_E_LEVELS", "xag")
    monkeypatch.setenv("SKLZ_MIN_TARGET_RR", "1.5")
    h1 = [_bar(100, 101, 99, 100)] * 50
    m15 = [_bar(100, 110, 100, 105)] * 20 + [_bar(101, 101.5, 100.0, 100.8)] * 12
    m5 = [_bar(100.9, 101.0, 100.4, 100.6)] * 12 + [_bar(100.6, 100.9, 100.3, 100.8)]
    ex = {"symbol": "XAUUSD", "m15": m15, "xag_lead": {"side": 1, "tag": "e", "age_min": 12, "corr": 0.8}}
    s = MD.model_e(h1, m5, 0.1, ex)
    assert s.ok and s.tag == "e_xag" and s.side == 1 and s.target == 110


def test_model_e_xag_respects_corr_and_symbol(monkeypatch):
    monkeypatch.setenv("SKLZ_E_LEVELS", "xag")
    h1 = [_bar(100, 101, 99, 100)] * 50
    m15 = [_bar(100, 110, 100, 105)] * 32
    m5 = [_bar(100.9, 101.0, 100.4, 100.6)] * 13
    ex = {"symbol": "XAUUSD", "m15": m15, "xag_lead": {"side": 1, "tag": "e", "age_min": 1, "corr": 0.1}}
    assert not MD.model_e(h1, m5, 0.1, ex).ok
    ex2 = {"symbol": "EURUSD", "m15": m15, "xag_lead": {"side": 1, "tag": "e", "age_min": 1, "corr": 0.9}}
    assert not MD.model_e(h1, m5, 0.1, ex2).ok


# ── A trendline break, C fail precondition ───────────────────────────
def test_a_trendline_levels_need_momentum_loss(monkeypatch):
    monkeypatch.setenv("SKLZ_TL_NEED_FAIL", "1")
    bars = _uptrend()
    # keeps making higher highs -> no failure -> no level
    assert not [l for l in MD._a_trendline_levels(bars) if l["kind"] == "low"]
    monkeypatch.setenv("SKLZ_TL_NEED_FAIL", "0")
    lv = MD._a_trendline_levels(bars)
    assert any(l["kind"] == "low" and l.get("tl") for l in lv)


def test_c_msb_need_fail_blocks_fresh_lows(monkeypatch):
    monkeypatch.setenv("SKLZ_C_SWEEP", "0")
    monkeypatch.setenv("SKLZ_C_MSB", "1")
    monkeypatch.setenv("SKLZ_C_MSB_NEED_FAIL", "1")
    h4 = [_bar(100, 102, 99, 101.5)] * 4 + [_bar(101.5, 102, 99, 101)]
    # trap leg: a zigzag of LOWER lows (every dip a pivot), then a sharp
    # reversal back through the leg's structure
    m5 = [_bar(101.5, 101.6, 101.2, 101.3)] * 30
    for i in range(5):
        lo = 101.0 - i * 0.3
        m5.append(_bar(lo + 0.25, lo + 0.3, lo, lo + 0.05))          # down to a new low
        m5.append(_bar(lo + 0.05, lo + 0.25, lo + 0.03, lo + 0.2))   # bounce
    m5 += [_bar(99.9, 101.9, 99.88, 101.8), _bar(101.8, 102.0, 101.4, 101.7), _bar(101.7, 101.75, 101.3, 101.65)]
    s = MD.model_c(h4, m5, 0.1)
    assert not s.ok and any("momentum loss" in b for b in s.blockers), s.blockers


# ── M aorb ───────────────────────────────────────────────────────────
def _aorb_frames():
    """Sydney 10:00 on 2026-01-20 (AEDT, UTC+11) = 23:00 UTC 2026-01-19.
    Server clock = UTC. 'now' = 00:20 UTC. Range candle 100-101; PDH 103
    swept at 00:00, FVG down through the 0.618 line, inverted, retested."""
    t_open = int(datetime(2026, 1, 19, 23, 0, tzinfo=timezone.utc).timestamp())
    now = datetime(2026, 1, 20, 0, 20, tzinfo=timezone.utc)
    m15 = []
    t = t_open - 96 * 900
    for i in range(96):                                     # yesterday + pre-open, range 98-103
        hi = 103.0 if i == 40 else 101.0
        m15.append(_bar(100.0, hi, 98.0, 100.0, t + i * 900))
    m15.append(_bar(100.2, 101.0, 100.0, 100.8, t_open))     # the opening range
    for i in range(1, 6):
        m15.append(_bar(100.8, 101.2, 100.5, 100.9, t_open + i * 900))
    # M5 inside the window
    m5 = [_bar(100.5, 100.6, 100.4, 100.5, t_open - (30 - i) * 300) for i in range(30)]
    seq = [
        _bar(100.8, 101.0, 100.7, 100.9), _bar(100.9, 101.1, 100.8, 101.0),
        _bar(101.0, 102.0, 100.9, 101.9), _bar(101.9, 103.2, 101.8, 102.6),   # sweeps PDH 103, closes back
        _bar(102.6, 102.7, 102.3, 102.4),
        _bar(102.4, 102.5, 101.5, 101.6),    # FVG down: prev low 102.3 > next high ... see next
        _bar(101.4, 101.45, 100.9, 101.0),   # gap between bar[-3].low 102.3 and this high 101.45 -> FVG 101.45-102.3 (0.618 line 100.618? no: 1.272 ext up=101.27 inside)
        _bar(101.0, 101.2, 100.8, 100.9),
        _bar(100.9, 102.5, 100.8, 102.4),    # inverts the gap (close > top 102.3)
        _bar(102.4, 102.5, 102.0, 102.2),    # retest (low <= top)
        _bar(102.2, 102.9, 102.1, 102.8),    # close beyond the gap -> entry (long? no — side after a HIGH sweep is SHORT)
    ]
    for i, b in enumerate(seq):
        b["time"] = t_open + 900 + i * 300
        m5.append(b)
    m5.append(_bar(102.8, 102.9, 102.6, 102.7, t_open + 900 + len(seq) * 300))   # forming bar
    return m15, m5, now


def test_aorb_window_and_symbol_gates(monkeypatch):
    monkeypatch.setenv("SKLZ_M_AORB_SYMBOLS", "XAUUSD")
    m15, m5, now = _aorb_frames()
    s = MD._model_m_aorb(m15, m5, 0.1, {"symbol": "EURUSD", "now": now})
    assert not s.ok and "SKLZ_M_AORB_SYMBOLS" in s.blockers[0]
    late = datetime(2026, 1, 20, 3, 0, tzinfo=timezone.utc)
    s2 = MD._model_m_aorb(m15, m5, 0.1, {"symbol": "XAUUSD", "now": late})
    assert not s2.ok and "window closed" in s2.blockers[0]


def test_aorb_fib_lines_cover_both_directions():
    f = MD._aorb_fib_lines(100.0, 101.0)
    prices = [p for p, _ in f]
    r = [round(p, 3) for p in prices]
    assert 100.5 in r and 101.272 in r and 99.382 in r and 100.618 in r


def test_aorb_requires_sweep_in_window(monkeypatch):
    monkeypatch.setenv("SKLZ_M_AORB_SYMBOLS", "XAUUSD")
    m15, m5, now = _aorb_frames()
    t0 = m5[30]["time"]
    quiet = m5[:30] + [_bar(100.8, 100.9, 100.7, 100.8, t0 + 300 * i) for i in range(10)]
    s = MD._model_m_aorb(m15, quiet, 0.1, {"symbol": "XAUUSD", "now": now})
    assert not s.ok and any("swept" in b for b in s.blockers), s.blockers


def test_aorb_short_after_pdh_sweep(monkeypatch):
    monkeypatch.setenv("SKLZ_M_AORB_SYMBOLS", "XAUUSD")
    monkeypatch.setenv("SKLZ_M_AORB_MIN_RR", "0.5")
    monkeypatch.setenv("SKLZ_MIN_FVG_PIPS", "1")
    m15, m5, now = _aorb_frames()
    # the sweep is of a HIGH -> trade is SHORT: rebuild the tail for a short
    t0 = m5[30]["time"]
    tail = [
        _bar(100.8, 101.0, 100.7, 100.9), _bar(100.9, 101.1, 100.8, 101.0),
        _bar(101.0, 102.0, 100.9, 101.9), _bar(101.9, 103.2, 101.8, 102.6),   # sweep PDH 103
        _bar(102.6, 102.7, 102.3, 102.4),
        _bar(102.4, 102.6, 102.35, 102.55),
        _bar(102.55, 103.4, 102.5, 103.3),                                   # bullish FVG up (bar-2 high 102.7 < low 102.5? no)
    ]
    # construct an explicit bullish FVG through the 1.618 ext (101.618) then invert it downward
    tail = [
        _bar(100.8, 101.0, 100.7, 100.9), _bar(100.9, 101.1, 100.8, 101.0),
        _bar(101.0, 101.3, 100.9, 101.2),
        _bar(101.2, 101.4, 101.1, 101.35),      # a
        _bar(101.35, 102.4, 101.3, 102.3),      # big up bar
        _bar(102.3, 103.2, 101.9, 102.6),       # b: low 101.9 > a.high 101.4 -> FVG 101.4-101.9 (1.618 ext 101.618 inside); sweeps 103
        _bar(102.6, 102.7, 102.2, 102.3),
        _bar(102.3, 102.4, 101.0, 101.1),       # inverts: close < bottom 101.4
        _bar(101.1, 101.6, 101.0, 101.3),       # retest: high >= bottom 101.4
        _bar(101.3, 101.35, 100.6, 100.7),      # close beyond (below bottom) -> entry
    ]
    base = m5[:30]
    for i, b in enumerate(tail):
        b["time"] = t0 + i * 300
        base.append(b)
    base.append(_bar(100.7, 100.8, 100.5, 100.6, t0 + len(tail) * 300))
    s = MD._model_m_aorb(m15, base, 0.1, {"symbol": "XAUUSD", "now": now})
    assert s.ok, s.blockers
    assert s.side == -1 and s.tag == "m_aorb" and s.stop > s.entry and s.target < s.entry


# ── partial at target1, runner extend ────────────────────────────────
class _TrailIO:
    def __init__(self, bars5, tp=105.0):
        self.bars5 = bars5
        self.pos = {"ticket": 7, "symbol": "XAUUSD", "side": 1, "open_price": 100.0,
                    "sl": 99.0, "tp": tp, "lots": 0.1, "comment": "sklz-a E"}
        self.modified = []
        self.closed = []

    def my_positions(self):
        return [self.pos]

    def price(self, sym, side):
        return 102.0

    def spec(self, sym):
        return {"digits": 2, "lot_step": 0.01, "lot_min": 0.01}

    def bars(self, sym, tf, n):
        return self.bars5[-n:]

    def modify_sl(self, tk, sl, tp=None):
        self.modified.append((tk, sl, tp))
        return True

    def close(self, pos):
        self.closed.append(pos)
        return True


def test_partial_at_target1_waits_for_the_level(monkeypatch):
    monkeypatch.setenv("SKLZ_PARTIAL_R", "1.0")
    monkeypatch.setenv("SKLZ_PARTIAL_AT", "target1")
    monkeypatch.setenv("SKLZ_RUNNER_EXTEND", "0")
    monkeypatch.setenv("SKLZ_TRAIL_MODE", "r")
    TR._PARTIAL_DONE.clear()
    TR._TARGET1.clear()
    io = _TrailIO([_bar(100, 100.5, 99.5, 100.2)] * 10)
    TR.remember_target1(7, 103.0)                     # price 102 < 103: no partial yet
    TR.manage(io, log=lambda *a: None)
    assert not io.closed
    TR.remember_target1(7, 101.5)                     # level reached -> half off
    TR._PARTIAL_DONE.clear()
    TR.manage(io, log=lambda *a: None)
    assert io.closed and abs(io.closed[0]["lots"] - 0.05) < 1e-9


def test_runner_extend_drops_tp_after_six_closes(monkeypatch):
    monkeypatch.setenv("SKLZ_PARTIAL_R", "0")
    monkeypatch.setenv("SKLZ_RUNNER_EXTEND", "1")
    monkeypatch.setenv("SKLZ_RUNNER_BARS", "6")
    monkeypatch.setenv("SKLZ_TRAIL_MODE", "r")
    monkeypatch.setenv("SKLZ_TRAIL_TRIGGER_R", "0.8")
    monkeypatch.setenv("SKLZ_TRAIL_DIST_R", "0.5")
    TR._EXTENDED.clear()
    greens = [_bar(100 + i * 0.1, 100.2 + i * 0.1, 99.9 + i * 0.1, 100.15 + i * 0.1) for i in range(8)]
    io = _TrailIO(greens, tp=105.0)
    out = TR.manage(io, log=lambda *a: None)
    assert any(ev.get("tp_dropped") for ev in out)
    assert io.modified and io.modified[-1][2] == 0.0
    # mixed bars: TP stays
    TR._EXTENDED.clear()
    mixed = greens[:-1] + [_bar(100.8, 100.9, 100.5, 100.6)] + [greens[-1]]
    io2 = _TrailIO(mixed, tp=105.0)
    out2 = TR.manage(io2, log=lambda *a: None)
    assert not any(ev.get("tp_dropped") for ev in out2)


# ── runner smoke: the v3.35 confluence block and target wiring run end to end ──
class _ScanIO:
    def __init__(self):
        t0 = 1_700_000_000
        self.m = []
        px = 100.0
        for i in range(320):
            px += 0.05 if (i // 7) % 2 == 0 else -0.04
            self.m.append({"open": px - 0.02, "high": px + 0.08, "low": px - 0.08,
                           "close": px + 0.02, "volume": 5, "time": t0 + i * 300})
        self.px = px
        self.orders = []

    def account(self): return {"equity": 50000.0, "balance": 50000.0, "free_margin": 50000.0}
    def closes(self, s, tf, n): return [b["close"] for b in self.m][-n:]
    def bars(self, s, tf, n): return self.m[-n:]
    def has_symbol(self, s): return True
    def resolve_symbol(self, s): return s
    def spec(self, s): return {"point": 0.01, "tick_value": 1.0, "tick_size": 0.01,
                               "lot_min": 0.01, "lot_step": 0.01, "lot_max": 100.0, "digits": 2,
                               "contract_size": 1.0, "margin_initial": 0.0}
    def price(self, s, side): return self.px + (0.01 if side > 0 else -0.01)
    def spread(self, s): return 0.02
    def my_positions(self): return []
    def basket_profit(self): return 0.0
    def margin_required(self, s, lots, side=1): return 10.0
    def market_live(self, s, max_age_sec=120): return True
    def market(self, symbol, side, lots, sl, comment, tp=0.0):
        self.orders.append({"symbol": symbol, "side": side, "lots": lots, "sl": sl, "tp": tp, "comment": comment})
        return {"ok": True, "ticket": 900 + len(self.orders), "price": self.price(symbol, side), "retcode": 10009}


def test_scan_once_runs_confluence_and_enters(tmp_path, monkeypatch):
    from basket_engine.learn import runner as RN
    from basket_engine.learn import quality as Q
    for k, v in {"SKLZ_MODELS_ENABLED": "e", "SKLZ_PROP_GUARD": "0", "SKLZ_INSTITUTIONAL": "0",
                 "SKLZ_PLAYBOOK": "0", "SKLZ_ENTRY_CONFIRM": "0", "SKLZ_PUBLISH_SIGNALS": "0",
                 "SKLZ_SL_STRUCTURE": "0", "SKLZ_XAU_DXY": "off", "SKLZ_RSI_DIV": "score",
                 "SKLZ_PD_FILTER": "score", "SKLZ_MO_MODE": "score", "SKLZ_TARGET_FRESH": "1",
                 "SKLZ_TARGET_PREFER_HTF": "1", "SKLZ_SMT_PAIRS": "XAUUSD:XAGUSD"}.items():
        monkeypatch.setenv(k, v)
    monkeypatch.chdir(tmp_path)
    io = _ScanIO()
    logs = []
    r = LearningRunner = RN.LearningRunner(io, log=logs.append, auto=True, symbols=["XAUUSD"])
    monkeypatch.setattr(RN, "SCANNERS", {"sweep_reversal": lambda io_, s, tf, lb: (1, f"sweep of lows {io.px - 1:.2f}")})
    setup = MD.Setup(ok=True, model="E: session sweep reclaim", side=1, entry=io.px, level=io.px - 1.0,
                     stop=io.px - 1.5, reasons=["swept and reclaimed"], tag="e")
    monkeypatch.setattr(r, "_run_models", lambda sym: setup)
    monkeypatch.setattr(Q, "score_setup", lambda *a, **k: {"side": 1, "score": 80, "scanners": ["sweep_reversal", "model_e"],
                                                            "reasons": ["test"], "detail": "test"})
    XM._SMT.clear()
    XM.note_fire("XAGUSD", 1, "e")
    n = r.scan_once()
    errs = [l for l in logs if l.startswith("[confluence]") or "check failed" in l]
    assert not errs, errs
    assert n == 1 and io.orders, logs[-10:]
    assert any(l.startswith("[smt]") for l in logs), logs
    assert any(l.startswith("[pd]") or l.startswith("[rsidiv]") or l.startswith("[mo]") for l in logs)


def test_max_risk_pct_caps_risk_based_sizing(monkeypatch):
    from basket_engine.learn.entries import EntryController

    class IO:
        def account(self): return {"equity": 50000.0}
        def spec(self, s): return {"tick_size": 0.01, "tick_value": 1.0, "lot_min": 0.01,
                                   "lot_step": 0.01, "lot_max": 100.0, "digits": 2}
    monkeypatch.delenv("SKLZ_LOT_PER_EQUITY", raising=False)
    monkeypatch.setenv("SKLZ_MAX_LOTS", "0")
    monkeypatch.setenv("SKLZ_MAX_LOTS_BY_SYMBOL", "")
    ec = EntryController(IO(), None, risk_pct=0.5, log=lambda *a: None)
    monkeypatch.setenv("SKLZ_MAX_RISK_PCT", "0")
    full = ec._size("XAUUSD", 1.0)                 # $250 risk / (100 ticks * $1) = 2.5 lots
    monkeypatch.setenv("SKLZ_MAX_RISK_PCT", "0.25")
    half = ec._size("XAUUSD", 1.0)
    assert full == 2.5 and half == 1.25


def test_runner_reads_risk_pct_env(tmp_path, monkeypatch):
    from basket_engine.learn import runner as RN
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("SKLZ_RISK_PCT", "0.25")
    r = RN.LearningRunner(_ScanIO(), log=lambda *a: None, auto=False, symbols=["XAUUSD"])
    assert r.ec.risk_pct == 0.25


def test_scan_once_survives_several_symbols_with_the_shipped_bat(tmp_path, monkeypatch):
    """v3.35.1 regression: the confluence block shadowed the SKLZ_BLOCKED_SYMBOLS
    set and the second symbol of every scan raised TypeError."""
    import re
    from basket_engine.learn import runner as RN
    bat = os.path.join(os.path.dirname(__file__), "..", "start_master.bat")
    for line in open(bat, encoding="utf-8", errors="ignore"):
        m = re.match(r"set (\w+)=(.*)", line.strip())
        if m:
            monkeypatch.setenv(m.group(1), m.group(2).replace("%%", "%"))
    monkeypatch.setenv("SKLZ_PUBLISH_SIGNALS", "0")
    monkeypatch.setenv("SKLZ_PROP_GUARD", "0")
    monkeypatch.setenv("SKLZ_BOT_KEY", "")
    monkeypatch.chdir(tmp_path)
    logs = []
    r = RN.LearningRunner(_ScanIO(), log=logs.append, auto=True, symbols=["EURUSD", "XAUUSD", "XAGUSD", "US30"])
    r.scan_once()                       # must not raise
    r.scan_once()


# ── v3.35.2 ──────────────────────────────────────────────────────────
def test_premium_discount_ignores_tiny_legs_and_outside_price(monkeypatch):
    monkeypatch.setenv("SKLZ_PD_MIN_ATR", "2.0")
    # a big rising leg 100 -> 110, then a 2-pip wiggle at the top
    bars = [_bar(100, 100.5, 99.5, 100)] * 5
    bars += [_bar(100 + i, 100.5 + i, 99.5 + i, 101 + i) for i in range(10)]
    bars += [_bar(110.0, 110.02, 109.98, 110.01), _bar(110.01, 110.03, 109.99, 110.0),
             _bar(110.0, 110.02, 109.97, 109.99), _bar(109.99, 110.01, 109.98, 110.0)]
    r = LV.premium_discount(bars, 109.5, 1)
    assert r["ok"] is False and 0.9 < r["frac"] < 1.0        # measured on the big leg, not the wiggle
    far = LV.premium_discount(bars, 125.0, 1)
    assert far["ok"] is None


def test_model_led_setup_not_vetoed_by_node_or_block_flags(tmp_path, monkeypatch):
    from basket_engine.learn import runner as RN
    from basket_engine.learn import quality as Q
    from basket_engine.learn import institutional as INST
    for k, v in {"SKLZ_MODELS_ENABLED": "e", "SKLZ_PROP_GUARD": "0", "SKLZ_INSTITUTIONAL": "1",
                 "SKLZ_INST_MODELS": "score", "SKLZ_INST_MIN_SCORE_MODEL": "70",
                 "SKLZ_PLAYBOOK": "0", "SKLZ_ENTRY_CONFIRM": "0", "SKLZ_PUBLISH_SIGNALS": "0",
                 "SKLZ_SL_STRUCTURE": "0", "SKLZ_XAU_DXY": "off", "SKLZ_RSI_DIV": "off",
                 "SKLZ_PD_FILTER": "off", "SKLZ_MO_MODE": "off", "SKLZ_KZ_SCORE": "0"}.items():
        monkeypatch.setenv(k, v)
    monkeypatch.chdir(tmp_path)
    io = _ScanIO()
    logs = []
    r = RN.LearningRunner(io, log=logs.append, auto=True, symbols=["EURUSD"])
    monkeypatch.setattr(RN, "SCANNERS", {})
    setup = MD.Setup(ok=True, model="E: session sweep reclaim", side=1, entry=io.px, level=io.px - 1.0,
                     stop=io.px - 1.5, reasons=["swept and reclaimed"], tag="e")
    monkeypatch.setattr(r, "_run_models", lambda sym: setup)
    monkeypatch.setattr(Q, "score_setup", lambda *a, **k: {"side": 1, "score": 80, "scanners": ["model_e"],
                                                            "reasons": ["t"], "detail": "t"})
    a = INST.Assessment() if hasattr(INST, "Assessment") else None
    if a is None:
        pytest.skip("no Assessment class")
    a.score, a.veto, a.passed = 80.0, True, False
    a.flags = ["price is sitting ON a high-volume node (1.1) — absorbed", "INTO HTF BLOCK — opposing"]
    a.verdict = "rejected"
    monkeypatch.setattr(r, "_institutional", lambda sym, side: a)
    n = r.scan_once()
    assert n == 1 and io.orders, logs[-8:]
    # with measured flow against, still kept out
    io.orders.clear(); r._auto_seen.clear(); r._recent_entries = {}
    a.flags = ["DELTA AGAINST — order flow is -40% sell-side"]
    a.passed = False
    n2 = r.scan_once()
    assert n2 == 0 and not io.orders
