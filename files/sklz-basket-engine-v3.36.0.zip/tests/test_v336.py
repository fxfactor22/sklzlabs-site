"""v3.36 — Model R (order flow) injection tests.

The contract this release makes: with "r" absent from SKLZ_MODELS_ENABLED
and the new SKLZ_OF_* / SKLZ_R_* / *_BY_MODEL variables unset, every
existing switch behaves exactly as in v3.35.2. These tests pin that first,
then exercise the feed maths, the guards, the model, and the hooks.
"""
from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone

import pytest

from basket_engine.learn import of_feed as OF
from basket_engine.learn import permodel as PM
from basket_engine.learn import model_r as R
from basket_engine.learn import models as MD
from basket_engine.learn import entries as EN
from basket_engine.learn import trailing as TR
from basket_engine.learn import context_note as CN


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch, tmp_path):
    for k in list(os.environ):
        if k.startswith(("SKLZ_OF_", "SKLZ_R_", "SKLZ_LLM_", "SKLZ_MODEL_SL", "SKLZ_MAX_LOTS",
                         "SKLZ_ENTRY_CONFIRM", "SKLZ_MODELS_ENABLED", "ANTHROPIC_API_KEY")):
            monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("SKLZ_OF_STATE", str(tmp_path / "orderflow_state.json"))
    R._first_seen.clear()
    CN._cache.clear()
    yield


# ───────────────────────── synthetic footprint ────────────────────────
def _stream(fp: OF.Footprint, t0: float, minutes: int, px0: float, drift: float,
            buy_share: float, qty: float = 1.0, per_min: int = 30, big_at: list[int] | None = None):
    """Feed `minutes` of trades; buy_share of them are aggressive buys."""
    px = px0
    for m in range(minutes):
        for i in range(per_min):
            ts = t0 + m * 60 + i * (60 / per_min)
            is_buy = i < buy_share * per_min
            px += drift / per_min
            q = qty
            if big_at and m in big_at and i in (3, 7, 11):
                q = qty * 12          # three big prints in this bar
            fp.add_trade(round(px, 2), q, is_buy, ts)
    return fp


def _state(fp: OF.Footprint, basis_pct=0.05, corr=0.9, n=60, ts=None, mt5=True):
    px = fp.price or 1.0
    mt = {"symbol": "XAUUSD", "mid": px * (1 - basis_pct / 100), "ts": ts or time.time(),
          "basis": px * basis_pct / 100, "basis_pct": basis_pct, "corr60": corr, "n": n}
    st = fp.snapshot(mt5=mt if mt5 else None)
    if ts:
        st["ts"] = ts
    return st


def test_footprint_builds_minute_bars_with_delta_and_bins():
    fp = OF.Footprint(bin_sz=1.0, big_x=5.0)
    _stream(fp, 1_700_000_000, 5, 2000.0, 2.0, buy_share=0.8)
    assert 5 <= len(fp.bars) <= 6
    bar = fp.bars[-2]            # a closed one
    assert bar.v > 0 and bar.bv > bar.sv and bar.d > 0
    assert bar.bins and all(len(v) == 2 for v in bar.bins.values())
    assert fp.cvd > 0


def test_stacked_buy_imbalances_detected_on_one_sided_flow():
    fp = OF.Footprint(bin_sz=1.0)
    _stream(fp, 1_700_000_000, 4, 2000.0, 6.0, buy_share=0.95)
    st = fp.snapshot()
    ag = OF.aggression(st, +1)
    assert ag["ok"] and ag["kind"] in ("stacked_imbalance", "big_print", "absorption")
    assert ag["print_px"] > 0
    # the opposite side sees no aggression in the same tape
    assert not OF.aggression(st, -1)["ok"]


def test_big_prints_count_against_rolling_median():
    fp = OF.Footprint(bin_sz=1.0, big_x=5.0)
    _stream(fp, 1_700_000_000, 6, 2000.0, 0.5, buy_share=0.7, big_at=[4])
    bars = list(fp.bars)
    assert any(b.big_buy >= 2 for b in bars)


def test_guards_fail_closed():
    ok, why = OF.guards(None, "no state")
    assert not ok and "no state" in why
    fp = OF.Footprint(bin_sz=1.0)
    _stream(fp, 1_700_000_000, 3, 2000.0, 1.0, 0.6)
    assert OF.guards(_state(fp, mt5=False))[0] is False        # needs MT5 reference by default
    assert OF.guards(_state(fp, basis_pct=0.9))[0] is False    # PAXG off gold
    assert OF.guards(_state(fp, corr=0.2, n=60))[0] is False   # decoupled
    assert OF.guards(_state(fp, corr=0.2, n=10))[0] is True    # too few samples to judge → allowed
    assert OF.guards(_state(fp))[0] is True


def test_state_file_roundtrip_and_staleness(tmp_path):
    fp = OF.Footprint(bin_sz=1.0)
    _stream(fp, 1_700_000_000, 3, 2000.0, 1.0, 0.6)
    st = _state(fp, ts=1000.0)
    OF.write_state(st)
    got, why = OF.load_state(now=1003.0)
    assert got and not why
    got, why = OF.load_state(now=1010.0)
    assert got is None and "old" in why


def test_map_price_removes_basis():
    st = {"mt5": {"basis": 1.5}}
    assert OF.map_price(2001.5, st) == pytest.approx(2000.0)


def test_pressure_fading_requires_all_bars_against():
    fp = OF.Footprint(bin_sz=1.0)
    _stream(fp, 1_700_000_000, 6, 2000.0, -3.0, buy_share=0.1)   # heavy selling
    st = fp.snapshot()
    fading, why = OF.pressure_fading(st, +1, bars=3)
    assert fading and "against" in why
    assert OF.pressure_fading(st, -1, bars=3)[0] is False


def test_reference_basis_and_correlation():
    ref = OF.Reference("XAUUSD", window_min=60)
    t0 = 1_700_000_000
    for i in range(70):
        px = 2000 + i * 0.5 + (i % 3)
        ref.update(px + 1.0, px, t0 + i * 60)
    d = ref.to_dict()
    assert d["basis"] == pytest.approx(1.0, abs=0.2)
    assert d["corr60"] is not None and d["corr60"] > 0.8 and d["n"] >= 30


# ───────────────────────── permodel ───────────────────────────────────
def test_permodel_tag_and_lookups(monkeypatch):
    assert PM.model_tag("strength_extreme+model_r_trend") == "r"
    assert PM.model_tag("model_e_tl") == "e"
    assert PM.model_tag("strength_extreme") == ""
    assert PM.lot_cap("r") is None
    monkeypatch.setenv("SKLZ_MAX_LOTS_BY_MODEL", "r:0.04, p:0.02")
    assert PM.lot_cap("r") == 0.04 and PM.lot_cap("p") == 0.02 and PM.lot_cap("e") is None
    monkeypatch.setenv("SKLZ_MODEL_SL", "0")
    assert PM.model_sl_allowed("e") is False and PM.model_sl_allowed("r") is False
    monkeypatch.setenv("SKLZ_MODEL_SL_BY_MODEL", "r:1")
    assert PM.model_sl_allowed("r") is True and PM.model_sl_allowed("e") is False
    # confirm exemption: default p_open only, letters match variants
    assert PM.confirm_exempt("p_open") and not PM.confirm_exempt("r_trend")
    monkeypatch.setenv("SKLZ_ENTRY_CONFIRM_EXEMPT", "p_open,r")
    assert PM.confirm_exempt("r_trend") and PM.confirm_exempt("r_mr") and PM.confirm_exempt("p_open")
    assert not PM.confirm_exempt("e_tl")


# ───────────────────────── model R ────────────────────────────────────
def _bars(n, start, step_min, px0, path, vol=None):
    """OHLC bars with timestamps; `path(i)` gives the close for bar i,
    `vol(i)` the volume (default 100)."""
    out, prev = [], px0
    for i in range(n):
        c = path(i)
        o = prev
        hi, lo = max(o, c) + 0.3, min(o, c) - 0.3
        out.append({"time": start + i * step_min * 60, "open": o, "high": hi, "low": lo,
                    "close": c, "volume": vol(i) if vol else 100})
        prev = c
    return out


def _now():
    return datetime(2026, 11, 11, 9, 0, tzinfo=timezone.utc)      # 09:00 UTC = London


def _trend_fixture():
    """Yesterday balanced 1990-2010; today impulse up to 2040, pullback to ~2025."""
    now = _now()
    t_now = int(now.timestamp())
    day0 = t_now // 86400 * 86400
    # M15: yesterday (full server day) oscillates inside 1992-2008; today's
    # 36 bars run up to 2040 and pull back
    m15 = _bars(96, day0 - 86400, 15, 2000.0, lambda i: 2000 + 8 * ((i % 8) - 4) / 4)
    m15 += _bars(36, day0, 15, 2004.0,
                 lambda i: 2004 + min(36, i * 1.5) if i < 26 else 2040 - (i - 26) * 1.5)
    h1 = _bars(60, t_now - 60 * 3600, 60, 2000.0,
               lambda i: (2000 + (i - 40) * 1.0 + 4 * (i % 2)) if i >= 40 else 2000 + 4 * (i % 2))
    # M5: chop at 2005 (inside value), leave value slowly, a FAST stretch
    # 2017→2033 (the low-volume node), stall near 2040, pull back into the
    # fast stretch and hold around 2021.5
    def p5(i):
        if i < 44:
            return 2000 + 0.3 * ((i % 4) - 2)          # rotating inside value
        if i < 56:
            return 2000 + (i - 44) * 1.4               # leaves value
        if i < 58:
            return 2017 + (i - 56) * 8.0               # two-bar fast stretch = the low-volume node
        if i < 72:
            return 2033 + (i - 58) * 0.5               # stalls near 2040 (volume builds)
        if i < 76:
            return 2040 - (i - 72) * 5.1               # fast pullback into the node
        return 2019.5 + 0.2 * ((i % 3) - 1)            # a few quiet bars resting there

    def v5(i):
        return 25 if i >= 76 or 56 <= i < 58 or 72 <= i < 76 else 100   # fast / resting bars are thin
    m5 = _bars(82, t_now - 82 * 300, 5, 2000.0, p5, vol=v5)
    return m15, h1, m5, now


def _write_feed(side_bias: float, drift: float, px0: float, ts: float):
    fp = OF.Footprint(bin_sz=1.0)
    _stream(fp, ts - 300, 5, px0, drift, buy_share=side_bias)
    OF.write_state(_state(fp, ts=ts))
    return fp


def _extra(m15, now, fp=None):
    return {"symbol": "XAUUSD..", "m15": m15, "now_utc": now,
            "now_epoch": now.timestamp(), "r_losses_today": 0}


def test_model_r_refuses_other_symbols_and_hours():
    m15, h1, m5, now = _trend_fixture()
    s = R.model_r(h1, m5, 0.1, {"symbol": "EURUSD", "m15": m15, "now_utc": now})
    assert not s.ok and "XAUUSD only" in s.blockers[0]
    late = datetime(2026, 11, 11, 20, 0, tzinfo=timezone.utc)
    s = R.model_r(h1, m5, 0.1, {"symbol": "XAUUSD", "m15": m15, "now_utc": late})
    assert not s.ok and "outside R hours" in s.blockers[0]


def test_model_r_fails_closed_without_feed():
    m15, h1, m5, now = _trend_fixture()
    s = R.model_r(h1, m5, 0.1, _extra(m15, now))
    assert not s.ok and "orderflow_feed.py" in s.blockers[0]


def test_model_r_trend_fires_with_aggression_and_declines_without(monkeypatch):
    m15, h1, m5, now = _trend_fixture()
    monkeypatch.setenv("SKLZ_MIN_TARGET_RR", "1.0")
    # buyers stepping in at the pullback
    _write_feed(0.95, 4.0, 2019.5, now.timestamp())
    s = R.model_r(h1, m5, 0.1, _extra(m15, now))
    assert s.ok, s.blockers
    assert s.side == 1 and s.tag == "r_trend"
    assert s.stop < s.entry < s.target
    assert (s.entry - s.stop) <= 120 * 0.1 + 1e-6
    assert any("aggression" in r for r in s.reasons)
    # same chart, sellers in control at the node -> no trade
    _write_feed(0.05, -4.0, 2019.5, now.timestamp())
    s2 = R.model_r(h1, m5, 0.1, _extra(m15, now))
    assert not s2.ok and any("aggression" in b for b in s2.blockers)


def test_model_r_daily_loss_limit(monkeypatch):
    m15, h1, m5, now = _trend_fixture()
    _write_feed(0.95, 4.0, 2019.5, now.timestamp())
    ex = _extra(m15, now)
    ex["r_losses_today"] = 3
    s = R.model_r(h1, m5, 0.1, ex)
    assert not s.ok and "stops today" in s.blockers[0]


def test_model_r_mean_reversion_after_failed_break(monkeypatch):
    now = _now()
    t_now = int(now.timestamp())
    # yesterday: 1990-2010 balance; today: push to 2016 that fails, back inside, pullback to VAH
    day0 = t_now // 86400 * 86400
    m15 = _bars(96, day0 - 86400, 15, 2000.0, lambda i: 2000 + 8 * ((i % 8) - 4) / 4)
    m15 += _bars(36, day0, 15, 2000.0, lambda i: 2000 + 2 * ((i % 5) - 2))
    h1 = _bars(60, t_now - 60 * 3600, 60, 2000.0, lambda i: 2000 + 3 * ((i % 4) - 2))

    def p5(i):
        if i < 50:
            return 2000 + 2 * ((i % 5) - 2)           # rotating inside value
        if i < 56:
            return 2001 + (i - 50) * 1.2              # break above VAH (~2002) to ~2007
        if i < 64:
            return 2007 - (i - 56) * 1.4              # fails, back inside to ~1997
        if i < 72:
            return 1997 + (i - 64) * 0.55             # pullback toward the VAH edge
        return 2001.3 + 0.15 * ((i % 3) - 1)
    m5 = _bars(80, t_now - 80 * 300, 5, 2000.0, p5)
    monkeypatch.setenv("SKLZ_R_MODES", "mr")
    monkeypatch.setenv("SKLZ_R_EDGE_TOL_ATR", "3.0")
    monkeypatch.setenv("SKLZ_MIN_TARGET_RR", "0.3")
    _write_feed(0.05, -4.0, 2001.3, now.timestamp())      # sellers at the edge
    s = R.model_r(h1, m5, 0.1, _extra(m15, now))
    assert s.ok, s.blockers
    assert s.side == -1 and s.tag == "r_mr"
    assert s.stop > s.entry > s.target


# ───────────────────────── hooks ──────────────────────────────────────
def test_dispatch_has_r_and_is_inert_when_disabled(monkeypatch):
    assert "r" in MD.ALL_MODELS
    m15, h1, m5, now = _trend_fixture()
    monkeypatch.setenv("SKLZ_MODELS_ENABLED", "a,e,p")
    # with r off, evaluate never touches model_r (no feed → it would block loudly)
    s = MD.evaluate(m15, m5, h1, h1, 0.1, {"symbol": "XAUUSD", "m15": m15})
    assert "order-flow" not in " ".join(s.blockers).lower()
    assert not any("orderflow_feed" in b for b in s.blockers)
    r = MD.call_model("r", m15, m5, h1, h1, 0.1, {"symbol": "XAUUSD", "now_utc": now})
    assert not r.ok and "orderflow_feed.py" in r.blockers[0]


class _IO:
    def __init__(self):
        self.closed = []
    def spec(self, sym):
        return {"lot_min": 0.01, "lot_step": 0.01, "digits": 2, "tick_value": 1.0, "tick_size": 0.01,
                "contract": 100}
    def close(self, pos):
        self.closed.append(pos["ticket"]); return True


def test_entries_lot_cap_per_model(monkeypatch):
    monkeypatch.setenv("SKLZ_MAX_LOTS_BY_SYMBOL", "XAUUSD:0.02")
    monkeypatch.setenv("SKLZ_MAX_LOTS_BY_MODEL", "r:0.04")
    ec = EN.EntryController.__new__(EN.EntryController)
    ec.io = _IO(); ec.log = lambda *a, **k: None
    ec._size_raw = lambda symbol, sl_dist: 0.10          # sizing wants 0.10
    assert ec._size("XAUUSD..", 5.0) == pytest.approx(0.02)                       # symbol cap, as v3.35
    assert ec._size("XAUUSD..", 5.0, model_tag="e") == pytest.approx(0.02)        # other models unchanged
    assert ec._size("XAUUSD..", 5.0, model_tag="r") == pytest.approx(0.04)        # R's own ceiling
    monkeypatch.delenv("SKLZ_MAX_LOTS_BY_MODEL")
    assert ec._size("XAUUSD..", 5.0, model_tag="r") == pytest.approx(0.02)        # unset → falls back


def test_order_comment_marks_r_and_trailing_recognises_it():
    c = EN.order_comment("auto", "strength_extreme+model_r_trend")
    assert c.startswith("sklz-a") and "R_TREN" in c
    assert TR._is_r_ticket(c)
    assert TR._is_r_ticket("sklz-a R_MR")
    assert not TR._is_r_ticket("sklz-a SE+E_TL")
    assert not TR._is_r_ticket("sklz-f R_TREND")       # forced entries are never scratched
    assert not TR._is_r_ticket("")


def test_scratch_closes_only_fading_r_tickets_early(monkeypatch):
    io = _IO()
    now = time.time()
    fp = OF.Footprint(bin_sz=1.0)
    _stream(fp, now - 400, 6, 2020.0, -3.0, buy_share=0.1)       # sellers all the way
    OF.write_state(_state(fp, ts=now))
    pos = {"ticket": 77, "symbol": "XAUUSD..", "comment": "sklz-a SE+R_TREND"}
    # long R ticket, flow against it, first seen now -> scratched
    assert R.scratch_check(io, pos, +1, 2020.0, 2019.5, 5.0, log=lambda *_: None) is True
    assert io.closed == [77]
    # a non-R ticket is never touched
    io2 = _IO()
    assert R.scratch_check(io2, {"ticket": 78, "symbol": "XAUUSD..", "comment": "sklz-a SE+E_TL"},
                           +1, 2020.0, 2019.5, 5.0) is False and io2.closed == []
    # an R ticket already +0.5R is left to the trailing engine
    io3 = _IO()
    assert R.scratch_check(io3, {"ticket": 79, "symbol": "XAUUSD..", "comment": "sklz-a R_MR"},
                           +1, 2020.0, 2022.5, 5.0) is False and io3.closed == []
    # too old to scratch
    io4 = _IO()
    R._first_seen[80] = now - 3600
    assert R.scratch_check(io4, {"ticket": 80, "symbol": "XAUUSD..", "comment": "sklz-a R_MR"},
                           +1, 2020.0, 2019.5, 5.0) is False and io4.closed == []
    # switch off
    monkeypatch.setenv("SKLZ_R_SCRATCH", "0")
    io5 = _IO()
    assert R.scratch_check(io5, pos, +1, 2020.0, 2019.5, 5.0) is False


def test_in_hours_sessions_and_explicit(monkeypatch):
    assert R.in_hours(datetime(2026, 11, 11, 8, 30, tzinfo=timezone.utc))[0]
    assert R.in_hours(datetime(2026, 11, 11, 14, 0, tzinfo=timezone.utc))[0]
    assert not R.in_hours(datetime(2026, 11, 11, 12, 0, tzinfo=timezone.utc))[0]
    monkeypatch.setenv("SKLZ_R_HOURS", "0-24")
    assert R.in_hours(datetime(2026, 11, 11, 12, 0, tzinfo=timezone.utc))[0]


# ───────────────────────── context note ───────────────────────────────
def test_context_note_off_by_default_and_deterministic_when_on(monkeypatch):
    assert CN.note("XAUUSD", 2000.0, None, [], None) is None
    assert CN.apply(None, 1, 50.0) == (50.0, False, "")
    monkeypatch.setenv("SKLZ_LLM_CONTEXT", "score")
    h1 = _bars(20, 0, 60, 2000.0, lambda i: 2000 + i * 2.0)
    pdva = {"val": 1960.0, "poc": 1970.0, "vah": 1980.0}
    st = {"bars": [{"d": 1.0, "cvd": 5.0, "big_buy": 1, "big_sell": 0}] * 12, "mt5": {"basis_pct": 0.1, "corr60": 0.9}}
    ctx = CN.note("XAUUSD", 2038.0, pdva, h1, st, now=1000.0)
    assert ctx and ctx["lean"] == 1 and ctx["source"] == "rules"
    sc, veto, txt = CN.apply(ctx, +1, 50.0)
    assert sc == 58.0 and not veto and txt.startswith("[ctx]")
    sc, veto, _ = CN.apply(ctx, -1, 50.0)
    assert sc == 42.0 and not veto
    # cached for SKLZ_LLM_EVERY_MIN
    assert CN.note("XAUUSD", 1900.0, pdva, h1, st, now=1100.0) is ctx
    # gate mode vetoes only a confident opposite read
    monkeypatch.setenv("SKLZ_LLM_CONTEXT", "gate")
    assert CN.apply({"lean": -1, "confidence": 0.9, "note": "x"}, +1, 50.0)[1] is True
    assert CN.apply({"lean": -1, "confidence": 0.3, "note": "x"}, +1, 50.0)[1] is False
