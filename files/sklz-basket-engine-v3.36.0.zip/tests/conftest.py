"""Keep the test runs out of the real journal: every LearningRunner built
under pytest writes to a throwaway file (v3.35.1)."""
import os
import tempfile

import pytest


@pytest.fixture(autouse=True)
def _isolated_journal(monkeypatch, tmp_path):
    monkeypatch.setenv("SKLZ_JOURNAL_PATH", str(tmp_path / "journal.jsonl"))
    yield
