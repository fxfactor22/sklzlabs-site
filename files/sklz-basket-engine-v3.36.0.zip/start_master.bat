@echo off
title SKLZ MASTER - Upcomers PROP 1444538 ($50k) - v3.36.0
cd /d C:\Users\Administrator
set SKLZ_MT5_PATH=C:\Program Files\MetaTrader 5 IC Markets Global\terminal64.exe
set SKLZ_EXPECT_LOGIN=1444538
set SKLZ_EXPECT_SERVER=Upcomers-Server
set SKLZ_BOT_NAME=SKLZ Master
set SKLZ_ALLOW_LIVE=I_ACCEPT_THE_RISK
set SKLZ_API_URL=https://api.sklzlabs.com
set SKLZ_BOT_KEY=
set SIGNAL_WEBHOOK_KEY=
set SKLZ_PUBLISH_SIGNALS=1
set SKLZ_INST_MIN_SCORE=75

REM ================== THE ENTRY RULE (v3.34.0, eased in v3.35.2) ==============
REM Every auto entry waits for: M5 BODY close beyond the line -> retest of the
REM line -> confirmation candle -> entry within SKLZ_NO_CHASE_ATR of the line.
REM SKLZ_CONFIRM_LEVEL: strict = engulfing (3.34)  normal = any M5 close in
REM direction after the retest  ema = 9/21 EMA cross in direction (13 Oct video)
REM 0 = off. p_open (Judas swing) is exempt by design; remove it to gate it too.
set SKLZ_ENTRY_CONFIRM=1
set SKLZ_CONFIRM_LEVEL=normal
set SKLZ_CONFIRM_EMA_FAST=9
set SKLZ_CONFIRM_EMA_SLOW=21
set SKLZ_NO_CHASE_ATR=2.0
set SKLZ_ARM_MINUTES=180
set SKLZ_ENTRY_CONFIRM_EXEMPT=p_open
REM Quality bars for model-led setups (scanner-led keep 60 / 80)
set SKLZ_SIGNAL_MIN_SCORE_MODEL=45
set SKLZ_INST_MIN_SCORE_MODEL=70
REM v3.35.2: on a model-led setup only MEASURED order flow the other way vetoes;
REM "price on a high-volume node" / "into an HTF block" go to the score. 1 = old behaviour.
set SKLZ_INST_MODEL_HARD_VETO=0

REM ================== models (v3.33 + v3.34) ==================================
REM o = 09:30 straddle (US30)  p = session-range sweep reversal  q = TOTT band flip
set SKLZ_MODELS_ENABLED=a,b,c,d,e,f,g,x,h,j,k,l,m,n,o,p,q

REM Variants run as their own report tags so the numbers can rank them:
REM   A: model_a / _va / _tl             B: model_b / model_b_base
REM   C: model_c / model_c_ob            E: model_e / _va / _pd / _ss / _trc / _tl / _xag
REM   F: model_f / model_f_trend         M: model_m / _orb / _lon / _pre8 / _asia / _aorb
REM   P: model_p / _7 / _ldn / _asia / _open
set SKLZ_A_LEVELS=both
REM v3.35 trendlines (A break-retest after momentum loss, E bounce): best-fit
REM line with >= SKLZ_TL_TOUCHES touches, zone = SKLZ_TL_TOL_ATR x ATR
set SKLZ_TL_TOUCHES=3
set SKLZ_TL_TOL_ATR=0.3
set SKLZ_TL_NEED_FAIL=1
REM C: 1 = a reversal break also needs a failed HH/LL first (video #5). Off for now.
set SKLZ_C_MSB_NEED_FAIL=0
set SKLZ_B_ZONE=both
set SKLZ_C_TRIGGER=either
set SKLZ_C_SWEEP=1
set SKLZ_C_MSB=1
set SKLZ_E_LEVELS=all
set SKLZ_E_BOUNCE=1
set SKLZ_F_MODE=both
set SKLZ_G_CONFIRM=1
set SKLZ_M_BOX=all
REM v3.35 M_AORB: Asian opening-range fib reversal on gold (Sydney 10:00 M15 candle)
set SKLZ_M_AORB_SYMBOLS=XAUUSD
set SKLZ_M_AORB_OPEN_LOCAL=10
set SKLZ_M_AORB_WINDOW_H=2
set SKLZ_M_AORB_MIN_RR=2.2
set SKLZ_M_ORB_BIAS=1
set SKLZ_M_ORB_NEED_BOS=1
set SKLZ_M_ORB_TARGET=liquidity
set SKLZ_P_RANGE_HOURS_NY=7,8
set SKLZ_P_SESSIONS=ny,london,asia
set SKLZ_P_OPEN=1
set SKLZ_Q_EMA=200

REM Partials: close half at +1R and move the stop to break-even (CallistoFX).
REM v3.35 SKLZ_PARTIAL_AT=target1 takes the half at the first M15 S/R the
REM entry recorded instead (ORB-15 clip); r = the +1R rule.
set SKLZ_PARTIAL_R=1.0
set SKLZ_PARTIAL_PCT=50
set SKLZ_PARTIAL_AT=target1
REM v3.35 runner: 6 straight M5 closes in direction while a TP is open ->
REM drop the TP, structure trailing manages the runner. 0 = off.
set SKLZ_RUNNER_EXTEND=1
set SKLZ_RUNNER_BARS=6

REM Model O: US30 straddle at the 09:30 NY candle, 10 pts SL (floor 3x spread), 3:1
set SKLZ_O_SYMBOLS=US30
set SKLZ_O_SL_PTS=10
set SKLZ_O_RR=3

REM Structural targets: model entries carry their own stop and target to the broker.
REM A target must pay at least this many R or the model stands aside.
set SKLZ_MODEL_SL=1
set SKLZ_MODEL_TP=1
set SKLZ_MIN_TARGET_RR=1.5
REM v3.35 targets: skip PDH/PDL/session levels already hit today; prefer a
REM 4H/H1 level held >= 3 times within 4R (partial at the nearer swing).
set SKLZ_TARGET_FRESH=1
set SKLZ_TARGET_PREFER_HTF=1
set SKLZ_TARGET_HTF_HOLDS=3
set SKLZ_TARGET_HTF_MAX_R=4

REM Gold vs the dollar index: score first (logs [xmkt] on every gold entry).
REM After two weeks of lines, switch to gate if the split shows it pays.
set SKLZ_XAU_DXY=score

REM ================== v3.35 confluence (score first, gate later) ==============
REM Each verdict adds / removes SKLZ_CONFLUENCE_PTS from the quality score and
REM logs its own line: [rsidiv] [pd] [mo] [smt] [kz]. Switch any to gate once
REM model_report.py shows it pays. off = silent.
set SKLZ_CONFLUENCE_PTS=10
set SKLZ_RSI_DIV=score
set SKLZ_PD_FILTER=score
set SKLZ_PD_MIN_ATR=2.0
set SKLZ_MO_MODE=score
set SKLZ_MO_MAX_ATR=0.5
set SKLZ_KZ_SCORE=10
set SKLZ_KZ_HOURS=7-11,12-16
REM silver leads gold: a sweep model on XAGUSD is remembered 60 min; same-
REM direction gold setups get +10, model E `xag` can trade it outright.
set SKLZ_SMT_PAIRS=XAUUSD:XAGUSD
set SKLZ_SMT_SCORE=10
set SKLZ_XAG_TTL_MIN=60
set SKLZ_XAG_MIN_CORR=0.5
set SKLZ_XAU_FOLLOW_XAG=1

REM ================== prop guard - Upcomers 4%% daily / 7%% total ==============
set SKLZ_PROP_GUARD=1
set SKLZ_PROP_BASELINE=50000
set SKLZ_PROP_SOFT_PCT=1.5
set SKLZ_PROP_HARD_PCT=2.8
REM v3.35 (owner's call, 13 Oct): total soft 4.0 -> 5.0, hard 5.5 -> 6.0 so the
REM engine can keep testing; per-trade risk halved to 0.25%% to pay for it.
REM Firm fail line is 7%%: the hard stop leaves ~$500 of room, not more.
set SKLZ_PROP_TOTAL_SOFT_PCT=5.0
set SKLZ_PROP_TOTAL_HARD_PCT=6.0
set SKLZ_DAY_RESET_UTC_HOUR=21
set SKLZ_PROP_TARGET_PCT=0
set SKLZ_PROP_TARGET_MODE=protect
set SKLZ_PROP_MAX_OPEN=3

REM ================== sizing ==================================================
REM v3.35: SKLZ_RISK_PCT is the per-trade risk (risk-based sizing); before
REM 3.35 it was fixed at 0.5 in code and MAX_RISK_PCT did not touch it.
set SKLZ_RISK_PCT=0.25
set SKLZ_MAX_RISK_PCT=0.25
set SKLZ_MAX_LOTS=0.2
set SKLZ_MAX_LOTS_BY_SYMBOL=XAUUSD:0.08,XAGUSD:0.01,BTCUSD:0.05,US30:0.2,NAS100:0.1,DE40:0.1

REM ================== exits ===================================================
REM r = R-multiples of each trade's own stop (3.32). structure = after the first
REM lock the stop follows the last completed M5 swing instead of a fixed band.
REM Model O is never trailed (SKLZ_TRAIL_SKIP_CODES=O, default).
set SKLZ_TRAIL_MODE=r
set SKLZ_TRAIL_TRIGGER_R=0.8
set SKLZ_TRAIL_DIST_R=0.5

REM Playbook: playbook.json, hot-reloads. 0 = off.
set SKLZ_PLAYBOOK=1

REM Oil killed the last prop account on a weekend gap; EURJPY/NZDUSD never paid.
set SKLZ_BLOCKED_SYMBOLS=EURJPY,NZDUSD,UKOIL,USOIL,XBRUSD,XTIUSD,BRENT,WTI,UKOUSD,USOUSD
REM ============================================================================

REM Model R (v3.36) is OFF here: add ,r to SKLZ_MODELS_ENABLED and
REM p_open,r to SKLZ_ENTRY_CONFIRM_EXEMPT to enable. See model-R-bat-block.txt.

REM ================== MODEL R: order flow on gold (v3.36) =====================
REM Reads orderflow_state.json written by start_orderflow.bat (Binance PAXG/USDT).
REM XAUUSD only, London 07-11 + NY 13-16 UTC. Fails closed: no feed / stale /
REM PAXG off gold -> R stands aside and logs why; every other model unaffected.
set SKLZ_OF_STATE=C:\Users\Administrator\orderflow_state.json
set SKLZ_OF_MAP_TO=XAUUSD
set SKLZ_OF_MAX_AGE_SEC=5
set SKLZ_OF_MAX_BASIS_PCT=0.5
set SKLZ_OF_MIN_CORR=0.6
REM R keeps the stop its model computed (beyond the print) even though the
REM global SKLZ_MODEL_SL=0 sends every other model to the 15-40 pip band.
REM Rejects a setup whose print-stop would be wider than SKLZ_R_SL_MAX_PIPS.
set SKLZ_MODEL_SL_BY_MODEL=r:1
set SKLZ_R_SL_MAX_PIPS=120
REM R's own lot ceiling (replaces the XAUUSD:0.02 cap for R entries only; the
REM SKLZ_MAX_RISK_PCT risk cap still applies on top).
set SKLZ_MAX_LOTS_BY_MODEL=r:0.04
set SKLZ_R_SESSIONS=london,ny
set SKLZ_R_MODES=trend,mr
set SKLZ_R_MAX_LOSSES=3
set SKLZ_R_IMPULSE_ATR=1.5
set SKLZ_R_SCRATCH=1
set SKLZ_R_SCRATCH_BARS=3
REM aggression thresholds (tune from the --report after day 1)
set SKLZ_OF_IMBALANCE=3.0
set SKLZ_OF_STACK=3
set SKLZ_OF_BIGPRINT_X=5
set SKLZ_OF_AGGR_BARS=3
REM LLM context note: off = never called. score = +/-8 to R's quality score
REM every 30 min (needs ANTHROPIC_API_KEY, else a deterministic note). gate = veto.
set SKLZ_LLM_CONTEXT=off
set SKLZ_LLM_EVERY_MIN=30
REM ============================================================================

python learn_main.py --auto
