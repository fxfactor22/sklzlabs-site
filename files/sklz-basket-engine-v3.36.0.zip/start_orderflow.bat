@echo off
title SKLZ ORDER FLOW FEED - Binance PAXG/USDT -> orderflow_state.json (v3.36)
cd /d C:\Users\Administrator
REM The Model R feed. Runs beside start_master.bat in its OWN window and
REM restarts itself. Public Binance spot stream: no API key, no account.
REM The engine only reads orderflow_state.json; if this window is closed the
REM engine keeps trading every other model and R stands aside, saying why.
REM First time: pip install websockets
set SKLZ_OF_SYMBOL=PAXGUSDT
set SKLZ_OF_MAP_TO=XAUUSD
set SKLZ_OF_STATE=C:\Users\Administrator\orderflow_state.json
set SKLZ_OF_BIN=1.0
set SKLZ_OF_MT5=1
set SKLZ_OF_DEPTH=0
set SKLZ_DAY_RESET_UTC_HOUR=21
REM Day 1 (recommended): add --record paxg_day1.jsonl to the line below, then
REM   python tools\orderflow_feed.py --report paxg_day1.jsonl
REM shows basis / correlation per session / how often each trigger fires.
:loop
echo [%date% %time%] starting order-flow feed...
python tools\orderflow_feed.py
echo [%date% %time%] feed exited. Restarting in 10s (Ctrl+C to stop)...
timeout /t 10 /nobreak >nul
goto loop
