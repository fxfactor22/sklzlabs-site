"""SKLZ — check the ClusterDelta bridge.

Run this on the VPS from the folder where learn_main.py lives:

    python check_bridge.py

It answers one question: is real ClusterDelta delta reaching the bot, or is
it falling back to tick inference? No guessing from log lines.
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main() -> None:
    print("SKLZ bridge check")
    print("=" * 58)

    # 1. can we find the terminal's Files folder?
    try:
        import MetaTrader5 as mt5
    except ImportError:
        print("FAIL  MetaTrader5 package not installed in this Python.")
        return

    if not mt5.initialize():
        print("FAIL  Could not connect to MT5. Is the terminal running?")
        return

    info = mt5.terminal_info()
    files_dir = os.path.join(getattr(info, "data_path", ""), "MQL5", "Files")
    print(f"terminal files: {files_dir}")
    if not os.path.isdir(files_dir):
        print("FAIL  That folder does not exist. Check the terminal is the")
        print("      one the bot is attached to.")
        mt5.shutdown()
        return

    # 2. which bridge files exist?
    found = [f for f in os.listdir(files_dir)
             if f.startswith("sklz_delta_") and f.endswith(".csv")]
    if not found:
        print("FAIL  No sklz_delta_*.csv files.")
        print("      The bridge EA is not writing. Check the Experts tab in")
        print("      MT5 for its startup message.")
        mt5.shutdown()
        return

    print(f"bridge files:   {len(found)}")
    print()

    # 3. is each one fresh, and does it contain real numbers?
    import csv
    ok_count = 0
    for name in sorted(found):
        path = os.path.join(files_dir, name)
        age = time.time() - os.path.getmtime(path)
        symbol = name[len("sklz_delta_"):-4]

        try:
            with open(path, newline="", encoding="ascii", errors="ignore") as f:
                rows = list(csv.DictReader(f))
        except Exception as exc:
            print(f"  {symbol:14} FAIL  cannot read: {exc}")
            continue

        if not rows:
            print(f"  {symbol:14} FAIL  file is empty")
            continue

        nonzero = 0
        buy = sell = 0.0
        for r in rows:
            try:
                a = float(r.get("ask_volume") or 0)
                b = float(r.get("bid_volume") or 0)
            except (TypeError, ValueError):
                continue
            if a or b:
                nonzero += 1
                buy += a
                sell += b

        if age > 180:
            print(f"  {symbol:14} STALE {age/60:.0f} min old — EA stopped?")
            continue
        if nonzero == 0:
            print(f"  {symbol:14} FAIL  {len(rows)} rows but every volume is 0")
            print(f"  {'':14}       -> the buffer indices in the EA are wrong.")
            print(f"  {'':14}       Open DemoVolumes.mq5 and check which")
            print(f"  {'':14}       CopyBuffer index holds ask / bid volume.")
            continue

        delta = buy - sell
        print(f"  {symbol:14} OK    {nonzero} bars, {age:.0f}s old")
        print(f"  {'':14}       ask {buy:,.0f}  bid {sell:,.0f}  "
              f"delta {delta:+,.0f}")
        ok_count += 1

    print()

    # 4. does the bot's own reader agree?
    try:
        from basket_engine.mt5io import BasketIO
        from basket_engine.learn import orderflow as OF
        io = BasketIO.__new__(BasketIO)
        io.mt5 = mt5
        io._sym_cache = {}
        io._sym_fill = {}
        for name in sorted(found)[:3]:
            symbol = name[len("sklz_delta_"):-4]
            r = OF.read_bridge(symbol, io)
            verdict = "MEASURED" if r.quality == "measured" else "not used"
            print(f"bot reader: {symbol:14} {verdict}  — {r.note}")
    except Exception as exc:
        print(f"bot reader: could not run ({type(exc).__name__}: {exc})")

    print()
    print("=" * 58)
    if ok_count:
        print(f"{ok_count} symbol(s) supplying real ClusterDelta volumes.")
        print("Those will score on MEASURED delta. Everything else in your")
        print("scan list still uses tick inference, which is fine but less")
        print("precise — attach the EA to more charts to widen coverage.")
    else:
        print("No symbol is supplying usable data yet. The bot will keep")
        print("working on tick-inferred delta; it just will not benefit")
        print("from ClusterDelta until the above is resolved.")

    mt5.shutdown()


if __name__ == "__main__":
    main()
